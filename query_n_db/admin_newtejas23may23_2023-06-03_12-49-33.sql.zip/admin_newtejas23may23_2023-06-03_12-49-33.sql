-- MySQL dump 10.14  Distrib 5.5.68-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: admin_newtejas23may23
-- ------------------------------------------------------
-- Server version	5.5.68-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `anxious_for_issue`
--

DROP TABLE IF EXISTS `anxious_for_issue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `anxious_for_issue` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `case_id` int(11) DEFAULT NULL,
  `case_number` varchar(255) DEFAULT NULL,
  `wife_name` varchar(255) DEFAULT NULL,
  `wife_age` varchar(50) DEFAULT NULL,
  `husband_name` varchar(255) DEFAULT NULL,
  `husband_age` varchar(50) DEFAULT NULL,
  `married_since` varchar(255) DEFAULT NULL,
  `menstrual_history` text,
  `lmp` text,
  `obstetric_history` text,
  `other_medical_surgical_illness` text,
  `other_art_procedure_past` text,
  `hsg` text,
  `laproscopy` text,
  `hsf` varchar(255) DEFAULT NULL,
  `lh` varchar(255) DEFAULT NULL,
  `fsh` varchar(255) DEFAULT NULL,
  `tsh` varchar(255) DEFAULT NULL,
  `prolactin` varchar(255) DEFAULT NULL,
  `amh` varchar(255) DEFAULT NULL,
  `folliculometry` text,
  `adviced` text,
  `complaints` text,
  `lab_investigation` text,
  `pulse` varchar(50) DEFAULT NULL,
  `BP1` varchar(20) DEFAULT NULL,
  `BP2` varchar(20) DEFAULT NULL,
  `temp` varchar(30) DEFAULT NULL,
  `rs` varchar(50) DEFAULT NULL,
  `cvs` varchar(50) DEFAULT NULL,
  `cns` varchar(50) DEFAULT NULL,
  `P_A` varchar(100) DEFAULT NULL,
  `L_E` varchar(200) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `anxious_for_issue`
--

LOCK TABLES `anxious_for_issue` WRITE;
/*!40000 ALTER TABLE `anxious_for_issue` DISABLE KEYS */;
/*!40000 ALTER TABLE `anxious_for_issue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `appointment_stop`
--

DROP TABLE IF EXISTS `appointment_stop`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `appointment_stop` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `stop_level` int(11) NOT NULL COMMENT '[''1''=>''Date'', ''2''=>''Doctor'',''3''=>''Time Slot'']',
  `date` date DEFAULT NULL,
  `DoctorId` int(11) DEFAULT NULL,
  `TimeSlotId` int(11) DEFAULT NULL,
  `description` text,
  `created_dt` datetime DEFAULT NULL,
  `updated_dt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `appointment_stop`
--

LOCK TABLES `appointment_stop` WRITE;
/*!40000 ALTER TABLE `appointment_stop` DISABLE KEYS */;
/*!40000 ALTER TABLE `appointment_stop` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `appointments`
--

DROP TABLE IF EXISTS `appointments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `appointments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `doctor_id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mobile_no` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `appointment_subject` text COLLATE utf8mb4_unicode_ci,
  `appointment_dt` text COLLATE utf8mb4_unicode_ci,
  `existing_patient` tinyint(1) NOT NULL DEFAULT '0' COMMENT '1: true, 0: false',
  `tokenNumber` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `morningEvening` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `appointment_timeslot` int(11) DEFAULT NULL,
  `isAccepted` tinyint(1) DEFAULT NULL,
  `AcceptDenyComment` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  `isadminstop` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=168 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `appointments`
--

LOCK TABLES `appointments` WRITE;
/*!40000 ALTER TABLE `appointments` DISABLE KEYS */;
/*!40000 ALTER TABLE `appointments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `back_record_tbl`
--

DROP TABLE IF EXISTS `back_record_tbl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `back_record_tbl` (
  `id` bigint(11) NOT NULL AUTO_INCREMENT,
  `recorddata` text NOT NULL,
  `case_id` bigint(20) NOT NULL,
  `rec_date` varchar(100) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `back_record_tbl`
--

LOCK TABLES `back_record_tbl` WRITE;
/*!40000 ALTER TABLE `back_record_tbl` DISABLE KEYS */;
/*!40000 ALTER TABLE `back_record_tbl` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bill_details`
--

DROP TABLE IF EXISTS `bill_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bill_details` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `case_number` text NOT NULL,
  `department` text,
  `bill_no` text,
  `bill_item` text,
  `bill_Amount` decimal(10,2) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `case_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=177 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bill_details`
--

LOCK TABLES `bill_details` WRITE;
/*!40000 ALTER TABLE `bill_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `bill_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blnc_test`
--

DROP TABLE IF EXISTS `blnc_test`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blnc_test` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `case_id` text NOT NULL,
  `case_number` text NOT NULL,
  `blncetestname` text NOT NULL,
  `sts` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blnc_test`
--

LOCK TABLES `blnc_test` WRITE;
/*!40000 ALTER TABLE `blnc_test` DISABLE KEYS */;
/*!40000 ALTER TABLE `blnc_test` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blood_investigation_titles`
--

DROP TABLE IF EXISTS `blood_investigation_titles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blood_investigation_titles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `blood_title` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blood_investigation_titles`
--

LOCK TABLES `blood_investigation_titles` WRITE;
/*!40000 ALTER TABLE `blood_investigation_titles` DISABLE KEYS */;
/*!40000 ALTER TABLE `blood_investigation_titles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blood_investigations`
--

DROP TABLE IF EXISTS `blood_investigations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blood_investigations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `case_id` varchar(255) DEFAULT NULL,
  `form_type` varchar(255) DEFAULT NULL,
  `test_type` varchar(255) DEFAULT NULL,
  `value` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blood_investigations`
--

LOCK TABLES `blood_investigations` WRITE;
/*!40000 ALTER TABLE `blood_investigations` DISABLE KEYS */;
/*!40000 ALTER TABLE `blood_investigations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bulk_sms`
--

DROP TABLE IF EXISTS `bulk_sms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bulk_sms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_name` text,
  `mobile_numbers` text,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bulk_sms`
--

LOCK TABLES `bulk_sms` WRITE;
/*!40000 ALTER TABLE `bulk_sms` DISABLE KEYS */;
/*!40000 ALTER TABLE `bulk_sms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `case_master`
--

DROP TABLE IF EXISTS `case_master`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `case_master` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `patient_type` enum('opd','ipd') DEFAULT 'opd',
  `patient_priority` varchar(255) DEFAULT NULL,
  `is_opd` enum('0','1') NOT NULL DEFAULT '1',
  `is_ipd` enum('0','1') NOT NULL DEFAULT '0',
  `patient_name` varchar(500) DEFAULT NULL,
  `patient_pic` varchar(255) DEFAULT NULL,
  `patient_age` int(11) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `pan` varchar(255) DEFAULT NULL,
  `adhar_number` varchar(255) DEFAULT NULL,
  `alternate_number` varchar(255) DEFAULT NULL,
  `patient_address` varchar(500) DEFAULT NULL,
  `patient_emailId` varchar(100) DEFAULT NULL,
  `patient_mobile` varchar(45) DEFAULT NULL,
  `male_female` varchar(45) DEFAULT NULL,
  `doctor_id` int(11) DEFAULT NULL,
  `complaint` text,
  `diagnosis` text,
  `infection` varchar(255) DEFAULT NULL,
  `miscellaneous_history` varchar(255) DEFAULT NULL,
  `patient_weight` text,
  `patient_height` text,
  `treatment` text,
  `ReportfilePath` text,
  `BeforeImagePath` text,
  `AfterImagePath` text,
  `diagnosis_filePath` text,
  `FollowUpDate` text,
  `FollowUpTimeSlot` text,
  `FollowUpDoctor_Id` int(11) DEFAULT NULL,
  `case_number` text,
  `uhid_no` text,
  `blood_pressure` varchar(200) DEFAULT NULL,
  `referedby` varchar(1000) DEFAULT NULL,
  `billAmount` text,
  `sub_total` varchar(255) DEFAULT NULL,
  `bill_discount` varchar(255) DEFAULT NULL,
  `bill_number` varchar(255) DEFAULT NULL,
  `bill_date` date DEFAULT NULL,
  `paidAmount` text,
  `bill_created_by` int(11) DEFAULT NULL,
  `tax_percentage` decimal(10,2) DEFAULT '0.00',
  `visit_time` text,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `is_deleted` bit(1) DEFAULT b'0',
  `payment_mode` varchar(100) NOT NULL,
  `pdfname` text NOT NULL,
  `admission_date_time` text NOT NULL,
  `surgery_complete_date_time` datetime DEFAULT NULL,
  `discharge_date_time` text NOT NULL,
  `surgery_date_time` text NOT NULL,
  `reporting_date_time` varchar(255) DEFAULT NULL,
  `posted_for_doctor` int(11) DEFAULT NULL,
  `Surgeon` text NOT NULL,
  `final_diagnosis` text NOT NULL,
  `discharge_sts` text NOT NULL,
  `IPD_no` text NOT NULL,
  `classes` text NOT NULL,
  `elective_emergency` text,
  `admission_reason` text,
  `case_type` varchar(255) DEFAULT NULL,
  `case_appointment_time` varchar(255) DEFAULT NULL,
  `discharge_history` longtext,
  `created_by` int(11) DEFAULT NULL,
  `casehistory_followup_notes` longtext,
  `mr_mrs_ms` varchar(255) DEFAULT NULL,
  `middle_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `area` varchar(255) DEFAULT NULL,
  `is_followup` enum('0','1') DEFAULT '0',
  `city` varchar(255) DEFAULT NULL,
  `district` varchar(255) DEFAULT NULL,
  `accompanied_by` varchar(255) DEFAULT NULL,
  `occupation` varchar(255) DEFAULT NULL,
  `daily_travel_time` varchar(255) DEFAULT NULL,
  `screen_time` varchar(255) DEFAULT NULL,
  `ivf_form` varchar(255) DEFAULT NULL,
  `registration_year` varchar(255) DEFAULT NULL,
  `uhid_suggested` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=142 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `case_master`
--

LOCK TABLES `case_master` WRITE;
/*!40000 ALTER TABLE `case_master` DISABLE KEYS */;
INSERT INTO `case_master` VALUES (136,'opd',NULL,'1','0','Pradeep',NULL,51,'1970-01-01',NULL,NULL,NULL,NULL,NULL,'7498834810','Male',149,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'p_00001443','SH/0001/2023',NULL,'Self',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,'13:49','2023-05-13 13:52:24','2023-05-13 13:52:24','\0','','','',NULL,'','',NULL,NULL,'','','','','',NULL,NULL,'walkin','',NULL,14,NULL,NULL,NULL,'Divekar',NULL,NULL,'Badlapur','Thane',NULL,NULL,NULL,NULL,NULL,'2023','SH/0001/2023'),(137,'opd',NULL,'1','0','Gulab',NULL,75,'1970-01-01',NULL,NULL,NULL,NULL,NULL,'9920272477','Female',149,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'p_00001444','SH/0002/2023',NULL,'Self',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,'11:59','2023-05-15 12:02:28','2023-05-15 12:02:28','\0','','','',NULL,'','',NULL,NULL,'','','','','',NULL,NULL,'walkin','',NULL,14,NULL,NULL,NULL,'Devrukar',NULL,NULL,'Badlapur','Thane',NULL,NULL,NULL,NULL,NULL,'2023','SH/0002/2023'),(138,'opd','Regular','1','0','Raj',NULL,30,'1970-01-01',NULL,NULL,NULL,'54bbbx',NULL,'8788778571','Male',149,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'p_00001445','SH/0004/2023',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,'21:30','2023-05-24 21:30:57','2023-05-24 21:30:57','\0','','','',NULL,'','',NULL,NULL,'','','','','',NULL,NULL,'walkin','',NULL,2,NULL,NULL,'R','Rane','vcxv',NULL,'cxvxc','cxv',NULL,NULL,NULL,NULL,NULL,'2023','SH/0004/2023'),(139,'opd','Regular','1','0','s',NULL,30,'1970-01-01',NULL,NULL,NULL,'sd',NULL,'8788778571','Male',149,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'p_00001446','SH/0005/2023',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,'21:30','2023-05-24 21:31:29','2023-05-24 21:31:29','\0','','','',NULL,'','',NULL,NULL,'','','','','',NULL,NULL,'walkin','',NULL,2,NULL,NULL,'s','s','sd',NULL,'ds','sd',NULL,NULL,NULL,NULL,NULL,'2023','SH/0005/2023'),(140,'opd','Regular','1','0','Raj',NULL,30,'1970-01-01',NULL,NULL,NULL,'54bbbx',NULL,'8788778571','Male',149,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'p_00001445','SH/0004/2023',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,'20:17','2023-05-27 20:20:00','2023-05-27 20:20:00','\0','','','',NULL,'','',NULL,NULL,'','','','','',NULL,NULL,'walkin','',NULL,2,NULL,NULL,'R','Rane','vcxv',NULL,'cxvxc','cxv',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(141,'opd','Regular','1','0','Raj',NULL,30,'1970-01-01',NULL,NULL,NULL,'54bbbx',NULL,'8788778571','Male',149,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'p_00001445','SH/0004/2023',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,'12:52','2023-05-29 12:53:08','2023-05-29 12:53:08','\0','','','',NULL,'','',NULL,NULL,'','','','','',NULL,NULL,'walkin','',NULL,2,NULL,NULL,'R','Rane','vcxv',NULL,'cxvxc','cxv',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `case_master` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `case_master_operation_details`
--

DROP TABLE IF EXISTS `case_master_operation_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `case_master_operation_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `case_id` int(11) DEFAULT NULL,
  `field_name` text,
  `field_value` text,
  `field_value_os` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `case_master_operation_details`
--

LOCK TABLES `case_master_operation_details` WRITE;
/*!40000 ALTER TABLE `case_master_operation_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `case_master_operation_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `case_number_generators`
--

DROP TABLE IF EXISTS `case_number_generators`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `case_number_generators` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `case_number` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1447 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `case_number_generators`
--

LOCK TABLES `case_number_generators` WRITE;
/*!40000 ALTER TABLE `case_number_generators` DISABLE KEYS */;
INSERT INTO `case_number_generators` VALUES (1443,'p_00001443'),(1444,'p_00001444'),(1445,'p_00001445'),(1446,'p_00001446');
/*!40000 ALTER TABLE `case_number_generators` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `certificate`
--

DROP TABLE IF EXISTS `certificate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `certificate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `case_id` varchar(255) DEFAULT NULL,
  `diagnosis` longtext,
  `show_is_opd_ipd` enum('0','1') NOT NULL DEFAULT '0',
  `is_opd_ipd` varchar(255) DEFAULT NULL,
  `show_opd` enum('0','1') NOT NULL DEFAULT '0',
  `opd_from` date DEFAULT NULL,
  `opd_to` date DEFAULT NULL,
  `show_ipd` enum('0','1') DEFAULT '0',
  `ipd_on` date DEFAULT NULL,
  `discharge_on` date DEFAULT NULL,
  `show_operated` enum('0','1') NOT NULL DEFAULT '0',
  `operated_for` longtext,
  `operated_date` date DEFAULT NULL,
  `show_advised` enum('0','1') NOT NULL DEFAULT '0',
  `rest_from` date DEFAULT NULL,
  `rest_days` int(11) DEFAULT NULL,
  `show_further_advised` enum('0','1') NOT NULL DEFAULT '0',
  `further_rest_from` date DEFAULT NULL,
  `further_rest_days` int(11) DEFAULT NULL,
  `show_resume_work` enum('0','1') NOT NULL DEFAULT '0',
  `is_nominal_or_light_work` varchar(255) DEFAULT NULL,
  `nominal_or_light_work_from` date DEFAULT NULL,
  `show_identification_mark` enum('0','1') NOT NULL DEFAULT '0',
  `identification_mark` longtext,
  `create_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `certificate`
--

LOCK TABLES `certificate` WRITE;
/*!40000 ALTER TABLE `certificate` DISABLE KEYS */;
/*!40000 ALTER TABLE `certificate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `covid_consent_form`
--

DROP TABLE IF EXISTS `covid_consent_form`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `covid_consent_form` (
  `id` int(11) NOT NULL,
  `case_id` int(11) DEFAULT NULL,
  `consent_date` date DEFAULT NULL,
  `name_of_attendant` varchar(255) DEFAULT NULL,
  `attendant_signature_date` date DEFAULT NULL,
  `name_of_doctor` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `covid_consent_form`
--

LOCK TABLES `covid_consent_form` WRITE;
/*!40000 ALTER TABLE `covid_consent_form` DISABLE KEYS */;
/*!40000 ALTER TABLE `covid_consent_form` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `daily_order_sheet`
--

DROP TABLE IF EXISTS `daily_order_sheet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `daily_order_sheet` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `registration_id` varchar(255) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` enum('0','1') NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `daily_order_sheet`
--

LOCK TABLES `daily_order_sheet` WRITE;
/*!40000 ALTER TABLE `daily_order_sheet` DISABLE KEYS */;
/*!40000 ALTER TABLE `daily_order_sheet` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `daily_order_sheet_data`
--

DROP TABLE IF EXISTS `daily_order_sheet_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `daily_order_sheet_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `daily_order_sheet_id` int(11) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `clinical_notes` longtext,
  `day` varchar(255) DEFAULT NULL,
  `treatment_adviced` longtext,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `daily_order_sheet_data`
--

LOCK TABLES `daily_order_sheet_data` WRITE;
/*!40000 ALTER TABLE `daily_order_sheet_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `daily_order_sheet_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dentist_bill`
--

DROP TABLE IF EXISTS `dentist_bill`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dentist_bill` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `case_id` bigint(20) DEFAULT NULL,
  `treatmentDone` text,
  `date` text,
  `amountPaid` text,
  `balance` bigint(20) NOT NULL,
  `payment_mode` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dentist_bill`
--

LOCK TABLES `dentist_bill` WRITE;
/*!40000 ALTER TABLE `dentist_bill` DISABLE KEYS */;
/*!40000 ALTER TABLE `dentist_bill` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dentist_form_dropdowns`
--

DROP TABLE IF EXISTS `dentist_form_dropdowns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dentist_form_dropdowns` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `formName` text,
  `fieldName` text,
  `ddText` text,
  `ddValue` text,
  `isdefault` bit(1) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dentist_form_dropdowns`
--

LOCK TABLES `dentist_form_dropdowns` WRITE;
/*!40000 ALTER TABLE `dentist_form_dropdowns` DISABLE KEYS */;
/*!40000 ALTER TABLE `dentist_form_dropdowns` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dentist_pain_in`
--

DROP TABLE IF EXISTS `dentist_pain_in`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dentist_pain_in` (
  `dentist_id` bigint(20) DEFAULT NULL,
  `pain_in_teeth` text,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dentist_pain_in`
--

LOCK TABLES `dentist_pain_in` WRITE;
/*!40000 ALTER TABLE `dentist_pain_in` DISABLE KEYS */;
INSERT INTO `dentist_pain_in` VALUES (1,'10','2018-06-03 10:12:49','2018-06-03 10:12:49'),(1,'11','2018-06-03 10:12:49','2018-06-03 10:12:49'),(1,'12','2018-06-03 10:12:49','2018-06-03 10:12:49'),(1,'22','2018-06-03 10:12:49','2018-06-03 10:12:49'),(1,'23','2018-06-03 10:12:49','2018-06-03 10:12:49'),(1,'24','2018-06-03 10:12:49','2018-06-03 10:12:49'),(1,'10','2018-06-03 10:12:49','2018-06-03 10:12:49'),(1,'11','2018-06-03 10:12:49','2018-06-03 10:12:49'),(1,'12','2018-06-03 10:12:49','2018-06-03 10:12:49'),(1,'22','2018-06-03 10:12:49','2018-06-03 10:12:49'),(1,'23','2018-06-03 10:12:49','2018-06-03 10:12:49'),(1,'24','2018-06-03 10:12:49','2018-06-03 10:12:49'),(1,'10','2018-06-03 10:12:49','2018-06-03 10:12:49'),(1,'11','2018-06-03 10:12:49','2018-06-03 10:12:49'),(1,'12','2018-06-03 10:12:49','2018-06-03 10:12:49'),(1,'22','2018-06-03 10:12:49','2018-06-03 10:12:49'),(1,'23','2018-06-03 10:12:49','2018-06-03 10:12:49'),(1,'24','2018-06-03 10:12:49','2018-06-03 10:12:49'),(0,'10','2020-03-23 06:01:14','2020-03-23 06:01:14'),(0,'11','2020-03-23 06:01:14','2020-03-23 06:01:14'),(0,'12','2020-03-23 06:01:14','2020-03-23 06:01:14'),(0,'22','2020-03-23 06:01:14','2020-03-23 06:01:14'),(0,'23','2020-03-23 06:01:14','2020-03-23 06:01:14'),(0,'24','2020-03-23 06:01:15','2020-03-23 06:01:15'),(3,'8','2020-10-08 09:19:25','2020-10-08 09:19:25'),(3,'9','2020-10-08 09:19:25','2020-10-08 09:19:25'),(3,'10','2020-10-08 09:19:25','2020-10-08 09:19:25'),(3,'11','2020-10-08 09:19:25','2020-10-08 09:19:25'),(3,'12','2020-10-08 09:19:25','2020-10-08 09:19:25'),(3,'22','2020-10-08 09:19:25','2020-10-08 09:19:25'),(3,'23','2020-10-08 09:19:25','2020-10-08 09:19:25'),(3,'24','2020-10-08 09:19:25','2020-10-08 09:19:25'),(3,'13','2020-10-20 10:53:38','2020-10-20 10:53:38'),(3,'14','2020-10-20 10:53:38','2020-10-20 10:53:38'),(7,'6','2022-01-21 09:28:40','2022-01-21 09:28:40'),(7,'21','2022-01-21 12:30:13','2022-01-21 12:30:13'),(11,'21','2022-02-05 05:34:34','2022-02-05 05:34:34'),(11,'27','2022-02-05 05:34:34','2022-02-05 05:34:34'),(12,'3','2022-02-17 16:02:11','2022-02-17 16:02:11'),(12,'5','2022-02-17 16:02:11','2022-02-17 16:02:11'),(13,'6','2022-06-22 06:21:10','2022-06-22 06:21:10'),(13,'7','2022-06-22 06:21:10','2022-06-22 06:21:10'),(13,'8','2022-06-22 06:21:10','2022-06-22 06:21:10'),(13,'9','2022-06-22 06:21:10','2022-06-22 06:21:10'),(13,'27','2022-06-22 06:21:10','2022-06-22 06:21:10'),(14,'14','2022-06-25 08:28:51','2022-06-25 08:28:51'),(14,'15','2022-06-25 08:28:51','2022-06-25 08:28:51'),(15,'3','2022-06-25 17:25:49','2022-06-25 17:25:49'),(15,'5','2022-06-25 17:25:49','2022-06-25 17:25:49'),(15,'6','2022-06-25 17:25:49','2022-06-25 17:25:49'),(15,'7','2022-06-25 17:25:49','2022-06-25 17:25:49'),(15,'8','2022-06-25 17:25:49','2022-06-25 17:25:49'),(15,'9','2022-06-25 17:25:49','2022-06-25 17:25:49'),(15,'10','2022-06-25 17:25:49','2022-06-25 17:25:49'),(15,'11','2022-06-25 17:25:49','2022-06-25 17:25:49'),(15,'12','2022-06-25 17:25:49','2022-06-25 17:25:49'),(15,'13','2022-06-25 17:25:49','2022-06-25 17:25:49'),(15,'14','2022-06-25 17:25:49','2022-06-25 17:25:49'),(15,'15','2022-06-25 17:25:49','2022-06-25 17:25:49'),(15,'21','2022-06-25 17:25:49','2022-06-25 17:25:49'),(15,'22','2022-06-25 17:25:49','2022-06-25 17:25:49'),(15,'23','2022-06-25 17:25:49','2022-06-25 17:25:49'),(15,'24','2022-06-25 17:25:49','2022-06-25 17:25:49'),(15,'27','2022-06-25 17:25:49','2022-06-25 17:25:49');
/*!40000 ALTER TABLE `dentist_pain_in` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dentists`
--

DROP TABLE IF EXISTS `dentists`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dentists` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `case_id` bigint(20) DEFAULT NULL,
  `oral_examination` text,
  `advised_treatment_1` text,
  `advised_treatment_2` text,
  `advised_treatment_3` text,
  `advised_treatment_4` text,
  `advised_treatment_5` text,
  `is_diabetes` text,
  `is_bp` text,
  `is_haemophiles` text,
  `any_other_disease` text,
  `FollowUpDate` text NOT NULL,
  `FollowUpTimeSlot` text NOT NULL,
  `FollowUpDoctor_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dentists`
--

LOCK TABLES `dentists` WRITE;
/*!40000 ALTER TABLE `dentists` DISABLE KEYS */;
/*!40000 ALTER TABLE `dentists` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dilations`
--

DROP TABLE IF EXISTS `dilations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dilations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `case_id` varchar(255) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `start_time` varchar(255) DEFAULT NULL,
  `end_time` varchar(255) DEFAULT NULL,
  `duration` varchar(255) DEFAULT NULL,
  `is_completed` enum('0','1') NOT NULL DEFAULT '0',
  `is_acknowledged` enum('0','1') NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dilations`
--

LOCK TABLES `dilations` WRITE;
/*!40000 ALTER TABLE `dilations` DISABLE KEYS */;
/*!40000 ALTER TABLE `dilations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `discharge`
--

DROP TABLE IF EXISTS `discharge`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `discharge` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `case_id` bigint(20) NOT NULL,
  `case_number` text,
  `IPD_no` text,
  `address` text,
  `admission_date_time` text,
  `discharge_date_time` text,
  `surgery_date_time` text,
  `systemic_diseases` text,
  `general_condition` text,
  `anesthesia_procedure` text,
  `procedures` text,
  `name_of_iol` text,
  `post_operative` text,
  `advice` text,
  `review` text,
  `surgeon_name` text,
  `diagnosis` text,
  `surgery` text,
  `brief_history` text,
  `cataract_thru` text,
  `diminished_vision_in` text,
  `re_dv` text,
  `lf_dv` text,
  `re_iop` text,
  `lf_iop` text,
  `re_io` text,
  `lf_io` text,
  `bsf` text,
  `bspp` text,
  `hb` text,
  `cbc` text,
  `esr` text,
  `hiv` text,
  `hbsag` text,
  `urinal_analysis` text,
  `ecg` text,
  `medical_fitness` text,
  `treatment_advised` text,
  `investigation` text,
  `followup` text,
  `dischargeimg` text,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `discharge_history` longtext,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `discharge`
--

LOCK TABLES `discharge` WRITE;
/*!40000 ALTER TABLE `discharge` DISABLE KEYS */;
/*!40000 ALTER TABLE `discharge` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `discharge2`
--

DROP TABLE IF EXISTS `discharge2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `discharge2` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `case_id` bigint(20) NOT NULL,
  `case_number` text,
  `IPD_no` text,
  `address` text,
  `admission_date_time` text,
  `discharge_date_time` text,
  `surgery_date_time` text,
  `diagnosis` text,
  `systemic_diseases` text,
  `general_condition` text,
  `anesthesia_procedure` text,
  `procedures` text,
  `name_of_iol` text,
  `post_operative` text,
  `advice` text,
  `review` text,
  `surgeon_name` text,
  `surgery` text,
  `brief_history` text,
  `cataract_thru` text,
  `diminished_vision_in` text,
  `re_dv` text,
  `lf_dv` text,
  `re_iop` text,
  `lf_iop` text,
  `re_io` text,
  `lf_io` text,
  `bsf` text,
  `bspp` text,
  `hb` text,
  `cbc` text,
  `esr` text,
  `hiv` text,
  `hbsag` text,
  `urinal_analysis` text,
  `ecg` text,
  `medical_fitness` text,
  `treatment_advised` text,
  `investigation` text,
  `followup` text,
  `dischargeimg` text NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `discharge2`
--

LOCK TABLES `discharge2` WRITE;
/*!40000 ALTER TABLE `discharge2` DISABLE KEYS */;
/*!40000 ALTER TABLE `discharge2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `discharge_appointments`
--

DROP TABLE IF EXISTS `discharge_appointments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `discharge_appointments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `case_id` int(11) DEFAULT NULL,
  `doctor_id` int(11) DEFAULT NULL,
  `date` varchar(200) DEFAULT NULL,
  `time` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `discharge_appointments`
--

LOCK TABLES `discharge_appointments` WRITE;
/*!40000 ALTER TABLE `discharge_appointments` DISABLE KEYS */;
/*!40000 ALTER TABLE `discharge_appointments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `doctor_charges`
--

DROP TABLE IF EXISTS `doctor_charges`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `doctor_charges` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `userid` int(11) NOT NULL,
  `doctor_id` int(11) NOT NULL,
  `procedure_id` int(11) NOT NULL,
  `fees` double NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `doctor_charges`
--

LOCK TABLES `doctor_charges` WRITE;
/*!40000 ALTER TABLE `doctor_charges` DISABLE KEYS */;
/*!40000 ALTER TABLE `doctor_charges` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `doctor_fees`
--

DROP TABLE IF EXISTS `doctor_fees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `doctor_fees` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `doctor_id` int(11) DEFAULT NULL,
  `fees_details` varchar(255) DEFAULT NULL,
  `fees_amount` varchar(255) DEFAULT NULL,
  `status` enum('0','1') DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=197 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `doctor_fees`
--

LOCK TABLES `doctor_fees` WRITE;
/*!40000 ALTER TABLE `doctor_fees` DISABLE KEYS */;
INSERT INTO `doctor_fees` VALUES (149,147,'Follow-up','400','1','2023-03-28 22:42:36','2023-04-13 04:23:01',2),(150,146,'Follow-up','400','1','2023-03-28 22:50:04','2023-04-12 03:53:45',2),(151,147,'Consalting','500','1','2023-04-05 21:09:33','2023-04-05 21:09:33',2),(152,147,'Sonography','900','1','2023-04-05 21:09:33','2023-04-05 21:09:33',2),(153,147,'Tab. C-hope','350','1','2023-04-05 21:09:33','2023-04-05 21:09:33',2),(154,147,'Pill','2500','1','2023-04-05 21:16:06','2023-04-05 21:16:06',2),(155,146,'Dressing','200','1','2023-04-05 21:19:23','2023-04-05 21:19:23',2),(156,147,'Origen','500','1','2023-04-06 20:19:57','2023-04-06 20:19:57',2),(157,147,'F-study','250','1','2023-04-06 20:19:57','2023-04-06 20:19:57',2),(158,147,'Pcos profile','3200','1','2023-04-11 01:13:33','2023-04-11 01:13:33',2),(159,147,'Ova BD','280','1','2023-04-11 01:13:56','2023-04-11 01:13:56',2),(160,147,'H .P.R',NULL,'1','2023-04-11 01:15:31','2023-04-11 01:15:31',2),(161,147,'Day care','1600','1','2023-04-11 01:15:31','2023-04-11 01:15:31',2),(162,147,'T.T','100','1','2023-04-11 01:17:12','2023-04-11 01:17:12',2),(163,147,'Copper T','1500','1','2023-04-11 01:17:12','2023-04-11 01:17:12',2),(164,147,'UPT','200','1','2023-04-11 01:17:12','2023-04-11 01:17:12',2),(165,147,'F. Study','250','1','2023-04-11 01:17:12','2023-04-11 01:17:12',2),(166,146,'Consulting charges','500','1','2023-04-12 03:53:45','2023-04-12 03:53:45',2),(167,148,'Consulting charges','500','1','2023-04-12 04:44:04','2023-04-12 04:44:04',2),(168,148,'Followup','400','1','2023-04-12 04:44:04','2023-04-12 04:44:04',2),(169,148,'Dressing Small','200','1','2023-04-12 04:44:04','2023-04-12 04:44:04',2),(170,148,'Dressing Big','400','1','2023-04-12 04:44:04','2023-04-12 04:44:04',2),(171,148,'Neb','50','1','2023-04-12 04:44:04','2023-04-12 04:44:04',2),(172,148,'Injection','100','1','2023-04-12 04:44:04','2023-04-12 04:44:04',2),(173,148,'Blood Tests','0','1','2023-04-12 04:44:04','2023-04-12 04:44:04',2),(174,149,'Consulting charges','500','1','2023-04-12 05:30:49','2023-04-12 05:30:49',2),(175,149,'Followup charges','400','1','2023-04-12 05:30:49','2023-04-12 05:30:49',2),(176,149,'Dressing small','200','1','2023-04-12 05:30:49','2023-04-12 05:30:49',2),(177,149,'Dressing Big','400','1','2023-04-12 05:30:49','2023-04-12 05:30:49',2),(178,149,'Blood Test','O','1','2023-04-12 05:30:49','2023-04-12 05:30:49',2),(179,149,'Neb','50','1','2023-04-12 05:30:49','2023-04-12 05:30:49',2),(180,149,'Injection','100','1','2023-04-12 05:30:49','2023-04-12 05:30:49',2),(181,149,'Day care','0','1','2023-04-12 05:30:49','2023-04-12 05:30:49',2),(182,149,'Consulting charges','500','1','2023-04-12 05:30:52','2023-04-12 05:30:52',2),(183,149,'Followup charges','400','1','2023-04-12 05:30:52','2023-04-12 05:30:52',2),(184,149,'Dressing small','200','1','2023-04-12 05:30:52','2023-04-12 05:30:52',2),(185,149,'Dressing Big','400','1','2023-04-12 05:30:52','2023-04-12 05:30:52',2),(186,149,'Blood Test','O','1','2023-04-12 05:30:52','2023-04-12 05:30:52',2),(187,149,'Neb','50','1','2023-04-12 05:30:52','2023-04-12 05:30:52',2),(188,149,'Injection','100','1','2023-04-12 05:30:52','2023-04-12 05:30:52',2),(189,149,'Day care','0','1','2023-04-12 05:30:52','2023-04-12 05:30:52',2),(190,147,'Drolut tab','575','1','2023-04-13 04:23:01','2023-04-13 04:23:01',2),(191,147,'Ultra ca tab','600','1','2023-04-13 04:23:01','2023-04-13 04:23:01',2),(192,147,'Dual marker','2580','1','2023-04-18 00:27:25','2023-04-18 00:27:25',2),(193,147,'Pills','2500','1','2023-04-22 00:46:17','2023-04-22 00:46:17',2),(194,149,'ECG','300','1','2023-04-22 01:26:00','2023-05-13 08:12:29',2),(195,149,'Catheterization','0','1','2023-04-22 01:26:00','2023-04-22 01:26:00',2),(196,147,'Iv iron therphy','1600','1','2023-05-04 07:49:13','2023-05-04 07:49:13',2);
/*!40000 ALTER TABLE `doctor_fees` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `doctor_form_mapping`
--

DROP TABLE IF EXISTS `doctor_form_mapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `doctor_form_mapping` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `formViewName` varchar(500) NOT NULL,
  `displayText` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `doctor_form_mapping`
--

LOCK TABLES `doctor_form_mapping` WRITE;
/*!40000 ALTER TABLE `doctor_form_mapping` DISABLE KEYS */;
INSERT INTO `doctor_form_mapping` VALUES (1,'patientDetails.caseHistory','MD'),(2,'patientDetails.CasHisFemale','Gynecologist'),(3,'case_masters.add','General Practictioner'),(4,'EyeForm.EyeForm','Eye Specialist'),(5,'dentist.add','Dentist'),(6,'skin.addUpdate','Skin'),(7,'ent.index','ENT'),(8,'EyeForm.EyeFormold','EyeFormold'),(9,'EyeForm.UploadCaseForm','Upload Case Paper'),(10,'Psychiatrist.add','Psychiatrist Case Paper'),(11,'anxious_for_Issue.anxious_for_Issue','Anxious for Issue'),(12,'obg.obg','OBG'),(13,'follow.follow','Follow\r\n');
/*!40000 ALTER TABLE `doctor_form_mapping` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `doctorbill`
--

DROP TABLE IF EXISTS `doctorbill`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `doctorbill` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `case_id` bigint(20) NOT NULL,
  `case_number` text NOT NULL,
  `doctor_Id` int(10) DEFAULT NULL,
  `bill_item` text,
  `bill_Amount` decimal(10,2) DEFAULT NULL,
  `billed_date` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `doctorbill`
--

LOCK TABLES `doctorbill` WRITE;
/*!40000 ALTER TABLE `doctorbill` DISABLE KEYS */;
/*!40000 ALTER TABLE `doctorbill` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `doctors`
--

DROP TABLE IF EXISTS `doctors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `doctors` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `doctor_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `isActive` tinyint(1) NOT NULL,
  `doctorDegree` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mobile_no` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `doctorFee` decimal(10,0) DEFAULT NULL,
  `formViewName` text COLLATE utf8mb4_unicode_ci,
  `reg_number` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `img_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=150 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `doctors`
--

LOCK TABLES `doctors` WRITE;
/*!40000 ALTER TABLE `doctors` DISABLE KEYS */;
INSERT INTO `doctors` VALUES (147,'Dr. Manisha Chandurkar',1,'M.D. (Obst. & Gynaec.)','98812 04068','2023-03-28 14:17:48','2023-03-28 14:17:48',NULL,'patientDetails.CasHisFemale','Reg. No. 69263',NULL),(149,'Dr. Jitendra  Chandurkar',1,'M.S. SURGERY','9822376434','2023-04-12 05:01:07','2023-05-29 07:22:41',NULL,'patientDetails.CasHisFemale','62863',NULL);
/*!40000 ALTER TABLE `doctors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `doctorspecialitymapping`
--

DROP TABLE IF EXISTS `doctorspecialitymapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `doctorspecialitymapping` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `doctor_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `speciality_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `doctorspecialitymapping`
--

LOCK TABLES `doctorspecialitymapping` WRITE;
/*!40000 ALTER TABLE `doctorspecialitymapping` DISABLE KEYS */;
INSERT INTO `doctorspecialitymapping` VALUES (1,1,'2017-02-11 10:59:59','2017-02-11 10:59:59',2),(2,2,'2017-02-11 10:59:59','2017-02-11 10:59:59',2),(3,1,'2017-02-11 10:59:59','2017-02-11 10:59:59',1),(4,3,'2017-02-11 11:02:04','2017-02-11 11:02:04',3),(5,4,'2017-02-11 11:02:04','2017-02-11 11:02:04',3),(6,5,'2017-02-11 11:02:04','2017-02-11 11:02:04',3);
/*!40000 ALTER TABLE `doctorspecialitymapping` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dynamic_fields`
--

DROP TABLE IF EXISTS `dynamic_fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dynamic_fields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(200) NOT NULL,
  `last_name` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dynamic_fields`
--

LOCK TABLES `dynamic_fields` WRITE;
/*!40000 ALTER TABLE `dynamic_fields` DISABLE KEYS */;
INSERT INTO `dynamic_fields` VALUES (1,'Seema','Sutar'),(2,'Seema','Sutar'),(3,'Seema','Sutar');
/*!40000 ALTER TABLE `dynamic_fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dynamic_text`
--

DROP TABLE IF EXISTS `dynamic_text`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dynamic_text` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `html_text` text,
  `textType` int(11) DEFAULT NULL,
  `relationshipKey` int(11) DEFAULT NULL,
  `name` text,
  `description` text,
  `meta_title` text,
  `meta_desc` text,
  `meta_key` text,
  `isActive` bit(1) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `image` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=64 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dynamic_text`
--

LOCK TABLES `dynamic_text` WRITE;
/*!40000 ALTER TABLE `dynamic_text` DISABLE KEYS */;
INSERT INTO `dynamic_text` VALUES (1,'&lt;div class=&quot;s-12 m-12 l-4 margin-m-bottom&quot;&gt;&lt;img class=&quot;margin-bottom&quot; src=&quot;https://drvidyashankar.com/storage/uploads/A3AOoWdhQuZCKJp4AwtQ3hDJGBRCm0Q56z7XDMse.jpeg&quot; alt=&quot;&quot; /&gt;\r\n&lt;h2 class=&quot;text-thin&quot;&gt;WELCOME TO OUR SITE !&lt;/h2&gt;\r\n&lt;p&gt;Dr. Vidyashankar&rsquo;s Center for Vision is a Super specialty eye clinic with a vision to provide services for all the subspecialties of Ophthalmology under one roof. Our mission is to serve patients from the entire community irrespective of any discrimination........&lt;/p&gt;\r\n&lt;p&gt;&nbsp;&lt;/p&gt;\r\n&lt;a class=&quot;text-more-info text-primary-hover&quot; href=&quot;https://drvidyashankar.com/pages/Hospital&quot;&gt;Read more&lt;/a&gt;&lt;/div&gt;\r\n&lt;div class=&quot;s-12 m-12 l-4 margin-m-bottom&quot;&gt;&lt;img src=&quot;https://drvidyashankar.com/storage/uploads/3gXUgwvtwmncuOedYuICJBcgb8MmIl588JktXqV7.gif&quot; alt=&quot;&quot; width=&quot;768&quot; height=&quot;450&quot; /&gt;&lt;img class=&quot;margin-bottom&quot; src=&quot;https://drvidyashankar.com/storage/uploads/hShv6kUURMl7twVcGuKAOgxMMX0okjiInLWRUc6U.gif&quot; alt=&quot;&quot; /&gt;\r\n&lt;h2 class=&quot;text-thin&quot;&gt;About Me&lt;/h2&gt;\r\n&lt;p&gt;&lt;strong&gt;Dr. B. Vidyashankar&lt;/strong&gt;&lt;/p&gt;\r\n&lt;p&gt;MBBS, DOMS, DNB, FMRF (SANKARA NETHRALAYA) ,FICO (UK)&nbsp;&lt;a class=&quot;text-more-info text-primary-hover&quot; href=&quot;https://drvidyashankar.com/pages/Dr.%20B.%20Vidyashankar&quot;&gt;Read more&lt;/a&gt;&lt;/p&gt;\r\n&lt;p&gt;&lt;strong&gt;Dr. Hemalatha Vidyashankar&lt;/strong&gt;&lt;/p&gt;\r\n&lt;p&gt;MBBS, DOMS, DNB, FMRF (SANKARA NETHRALAYA)&lt;/p&gt;\r\n&lt;a class=&quot;text-more-info text-primary-hover&quot; href=&quot;https://drvidyashankar.com/pages/Dr.%20Hemalatha%20Vidyashankar&quot;&gt;Read more&lt;/a&gt;&lt;/div&gt;\r\n&lt;div class=&quot;s-12 m-12 l-4 margin-m-bottom&quot;&gt;&lt;img class=&quot;margin-bottom&quot; src=&quot;https://drvidyashankar.com/storage/uploads/65stIQZCz6u8wuqwisS0LAdCodVvqtBykTuaN3BQ.jpeg&quot; alt=&quot;&quot; /&gt;\r\n&lt;h2 class=&quot;text-thin&quot;&gt;OPD&nbsp;HOURS&lt;/h2&gt;\r\n&lt;p&gt;&lt;strong&gt;Dr. Vidyashankar&rsquo;s Center for Vision&lt;/strong&gt;&lt;/p&gt;\r\n&lt;p&gt;OPD Timings : Mon-Sat&nbsp; 10:00&nbsp; - 08:00 PM&nbsp;&lt;/p&gt;\r\n&lt;p&gt;Sunday Only Emergncy&nbsp;&lt;/p&gt;\r\n&lt;p&gt;&nbsp;&lt;/p&gt;\r\n&lt;p&gt;&nbsp;&lt;/p&gt;\r\n&lt;p&gt;&nbsp;&lt;/p&gt;\r\n&lt;a class=&quot;text-more-info text-primary-hover&quot; href=&quot;https://drvidyashankar.com/appointment&quot;&gt;Book Appointment&lt;/a&gt;&lt;/div&gt;',3,1,'111111111111',NULL,NULL,NULL,NULL,'','2017-03-13 08:46:08','2021-11-29 16:02:31',NULL),(2,'&lt;p&gt;vjnvbnmvjvm&lt;/p&gt;\r\n&lt;p&gt;&lt;img src=&quot;../../storage/uploads/xW4eWsftWidW3FiSTQ97OhN20ohPHHiEvzv2740a.jpeg&quot; alt=&quot;&quot; width=&quot;1920&quot; height=&quot;604&quot; /&gt;&lt;/p&gt;',4,1,'Akshay Eye Clinic',NULL,NULL,NULL,NULL,'','2017-03-13 09:10:22','2021-11-29 16:04:15',NULL),(3,'&lt;section class=&quot;section background-dark&quot;&gt;\r\n&lt;div class=&quot;line&quot;&gt;\r\n&lt;div class=&quot;margin&quot;&gt;&lt;!-- Collumn 1 --&gt;\r\n&lt;div class=&quot;s-12 m-12 l-4 margin-m-bottom-2x&quot;&gt;\r\n&lt;h4 class=&quot;text-uppercase text-strong&quot; style=&quot;text-align: left;&quot;&gt;&lt;span style=&quot;color: #ffffff;&quot;&gt;&nbsp;lkjhnlhjkhkhkjhkjhkjhjkhkhkj&lt;/span&gt;&lt;/h4&gt;\r\n&lt;a href=&quot;https://goo.gl/maps/eKJhAjZDAmebgLcF8&quot; target=&quot;_parent&quot;&gt;&lt;img src=&quot;../../storage/uploads/sBlF1pb1TE5SD1zb0BeeR8aExiruxbbQ42Kd8wcv.jpeg&quot; width=&quot;497&quot; height=&quot;324&quot; /&gt;&lt;/a&gt;\r\n&lt;div class=&quot;line&quot;&gt;&nbsp;&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;!-- Collumn 2 --&gt;\r\n&lt;div class=&quot;s-12 m-12 l-4 margin-m-bottom-2x&quot;&gt;\r\n&lt;h4 class=&quot;text-uppercase text-strong&quot;&gt;Contact Us&lt;/h4&gt;\r\n&lt;div class=&quot;line&quot;&gt;\r\n&lt;div class=&quot;s-1 m-1 l-1 text-center&quot;&gt;&nbsp;&lt;/div&gt;\r\n&lt;div class=&quot;s-11 m-11 l-11 margin-bottom-10&quot;&gt;\r\n&lt;p&gt;&lt;strong&gt;Adress:&lt;/strong&gt; &lt;strong&gt;&nbsp;CENTRE FOR VISION&lt;/strong&gt;&lt;/p&gt;\r\n&lt;p&gt;,&nbsp;Maharashtra 400071.&lt;/p&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;div class=&quot;line&quot;&gt;\r\n&lt;div class=&quot;s-1 m-1 l-1 text-center&quot;&gt;&nbsp;&lt;/div&gt;\r\n&lt;div class=&quot;s-11 m-11 l-11 margin-bottom-10&quot;&gt;\r\n&lt;p&gt;&lt;a class=&quot;text-primary-hover&quot; href=&quot;../../&quot;&gt;&lt;strong&gt;E-mail:&lt;/strong&gt;&nbsp;info@&lt;/a&gt;&lt;/p&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;div class=&quot;line&quot;&gt;\r\n&lt;div class=&quot;s-1 m-1 l-1 text-center&quot;&gt;&nbsp;&lt;/div&gt;\r\n&lt;div class=&quot;s-11 m-11 l-11 margin-bottom-10&quot;&gt;\r\n&lt;p&gt;&lt;strong&gt;Phone:&lt;/strong&gt; ; 022&nbsp;&lt;/p&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;div class=&quot;line&quot;&gt;\r\n&lt;div class=&quot;s-1 m-1 l-1 text-center&quot;&gt;&nbsp;&lt;/div&gt;\r\n&lt;div class=&quot;s-11 m-11 l-11 margin-bottom-10&quot;&gt;&nbsp;&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;div class=&quot;line&quot;&gt;&nbsp;&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;!-- Collumn 3 --&gt;\r\n&lt;div class=&quot;s-12 m-12 l-4&quot;&gt;\r\n&lt;h4 class=&quot;text-uppercase text-strong&quot;&gt;OPD HOURS&lt;/h4&gt;\r\n&lt;p&gt;&lt;strong&gt;Center for Vision&lt;/strong&gt;&lt;/p&gt;\r\n&lt;p&gt;OPD Timings : Mon-Sat&nbsp; 10:00&nbsp; - 08:00 PM&nbsp;&lt;/p&gt;\r\n&lt;p&gt;Sunday Only Emergncy&lt;/p&gt;\r\n&lt;form class=&quot;customform text-white&quot;&gt;\r\n&lt;div class=&quot;line&quot;&gt;&nbsp;&lt;/div&gt;\r\n&lt;/form&gt;&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/section&gt;\r\n&lt;hr class=&quot;break margin-top-bottom-0&quot; style=&quot;border-color: rgba(0, 38, 51, 0.80);&quot; /&gt;&lt;!-- Bottom Footer --&gt;\r\n&lt;section class=&quot;padding background-dark&quot;&gt;\r\n&lt;div class=&quot;line&quot;&gt;\r\n&lt;div class=&quot;s-12 l-6&quot;&gt;\r\n&lt;p class=&quot;text-size-12&quot;&gt;Copyright 2019, Design -&nbsp;&lt;/p&gt;\r\n&lt;p class=&quot;text-size-12&quot;&gt;Tejas Infotech 8485079273 / 8788778571&lt;/p&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/section&gt;',5,1,'Contact',NULL,NULL,NULL,NULL,'','2017-03-13 09:10:54','2022-12-19 15:06:34',NULL),(4,'&lt;p&gt;sadf asd as &nbsp;a asdfaad asdfas asdf&nbsp;&lt;/p&gt;\r\n&lt;p&gt;asdf asd&lt;/p&gt;\r\n&lt;p&gt;&nbsp;asdf&nbsp;&lt;/p&gt;\r\n&lt;p&gt;asdf&lt;/p&gt;',1,3,'page 3 menu data',NULL,'','0','0','','2017-03-13 12:12:13','2017-03-13 12:12:23',NULL),(5,'&lt;p&gt;dsf dsfg dsfg asdf asd assdf asd&lt;/p&gt;\r\n&lt;p&gt;asd&nbsp;&lt;/p&gt;\r\n&lt;p&gt;sdf&lt;/p&gt;\r\n&lt;p&gt;&nbsp;&lt;/p&gt;\r\n&lt;p&gt;&nbsp;&lt;/p&gt;\r\n&lt;p&gt;&nbsp;&lt;/p&gt;\r\n&lt;p&gt;dssafasdf asdfas&nbsp;&lt;/p&gt;\r\n&lt;p&gt;&nbsp;&lt;/p&gt;\r\n&lt;p&gt;asdf asdfas df a asdfasdf asdf&lt;/p&gt;',1,1,'Menu One',NULL,'','0','0','','2017-03-13 12:13:06','2017-03-13 12:13:33',NULL),(6,'&lt;p&gt;asdf asdf asdf asd asdf as dfasf&lt;/p&gt;\r\n&lt;p&gt;&nbsp;asdf&nbsp;&lt;/p&gt;\r\n&lt;p&gt;asdf&lt;/p&gt;\r\n&lt;p&gt;a asdf&lt;/p&gt;\r\n&lt;p&gt;&nbsp;asdf&lt;/p&gt;\r\n&lt;p&gt;&nbsp;asdf&lt;/p&gt;',1,5,'level 2 Menu , Menu  id 2','adsf asdf asdf','','0','0','','2017-03-13 17:02:21','2017-03-13 17:02:21',NULL),(7,'&lt;ul&gt;\r\n&lt;li&gt;Dynamic text id 4&lt;/li&gt;\r\n&lt;li&gt;Dynamic text id 4&lt;/li&gt;\r\n&lt;li&gt;Dynamic text id 4&lt;/li&gt;\r\n&lt;li&gt;Dynamic text id 4&lt;/li&gt;\r\n&lt;/ul&gt;',1,4,'Dynamic text id 4','asdfasdf','','0','0','','2018-02-17 12:47:16','2018-02-17 12:47:16',NULL),(8,'&lt;p&gt;We are leading doctors in surgery&nbsp;&lt;/p&gt;',1,2,'About Us','We are leading doctors in surgery','','0','0','','2018-02-17 19:39:55','2018-02-17 19:39:55',NULL),(9,'&lt;p style=&quot;text-align: left;&quot;&gt;Add Address here&lt;/p&gt;',6,1,'Address',NULL,NULL,NULL,NULL,'','2019-03-30 23:19:39','2022-04-19 16:01:15',NULL),(10,'&lt;div class=&quot;s-12 m-6 l-3&quot; style=&quot;color: #000000; font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;&quot;&gt;\r\n&lt;div class=&quot;image-with-hover-overlay image-hover-zoom margin-bottom&quot;&gt;&lt;img src=&quot;../../storage/uploads/Ze91YWCOC5seLJuSsif0hyYDXP2GqBUFAR1RDU8p.jpeg&quot; width=&quot;478&quot; height=&quot;130&quot; /&gt;&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;div class=&quot;s-12 m-12 l-8&quot; style=&quot;color: #000000; font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;&quot;&gt;\r\n&lt;h2 class=&quot;text-theme-colored mt-0&quot; style=&quot;text-align: left;&quot;&gt;&lt;strong&gt;About Dr. B. Vidyashankar&lt;/strong&gt;&lt;/h2&gt;\r\n&lt;p&gt;MBBS, DOMS, DNB, FMRF (SANKARA NETHRALAYA) ,FICO (UK)&lt;/p&gt;\r\n&lt;p&gt;&lt;strong&gt;Eye Specialist &lt;/strong&gt;&lt;/p&gt;\r\n&lt;p style=&quot;text-align: left;&quot;&gt;&nbsp;&lt;/p&gt;\r\n&lt;p&gt;Dr.B Vidyashankar pursued his MBBS from MGM Hospital, Navi Mumbai and his Post graduation from Lokmanya Tilak Medical College, Sion, Mumbai. He completed his long term Fellowship in Oculoplasty, Orbit an Ocular Oncology from&nbsp;Sankara Nethralaya, Chennai. He has an experience of close to 18 years in this field and has performed more than 10,000 surgeries so far.&lt;/p&gt;\r\n&lt;p&gt;&nbsp;&lt;/p&gt;\r\n&lt;p&gt;Oculoplasty deals with problems pertaining to the eyelids, lacrimal system, orbit and aesthetic lid surgery. He has rich experience in Ptosis Surgery (drooping of lids), Management of Orbital fractures, and all Lid surgeries. &nbsp;&lt;/p&gt;\r\n&lt;p&gt;He is very proficient in Facial Aesthetics and cosmetic surgery around the eyes.&lt;/p&gt;\r\n&lt;p&gt;His special interest is in Ocular oncology and management of cancers of the eye, the orbit, the lids and the face.&lt;/p&gt;\r\n&lt;p&gt;â€‹&lt;/p&gt;\r\n&lt;p&gt;He is an invited expert speaker for various international and national ophthalmology conferences and Postgraduate training Programmes. He has several publications in peer reviewed scientific journals and has contributed to chapters in medical text books. He has trained several fellows in Oculoplasty, Orbit an Ocular Oncology under him.&lt;/p&gt;\r\n&lt;/div&gt;',1,21,'Dr. B. Vidyashankar',NULL,'','0','0','','2019-04-22 16:01:55','2019-06-27 18:59:44',NULL),(11,'&lt;div class=&quot;s-12 m-6 l-3&quot; style=&quot;color: #000000; font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;&quot;&gt;\r\n&lt;p&gt;&nbsp;&lt;/p&gt;\r\n&lt;div class=&quot;image-with-hover-overlay image-hover-zoom margin-bottom&quot;&gt;&lt;img src=&quot;../../storage/uploads/zMnuVmJo2I4liVZtszuxG8hG79X9JnNt6gYn05eg.jpeg&quot; width=&quot;478&quot; height=&quot;130&quot; /&gt;&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;div class=&quot;s-12 m-12 l-8&quot; style=&quot;color: #000000; font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;&quot;&gt;\r\n&lt;div id=&quot;comp-jqjmd9c7&quot; class=&quot;txtNew&quot; data-packed=&quot;true&quot;&gt;\r\n&lt;h1 class=&quot;font_0&quot;&gt;&lt;span class=&quot;color_15&quot;&gt;LID SURGERIES&lt;/span&gt;&lt;/h1&gt;\r\n&lt;/div&gt;\r\n&lt;div id=&quot;comp-jqjnl2n8&quot; class=&quot;s_BIwzIGroupSkin&quot;&gt;\r\n&lt;div id=&quot;comp-jqjnl2n8inlineContent&quot; class=&quot;s_BIwzIGroupSkininlineContent&quot;&gt;\r\n&lt;div id=&quot;comp-jqjnl2n8inlineContent-gridWrapper&quot; data-mesh-internal=&quot;true&quot;&gt;\r\n&lt;div id=&quot;comp-jqjnl2n8inlineContent-gridContainer&quot; data-mesh-internal=&quot;true&quot;&gt;\r\n&lt;div id=&quot;comp-jqjmd9cj&quot; class=&quot;txtNew&quot; data-packed=&quot;true&quot;&gt;\r\n&lt;h1 class=&quot;font_0&quot;&gt;A. PTOSIS - DROOPING OF UPPER LIDS&lt;/h1&gt;\r\n&lt;h6 class=&quot;font_8&quot;&gt;&nbsp;&lt;/h6&gt;\r\n&lt;ul class=&quot;font_8&quot;&gt;\r\n&lt;li&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;Ptosis is a condition where there is drooping of the lid, though it is more common in the upper lid but can involve the lower lid too. It can which can be present in one or both eyes.&lt;/p&gt;\r\n&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;&nbsp;&lt;/p&gt;\r\n&lt;ul class=&quot;font_8&quot;&gt;\r\n&lt;li&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;Ptosis can either be present at birth (congenital), or may present later in life (acquired) usually as a result of stretching of the muscle over time. It may also occur with long-term contact lens wear, trauma, after cataract surgery or other eye operations. There are also less common causes of a droopy eyelid, such as problems with the nerves or muscles.&nbsp;&lt;/p&gt;\r\n&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;&nbsp;&lt;/p&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;Symptoms&lt;/p&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;&nbsp;&lt;/p&gt;\r\n&lt;ul class=&quot;font_8&quot;&gt;\r\n&lt;li&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;It can interfere with vision, by affecting the top part of the visual field&lt;/p&gt;\r\n&lt;/li&gt;\r\n&lt;li&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;It may be a cosmetic problem.&lt;/p&gt;\r\n&lt;/li&gt;\r\n&lt;li&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;Patients might have difficulty keeping their eyelids open, eyestrain or fatigue.&lt;/p&gt;\r\n&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;&nbsp;&lt;/p&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;Treatment&lt;/p&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;&nbsp;&lt;/p&gt;\r\n&lt;ul class=&quot;font_8&quot;&gt;\r\n&lt;li&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;Ptosis can be corrected in most cases by a surgery which involves strengthening of the Lid muscles. It&rsquo;s usually a Day Care procedure&lt;/p&gt;\r\n&lt;/li&gt;\r\n&lt;li&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;The surgery is done through an incision in the eyelid crease so the scar will not visible once healed. Any excess skin in the upper eyelid may also be removed at the same time. There will be some stitches along the upper eyelid fold which will be removed at one week.&lt;/p&gt;\r\n&lt;/li&gt;\r\n&lt;li&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;If both eyes have ptosis it is usually best to operate on both sides at the same time to give the best chance of a symmetrical result.&lt;/p&gt;\r\n&lt;/li&gt;\r\n&lt;li&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;In children with severe ptosis, surgical intervention needs to be done early to prevent Lazy eyes&lt;/p&gt;\r\n&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;&lt;span class=&quot;wixGuard&quot;&gt;&acirc;&euro;&lsaquo;&lt;/span&gt;&lt;/p&gt;\r\n&lt;/div&gt;\r\n&lt;div id=&quot;comp-jqjmhk2s&quot; class=&quot;txtNew&quot; data-packed=&quot;true&quot;&gt;\r\n&lt;h1 class=&quot;font_0&quot;&gt;B. LID RETRACTION - LARGE EYES&lt;/h1&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;&nbsp;&lt;/p&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;In contrast to ptosis, Lid retraction is a condition where the eyelid of the eye is retracted upwards and we have an appearance as if the patient is staring&lt;/p&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;&nbsp;&lt;/p&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;Causes&lt;/p&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;&nbsp;&lt;/p&gt;\r\n&lt;ul class=&quot;font_8&quot;&gt;\r\n&lt;li&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;Thyroid eye disease&lt;/p&gt;\r\n&lt;/li&gt;\r\n&lt;li&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;Neurological causes like dorsal midbrain syndrome&lt;/p&gt;\r\n&lt;/li&gt;\r\n&lt;li&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;Endocrinal causes like Cushing&rsquo;s syndrome&lt;/p&gt;\r\n&lt;/li&gt;\r\n&lt;li&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;Ptosis in the other eye&lt;/p&gt;\r\n&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;&nbsp;&lt;/p&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;Treatment&lt;/p&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;&nbsp;&lt;/p&gt;\r\n&lt;ul class=&quot;font_8&quot;&gt;\r\n&lt;li&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;Botox injection&lt;/p&gt;\r\n&lt;/li&gt;\r\n&lt;li&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;Surgical Correction&lt;/p&gt;\r\n&lt;/li&gt;\r\n&lt;li&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;Treating the underlying systemic condition&lt;/p&gt;\r\n&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;&acirc;&euro;&lsaquo;&lt;span class=&quot;wixGuard&quot;&gt;&acirc;&euro;&lsaquo;&lt;/span&gt;&lt;/p&gt;\r\n&lt;/div&gt;\r\n&lt;div id=&quot;comp-jqjmjgz6&quot; class=&quot;txtNew&quot; data-packed=&quot;true&quot;&gt;\r\n&lt;h1 class=&quot;font_0&quot;&gt;ENTROPION AND ECTROPION&lt;/h1&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;&nbsp;&lt;/p&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;Entropion&lt;/p&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;Entropion is a condition where the lid margin is turned inwards.&lt;/p&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;Causes: It can be caused by the aging changes in the muscles of the lid, following chronic infections or following an injury.&lt;/p&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;Symptoms: The eyelashes rub against the cornea and lead to watering, redness and sometime corneal ulceration and scarring.&lt;/p&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;Treatment&nbsp;: Surgical Correction&lt;/p&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;&lt;span class=&quot;wixGuard&quot;&gt;&acirc;&euro;&lsaquo;&lt;/span&gt;&lt;/p&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;&lt;span class=&quot;wixGuard&quot;&gt;&acirc;&euro;&lsaquo;&lt;/span&gt;&lt;/p&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;&lt;span class=&quot;wixGuard&quot;&gt;&acirc;&euro;&lsaquo;&lt;/span&gt;&lt;/p&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;Ectropion&lt;/p&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;Ectropion is a condition where the lower eyelid is everted out&lt;/p&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;Causes: Age-related changes in the eyelid tissue, cranial nerve VII palsy, and post-traumatic or post-surgical changes.&lt;/p&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;Symptoms: Excess tearing due to poor drainage of tears through the naso-lacrimal system and symptoms of&nbsp;&lt;a href=&quot;https://www.msdmanuals.com/professional/eye-disorders/corneal-disorders/keratoconjunctivitis-sicca&quot; target=&quot;_blank&quot; rel=&quot;undefined noopener noreferrer&quot; data-content=&quot;https://www.msdmanuals.com/professional/eye-disorders/corneal-disorders/keratoconjunctivitis-sicca&quot; data-type=&quot;external&quot;&gt;dry eyes&lt;/a&gt;.&lt;/p&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;Treatment: Medical management includes tear supplements and definitive treatment is surgery.&lt;/p&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;',1,25,'LID SURGERIES',NULL,'','0','0','','2019-04-24 21:25:52','2019-09-12 16:34:36',NULL),(12,'&lt;div class=&quot;s-12 m-6 l-3&quot; style=&quot;color: #000000; font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;&quot;&gt;\r\n&lt;p&gt;&lt;img src=&quot;../../storage/uploads/X3LzUhtQ3nWkacgJKKOeH7vq1rmeCinJLZR6RmrX.jpeg&quot; width=&quot;478&quot; height=&quot;130&quot; /&gt;&lt;/p&gt;\r\n&lt;/div&gt;\r\n&lt;div class=&quot;s-12 m-12 l-8&quot; style=&quot;color: #000000; font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;&quot;&gt;\r\n&lt;p style=&quot;text-align: left;&quot;&gt;&lt;strong&gt;&nbsp;&lt;/strong&gt;&lt;/p&gt;\r\n&lt;div id=&quot;comp-jqjosc4t&quot; class=&quot;txtNew&quot; data-packed=&quot;true&quot;&gt;\r\n&lt;h1 class=&quot;font_0&quot;&gt;&lt;span class=&quot;color_15&quot;&gt;MANAGEMENT OF OCULAR TRAUMA&lt;/span&gt;&lt;/h1&gt;\r\n&lt;/div&gt;\r\n&lt;div id=&quot;comp-jqjosc4x&quot; class=&quot;txtNew&quot; data-packed=&quot;false&quot; data-min-height=&quot;108&quot;&gt;\r\n&lt;ol class=&quot;font_8&quot;&gt;\r\n&lt;li&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;Orbital fractures: An orbital fracture is when there is a break in one of the bones surrounding the eyeball (called the&nbsp;&lt;a href=&quot;https://www.aao.org/eye-health/anatomy/parts-of-eye&quot; target=&quot;_blank&quot; rel=&quot;undefined noopener noreferrer&quot; data-content=&quot;https://www.aao.org/eye-health/anatomy/parts-of-eye&quot; data-type=&quot;external&quot;&gt;orbit, or eye socket&lt;/a&gt;). Usually this kind of injury is caused by&nbsp;&lt;a href=&quot;https://www.aao.org/eye-health/tips-prevention/injuries&quot; target=&quot;_blank&quot; rel=&quot;undefined noopener noreferrer&quot; data-content=&quot;https://www.aao.org/eye-health/tips-prevention/injuries&quot; data-type=&quot;external&quot;&gt;blunt force trauma&lt;/a&gt;, when something hits the eye very hard. Symptoms of an orbital fracture will depend on the type of injury and its severity, it usually needs surgical correction&lt;/p&gt;\r\n&lt;/li&gt;\r\n&lt;li&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;Lid reconstruction&lt;/p&gt;\r\n&lt;/li&gt;\r\n&lt;li&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;Repair of the canalicular tear/stenting&lt;/p&gt;\r\n&lt;/li&gt;\r\n&lt;/ol&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;',1,26,'MANAGEMENT OF OCULAR TRAUMA',NULL,'','0','0','','2019-04-26 00:55:14','2019-09-19 18:54:35',NULL),(13,'&lt;div class=&quot;s-12 m-6 l-3&quot; style=&quot;color: #000000; font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;&quot;&gt;\r\n&lt;p&gt;&lt;img src=&quot;../../storage/uploads/Mt4HknwXTl36ZvjsOaaTQorwDFlGaH9tFR8VkBnX.jpeg&quot; width=&quot;478&quot; height=&quot;130&quot; /&gt;&lt;/p&gt;\r\n&lt;/div&gt;\r\n&lt;div class=&quot;s-12 m-12 l-8&quot; style=&quot;color: #000000; font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;&quot;&gt;\r\n&lt;p style=&quot;text-align: left;&quot;&gt;&lt;strong&gt;&nbsp;&lt;/strong&gt;&lt;/p&gt;\r\n&lt;div id=&quot;comp-jqjomllt&quot; class=&quot;txtNew&quot; data-packed=&quot;true&quot;&gt;\r\n&lt;h1 class=&quot;font_0&quot;&gt;&lt;span class=&quot;color_15&quot;&gt;LACRIMAL SAC PROBLEMS&lt;/span&gt;&lt;/h1&gt;\r\n&lt;/div&gt;\r\n&lt;div id=&quot;comp-jqjomllx&quot; class=&quot;txtNew&quot; data-packed=&quot;false&quot; data-min-height=&quot;380&quot;&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;The tears formed in the eyes are drained from eye to the nasal cavity. Any blockage in this pathway can lead to Stagnation of tears in the eye and this subsequently can lead to infection of the lacrimal sac known as dacryocystitis.&lt;/p&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;&lt;span class=&quot;wixGuard&quot;&gt;â€‹&lt;/span&gt;&lt;/p&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;&lt;span class=&quot;color_28&quot;&gt;Symptoms&lt;/span&gt;&lt;/p&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;&lt;span class=&quot;wixGuard&quot;&gt;â€‹&lt;/span&gt;&lt;/p&gt;\r\n&lt;ol class=&quot;font_8&quot;&gt;\r\n&lt;li&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;Congenital dacryocystitis: &nbsp;The child may have symptoms like watering or mucopurulent discharge from the eye&lt;/p&gt;\r\n&lt;/li&gt;\r\n&lt;li&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;Acute dacryocystitis: It may be associated with sudden onset of pain redness and swelling overlying lacrimal sac area and watering or discharge from the eye&nbsp;&lt;/p&gt;\r\n&lt;/li&gt;\r\n&lt;/ol&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;&nbsp;&nbsp;&nbsp;3.&nbsp;Chronic dacryocystitis: It may be associated with long standing swelling in the region of lacrimal sac and recurrent episodes of watering or discharge from the eye.&lt;/p&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;&lt;span class=&quot;wixGuard&quot;&gt;â€‹&lt;/span&gt;&lt;/p&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;&lt;span class=&quot;color_28&quot;&gt;Treatment&lt;/span&gt;&lt;/p&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;&lt;span class=&quot;wixGuard&quot;&gt;â€‹&lt;/span&gt;&lt;/p&gt;\r\n&lt;ul class=&quot;font_8&quot;&gt;\r\n&lt;li&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;Congenital dacryocystitis: is treated with NLD massage and /or Probing and Syringing&lt;/p&gt;\r\n&lt;/li&gt;\r\n&lt;li&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;Acute dacryocystitis: Needs systemic antibiotics and analgesics and anti-inflammatory drugs&lt;/p&gt;\r\n&lt;/li&gt;\r\n&lt;li&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;Chronic dacryocystitis: Needs Surgery Dacryocystorhinostomy +/- intubation&lt;/p&gt;\r\n&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;',1,27,'LACRIMAL SAC PROBLEMS',NULL,'','0','0','','2019-04-26 00:56:14','2019-07-01 16:40:36',NULL),(14,'&lt;div class=&quot;s-12 m-6 l-3&quot; style=&quot;color: #000000; font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;&quot;&gt;\r\n&lt;div class=&quot;image-with-hover-overlay image-hover-zoom margin-bottom&quot;&gt;&lt;img src=&quot;../../storage/uploads/yzITgc79KZMPpHRpY0ACC6HHhsfp1bbqbzr1J2wS.jpeg&quot; width=&quot;478&quot; height=&quot;130&quot; /&gt;&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;div class=&quot;s-12 m-12 l-8&quot; style=&quot;color: #000000; font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;&quot;&gt;\r\n&lt;p style=&quot;text-align: left;&quot;&gt;&lt;strong&gt;&nbsp;&lt;/strong&gt;&lt;/p&gt;\r\n&lt;div id=&quot;comp-jqjoprbe&quot; class=&quot;txtNew&quot; data-packed=&quot;true&quot;&gt;\r\n&lt;h1 class=&quot;font_0&quot;&gt;&lt;span class=&quot;color_15&quot;&gt;OCULAR ONCOLOGY&lt;/span&gt;&lt;/h1&gt;\r\n&lt;/div&gt;\r\n&lt;div id=&quot;comp-jqjoprbg&quot; class=&quot;txtNew&quot; data-packed=&quot;false&quot; data-min-height=&quot;380&quot;&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;Ocular oncology involves the study and treatment of tumors that occur in or around the eye. These tumors may cause vision loss or loss of the eye itself; some tumors are potentially fatal, while others may be benign yet severely disfiguring.&lt;/p&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;&lt;span class=&quot;wixGuard&quot;&gt;â€‹&lt;/span&gt;&lt;/p&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;The treatment includes management of the tumor , reconstruction of the lids and restoring the cosmesis&lt;/p&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;&lt;span class=&quot;wixGuard&quot;&gt;â€‹&lt;/span&gt;&lt;/p&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;Artificial / prosthetic eyes: An ocular prosthesis is a type of prosthesis that replaces an absent natural eye following an enucleation, evisceration, or orbital exenteration. The prosthesis fits over an orbital implant and under the eyelids.&lt;/p&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;&lt;span class=&quot;wixGuard&quot;&gt;â€‹&lt;/span&gt;&lt;/p&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;It is made of medical grade plastic acrylic.A variant of the ocular prosthesis is a very thin hard shell known as a scleral shell which can be worn over a damaged or eviscerated eye. An ocular prosthesis does not provide vision; but provides a good cosmesis&lt;/p&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;',1,28,'OCULAR ONCOLOGY',NULL,'','0','0','','2019-04-26 00:57:26','2019-07-01 16:43:42',NULL),(15,'&lt;div class=&quot;s-12 m-6 l-3&quot; style=&quot;color: #000000; font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;&quot;&gt;\r\n&lt;div class=&quot;image-with-hover-overlay image-hover-zoom margin-bottom&quot;&gt;&lt;img src=&quot;../../storage/uploads/Ncc3bNj7bMO6AGMj5BOgTJqZO6cAaFffh0BXsQWG.jpeg&quot; width=&quot;478&quot; height=&quot;130&quot; /&gt;&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;div class=&quot;s-12 m-12 l-8&quot; style=&quot;color: #000000; font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;&quot;&gt;\r\n&lt;p style=&quot;text-align: left;&quot;&gt;&lt;strong&gt;&nbsp;&lt;/strong&gt;&lt;/p&gt;\r\n&lt;div id=&quot;comp-jqjovk8y&quot; class=&quot;txtNew&quot; data-packed=&quot;true&quot;&gt;\r\n&lt;h1 class=&quot;font_0&quot;&gt;&lt;span class=&quot;color_15&quot;&gt;AESTHETIC CLINIC&lt;/span&gt;&lt;/h1&gt;\r\n&lt;/div&gt;\r\n&lt;div id=&quot;comp-jqjovk92&quot; class=&quot;txtNew&quot; data-packed=&quot;false&quot; data-min-height=&quot;108&quot;&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;Aesthetic surgery has become an increasingly important part of oculoplastic surgery during the past couple of decades.&lt;/p&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;Increased life expectancy, improved economic standards and greater cosmetic consciousness in the population have contributed to the increased demand for aesthetic oculoplastic surgery&lt;/p&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;Aesthetic surgery is no longer in the domain of only the women, as was traditionally the case. Men today account for about 25% of the population seeking aesthetic procedures&lt;/p&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;&nbsp;&lt;/p&gt;\r\n&lt;h1 class=&quot;font_0&quot;&gt;Services offered:&lt;/h1&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;&nbsp;&lt;/p&gt;\r\n&lt;ol class=&quot;font_8&quot;&gt;\r\n&lt;li&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;Reconstructive Aesthetic Surgery:&nbsp;&nbsp;All patients who have had a disfigurement due to accident and require reconstructive surgery for fractures and soft tissue injuries.&lt;br /&gt;Patients with complex orbital and facial conditions such as tumours (benign and malignant), as well as congenital or acquired deformities need reconstructive surgery&lt;/p&gt;\r\n&lt;/li&gt;\r\n&lt;li&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;Blepharoplasty:&nbsp;Here the lids are contoured by surgical removal of the excess skin, muscle and fat. It&rsquo;s done for cosmetic purpose and also for medical reasons in patients with Blepharophimosis syndrome to provide them a better vision&lt;/p&gt;\r\n&lt;/li&gt;\r\n&lt;li&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;Brow lifts and treatment for deep rooted wrinkles, crow&rsquo;s feet&lt;/p&gt;\r\n&lt;/li&gt;\r\n&lt;li&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;Fillers for removal of static wrinkles.&lt;/p&gt;\r\n&lt;/li&gt;\r\n&lt;li&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;Mid-face lifts for removal of facial wrinkles and younger appearing facial features.&lt;/p&gt;\r\n&lt;/li&gt;\r\n&lt;li&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;Botox injection for Hemifacial spasm, Blepharospam and age related wrinkles.&lt;br /&gt;Blepharospasm is effectively treated by injecting directly into the preseptal orbicularis oculi musculature. In patients with hemifacial spasm, injections are tailored specifically to the affected muscles. The most common areas injected for hyperdynamic facial rhytides include the lateral canthal region (crows feet), glabellar folds and forehead&lt;/p&gt;\r\n&lt;/li&gt;\r\n&lt;/ol&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;',1,29,'AESTHETIC CLINIC',NULL,'','0','0','','2019-04-26 00:58:47','2019-07-01 16:45:46',NULL),(16,'&lt;div class=&quot;s-12 m-6 l-3&quot; style=&quot;color: #000000; font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;&quot;&gt;\r\n&lt;p&gt;&nbsp;&lt;/p&gt;\r\n&lt;div class=&quot;image-with-hover-overlay image-hover-zoom margin-bottom&quot;&gt;&lt;img src=&quot;../../storage/uploads/WJSEECQgQc17luIjfntQXXHR4LMHt0hwvnav9fRH.jpeg&quot; width=&quot;478&quot; height=&quot;130&quot; /&gt;&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;div class=&quot;s-12 m-12 l-8&quot; style=&quot;color: #000000; font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;&quot;&gt;\r\n&lt;p style=&quot;text-align: left;&quot;&gt;&lt;strong&gt;&nbsp;&lt;/strong&gt;&lt;/p&gt;\r\n&lt;div id=&quot;comp-jqjohbxb&quot; class=&quot;txtNew&quot; data-packed=&quot;true&quot;&gt;\r\n&lt;h1 class=&quot;font_0&quot;&gt;&lt;span class=&quot;color_15&quot;&gt;THYROID EYE DISEASE&lt;/span&gt;&lt;/h1&gt;\r\n&lt;/div&gt;\r\n&lt;div id=&quot;comp-jqjohbxi&quot; class=&quot;txtNew&quot; data-packed=&quot;false&quot; data-min-height=&quot;380&quot;&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;Thyroid eye disease is an inflammatory disease of the eye and the surrounding tissues. The inflammation is due to an autoimmune reaction - the body&#039;s immune system is attacking tissues within and around the eye socket.&lt;/p&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;The most common signs and symptoms associated with TED are:&lt;/p&gt;\r\n&lt;ol class=&quot;font_8&quot;&gt;\r\n&lt;li&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;Upper and/or lower eyelid retraction:&nbsp;the eyelid is retracted up or down from its normal position ,this gives an appearance as if the patient is &ldquo;staring&rdquo; or is &ldquo;frightened&rdquo;&lt;/p&gt;\r\n&lt;/li&gt;\r\n&lt;li&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;Dry Eyes:&nbsp;In cases of severe retraction, the ocular surface is exposed more which can lead to tearing, foreign body sensation, and blurred vision.&lt;/p&gt;\r\n&lt;/li&gt;\r\n&lt;li&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;Exophthalmos/Proptosis:&nbsp;It looks as if the eyeball is bulging out of the eye socket. This can lead to dry eye and can also damage the cornea in severe cases. Sometimes it can also cause double vision&lt;/p&gt;\r\n&lt;/li&gt;\r\n&lt;li&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;Squint:&nbsp;there is swelling of the muscles that control eye movements in thyroid eye disease, this can lead to restriction of the movements of the eye and can lead to double vision&lt;/p&gt;\r\n&lt;/li&gt;\r\n&lt;li&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;Optic nerve dysfunction:&nbsp;Too much of swelling of the muscles and tissues surrounding the eye leads to increase in pressure in the bony socket around the eyes and this can lead to damage to the optic nerve. This can manifest as decrease in the colour vision or decrease in clarity of vision.&lt;/p&gt;\r\n&lt;/li&gt;\r\n&lt;/ol&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;&lt;span class=&quot;wixGuard&quot;&gt;â€‹&lt;/span&gt;&lt;/p&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;Treatment&nbsp;:&lt;/p&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;&nbsp;&lt;/p&gt;\r\n&lt;ol class=&quot;font_8&quot;&gt;\r\n&lt;li&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;Lid surgeries: To correct the lid retraction&lt;/p&gt;\r\n&lt;/li&gt;\r\n&lt;li&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;Management of Dry Eyes: require lubricating eye drops, gel or sometimes taping of the eyes at night. Some severe &nbsp;cases may need tarsorrhaphy&lt;/p&gt;\r\n&lt;/li&gt;\r\n&lt;li&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;Orbital decompression: this surgical procedure may be needed if there too much protrusion of the eyeball or if the optic nerve is compressed&lt;/p&gt;\r\n&lt;/li&gt;\r\n&lt;li&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;Management of Squint: requires prisms in some case and some cases may need surgery&lt;/p&gt;\r\n&lt;/li&gt;\r\n&lt;/ol&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;',1,30,'THYROID EYE DISEASE',NULL,'','0','0','','2019-04-26 00:59:50','2019-07-01 16:48:00',NULL),(17,'&lt;div class=&quot;s-12 m-6 l-3&quot; style=&quot;color: #000000; font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;&quot;&gt;\r\n&lt;p&gt;&nbsp;&lt;/p&gt;\r\n&lt;div class=&quot;image-with-hover-overlay image-hover-zoom margin-bottom&quot;&gt;&lt;img src=&quot;../../storage/uploads/VgIgb3xG5GKftLkuU62fkF3XuMCLb3ct6VCtBynX.jpeg&quot; alt=&quot;&quot; width=&quot;421&quot; height=&quot;520&quot; /&gt;&lt;/div&gt;\r\n&lt;div class=&quot;image-with-hover-overlay image-hover-zoom margin-bottom&quot;&gt;&nbsp;&lt;/div&gt;\r\n&lt;div class=&quot;image-with-hover-overlay image-hover-zoom margin-bottom&quot;&gt;&lt;img src=&quot;../../storage/uploads/ucFrGiBeByF5JbEzraoNBlVR30RJihBV7h0ZRPjJ.jpeg&quot; alt=&quot;&quot; width=&quot;415&quot; height=&quot;242&quot; /&gt;&lt;/div&gt;\r\n&lt;div class=&quot;image-with-hover-overlay image-hover-zoom margin-bottom&quot;&gt;&nbsp;&lt;/div&gt;\r\n&lt;div class=&quot;image-with-hover-overlay image-hover-zoom margin-bottom&quot;&gt;&lt;img src=&quot;../../storage/uploads/nSGGt8kd1MFECBGxFj766i5kpl09pRYHRESSGgzy.jpeg&quot; width=&quot;478&quot; height=&quot;130&quot; /&gt;&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;div class=&quot;s-12 m-12 l-8&quot; style=&quot;color: #000000; font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;&quot;&gt;\r\n&lt;p style=&quot;text-align: left;&quot;&gt;&lt;strong&gt;&nbsp;&lt;/strong&gt;&lt;/p&gt;\r\n&lt;div class=&quot;itemHeader&quot; style=&quot;color: #000000; font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;&quot;&gt;\r\n&lt;div id=&quot;comp-jqjz6y3e&quot; class=&quot;txtNew&quot; data-packed=&quot;true&quot;&gt;\r\n&lt;h1 class=&quot;font_0&quot;&gt;&lt;span class=&quot;color_15&quot;&gt;COMPREHENSIVE EYE EXAMINATION OF CHILDREN&lt;/span&gt;&lt;/h1&gt;\r\n&lt;/div&gt;\r\n&lt;div id=&quot;comp-jqjz6y3k&quot; class=&quot;txtNew&quot; data-packed=&quot;false&quot; data-min-height=&quot;747&quot;&gt;\r\n&lt;ul class=&quot;font_8&quot;&gt;\r\n&lt;li&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;Refractive errors are the commonest cause of preventive blindness in children.&lt;/p&gt;\r\n&lt;/li&gt;\r\n&lt;li&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;Vision and refraction can be checked using many picture charts for preschool children and complete comprehensive eye examination can be performed&lt;/p&gt;\r\n&lt;/li&gt;\r\n&lt;li&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;Every child should have his first dilated eye check-up before 3 years&lt;/p&gt;\r\n&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;&nbsp;&lt;/p&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;Refractive errors occurs when the light rays do not focus on the light sensitive layer of the the eye i.e, the retina. The length of the eyeball (longer or shorter), or there may be changes in the curvature of the cornea, or in the refractive index of the lens. Refractive errors are the most common cause of blindness in Children.&lt;/p&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;&nbsp;&lt;/p&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;The most common types of refractive errors are myopia, hyperopia, presbyopia, and astigmatism.&lt;/p&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;&nbsp;&lt;/p&gt;\r\n&lt;ul class=&quot;font_8&quot;&gt;\r\n&lt;li&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;Myopia:&nbsp;A condition where the light comes to focus in front of the retina instead of on the retina.&lt;/p&gt;\r\n&lt;/li&gt;\r\n&lt;li&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;Hyperopia:&nbsp;A condition where the light comes to focus behind the retina instead of on the retina.&lt;/p&gt;\r\n&lt;/li&gt;\r\n&lt;li&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;Astigmatism:&nbsp;A condition in which the eye does not focus light uniformly onto the retina ,the power is different in horizontal and vertical axes&lt;/p&gt;\r\n&lt;/li&gt;\r\n&lt;li&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;Presbyopia:&nbsp;is an age-related condition in which the ability to focus up close becomes more difficult. As the eye ages, the lens can no longer change shape enough to allow the eye to focus close objects clearly.This is usually seen above the age of 40 years and people need a separate near add.&lt;/p&gt;\r\n&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;&nbsp;&lt;/p&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;&lt;span class=&quot;color_28&quot;&gt;Symptoms:&lt;/span&gt;&nbsp;&lt;/p&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;Blurred vision is the most common symptom of refractive errors. Other symptoms may include:&lt;/p&gt;\r\n&lt;ul class=&quot;font_8&quot;&gt;\r\n&lt;li&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;Holding the books too close to the eyes&lt;/p&gt;\r\n&lt;/li&gt;\r\n&lt;li&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;Child going too close to the TV&lt;/p&gt;\r\n&lt;/li&gt;\r\n&lt;li&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;Headache&lt;/p&gt;\r\n&lt;/li&gt;\r\n&lt;li&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;Eyestrain&lt;/p&gt;\r\n&lt;/li&gt;\r\n&lt;li&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;Double-vision&lt;/p&gt;\r\n&lt;/li&gt;\r\n&lt;li&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;Haziness&lt;/p&gt;\r\n&lt;/li&gt;\r\n&lt;li&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;Glare or halos around bright lights&lt;/p&gt;\r\n&lt;/li&gt;\r\n&lt;li&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;Squinting&lt;/p&gt;\r\n&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;&lt;span class=&quot;wixGuard&quot;&gt;â€‹&lt;/span&gt;&lt;/p&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;&lt;span class=&quot;color_28&quot;&gt;How are refractive errors diagnosed?&lt;/span&gt;&lt;/p&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;A child needs a comprehensive dilated eye examination by a Paediatric Ophthalmologist to find out the correct Power, drops are instilled and an objective retinoscopy is performed&lt;/p&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;&nbsp;&lt;/p&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;&lt;span class=&quot;color_28&quot;&gt;Treatment:&lt;/span&gt;&lt;/p&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;Spectacles are the simplest and safest way to correct refractive errors and provide your kid the optimal vision.&lt;/p&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;Contact Lenses can be prescribed when a child is responsible enough to take care of them and maintain proper hygiene. They are also prescribed in some medical conditions like keratoconus and aphakia to provide clearer and a wider field of vision.&nbsp;Refractive Surgery aims to change the shape of the cornea permanently. They can be performed once the growth of the eye is complete i.e, around&nbsp;20 years of age.&lt;/p&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;',1,31,'COMPREHENSIVE EYE EXAMINATION OF CHILDREN',NULL,'','0','0','','2019-04-26 01:00:42','2019-07-01 16:57:14',NULL),(18,'&lt;div class=&quot;s-12 m-6 l-3&quot; style=&quot;color: #000000; font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;&quot;&gt;\r\n&lt;p&gt;&nbsp;&lt;/p&gt;\r\n&lt;div class=&quot;image-with-hover-overlay image-hover-zoom margin-bottom&quot;&gt;&lt;img src=&quot;../../storage/uploads/rdiQ80UHENy4px03lIjnSFhDDELb4TdWkeMceAET.jpeg&quot; width=&quot;478&quot; height=&quot;130&quot; /&gt;&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;div class=&quot;s-12 m-12 l-8&quot; style=&quot;color: #000000; font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;&quot;&gt;\r\n&lt;p style=&quot;text-align: left;&quot;&gt;&lt;strong&gt;&nbsp;&lt;/strong&gt;&lt;/p&gt;\r\n&lt;div id=&quot;comp-jqjzgyg6&quot; class=&quot;txtNew&quot; data-packed=&quot;true&quot;&gt;\r\n&lt;h1 class=&quot;font_0&quot;&gt;&lt;span class=&quot;color_15&quot;&gt;TREATMENT OF LAZY EYE&lt;/span&gt;&lt;/h1&gt;\r\n&lt;/div&gt;\r\n&lt;div id=&quot;comp-jqjzgygf&quot; class=&quot;txtNew&quot; data-packed=&quot;false&quot; data-min-height=&quot;428&quot;&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;Amblyopia is the medical term used when the vision in one of the eyes is reduced because the eye and the brain are not working together properly. The eye itself looks normal, but it is not being used normally because the brain is favoring the other eye. This condition is also sometimes called lazy eye.&lt;/p&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;&nbsp;&lt;/p&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;Amblyopia is the most common cause of visual impairment among children, affecting approximately 2 to 3 out of every 100 children. Unless it is successfully treated in early childhood, amblyopia usually persists into adulthood. It is also the most common cause of monocular (one eye) visual impairment among children. &nbsp;&lt;/p&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;&nbsp;&lt;/p&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;&lt;span class=&quot;color_28&quot;&gt;Causes:&lt;/span&gt;&lt;/p&gt;\r\n&lt;ul class=&quot;font_8&quot;&gt;\r\n&lt;li&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;Uncorrected refractive errors: Ametropic Amblyopia&lt;/p&gt;\r\n&lt;/li&gt;\r\n&lt;li&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;Difference between the refractive errors in two eyes: Ansiometropic Amblyopia&lt;/p&gt;\r\n&lt;/li&gt;\r\n&lt;li&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;Squint or deviation of eyes: Strabismic Amblyopia&lt;/p&gt;\r\n&lt;/li&gt;\r\n&lt;li&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;One eye has cataract or retina problem: Sensory or Stimulus deprivation Amblyopia&lt;br /&gt;&nbsp;&lt;/p&gt;\r\n&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;&lt;span class=&quot;color_28&quot;&gt;Treatment:&nbsp;&lt;/span&gt;&lt;/p&gt;\r\n&lt;ul class=&quot;font_8&quot;&gt;\r\n&lt;li&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;Correcting the underlying cause like glasses for the refractive error, treatment for the Squint and Surgery for cataracts.&nbsp;&lt;/p&gt;\r\n&lt;/li&gt;\r\n&lt;li&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;Patching: We have to force the child to use the eye with weaker vision by covering the good eye with a Patch. An adhesive patch is worn over the stronger eye for weeks to months.&nbsp; Patching stimulates vision in the weaker eye and helps parts of the brain involved in vision develop more completely.&lt;/p&gt;\r\n&lt;/li&gt;\r\n&lt;li&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;Previously, eye care professionals thought that treating amblyopia would be of little benefit to older children. However, our experience is that many children from ages seven to 17 years old also benefited from treatment for amblyopia. Hence age alone should not be used as a factor to decide whether or not to treat a child for amblyopia.&lt;/p&gt;\r\n&lt;/li&gt;\r\n&lt;li&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;Penalisation : A drop of a drug called atropine is placed in the stronger eye to temporarily blur vision so that the child will use the eye with amblyopia. This is given in children who are totally non compliant to patching. This works only for moderate Amblyopia and is much less effective than patching but is still better than not doing anything&lt;/p&gt;\r\n&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;',1,32,'TREATMENT OF LAZY EYE',NULL,'','0','0','','2019-04-26 01:01:48','2019-07-01 16:59:21',NULL),(19,'&lt;div class=&quot;s-12 m-6 l-3&quot; style=&quot;color: #000000; font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;&quot;&gt;\r\n&lt;div class=&quot;image-with-hover-overlay image-hover-zoom margin-bottom&quot;&gt;&lt;img src=&quot;../../storage/uploads/4rJn2sRoH0TOiVaPyQoszMLDS8HKmWdPmn25XyFA.jpeg&quot; width=&quot;478&quot; height=&quot;130&quot; /&gt;&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;div class=&quot;s-12 m-12 l-8&quot; style=&quot;color: #000000; font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;&quot;&gt;\r\n&lt;h2 class=&quot;text-theme-colored mt-0&quot; style=&quot;text-align: left;&quot;&gt;&lt;strong&gt;About Dr. Hemalatha Vidyashankar&lt;/strong&gt;&lt;/h2&gt;\r\n&lt;p&gt;MBBS, DOMS, DNB, FMRF (SANKARA NETHRALAYA)&lt;/p&gt;\r\n&lt;p&gt;&lt;strong&gt;Eye Specialist &lt;/strong&gt;&lt;/p&gt;\r\n&lt;p style=&quot;text-align: left;&quot;&gt;&nbsp;&lt;/p&gt;\r\n&lt;p&gt;Dr.Hemalatha Vidyashankar pursued her MBBS from Stanley Medical College, Chennai&nbsp;and her Post graduation from MGM Hospital, Navi Mumbai. She completed Sir Ratan Tata Fellowship Cataract Microsurgery: Basic and Advanced at the Sankara Nethralaya, Chennai. She further pursued her long term Fellowship in Paediatric Ophthalmology and Strabismus, Sankara Nethralaya, Chennai. She has an experience of more than a decade in treating children with eye problems&lt;/p&gt;\r\n&lt;p&gt;She specialises in Paediatric Cataract surgery with IOL implantation and all types of Squint surgeries. She has performed a vast number of eye surgeries in children. Her special interests are in Amblyopia/lazy Eye Therapy and Binocular vision therapy and treatment of Congenital Naso-lacrimal Duct Obstruction. She has keen interest in Genetic Eye diseases affecting the children&rsquo;s eyes.&lt;/p&gt;\r\n&lt;p&gt;&nbsp;&lt;/p&gt;\r\n&lt;p&gt;She is also proficient in Adult Micro-phaco Surgery in routine and complex cataract surgery with premium intra-ocular lenses and has trained several Post graduate students in the art of cataract surgery.&lt;/p&gt;\r\n&lt;p&gt;She is an invited expert speaker for various national ophthalmology conferences and Postgraduate training Programmes. She has conducted several CMEs and Hospital based training Programmes.&lt;/p&gt;\r\n&lt;p&gt;Dr. Hemalatha is loved by children and parents for her warm demeanour. Kids enjoy her calm and friendly personality.&lt;/p&gt;\r\n&lt;/div&gt;',1,22,'Dr. Hemalatha Vidyashankar',NULL,'','0','0','','2019-04-26 01:19:09','2019-07-02 05:19:24',NULL),(20,'&lt;div class=&quot;s-12 m-6 l-3&quot; style=&quot;color: #000000; font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;&quot;&gt;\r\n&lt;div class=&quot;image-with-hover-overlay image-hover-zoom margin-bottom&quot;&gt;&lt;img src=&quot;../../storage/uploads/rEPoElNp6joYh5W4ht8Ve57TSYnZFeKbpTfAP2UO.jpeg&quot; width=&quot;478&quot; height=&quot;130&quot; /&gt;&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;div class=&quot;s-12 m-12 l-8&quot; style=&quot;color: #000000; font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;&quot;&gt;\r\n&lt;h2 class=&quot;text-theme-colored mt-0&quot; style=&quot;text-align: left;&quot;&gt;&lt;span style=&quot;color: #ff0000;&quot;&gt;&lt;strong&gt;&lt;span style=&quot;font-family: Camphor; font-size: 24px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: bold; letter-spacing: normal; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: #ffffff; float: none; display: inline !important;&quot;&gt;DR. VIDYASHANKAR&rsquo;S CENTER FOR VISION&lt;/span&gt;&lt;/strong&gt;&lt;/span&gt;&lt;/h2&gt;\r\n&lt;p style=&quot;text-align: left;&quot;&gt;&nbsp;&lt;/p&gt;\r\n&lt;p style=&quot;text-align: justify;&quot;&gt;FACILITIES&lt;/p&gt;\r\n&lt;p&gt;Dr. Vidyashankar&rsquo;s Center for Vision is a Super specialty eye clinic with a vision to provide services for all the subspecialties of Ophthalmology under one roof. Our mission is to serve patients from the entire community irrespective of any discrimination.&lt;/p&gt;\r\n&lt;p&gt;&lt;br /&gt; We are committed to providing comprehensive and compassionate care to the patient maintaining the highest standards of ethics and expertise in terms of skills and technology. We emphasize specifically on preventive health care and build a personalized patient-doctor relationship which focusses on holistic care.&lt;/p&gt;\r\n&lt;p&gt;&lt;br /&gt; There are multiple Consultation, Counselling, and diagnostic rooms and also a large reception area which is Child-friendly.&lt;/p&gt;\r\n&lt;p&gt;&lt;br /&gt; We have a dedicated team of Vision therapists who specialize in Amblyopia therapy and Binocular Vision therapy and an Ocularist who specializes in artificial prosthetic eye and specialty clinics for Diabetic eye disease, Thyroid eye disease, ROP Clinic for Preterm babies and Genetic Eye diseases. The clinic also has an in house Optical outlet.&lt;/p&gt;\r\n&lt;p&gt;Address:&lt;/p&gt;\r\n&lt;p&gt;DR VIDYASHANKR&rsquo;S CENTRE FOR VISION,&lt;/p&gt;\r\n&lt;p&gt;503, Pure Gold Building,&nbsp;Opposite&lt;br /&gt; Saroj Restaurant, Narayan Gajanan Marg, Chembur East, Mumbai,&lt;br /&gt; Maharashtra 400071.&lt;/p&gt;\r\n&lt;p&gt;&nbsp;Phone numbers:&nbsp; 022 25293354/ 9819846802/9769022448&lt;/p&gt;\r\n&lt;p&gt;&lt;strong&gt;Direction&lt;/strong&gt;&lt;/p&gt;\r\n&lt;p&gt;It is conveniently located at walking distance from Chembur railway station and also easily accessible from Road both from Navi Mumbai and Central suburbs.&lt;/p&gt;\r\n&lt;/div&gt;',1,33,'Hospital',NULL,'','0','0','','2019-06-27 19:03:44','2019-07-02 05:00:01',NULL),(21,'&lt;div class=&quot;s-12 m-12 l-4 margin-bottom&quot;&gt;\r\n&lt;div class=&quot;padding-2x block-bordered border-radius&quot;&gt;\r\n&lt;h2 class=&quot;text-thin&quot; style=&quot;text-align: center;&quot;&gt;Dr. B. Vidyashankar&lt;/h2&gt;\r\n&lt;p&gt;&nbsp;&lt;/p&gt;\r\n&lt;p class=&quot;margin-bottom-30&quot; style=&quot;text-align: center;&quot;&gt;&lt;a class=&quot;button border-radius background-primary text-size-12 text-white text-strong&quot;&gt;&lt;img src=&quot;../../storage/uploads/VOC7gBFdN8XUmJXPyHshJJxUMF9brdIfCdewBuTO.jpeg&quot; width=&quot;214&quot; height=&quot;254&quot; /&gt;&lt;/a&gt;&lt;/p&gt;\r\n&lt;p class=&quot;margin-bottom-30&quot; style=&quot;text-align: center;&quot;&gt;MBBS, DOMS, DNB, FMRF (SANKARA NETHRALAYA) ,FICO (UK)&lt;/p&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;div class=&quot;s-12 m-12 l-4 margin-bottom&quot;&gt;\r\n&lt;div class=&quot;padding-2x block-bordered border-radius&quot;&gt;\r\n&lt;h2 class=&quot;text-thin&quot; style=&quot;text-align: center;&quot;&gt;Dr. Hemalatha Vidyashankar&lt;/h2&gt;\r\n&lt;p class=&quot;margin-bottom-30&quot; style=&quot;text-align: center;&quot;&gt;&lt;a class=&quot;button border-radius background-primary text-size-12 text-white text-strong&quot;&gt;&lt;img src=&quot;../../storage/uploads/OLQXYFbCx7xk2bDuhcHJMDuBW6DUn63Uaxk2GpQS.jpeg&quot; width=&quot;214&quot; height=&quot;254&quot; /&gt;&lt;/a&gt;&lt;/p&gt;\r\n&lt;p class=&quot;margin-bottom-30&quot; style=&quot;text-align: center;&quot;&gt;MBBS, DOMS, DNB, FMRF (SANKARA NETHRALAYA)&lt;/p&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;div class=&quot;s-12 m-12 l-4 margin-bottom&quot;&gt;\r\n&lt;div class=&quot;padding-2x block-bordered border-radius&quot;&gt;\r\n&lt;h2 class=&quot;text-thin&quot; style=&quot;text-align: center;&quot;&gt;Dr.&nbsp;&lt;/h2&gt;\r\n&lt;p&gt;&nbsp;&lt;/p&gt;\r\n&lt;p class=&quot;margin-bottom-30&quot; style=&quot;text-align: center;&quot;&gt;&lt;a class=&quot;button border-radius background-primary text-size-12 text-white text-strong&quot;&gt;&lt;img src=&quot;../../storage/uploads/TfwcGgIL1WA13czp9AjafiOaYkASewTmn63vxh7H.jpeg&quot; width=&quot;214&quot; height=&quot;254&quot; /&gt;&lt;/a&gt;&lt;/p&gt;\r\n&lt;p class=&quot;margin-bottom-30&quot; style=&quot;text-align: center;&quot;&gt;MBBS&lt;/p&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;div class=&quot;s-12 m-12 l-4 margin-bottom&quot;&gt;&nbsp;&lt;/div&gt;',1,24,NULL,NULL,'','0','0','','2019-06-27 19:16:18','2019-07-02 05:10:20',NULL),(22,'&lt;div class=&quot;s-12 m-6 l-3&quot; style=&quot;color: #000000; font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;&quot;&gt;\r\n&lt;p&gt;&lt;img src=&quot;../../storage/uploads/vyfqJ5iJrfZMHV4JyNB1vSZhwo2wdOPof4RSmi9D.jpeg&quot; alt=&quot;&quot; width=&quot;406&quot; height=&quot;264&quot; /&gt;&nbsp;&lt;/p&gt;\r\n&lt;p&gt;&nbsp;&lt;/p&gt;\r\n&lt;div class=&quot;image-with-hover-overlay image-hover-zoom margin-bottom&quot;&gt;&lt;img src=&quot;../../storage/uploads/IKPthnJ4mxvwPd0r1DX2rDNYvFPxkgrjJv1jENpw.jpeg&quot; width=&quot;478&quot; height=&quot;130&quot; /&gt;&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;div class=&quot;s-12 m-12 l-8&quot; style=&quot;color: #000000; font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;&quot;&gt;\r\n&lt;div id=&quot;comp-jqjmd9c7&quot; class=&quot;txtNew&quot; data-packed=&quot;true&quot;&gt;\r\n&lt;div id=&quot;comp-jqjzko0v&quot; class=&quot;txtNew&quot; data-packed=&quot;true&quot;&gt;\r\n&lt;h1 class=&quot;font_0&quot;&gt;&lt;span class=&quot;color_15&quot;&gt;DIAGNOSIS AND TREATMENT OF BINOCULAR VISION PROBLEMS&lt;/span&gt;&lt;/h1&gt;\r\n&lt;/div&gt;\r\n&lt;div id=&quot;comp-jqjzko10&quot; class=&quot;txtNew&quot; data-packed=&quot;false&quot; data-min-height=&quot;244&quot;&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;Binocular vision impairment is any visual condition wherein binocular visual skills are inadequately developed.&nbsp; This may be due to presence of a squint or weakness of eye muscles or eye fatigue due to excessive use of Visual Display terminals.&lt;/p&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;&nbsp;&lt;/p&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;At our Binocular vision clinic, we perform a comprehensive eye examination of the important binocular visual skills:&nbsp;&lt;/p&gt;\r\n&lt;ul class=&quot;font_8&quot;&gt;\r\n&lt;li&gt;Tracking&lt;/li&gt;\r\n&lt;li&gt;Fusion&lt;/li&gt;\r\n&lt;li&gt;Stereopsis&lt;/li&gt;\r\n&lt;li&gt;Convergence&lt;/li&gt;\r\n&lt;li&gt;Visual Motor Integration&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;p&gt;&lt;span class=&quot;wixGuard&quot;&gt;â€‹&lt;/span&gt;&lt;/p&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;Problems like difficulty in focussing, double vision, eye fatigue are diagnosed and treated with exercises. We provide software based in office Eye Exercises and we also train the patient in home Exercises&lt;/p&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;',1,34,'DIAGNOSIS AND TREATMENT OF BINOCULAR VISION PROBLEMS',NULL,'','0','0','','2019-07-01 17:04:55','2019-07-01 17:04:55',NULL),(23,'&lt;div class=&quot;s-12 m-6 l-3&quot; style=&quot;color: #000000; font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;&quot;&gt;\r\n&lt;p&gt;&nbsp;&lt;/p&gt;\r\n&lt;div class=&quot;image-with-hover-overlay image-hover-zoom margin-bottom&quot;&gt;&lt;img src=&quot;../../storage/uploads/zMnuVmJo2I4liVZtszuxG8hG79X9JnNt6gYn05eg.jpeg&quot; width=&quot;478&quot; height=&quot;130&quot; /&gt;&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;div class=&quot;s-12 m-12 l-8&quot; style=&quot;color: #000000; font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;&quot;&gt;\r\n&lt;div id=&quot;comp-jqjmd9c7&quot; class=&quot;txtNew&quot; data-packed=&quot;true&quot;&gt;\r\n&lt;div id=&quot;comp-jqjzl7vt&quot; class=&quot;txtNew&quot; data-packed=&quot;true&quot;&gt;\r\n&lt;h1 class=&quot;font_0&quot;&gt;&lt;span class=&quot;color_15&quot;&gt;PAEDIATRIC CATARACT SURGERY WITH IOL IMPLANTATION&nbsp;&lt;/span&gt;&lt;/h1&gt;\r\n&lt;/div&gt;\r\n&lt;div id=&quot;comp-jqjzl7vy&quot; class=&quot;txtNew&quot; data-packed=&quot;false&quot; data-min-height=&quot;428&quot;&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;The lens is the transparent structure located just behind the pupil (the black circle in the centre of the eye).It allows light to pass through it and focusses it on to the light-sensitive layer of tissue at the back of the eye (retina).&lt;/p&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;&nbsp;&lt;/p&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;Cataracts most commonly affect older adults , but some babies are born with cataracts ( Congenital Cataract) and Children can also develop them at a young age. These are known as childhood cataracts.&nbsp;&lt;/p&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;&nbsp;&lt;/p&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;Cataracts occur when changes in the lens of the eye cause it to become less transparent (clear). This results in cloudy or misty vision.&lt;/p&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;â€‹&lt;span class=&quot;wixGuard&quot;&gt;â€‹&lt;/span&gt;â€‹&lt;/p&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;&lt;span class=&quot;color_28&quot;&gt;Symptoms&nbsp;&lt;/span&gt;&lt;/p&gt;\r\n&lt;ul class=&quot;font_8&quot;&gt;\r\n&lt;li&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;The child may not fix and follow light and objects&lt;/p&gt;\r\n&lt;/li&gt;\r\n&lt;li&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;Lack of social smile or face recognition&lt;/p&gt;\r\n&lt;/li&gt;\r\n&lt;li&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;Deviation of eye (squint) or shaking of eyeballs ( Nystagmus)&nbsp;&lt;/p&gt;\r\n&lt;/li&gt;\r\n&lt;li&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;Observing a white reflex in the eyes in photographs&lt;br /&gt;&nbsp;&lt;/p&gt;\r\n&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;&lt;span class=&quot;color_28&quot;&gt;Treatment&lt;/span&gt;&nbsp;â€‹â€‹&lt;/p&gt;\r\n&lt;ul class=&quot;font_8&quot;&gt;\r\n&lt;li&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;Sometimes Cataracts in children are not very dense or do not affect the visual axis and they require only close observation.&lt;/p&gt;\r\n&lt;/li&gt;\r\n&lt;li&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;But if cataracts are affecting your child&#039;s vision, they can slow down or stop their normal sight development.In these cases, we need to do surgery to remove the affected lens and implant an Intraocular lens.&lt;/p&gt;\r\n&lt;/li&gt;\r\n&lt;li&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;Post operative visual rehabilitation, Lazy eye therapy and regular follow up is necessary for good recovery.â€‹&lt;/p&gt;\r\n&lt;/li&gt;\r\n&lt;li&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;It&#039;s particularly important to spot cataracts in children quickly because early diagnosis and treatment can reduce the risk of long-term vision problems.&nbsp;&lt;/p&gt;\r\n&lt;/li&gt;\r\n&lt;li&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;Sometimes a white reflex in the eye may be associated with more severe problems like a Retinal detachment or Retinoblastoma (a cancer of the eye). Hence its very important to consult your Paediatric Ophthalmologist if you see a white reflex in your child&#039;s eye.â€‹â€‹&lt;/p&gt;\r\n&lt;/li&gt;\r\n&lt;li&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;Genetic counselling can help couples who may be at risk of passing an inherited condition on to their child&lt;/p&gt;\r\n&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;',1,35,'PAEDIATRIC CATARACT SURGERY WITH IOL IMPLANTATION',NULL,'','0','0','','2019-07-01 17:07:15','2019-07-01 17:07:15',NULL),(24,'&lt;div class=&quot;s-12 m-6 l-3&quot; style=&quot;color: #000000; font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;&quot;&gt;\r\n&lt;p&gt;&lt;img src=&quot;../../storage/uploads/clyrImR3bkgjdH0llRvbB8GNBsaHU57OLHcpn2J7.jpeg&quot; width=&quot;478&quot; height=&quot;130&quot; /&gt;&lt;/p&gt;\r\n&lt;/div&gt;\r\n&lt;div class=&quot;s-12 m-12 l-8&quot; style=&quot;color: #000000; font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;&quot;&gt;\r\n&lt;p style=&quot;text-align: left;&quot;&gt;&lt;strong&gt;&nbsp;&lt;/strong&gt;&lt;/p&gt;\r\n&lt;div id=&quot;comp-jqjosc4t&quot; class=&quot;txtNew&quot; data-packed=&quot;true&quot;&gt;\r\n&lt;div id=&quot;comp-jook8za5&quot; class=&quot;txtNew&quot; data-packed=&quot;true&quot;&gt;\r\n&lt;h5 class=&quot;font_5&quot; style=&quot;text-align: left;&quot;&gt;&lt;a href=&quot;https://www.drhemalathavidyashankar.online/copy-of-10-paediatric-cataract&quot; target=&quot;_self&quot;&gt;&lt;span class=&quot;color_15&quot;&gt;Treatment of Squint : with Exercises, Prisms and Surgery&lt;/span&gt;&lt;/a&gt;&lt;/h5&gt;\r\n&lt;/div&gt;\r\n&lt;div id=&quot;comp-jook8za9&quot; class=&quot;txtNew&quot; data-packed=&quot;true&quot;&gt;\r\n&lt;p class=&quot;font_8&quot; style=&quot;text-align: left;&quot;&gt;&lt;span class=&quot;color_15&quot;&gt;The aim of treating a squint in order of importance is:&lt;/span&gt;&lt;/p&gt;\r\n&lt;ul class=&quot;font_8 wix-list-text-align color_15&quot; style=&quot;text-align: left;&quot;&gt;\r\n&lt;li&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;&lt;span class=&quot;color_15&quot;&gt;To preserve or restore vision&lt;/span&gt;&lt;/p&gt;\r\n&lt;/li&gt;\r\n&lt;li&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;&lt;span class=&quot;color_15&quot;&gt;Straighten the eyes&lt;/span&gt;&lt;/p&gt;\r\n&lt;/li&gt;\r\n&lt;li&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;&lt;span class=&quot;color_15&quot;&gt;Restore 3D vision&lt;/span&gt;&lt;br /&gt;&nbsp;&lt;/p&gt;\r\n&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;p class=&quot;font_8&quot; style=&quot;text-align: left;&quot;&gt;&lt;span class=&quot;color_15&quot;&gt;In a child, the treatment of squint and any associated amblyopia should be started as soon as possible. Generally speaking the younger the age at which amblyopia is treated the better the chance of recovery of vision&lt;/span&gt;&lt;/p&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;',1,36,'Treatment of Squint : with Exercises, Prisms and Surgery',NULL,'','0','0','','2019-07-01 17:09:57','2019-10-01 15:56:02',NULL),(25,'&lt;div class=&quot;s-12 m-6 l-3&quot; style=&quot;color: #000000; font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;&quot;&gt;\r\n&lt;p&gt;&nbsp;&lt;/p&gt;\r\n&lt;div class=&quot;image-with-hover-overlay image-hover-zoom margin-bottom&quot;&gt;&lt;img src=&quot;../../storage/uploads/zMnuVmJo2I4liVZtszuxG8hG79X9JnNt6gYn05eg.jpeg&quot; width=&quot;478&quot; height=&quot;130&quot; /&gt;&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;div class=&quot;s-12 m-12 l-8&quot; style=&quot;color: #000000; font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;&quot;&gt;\r\n&lt;div id=&quot;comp-jqjmd9c7&quot; class=&quot;txtNew&quot; data-packed=&quot;true&quot;&gt;\r\n&lt;div id=&quot;comp-jqjzltnp&quot; class=&quot;txtNew&quot; data-packed=&quot;true&quot;&gt;\r\n&lt;h1 class=&quot;font_0&quot;&gt;&lt;span class=&quot;color_15&quot;&gt;TREATMENT OF CONGENITAL NASO LACRIMAL DUCT OBSTRUCTION&lt;/span&gt;&lt;/h1&gt;\r\n&lt;/div&gt;\r\n&lt;div id=&quot;comp-jqjzltnv&quot; class=&quot;txtNew&quot; data-packed=&quot;false&quot; data-min-height=&quot;428&quot;&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;The tears produced in our eyes move down through the naso-lacrimal duct and drain into the nose.&lt;/p&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;&nbsp;&lt;/p&gt;\r\n&lt;ul class=&quot;font_8&quot;&gt;\r\n&lt;li&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;Many babies are born with an underdeveloped tear-duct system, a problem that can lead to tear-duct blockage, excess tearing, and infection.â€‹ Blocked tear ducts are common in infants; as many as one third may be born with this condition.&nbsp;&lt;/p&gt;\r\n&lt;/li&gt;\r\n&lt;li&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;Other causes of blockage, especially in older kids, are rare. Some kids have nasal polyps, which are cysts or growths of extra tissue in the nose at the end of the tear duct.&lt;/p&gt;\r\n&lt;/li&gt;\r\n&lt;li&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;A blockage also can be caused by a cyst or tumour in the nose, but again, this is very unusual in children&nbsp;&lt;/p&gt;\r\n&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;&nbsp;&lt;/p&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;&nbsp;&lt;/p&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;&lt;span class=&quot;color_28&quot;&gt;Symptoms&lt;/span&gt;â€‹&lt;/p&gt;\r\n&lt;ul class=&quot;font_8&quot;&gt;\r\n&lt;li&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;Symptoms usually excessive tearing (even when a baby is not crying) develop between birth and 12 weeks of age, although the problem might not be apparent until an eye becomes infected.&nbsp;&lt;/p&gt;\r\n&lt;/li&gt;\r\n&lt;li&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;There might be yellowish discharge,pus in the corner of the eye, or crusting over the eyelid or in the eyelashes.&lt;/p&gt;\r\n&lt;/li&gt;\r\n&lt;li&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;Sometimes,they&nbsp; can develop an infection in the lacrimal sac called dacryocystitis. Signs include redness at the inner corner of the eye and a slight tenderness and swelling or bump at the side of the nose.&lt;/p&gt;\r\n&lt;/li&gt;\r\n&lt;li&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;Some infants are born with a cyst in the lacrimal sac, causing a swollen blue bump called a dacryocystocele to appear next to the inside corner of the eye.&lt;/p&gt;\r\n&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;&nbsp;&lt;/p&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;&lt;span class=&quot;color_28&quot;&gt;Treatment&lt;/span&gt;â€‹&lt;/p&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;&nbsp;&lt;/p&gt;\r\n&lt;ul class=&quot;font_8&quot;&gt;\r\n&lt;li&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;Fortunately, more than 90% of all cases clear up by the time children are 1 year old with regular NLD massage&lt;/p&gt;\r\n&lt;/li&gt;\r\n&lt;li&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;If it becomes infected, topical (applied to the skin) antibiotics might be needed.&lt;/p&gt;\r\n&lt;/li&gt;\r\n&lt;li&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;However, with some infections, a baby may need to be treated in a hospital with IV (intravenous, given into a vein) antibiotics, followed by surgical probing of the nasolacrimal duct.&lt;/p&gt;\r\n&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;',1,37,'TREATMENT OF CONGENITAL NASO LACRIMAL DUCT OBSTRUCTION',NULL,'','0','0','','2019-07-01 17:12:15','2019-07-01 17:12:15',NULL),(26,'&lt;div class=&quot;s-12 m-6 l-3&quot; style=&quot;color: #000000; font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;&quot;&gt;\r\n&lt;p&gt;&nbsp;&lt;/p&gt;\r\n&lt;div class=&quot;image-with-hover-overlay image-hover-zoom margin-bottom&quot;&gt;&lt;img src=&quot;../../storage/uploads/IhfvBDYVjKu6QGMxyEINZnfj1RjJV0YO2mIJzNsn.jpeg&quot; width=&quot;478&quot; height=&quot;130&quot; /&gt;&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;div class=&quot;s-12 m-12 l-8&quot; style=&quot;color: #000000; font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;&quot;&gt;\r\n&lt;div id=&quot;comp-jqjmd9c7&quot; class=&quot;txtNew&quot; data-packed=&quot;true&quot;&gt;\r\n&lt;div id=&quot;comp-jqjzmacn&quot; class=&quot;txtNew&quot; data-packed=&quot;true&quot;&gt;\r\n&lt;h1 class=&quot;font_0&quot;&gt;&lt;span class=&quot;color_15&quot;&gt;MANAGEMENT AND COUNSELLING FOR GENETIC EYE DISEASES&lt;/span&gt;&lt;/h1&gt;\r\n&lt;/div&gt;\r\n&lt;div id=&quot;comp-jqjzmact&quot; class=&quot;txtNew&quot; data-packed=&quot;false&quot; data-min-height=&quot;261&quot;&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;Genetic factors play a role in many kinds of eye disease, including those diseases that are the leading cause of blindness among infants, children and adults.&lt;/p&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;&nbsp;&lt;/p&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;More than 60 percent of cases of blindness among infants are caused by inherited eye diseases such as&nbsp;&lt;a href=&quot;http://my.clevelandclinic.org/childrens-hospital/health-info/diseases-conditions/hic-cataracts-in-children&quot; target=&quot;_blank&quot; rel=&quot;undefined noopener noreferrer&quot; data-content=&quot;http://my.clevelandclinic.org/childrens-hospital/health-info/diseases-conditions/hic-cataracts-in-children&quot; data-type=&quot;external&quot;&gt;congenital (present at birth) cataracts&lt;/a&gt;, congenital glaucoma, retinal degeneration,&nbsp;&lt;a href=&quot;http://my.clevelandclinic.org/services/cole-eye/diseases-conditions/hic-optic-atrophy&quot; target=&quot;_blank&quot; rel=&quot;undefined noopener noreferrer&quot; data-content=&quot;http://my.clevelandclinic.org/services/cole-eye/diseases-conditions/hic-optic-atrophy&quot; data-type=&quot;external&quot;&gt;optic atrophy&lt;/a&gt;&nbsp;and eye malformations.&nbsp;&lt;/p&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;&nbsp;&lt;/p&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;In a child with a Genetic Eye disease, we perform a complete review of any medical records or test results available and discuss your personal and family medical history, with particular attention given to signs and symptoms of genetic disorders in detail. We do pedigree charting (draw the family tree) and identify other family members who may be affected with similar problems. We screen the family members and siblings and do a detailed eye examination for them. This helps us in formulating the diagnosis and treatment plan.&lt;/p&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;&nbsp;&lt;/p&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;We offer Genetic Counselling and optimise the vision using proper refractive correction and Low Visual Aids&lt;/p&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;',1,38,'MANAGEMENT AND COUNSELLING FOR GENETIC EYE DISEASES',NULL,'','0','0','','2019-07-01 17:16:06','2019-07-01 17:16:06',NULL),(27,'&lt;div class=&quot;s-12 m-6 l-3&quot; style=&quot;color: #000000; font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;&quot;&gt;\r\n&lt;p&gt;&nbsp;&lt;/p&gt;\r\n&lt;div class=&quot;image-with-hover-overlay image-hover-zoom margin-bottom&quot;&gt;&lt;img src=&quot;../../storage/uploads/zMnuVmJo2I4liVZtszuxG8hG79X9JnNt6gYn05eg.jpeg&quot; width=&quot;478&quot; height=&quot;130&quot; /&gt;&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;div class=&quot;s-12 m-12 l-8&quot; style=&quot;color: #000000; font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;&quot;&gt;\r\n&lt;div id=&quot;comp-jqjmd9c7&quot; class=&quot;txtNew&quot; data-packed=&quot;true&quot;&gt;\r\n&lt;div id=&quot;comp-jqjzmpqd&quot; class=&quot;txtNew&quot; data-packed=&quot;true&quot;&gt;\r\n&lt;h1 class=&quot;font_0&quot;&gt;&lt;span class=&quot;color_15&quot;&gt;LOW VISION AID CLINIC&lt;/span&gt;&lt;/h1&gt;\r\n&lt;/div&gt;\r\n&lt;div id=&quot;comp-jqjzmpqj&quot; class=&quot;txtNew&quot; data-packed=&quot;false&quot; data-min-height=&quot;222&quot;&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;Low vision optical devices include a variety of devices, such as stand and hand-held magnifiers, strong magnifying reading glasses, loupes, and small telescopes. These devices can provide greatly increased magnification powers and prescription strengths, along with higher-quality optics (i.e., the way the lens bends or refracts light) and are different from regular glasses and commercially available magnifiers.&lt;/p&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;&nbsp;&lt;/p&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;Low vision optical devices are task-specific. You can think of them as being similar to &quot;tools&quot; that are used to build a house&mdash;different tools for different tasks. Therefore ,we may prescribe several different low vision optical devices for various tasks: One or two devices for&nbsp;&lt;a href=&quot;http://www.visionaware.org/info/everyday-living/essential-skills/reading-writing-and-vision-loss/12&quot; target=&quot;_blank&quot; rel=&quot;undefined noopener noreferrer&quot; data-content=&quot;http://www.visionaware.org/info/everyday-living/essential-skills/reading-writing-and-vision-loss/12&quot; data-type=&quot;external&quot;&gt;reading&lt;/a&gt;, another for watching television and seeing faces, another for seeing the&nbsp;&lt;a href=&quot;http://www.visionaware.org/info/everyday-living/essential-skills/reading-writing-and-vision-loss/using-a-computer/1234&quot; target=&quot;_blank&quot; rel=&quot;undefined noopener noreferrer&quot; data-content=&quot;http://www.visionaware.org/info/everyday-living/essential-skills/reading-writing-and-vision-loss/using-a-computer/1234&quot; data-type=&quot;external&quot;&gt;computer screen&lt;/a&gt;, and yet another for&nbsp;&lt;a href=&quot;http://www.visionaware.org/info/everyday-living/recreation-and-leisure/arts-and-crafts/sewing-and-embroidery/1234&quot; target=&quot;_blank&quot; rel=&quot;undefined noopener noreferrer&quot; data-content=&quot;http://www.visionaware.org/info/everyday-living/recreation-and-leisure/arts-and-crafts/sewing-and-embroidery/1234&quot; data-type=&quot;external&quot;&gt;sewing&lt;/a&gt;.&nbsp;&lt;/p&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;&nbsp;&lt;/p&gt;\r\n&lt;p class=&quot;font_8&quot;&gt;We may also recommend&nbsp;&lt;a href=&quot;http://www.visionawar/&quot; target=&quot;_blank&quot; rel=&quot;undefined noopener noreferrer&quot; data-content=&quot;http://www.visionawar&quot; data-type=&quot;external&quot;&gt;sunglasses&lt;/a&gt;&nbsp;to reduce glare, protect your eyes from ultraviolet (UV) and blue light, and enhance your ability to see more clearly in different lighting conditions.&lt;/p&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;',1,39,'LOW VISION AID CLINIC',NULL,'','0','0','','2019-07-01 17:18:17','2019-07-01 17:18:17',NULL),(28,'&lt;div class=&quot;s-12 m-6 l-3&quot; style=&quot;color: #000000; font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;&quot;&gt;\r\n&lt;p&gt;&lt;img src=&quot;../../storage/uploads/kLUiWZPJCwDHTCLA6mOh0sFgyd7HnieUTM83aA2y.jpeg&quot; width=&quot;478&quot; height=&quot;130&quot; /&gt;&lt;/p&gt;\r\n&lt;/div&gt;\r\n&lt;div class=&quot;s-12 m-12 l-8&quot; style=&quot;color: #000000; font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;&quot;&gt;\r\n&lt;p style=&quot;text-align: justify;&quot;&gt;&lt;strong&gt;LENS IMPLANT&lt;/strong&gt;&lt;br /&gt;&lt;br /&gt;Twenty five years ago the usual treatment for cataracts was removal of the clouded lens followed by wearing glasses with very thick lenses, while presbyopia required the use of reading glasses.&nbsp;&lt;br /&gt;&lt;br /&gt;Today, due to the amazing advancements in IOL technology, a patient can hope for and achieve good to excellent vision quality from a lens implant without the need for glasses at all.&nbsp;&lt;br /&gt;A lens implant or intraocular lens (IOL) is an implanted synthetic lens that replaces the eye&#039;s natural lens.&lt;br /&gt;&lt;br /&gt;Depending on the type selected, an IOL can also correct the eye&#039;s existing refractive error (nearsightedness or farsightedness) and a patient who has received an IOL can still have his or her vision further improved with laser vision correction.&lt;br /&gt;&lt;br /&gt;The type of lifestyle IOL determines the quality of vision improvement.&lt;/p&gt;\r\n&lt;hr style=&quot;cursor: default; color: #000000; font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;&quot; /&gt;\r\n&lt;p style=&quot;text-align: justify;&quot;&gt;&nbsp;&lt;/p&gt;\r\n&lt;p style=&quot;text-align: justify;&quot;&gt;&lt;strong&gt;MONOFOCAL IOL&lt;/strong&gt;&lt;/p&gt;\r\n&lt;p style=&quot;text-align: justify;&quot;&gt;Monofocal IOLs are the &#039;standard&#039; or conventional type of lifestyle IOL. By definition, a monofocal IOL provides good vision correction for one distance only. The power of the lens is pre-calculated for each individual, generally for far vision. However, some patients, with their doctor&#039;s recommendation, may choose to correct for near vision. If corrected for far vision, glasses for reading will still be needed and patients with astigmatism may still require glasses to sharpen their distance vision.&lt;/p&gt;\r\n&lt;hr style=&quot;cursor: default; color: #000000; font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;&quot; /&gt;\r\n&lt;p style=&quot;text-align: justify;&quot;&gt;&lt;br /&gt;&lt;strong&gt;MULTIFOCAL IOL&lt;/strong&gt;&lt;br /&gt;&lt;br /&gt;&lt;/p&gt;\r\n&lt;p style=&quot;text-align: justify;&quot;&gt;Multifocal IOLs provide vision correction at all distances. Multifocal IOLs are more costly and generally not fully covered by insurance, but are frequently preferred over monofocal IOLs because they can reduce or completely eliminate the need for reading glasses.&lt;/p&gt;\r\n&lt;hr style=&quot;cursor: default; color: #000000; font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;&quot; /&gt;\r\n&lt;p style=&quot;text-align: justify;&quot;&gt;&lt;br /&gt;&lt;strong&gt;PRESBYOPIA&lt;/strong&gt;&lt;br /&gt;&lt;strong&gt;&lt;br /&gt;The surgical procedure for presbyopia is essentially the same as for cataracts and offers a permanent solution to the effects of this cause of impaired vision.&lt;/strong&gt;&lt;/p&gt;\r\n&lt;p style=&quot;text-align: justify;&quot;&gt;The direct translation of presbyopia is &quot;elder eye&quot;. This condition is due to the loss of flexibility of the natural lens of the eye.&lt;br /&gt;As a person ages beyond his or her 40s, the lens gradually becomes more rigid and the eye muscles can no longer flex enough to focus for close-up vision. In the past, presbyopia was usually addressed with bifocal lenses, reading glasses, or monovision contact lenses.&lt;br /&gt;&lt;br /&gt;&lt;strong&gt;Common symptoms of presbyopia are:&lt;/strong&gt;&lt;br /&gt;1. Difficulty reading fine print, particularly in low light conditions&lt;br /&gt;2. Eyestrain when reading for long periods&lt;br /&gt;3. Blurred near vision&lt;br /&gt;4. Difficulty transitioning between viewing distances from close to far&lt;br /&gt;5. The feeling that your arms have become &quot;too short&quot; to hold reading material at a comfortable distance&lt;/p&gt;\r\n&lt;p style=&quot;text-align: justify;&quot;&gt;&nbsp;&lt;/p&gt;\r\n&lt;hr style=&quot;cursor: default; color: #000000; font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;&quot; /&gt;\r\n&lt;p style=&quot;text-align: justify;&quot;&gt;&lt;br /&gt;&lt;strong&gt;THE PROCEDURE&lt;/strong&gt;&lt;/p&gt;\r\n&lt;p style=&quot;text-align: justify;&quot;&gt;&nbsp;&lt;/p&gt;\r\n&lt;p style=&quot;text-align: justify;&quot;&gt;More than three million cataract surgeries are performed in each year.&nbsp;&lt;br /&gt;&lt;em&gt;Cataract surgery is considered one of the safest and most effective of all medical procedures.&lt;/em&gt;&lt;br /&gt;The virtually painless procedure usually takes 15-30 minutes. The surgeon makes a small incision at or near the cornea and removes the cloudy or inflexible lens. The new lens (IOL) is then inserted into its permanent position.&lt;br /&gt;The most advanced type of surgical procedure &ndash; and the one performed at Vatsal eye care &ndash; is called phacoemulsification, which does not require needles or stitches.&lt;br /&gt;With this advanced technique the affected lens is removed and replaced with an IOL. Clear vision is restored and the eye heals rapidly. More than 97% of patients who undergo phacoemulsification experience no complications at all.&lt;br /&gt;Patients can usually return to their normal activities the following day.&lt;br /&gt;&lt;br /&gt;&lt;em&gt;&lt;strong&gt;Contrary to popular myth a cataract does not have to be &quot;ripe&quot; before it is removed.&lt;br /&gt;You should consider having surgery if cataracts make it hard for you to see well&lt;br /&gt;enough to do the things you enjoy.&lt;/strong&gt;&lt;/em&gt;&lt;/p&gt;\r\n&lt;hr style=&quot;cursor: default; color: #000000; font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;&quot; /&gt;\r\n&lt;p style=&quot;text-align: justify;&quot;&gt;&lt;br /&gt;&lt;strong&gt;Understanding cataracts&nbsp;&lt;br /&gt;&lt;br /&gt;What is a cataract?&lt;/strong&gt;&lt;br /&gt;&lt;br /&gt;Some vision problems like nearsightedness, farsightedness and astigmatism affect us from birth because they are related to irregularities of the cornea. Others, like the development of&nbsp;cataracts, slowly creep up on us as we age.&lt;/p&gt;\r\n&lt;p style=&quot;text-align: justify;&quot;&gt;A cataract is a&quot;clouding&quot; of the eye&#039;s natural lens, which results in blurred or defocused vision. Cataracts are often described as looking through wax paper or cloudy cellophane. People with cataracts also have color differentiation issues and may not be able to tell the difference between two black socks. In most cases cataract surgery is required where the natural lens is replaced with a man made lens, often referred to as IOL or intraocular lens.&nbsp;&lt;strong&gt;This surgery is highly successful and has been drastically improved over the years.&lt;/strong&gt;&lt;br /&gt;&lt;br /&gt;&lt;/p&gt;\r\n&lt;hr style=&quot;cursor: default; color: #000000; font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;&quot; /&gt;\r\n&lt;p style=&quot;text-align: justify;&quot;&gt;&lt;strong&gt;&lt;br /&gt;WHAT ARE SYMPTOMS OF CATARACT?&lt;/strong&gt;&lt;br /&gt;&lt;br /&gt;&lt;/p&gt;\r\n&lt;p style=&quot;text-align: justify;&quot;&gt;1. Blurred or cloudy vision&lt;br /&gt;2. Colors appear faded or dull&lt;br /&gt;3. Lamps such as headlights or streetlights have glare or halos; sunlight may appear too bright&lt;br /&gt;4. Poor night vision&lt;br /&gt;5. Double or multiple vision in one eye; this effect may disappear as the cataract grows&lt;br /&gt;6. Frequent prescription changes in your eyeglasses or contact lenses&lt;br /&gt;&lt;br /&gt;&lt;strong&gt;Important Note:&nbsp;&lt;/strong&gt;These symptoms can indicate other eye problems that may also result in blindness if left untreated. If you have any of these symptoms, make an appointment with Vatsal eye care immediately for a complete eye examination.&nbsp;&lt;br /&gt;&lt;br /&gt;&lt;/p&gt;\r\n&lt;hr style=&quot;cursor: default; color: #000000; font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;&quot; /&gt;\r\n&lt;p style=&quot;text-align: justify;&quot;&gt;&lt;br /&gt;&lt;strong&gt;WHAT CAN I EXPECT FROM CATARACT SURGERY?&lt;/strong&gt;&lt;br /&gt;&lt;br /&gt;&lt;/p&gt;\r\n&lt;p style=&quot;text-align: justify;&quot;&gt;Cataract surgery is almost always highly successful. Over 90% of patients who have the surgery enjoy improved vision. Many patients find that their vision improvement begins immediately and they can often resume normal activities within hours after surgery.&lt;br /&gt;Some find their vision better than ever after the procedure, while others may need to wear glasses for reading (known as Presbyopia) and other activities.&lt;br /&gt;During the initial healing period there may be a few limitations on strenuous activities, but most people can return to normal life quickly. They are surprised to find that they can also engage in activities that were once off-limits due to cataracts, such as reading and social activities. Of course, there is some risk with any surgery, and a perfect result, no matter how likely, cannot be guaranteed. Make sure you discuss the surgery in detail with us, and get all of your questions answered. At Vatsal eye care, we welcome and encourage our patients&#039; questions.&lt;/p&gt;\r\n&lt;p style=&quot;text-align: justify;&quot;&gt;&nbsp;&lt;/p&gt;\r\n&lt;hr style=&quot;cursor: default; color: #000000; font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;&quot; /&gt;\r\n&lt;p style=&quot;text-align: justify;&quot;&gt;&nbsp;&lt;/p&gt;\r\n&lt;p style=&quot;text-align: justify;&quot;&gt;&nbsp;&lt;/p&gt;\r\n&lt;p style=&quot;text-align: justify;&quot;&gt;&lt;strong&gt;WHAT CAUSES CATARACT?&lt;/strong&gt;&lt;br /&gt;&lt;br /&gt;Researchers believe that there are several causes:&lt;br /&gt;&lt;br /&gt;1. Aging&lt;br /&gt;2. Diabetes&lt;br /&gt;3. Long-term exposure to ultraviolet light&lt;br /&gt;4. Exposure to radiation&lt;br /&gt;5. Hypertension&lt;br /&gt;6. Smoking&lt;br /&gt;7. Alcohol abuse&lt;br /&gt;8. Eye injuries&lt;br /&gt;9. Genetic factors (a parent or grandparent who had cataracts)&lt;br /&gt;&lt;br /&gt;In the early stages of cataracts, one sees colors less vibrantly. In the later stages, the lens becomes almost opaque and has to be replaced with a clear artificial lens. This procedure is called refractive lens exchange.&lt;br /&gt;&lt;br /&gt;&lt;strong&gt;Currently, there are no medications, eye drops, exercises or glasses that will&lt;br /&gt;cause cataracts to disappear. Cataracts can only be treated surgically.&lt;/strong&gt;&lt;/p&gt;\r\n&lt;p style=&quot;text-align: justify;&quot;&gt;&lt;strong&gt;THE FUTURE IS BRIGHT FOR PEOPLE WITH CATARACTS!&lt;/strong&gt;&lt;/p&gt;\r\n&lt;p style=&quot;text-align: justify;&quot;&gt;&lt;strong&gt;&lt;em&gt;With treatment, most can enjoy better!!&lt;/em&gt;&lt;/strong&gt;&lt;/p&gt;\r\n&lt;/div&gt;',1,41,'Cataracts and Lens Implants',NULL,'','0','0','','2019-07-07 06:30:01','2019-07-07 06:30:01',NULL),(29,'&lt;div class=&quot;s-12 m-6 l-3&quot; style=&quot;color: #000000; font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;&quot;&gt;\r\n&lt;p&gt;&lt;img src=&quot;../../storage/uploads/WeTakK8xlM4GEa2otFg3fjn3Uyun6b5UiLAMOPW6.jpeg&quot; width=&quot;478&quot; height=&quot;130&quot; /&gt;&lt;/p&gt;\r\n&lt;/div&gt;\r\n&lt;div class=&quot;s-12 m-12 l-8&quot; style=&quot;color: #000000; font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;&quot;&gt;\r\n&lt;p style=&quot;text-align: left;&quot;&gt;&lt;strong&gt;&nbsp;&lt;/strong&gt;&lt;/p&gt;\r\n&lt;h2 style=&quot;text-align: justify;&quot;&gt;RETINA CLINIC&lt;/h2&gt;\r\n&lt;p style=&quot;text-align: justify;&quot;&gt;The retina is the innermost nerve layer that lines the back of the eye. Many ophthalmologists compare this to the film of a camera. The retina is responsible for processing the images projected onto it and then the optic nerve transmits this to the brain. The retina is susceptible to many types of diseases that we will detail in the web pages of this section.&nbsp;&lt;/p&gt;\r\n&lt;p style=&quot;text-align: justify;&quot;&gt;&nbsp;&lt;/p&gt;\r\n&lt;p style=&quot;text-align: justify;&quot;&gt;&lt;strong&gt;What is a retina specialist?&lt;/strong&gt;&nbsp;&lt;br /&gt;&lt;br /&gt;A retina specialist is a medical doctor trained as an ophthalmologist, who has received additional fellowship training in diseases and surgery of the vitreous and retina. As mentioned previously, the retina is a very sensitive part of the eye that requires special attention when in danger. Damage to your retina can cause blindness. Much of the treatment work done by retina specialists involves: macular degeneration, diabetic eye disease, retinal detachments, uveitis, and flashes or floaters.&nbsp;&lt;strong&gt;Dr&nbsp;Amol Mhatre has immense experience in this stream and is highly skilled in handling any Vitreoretinal disorders.&lt;br /&gt;&lt;/strong&gt;&lt;/p&gt;\r\n&lt;p style=&quot;text-align: justify;&quot;&gt;&nbsp;&lt;/p&gt;\r\n&lt;p style=&quot;text-align: justify;&quot;&gt;&lt;strong&gt;What are the common problems associated with the retina?&lt;/strong&gt;&lt;br /&gt;1. Retinal Detachment&lt;br /&gt;2. Macular Degeneration&lt;br /&gt;3. Diabetic Eye Disease&lt;br /&gt;4. Flashes &amp; Floaters&lt;br /&gt;5. Macular Edema&lt;br /&gt;6. Retinitis Pigmentosa&lt;/p&gt;\r\n&lt;p style=&quot;text-align: justify;&quot;&gt;&nbsp;&lt;/p&gt;\r\n&lt;p style=&quot;text-align: justify;&quot;&gt;&lt;strong&gt;What do I do if I have been told I have issues with the retina?&lt;/strong&gt;&lt;br /&gt;&lt;br /&gt;The retina is one of the most sensitive parts of the eye. If you have been told that you have retina eye problems or have been told that you have macular degeneration, macular edema, diabetic eye disease, or a retinal detachment you will have to seek the immediate retina specialist.&nbsp;&lt;br /&gt;A retinal detachment is a very serious problem that almost always causes blindness unless it is treated. As a person&#039;s normal eye ages the vitreous gel contracts and then becomes more liquid. As the vitreous gel becomes more liquid it may pull on the retina and create a retinal tear (and then tear.) When fluid passes through a tear, it will lift the retina from the back of the eye creating (making) a retinal detachment.&nbsp;&lt;br /&gt;&lt;br /&gt;Your eye doctor has ways to assess your risk for developing glaucoma and can prescribe treatments to help prevent or delay vision loss if you have glaucoma.&lt;/p&gt;\r\n&lt;/div&gt;',1,42,'Retina',NULL,'','0','0','','2019-07-07 06:34:50','2019-07-07 06:34:50',NULL),(30,'&lt;div class=&quot;s-12 m-6 l-3&quot; style=&quot;color: #000000; font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;&quot;&gt;\r\n&lt;p&gt;&nbsp;&lt;/p&gt;\r\n&lt;div class=&quot;image-with-hover-overlay image-hover-zoom margin-bottom&quot;&gt;&lt;img src=&quot;../../storage/uploads/e16sjFixbT1H8jBEbxuDjNgKWxpL3TMHRZfkdMQ9.jpeg&quot; width=&quot;478&quot; height=&quot;130&quot; /&gt;&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;div class=&quot;s-12 m-12 l-8&quot; style=&quot;color: #000000; font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;&quot;&gt;\r\n&lt;p style=&quot;text-align: left;&quot;&gt;&lt;strong&gt;&nbsp;&lt;/strong&gt;&lt;/p&gt;\r\n&lt;h2 style=&quot;text-align: justify;&quot;&gt;GLAUCOMA&lt;/h2&gt;\r\n&lt;p style=&quot;text-align: justify;&quot;&gt;&lt;strong&gt;The sneak thief of sight&lt;/strong&gt;&lt;br /&gt;&lt;br /&gt;Glaucoma, often called the &quot;sneak thief of sight,&quot; is a disease that strikes without any obvious symptoms. You usually don&#039;t even know it&#039;s there until serious vision loss has occurred. And unfortunately, there is no cure for glaucoma. Once you have lost your vision, it can&#039;t be restored. The good news is that glaucoma can be detected early before there is any loss of vision. Plus, there are convenient treatments that can lower intraocular pressure (IOP), one of the major risk for glaucoma. The key to managing diseases that cause vision loss are early diagnosis, proper treatment, and regular eye exams.&nbsp;&lt;br /&gt;&lt;br /&gt;&lt;strong&gt;Why is glaucoma the main suspect?&lt;/strong&gt;&lt;br /&gt;&lt;br /&gt;Glaucoma is an eye disease that involves damage to the optic nerve which sends visual signals to the brain. No one knows exactly what causes this damage, but pressure buildup in the eye is proven to be one of the major risk factors associated with glaucoma . When the optic nerve gets damaged by high IOP, some signals from the eye aren&#039;t transmitted tothe brain. This can result in visual field loss, and if not managed, could eventually lead to blindness.&lt;br /&gt;&lt;br /&gt;There are several different types of glaucoma. The most common is called open angle glaucoma which accounts for about 80% of all cases. It develops slowly over time, usually after the age of 40. Patients with this type of glaucoma may experience a gradual narrowing of their peripheral vision, which many call &quot;tunnel vision,&quot; or areas of vision loss.&lt;br /&gt;&lt;br /&gt;&lt;strong&gt;Why is IOP (Intraocular pressure) such an important clue?&lt;/strong&gt;&lt;br /&gt;&lt;br /&gt;The front of the eye is filled with a liquid called the aqueous humor. This is produced by the eye to bathe and nourish its different parts. The aqueous humor normally flows out of the eye through various paths and chambers. When these paths get clogged aqueous humor gets trapped in the eye. This causes a pressure build up and leads to high IOP.&lt;br /&gt;&lt;br /&gt;Doctors can easily measure IOP, and use it as an important clue in the diagnosis and treatment of glaucoma. Normal IOP is about 12 to 22 mm Hg. One of the most common and important tests for meausuring IOP is Tonometry. Tonometry is a procedure in which your doctor uses a tonometer to measure IOP. This test is important because high IOP is a major risk factor for glaucoma. However, high IOP doesn&#039;t necessarily mean you will have glaucoma, nor does normal IOP mean you don&#039;t have glaucoma. Controlling IOP is the major goal of glaucoma therapy. When IOP is controlled, the optic nerve is less at risk of being damaged, so vision may be preserved.&lt;br /&gt;&lt;br /&gt;&lt;strong&gt;Could I become a victim?&lt;/strong&gt;&lt;br /&gt;&lt;br /&gt;Glaucoma is one of the most common causes of preventable blindness. One out of every five sufferers has a close relative with it. Could you be one of these people? Only your doctor can help you find out, but some people are at greater risk than others. Studies have proven that anyone who meets one or more of the following criteria is at increased risk: If you have any of these risk factors, it is important that you get regular eye checkups.&nbsp;&lt;strong&gt;Early detection and treatment of glaucoma can slow the disease&#039;s progression and help prevent blindness.&lt;/strong&gt;&lt;br /&gt;&lt;br /&gt;&lt;strong&gt;How can glaucoma be stopped?&lt;/strong&gt;&lt;br /&gt;&lt;br /&gt;It&#039;s awfully hard to stop glaucoma completely, but we have years of research that shows that treating the disease early helps preserve vision. The primary effect of any glaucoma treatment is lowering IOP. This has been proven over the years to be an effective way to help prevent or slow down vision loss in glaucoma patients. IOP canbe lowered with medication and/or surgery. In most cases, medication is used before surgery, which is often reserved for patients who haven&#039;t responded adequately to or are intolerant of medications. Most glaucoma patients instil eye drops to keep their eye pressures at a safe level. A patient may be on one, two or more different glaucoma eye drops. Laser treatment (laser trabeculoplasty) is a very safe and generally painless way to treat glaucoma and should be considered for all newly diagnosed cases of glaucoma. Successful laser treatment can keep the eye pressure down for many years without requiring eye drops. (The laser used is very different from the laser used to allow people to manage without glasses.) Surgery is also used to treat glaucoma: it is employed when the eye pressure cannot be controlled by drops and laser, and when patients cannot tolerate eye drops. Having glaucoma means that you must have a life-long association with your ophthalmologist.&nbsp;&lt;br /&gt;&lt;br /&gt;The disease can be controlled but not cured, and it is essential that patients are seen regularly (for most this is six monthly).&nbsp;&lt;br /&gt;&lt;br /&gt;&lt;strong&gt;The best way to control glaucoma and preserve your vision is through early detection and treatment.&lt;/strong&gt;&lt;br /&gt;&lt;br /&gt;Glaucoma is often referred to as &quot;the sneak thief of sight&quot; because it strikes without any obvious symptoms. Luckily, your doctor, who is a great detective, has tools to catch the early warning signs of glaucoma. If you have any of the risk factors for glaucoma or are over age 40, you should schedule an exam with an eye care professional.&lt;/p&gt;\r\n&lt;/div&gt;',1,43,'Glaucoma',NULL,'','0','0','','2019-07-07 06:37:53','2019-07-07 06:37:53',NULL),(31,'&lt;div class=&quot;s-12 m-6 l-3&quot; style=&quot;color: #000000; font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;&quot;&gt;\r\n&lt;div class=&quot;image-with-hover-overlay image-hover-zoom margin-bottom&quot;&gt;&lt;img src=&quot;../../storage/uploads/FuIAzOOjZL4S8LR46aKfD0gBkw3lLl16F6xY4ERy.jpeg&quot; width=&quot;478&quot; height=&quot;130&quot; /&gt;&lt;/div&gt;\r\n&lt;div class=&quot;image-with-hover-overlay image-hover-zoom margin-bottom&quot;&gt;&nbsp;&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;div class=&quot;s-12 m-12 l-8&quot; style=&quot;color: #000000; font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;&quot;&gt;\r\n&lt;p style=&quot;text-align: left;&quot;&gt;&lt;strong&gt;&nbsp;&lt;/strong&gt;&lt;/p&gt;\r\n&lt;h2 style=&quot;text-align: justify;&quot;&gt;LASIK&nbsp;&lt;/h2&gt;\r\n&lt;p style=&quot;text-align: justify;&quot;&gt;&lt;strong&gt;LASIK IS THE SMARTEST CHOICE FOR VISION CORRECTION!!&lt;/strong&gt;&lt;br /&gt;If you&#039;re one of the thousands of them who are suffering from nearsightedness, farsightedness or astigmatism, you&#039;ll know the impact a vision imperfection can have on your life&hellip; Glasses and contacts can be irritating to wear, easily lost or damaged and prevent you from doing the things you love. Playing sports, swimming, driving a car, pursuing a careerin the police,armed forces or aviation industry- they can all become more difficult!!&lt;br /&gt;&lt;br /&gt;&lt;strong&gt;LASIK SURGERY IS TRUSTED BY MILLIONS&lt;/strong&gt;&lt;br /&gt;When you choose LASIK, YOU&#039;LL BE JOINING MILLIONS OF PEOPLE WHO HAVE WAVED GOODBYE TO THE HASSLE AND RESTRICTIONS OF GLASSES AND CONTACTS FOR GOOD.&lt;br /&gt;&lt;br /&gt;1. Lasik is the most popular elective procedure vin the world.&lt;br /&gt;2. Over 32 million people worldwide owe their clear vision to LASIK.&lt;br /&gt;3. LASIK has been successfully used to correct vision since 1991&lt;br /&gt;4. LASIK is fast, safe and virtually painless&lt;br /&gt;&lt;br /&gt;Its natural to be a little scared of a medical procedure that involves your eyes. But with LASIK there is no need to be afraid. Its one of the safest and the most reliable procedures.&lt;/p&gt;\r\n&lt;/div&gt;',1,44,'Lasik',NULL,'','0','0','','2019-07-07 06:40:24','2019-07-07 06:40:44',NULL),(32,'&lt;div class=&quot;s-12 m-6 l-3&quot; style=&quot;color: #000000; font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;&quot;&gt;\r\n&lt;div class=&quot;image-with-hover-overlay image-hover-zoom margin-bottom&quot;&gt;&lt;img src=&quot;../../storage/uploads/JmOVmbNpRSMyWr7ZaEOPJxd8NU81JUZ0sB0PrKFj.jpeg&quot; width=&quot;478&quot; height=&quot;130&quot; /&gt;&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;div class=&quot;s-12 m-12 l-8&quot; style=&quot;color: #000000; font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;&quot;&gt;\r\n&lt;p style=&quot;text-align: left;&quot;&gt;&lt;strong&gt;&nbsp;&lt;/strong&gt;&lt;/p&gt;\r\n&lt;h2 style=&quot;text-align: justify;&quot;&gt;PEDIATRIC&nbsp;&lt;/h2&gt;\r\n&lt;p style=&quot;text-align: justify;&quot;&gt;&lt;strong&gt;Paediatric Ophthalmology and Squint Services&lt;/strong&gt;&lt;br /&gt;We provide treatment for an extensive range of paediatric eye problems such as sight-threatening conditions like paediatric glaucoma, cataract and congenital opacities of the cornea.&lt;br /&gt;We also have comprehensive services in:&lt;br /&gt;&lt;br /&gt;1. The management of squint, double vision and other disorders of eye alignment&lt;br /&gt;2. The management of amblyopia or lazy eyes&lt;br /&gt;3. Refraction in young children using eyedrops&lt;br /&gt;4. General eye problems such as eye sore, allergic conjunctivitis and lumps on the eyelids&lt;br /&gt;5. Retinopathy of prematurity: Dr Pritam Dedhia is highly experienced in handling ROP cases and lasers in premature infants.&lt;/p&gt;\r\n&lt;/div&gt;',1,45,'Pediatric Treatment',NULL,'','0','0','','2019-07-07 06:42:22','2019-07-07 06:42:22',NULL),(33,'&lt;div class=&quot;s-12 m-6 l-3&quot; style=&quot;color: #000000; font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;&quot;&gt;\r\n&lt;p&gt;&nbsp;&lt;/p&gt;\r\n&lt;div class=&quot;image-with-hover-overlay image-hover-zoom margin-bottom&quot;&gt;&lt;img src=&quot;../../storage/uploads/mfniMfRmJ8yPMrIMpDyJ3pAn67VKvhFDY2oK5EJl.jpeg&quot; width=&quot;478&quot; height=&quot;130&quot; /&gt;&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;div class=&quot;s-12 m-12 l-8&quot; style=&quot;color: #000000; font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;&quot;&gt;\r\n&lt;p style=&quot;text-align: left;&quot;&gt;&lt;strong&gt;&nbsp;&lt;/strong&gt;&lt;/p&gt;\r\n&lt;h2 id=&quot;what&quot; style=&quot;text-align: justify;&quot;&gt;&lt;strong&gt;What is Implantable Collamer Lens (ICL) surgery?&nbsp;&lt;/strong&gt;&lt;/h2&gt;\r\n&lt;p style=&quot;text-align: justify;&quot;&gt;Implantable Collamer Lens surgery (ICL), as the name itself suggests, is a procedure, wherein a pair of lens is implanted into the eyes which do not require to be removed like normal contact lenses. These lenses are similar to contact lenses but are inserted within the eyes for long-term vision correction. These lenses, therefore, work with the natural lens of your eyes to improve your vision. During the procedure, the lens is inserted between your iris and your natural lens thru a tiny incision near the cornea.&lt;/p&gt;\r\n&lt;h2 id=&quot;how&quot; style=&quot;text-align: justify;&quot;&gt;&lt;strong&gt;How is ICL surgery performed?&nbsp;&lt;/strong&gt;&lt;/h2&gt;\r\n&lt;p style=&quot;text-align: justify;&quot;&gt;ICl surgery consists of two separate procedures:&lt;/p&gt;\r\n&lt;ul style=&quot;text-align: justify;&quot;&gt;\r\n&lt;li&gt;The pre-procedure (iridotomy)&lt;/li&gt;\r\n&lt;li&gt;The main procedure (ICL)&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;p style=&quot;text-align: justify;&quot;&gt;The Pre-procedure (Iridotomy)&lt;/p&gt;\r\n&lt;ul style=&quot;text-align: justify;&quot;&gt;\r\n&lt;li&gt;This procedure known as iridotomy is performed at least two weeks prior to the surgery.&lt;/li&gt;\r\n&lt;li&gt;At the outset, the doctor applies anesthesia drops on the eyes to numb the surface of the eyes. An eyelid holder is used to keep your eyelids open and prevent you from blinking during the procedure.&lt;/li&gt;\r\n&lt;li&gt;The surgeon then makes one or two small holes in the edge of the iris (the coloured part of the eye), using laser, to ensure that there will be no intraocular fluid build-up behind the implanted lenses after the surgery, which can lead to glaucoma.&lt;/li&gt;\r\n&lt;li&gt;This procedure takes only a few seconds and prevents pressure build-up after the implant.&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;p style=&quot;text-align: justify;&quot;&gt;The Main ICL Procedure&lt;/p&gt;\r\n&lt;ul style=&quot;text-align: justify;&quot;&gt;\r\n&lt;li&gt;On the day of the surgery, the doctor applies anesthetic drops on your eye to numb it.&lt;/li&gt;\r\n&lt;li&gt;Eyelids holders are used to keep your eyelids open and prevent you from blinking.&lt;/li&gt;\r\n&lt;li&gt;The surgeon makes two tiny micro incisions at the base of the cornea.&lt;/li&gt;\r\n&lt;li&gt;Through the incisions, he injects the lens into the eye. The lens is positioned behind the iris and in front of the natural lens.&lt;br /&gt;(&lt;strong&gt;Please Note:&lt;/strong&gt;&nbsp;The lens is folded in a cartridge, and as soon as it is injected into the eye, it unfolds itself. Since the lens is made of highly biocompatible material it is not perceived as a foreign object by the immune system of the body.)&lt;/li&gt;\r\n&lt;li&gt;A gel-like substance is placed in your eye, to keep your eye safe while the lens is being positioned.&lt;/li&gt;\r\n&lt;li&gt;After the positioning of the lens, the gel is removed from the eye.&lt;/li&gt;\r\n&lt;li&gt;The surgeon then applies eyedrops on your eye to prevent inflammation and infection.&lt;br /&gt;&lt;br /&gt;&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;p style=&quot;text-align: justify;&quot;&gt;You will be required to continue with the eye drops for a number of days.&nbsp;&lt;/p&gt;\r\n&lt;p style=&quot;text-align: justify;&quot;&gt;Once this procedure is complete and you will notice the difference in vision quality immediately.&nbsp;&lt;/p&gt;\r\n&lt;p style=&quot;text-align: justify;&quot;&gt;The same procedure will be repeated with the other eye after a span of 2-4 weeks. &nbsp;&lt;/p&gt;\r\n&lt;p style=&quot;text-align: justify;&quot;&gt;There are exceptions though, depending on the patient&rsquo;s condition sometimes both the eyes are operated on the same day.&nbsp;&lt;/p&gt;\r\n&lt;h2 id=&quot;side effects&quot; style=&quot;text-align: justify;&quot;&gt;&lt;strong&gt;What are the side effects of ICL surgery?&nbsp;&lt;/strong&gt;&lt;/h2&gt;\r\n&lt;p style=&quot;text-align: justify;&quot;&gt;The iridotomy procedure performed in the first stage of the ICL surgery may have side effects such as:&lt;/p&gt;\r\n&lt;ul style=&quot;text-align: justify;&quot;&gt;\r\n&lt;li&gt;increasing eye pressure for a couple of hours after the procedure,&lt;/li&gt;\r\n&lt;li&gt;glare, or double vision.&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;p style=&quot;text-align: justify;&quot;&gt;More serious side effects of this procedure include:&lt;/p&gt;\r\n&lt;ul style=&quot;text-align: justify;&quot;&gt;\r\n&lt;li&gt;inflammation or iritis&lt;/li&gt;\r\n&lt;li&gt;hyphema or bleeding in the anterior chamber of the eye or the space between the cornea and the iris&lt;/li&gt;\r\n&lt;li&gt;injury to the cornea leading to corneal oedema&lt;/li&gt;\r\n&lt;li&gt;retinal burns&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;p style=&quot;text-align: justify;&quot;&gt;These side effects, though rare, can be treated with medication and/or additional surgeries.&nbsp;&lt;/p&gt;\r\n&lt;p style=&quot;text-align: justify;&quot;&gt;Possible side-effects that may occur post the ICL surgery are:&lt;/p&gt;\r\n&lt;ul style=&quot;text-align: justify;&quot;&gt;\r\n&lt;li&gt;infections&lt;/li&gt;\r\n&lt;li&gt;night glare or halos around light sources&lt;/li&gt;\r\n&lt;li&gt;pressure build-up in the eyes which happens not only if the iridotomy is not big enough, but also if the lenses are too big for your eyes. The size of the eye lenses vary for different people. Although the measurement is taken prior to the surgery, it is not an exact science, and therefore at times, bigger lenses block the little openings made during iridotomy. This can be corrected by removing the bigger lenses and inserting smaller ones. &nbsp;&lt;/li&gt;\r\n&lt;li&gt;overcorrection or under-correction of eyesight. When overcorrection occurs nearsightedness gets altered to farsightedness, and it is vice versa for under-correction. These residual power error conditions can be corrected through enhancement or retreatment surgeries. If however, your cornea is too thin or steep the surgeon will advise you to not go in for additional surgeries and will instead prescribe you glasses or lenses to correct your vision.&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;p style=&quot;text-align: justify;&quot;&gt;&nbsp;&lt;/p&gt;\r\n&lt;p style=&quot;text-align: justify;&quot;&gt;A major advantage ICL surgery has over other refractive surgeries is that unlike other refractive surgeries it does not induce dry eyes.&nbsp;&lt;/p&gt;\r\n&lt;p style=&quot;text-align: justify;&quot;&gt;Please be advised, that ICL does increase the long-term risk of getting cataract earlier in your life.&lt;/p&gt;\r\n&lt;h2 id=&quot;pre-surgery&quot; style=&quot;text-align: justify;&quot;&gt;&lt;strong&gt;Are There Any Pre-Surgery and Post-Surgery Guidelines for ICl surgery?&lt;/strong&gt;&lt;strong&gt;&nbsp;&lt;/strong&gt;&lt;/h2&gt;\r\n&lt;p style=&quot;text-align: justify;&quot;&gt;You need to avoid wearing contact lenses at least 4 weeks prior to the evaluation of your eyes for ICL surgery.&nbsp;&lt;/p&gt;\r\n&lt;p style=&quot;text-align: justify;&quot;&gt;The first stage of ICL surgery is the iridotomy procedure. On the day of the procedure:&lt;/p&gt;\r\n&lt;ul style=&quot;text-align: justify;&quot;&gt;\r\n&lt;li&gt;you need to avoid applying any makeup, creams or lotions on your face and especially around your eyes&lt;/li&gt;\r\n&lt;li&gt;avoid any form of makeup after the procedure&lt;/li&gt;\r\n&lt;li&gt;if you are a diabetic it would be better for you to discuss with your doctor at length about your insulin intake and the effects of the surgery on your condition&lt;/li&gt;\r\n&lt;li&gt;wear something comfortable on the day of the surgery. Avoid wearing pullovers, turtlenecks, or t-shirts and jewellery&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;p style=&quot;text-align: justify;&quot;&gt;After the main ICL surgery you need to:&lt;/p&gt;\r\n&lt;ul style=&quot;text-align: justify;&quot;&gt;\r\n&lt;li&gt;refrain from rubbing your eyes&lt;/li&gt;\r\n&lt;li&gt;wear the protective shield on your eyes for a period of 2 weeks after the surgery, which will prevent you from rubbing your eyes accidentally whilst asleep&lt;/li&gt;\r\n&lt;li&gt;you should avoid direct sunlight and wear sunglasses for at least 1 week after the surgery &nbsp;&lt;/li&gt;\r\n&lt;li&gt;avoid washing your face and avoid shampooing your hair or using face wash or soap on your face for at least three days&lt;/li&gt;\r\n&lt;li&gt;avoid any rigorous forms of exercises including, weightlifting, swimming, yoga, aerobics, for at least 4 weeks&lt;/li&gt;\r\n&lt;li&gt;avoid sexual activity for at least 1-2 weeks&lt;/li&gt;\r\n&lt;li&gt;avoid hot tubs &nbsp;&lt;/li&gt;\r\n&lt;li&gt;avoid bending over for at least 2-4 days after the surgery&lt;/li&gt;\r\n&lt;li&gt;avoid using eye makeup for at least 2 weeks after the surgery. And after that, avoid using your old eye makeup on your eyes which may contain bacteria. &nbsp;&lt;/li&gt;\r\n&lt;li&gt;religiously apply the eye drops given to you after the surgery and also take any medication that is prescribed by the doctor.&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;h2 id=&quot;recovery&quot; style=&quot;text-align: justify;&quot;&gt;&lt;strong&gt;How long will it take to recover from an ICL surgery?&lt;/strong&gt;&lt;/h2&gt;\r\n&lt;p style=&quot;text-align: justify;&quot;&gt;It takes a span of 2-4 weeks for each eye to stabilize after an ICL surgery.&nbsp;&lt;/p&gt;\r\n&lt;p style=&quot;text-align: justify;&quot;&gt;You will notice your improved vision immediately after the surgery. Over the next couple of days as the eye heals you might find the vision becoming blurry suddenly. It gradually stabilizes, and after about a week you should be able to experience optimum vision.&nbsp;&lt;/p&gt;\r\n&lt;p style=&quot;text-align: justify;&quot;&gt;You eye will completely heal over a period of two months. &nbsp;&lt;/p&gt;\r\n&lt;h2 id=&quot;eligible&quot; style=&quot;text-align: justify;&quot;&gt;&lt;strong&gt;Am I eligible or an ideal candidate for ICL surgery?&lt;/strong&gt;&lt;/h2&gt;\r\n&lt;p style=&quot;text-align: justify;&quot;&gt;If you are between 21-45 years of age, are nearsighted (myopic), astigmatism, possess general good health, you have thin corneas (not eligible for LASIK), and do not have a history of glaucoma, iritis, and diabetic retinopathy then you are a good candidate for ICL surgery.&nbsp;&lt;/p&gt;\r\n&lt;p style=&quot;text-align: justify;&quot;&gt;You should also have sufficient anterior chamber depth within your eye. The anterior chamber is the area between the iris and the cornea which is filled with fluid. If it is of the proper size it will have sufficient space for the implanted contact lens.&nbsp;&lt;/p&gt;\r\n&lt;p style=&quot;text-align: justify;&quot;&gt;Your surgeon will confirm the depth of the chamber during the evaluation to determine your candidacy for ICL surgery.&nbsp;&lt;/p&gt;\r\n&lt;p style=&quot;text-align: justify;&quot;&gt;&nbsp;&lt;/p&gt;\r\n&lt;h2 id=&quot;cost&quot; style=&quot;text-align: justify;&quot;&gt;&lt;strong&gt;What is the cost of ICL surgery in India?&nbsp;&lt;/strong&gt;&lt;/h2&gt;\r\n&lt;p style=&quot;text-align: justify;&quot;&gt;Depending on the eye power an ICL procedure in which spherical lenses are required will cost around Rs. 55,000 per eye, and the cylindrical power will cost Rs. 80,000 per eye.&nbsp;&lt;/p&gt;\r\n&lt;h2 id=&quot;results&quot; style=&quot;text-align: justify;&quot;&gt;&lt;strong&gt;Are the results of ICL surgery permanent?&lt;/strong&gt;&lt;/h2&gt;\r\n&lt;p style=&quot;text-align: justify;&quot;&gt;The results of ICL surgery are considered permanent. However, there exists the possibility of early&nbsp;&lt;a href=&quot;https://www.practo.com/health-wiki/cataracts-causes-symptoms-and-treatment/55/article&quot; target=&quot;_blank&quot; rel=&quot;noopener noreferrer&quot;&gt;cataract&lt;/a&gt;, which comes as a side effect of this procedure, in which case, additional&nbsp;&lt;a href=&quot;https://www.practo.com/health-wiki/cataract-surgery-procedure/156/article&quot; target=&quot;_blank&quot; rel=&quot;noopener noreferrer&quot;&gt;cataract surgery&lt;/a&gt;&nbsp;will be required. This may happen when contact occurs between the natural lens of the eye and the ICL. Due to the contact, the natural lens can become opaque. This condition can be treated by&lt;a href=&quot;https://www.practo.com/health-wiki/cataract-surgery-procedure/156/article&quot; target=&quot;_blank&quot; rel=&quot;noopener noreferrer&quot;&gt;&nbsp;cataract surgery&lt;/a&gt;.&nbsp;&lt;/p&gt;\r\n&lt;p style=&quot;text-align: justify;&quot;&gt;During the surgery, the natural lens, as well as the Collamer lens, will be removed and new intraocular lens will be inserted.&lt;br /&gt;If there is no&nbsp;&lt;a href=&quot;https://www.practo.com/health-wiki/cataract-surgery-procedure/156/article&quot; target=&quot;_blank&quot; rel=&quot;noopener noreferrer&quot;&gt;cataract&lt;/a&gt;&nbsp;formation, and no other severe side effects, the ICL procedure is considered to have more or less permanent results.&nbsp;&lt;/p&gt;\r\n&lt;/div&gt;',1,46,'ICL Surgery',NULL,'','0','0','','2019-07-07 06:46:26','2019-07-07 06:46:26',NULL),(34,'&lt;div class=&quot;s-12 m-6 l-3&quot; style=&quot;color: #000000; font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;&quot;&gt;\r\n&lt;p&gt;&nbsp;&lt;/p&gt;\r\n&lt;div class=&quot;image-with-hover-overlay image-hover-zoom margin-bottom&quot;&gt;&lt;img src=&quot;../../storage/uploads/KXxyzv5W1QOCWbV9JKAXxcBXlTau4dISMSKKDCQN.jpeg&quot; width=&quot;478&quot; height=&quot;130&quot; /&gt;&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;div class=&quot;s-12 m-12 l-8&quot; style=&quot;color: #000000; font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;&quot;&gt;\r\n&lt;p style=&quot;text-align: left;&quot;&gt;&lt;strong&gt;&nbsp;&lt;/strong&gt;&lt;/p&gt;\r\n&lt;div class=&quot;itemHeader&quot; style=&quot;color: #000000; font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;&quot;&gt;\r\n&lt;h2 class=&quot;itemTitle&quot; style=&quot;text-align: justify;&quot;&gt;Occuloplasty&lt;/h2&gt;\r\n&lt;/div&gt;\r\n&lt;div class=&quot;itemBody&quot; style=&quot;color: #000000; font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;&quot;&gt;\r\n&lt;div class=&quot;itemFullText&quot;&gt;\r\n&lt;p style=&quot;text-align: justify;&quot;&gt;Occuloplasty( Ocular Aesthetics and ocular oncology)&lt;/p&gt;\r\n&lt;p style=&quot;text-align: justify;&quot;&gt;It gives us immense pleasure to introduce you to the world of ophthalmic plastic surgery. This page is designed to give you the insight to the vast arena of possibilities that plastic surgery can offer you and your loved ones. Be it eye tumor , watering , disfigured face , trauma induced eyelid conditions , we have it all under a single roof of this hospital .&lt;/p&gt;\r\n&lt;p style=&quot;text-align: justify;&quot;&gt;We send excision biopsies, oncology sample to recognised histopathological laboratories . We provide a multidisplinary approach by guiding you the best possible treatment for your eye related oculoplasty condition. We have an oculoplasty clinic for diagnostics and surgical facilities available with a full time working experienced trained oculoplasty surgeons DR. Rahul Deshpande and Dr Nana Jare .&lt;/p&gt;\r\n&lt;p style=&quot;text-align: justify;&quot;&gt;We provide outpatient and in patient services along with best diagnostics and surgical options. We also provide training for interested candidates in our clinic for a period of 3 months/6 months as Short term Oculoplasty Certificate course.&lt;/p&gt;\r\n&lt;h2 style=&quot;text-align: justify;&quot;&gt;Facilities that can be availed.&lt;/h2&gt;\r\n&lt;ul class=&quot;list&quot;&gt;\r\n&lt;li style=&quot;text-align: justify;&quot;&gt;Orbitotomy - Surgical treatment for ocular tumors&lt;/li&gt;\r\n&lt;li style=&quot;text-align: justify;&quot;&gt;Dacryology - Management of epiphora( watering), Surgical procedures like Dacryocystorhinostomy (DCR), Dacryocystectomy (DCT), probing.&lt;/li&gt;\r\n&lt;li style=&quot;text-align: justify;&quot;&gt;Ocular prosthetic eye shells&lt;/li&gt;\r\n&lt;li style=&quot;text-align: justify;&quot;&gt;Ptosis (drooping of eyelids) eyelid surgery&lt;/li&gt;\r\n&lt;li style=&quot;text-align: justify;&quot;&gt;Trauma related cases and their management&lt;/li&gt;\r\n&lt;li style=&quot;text-align: justify;&quot;&gt;Reconstructive procedures.&lt;/li&gt;\r\n&lt;li style=&quot;text-align: justify;&quot;&gt;Lid surgeries like for ectropion, entropion.&lt;/li&gt;\r\n&lt;li style=&quot;text-align: justify;&quot;&gt;Socket reconstructive procedures&lt;/li&gt;\r\n&lt;li style=&quot;text-align: justify;&quot;&gt;Treatment for eye cancers&lt;/li&gt;\r\n&lt;li style=&quot;text-align: justify;&quot;&gt;Botox injections (botulinuim) for facial aesthetics&lt;/li&gt;\r\n&lt;li style=&quot;text-align: justify;&quot;&gt;Congenital eyelid and orbital problems anomalies surgical management&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;',1,47,'Oculoplasty',NULL,'','0','0','','2019-07-07 06:50:52','2019-07-07 06:50:52',NULL),(35,'&lt;div class=&quot;s-12 m-6 l-3&quot; style=&quot;color: #000000; font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;&quot;&gt;\r\n&lt;p&gt;&nbsp;&lt;/p&gt;\r\n&lt;div class=&quot;image-with-hover-overlay image-hover-zoom margin-bottom&quot;&gt;&lt;img src=&quot;../../storage/uploads/4C8tRWsBjQVJ748734dE7YE0hZwTCP622WoTR68G.jpeg&quot; width=&quot;478&quot; height=&quot;130&quot; /&gt;&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;div class=&quot;s-12 m-12 l-8&quot; style=&quot;color: #000000; font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;&quot;&gt;\r\n&lt;p style=&quot;text-align: left;&quot;&gt;&lt;strong&gt;&nbsp;&lt;/strong&gt;&lt;/p&gt;\r\n&lt;h2 style=&quot;text-align: justify;&quot;&gt;EYE CARE&lt;/h2&gt;\r\n&lt;p style=&quot;text-align: justify;&quot;&gt;The eye is a vital organ that provides us with the sense of sight, allowing us to perform countless activities everyday, whether working, reading, writing, driving a car or watching television.Maintaining eye health improves the quality of life for people throughout their lifespan. Proper eye health care helps slow down the processes associated with ageing such as macular degeneration.&lt;/p&gt;\r\n&lt;p style=&quot;text-align: justify;&quot;&gt;&lt;br /&gt;&lt;br /&gt;&lt;/p&gt;\r\n&lt;p style=&quot;text-align: justify;&quot;&gt;&lt;strong&gt;Nutrition for healthy eyes&lt;/strong&gt;&lt;br /&gt;Vitamin A, B, C, E, Lutein, Zeaxanthin, selenium, Lycopene and Zinc are important to maintain healthy eyes. These nutrients are helpful for many types of eye problems like poor vision, cataract, glaucoma, age related macular degeneration. These nutrients help to keep the blood vessels, retina healthy and to slow the ageing of the eye. The following table gives the food sources for vitamins and minerals required for healthy eyes:&lt;br /&gt;&lt;br /&gt;&lt;/p&gt;\r\n&lt;table style=&quot;color: #000000; font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;&quot; border=&quot;1pt solid&quot; align=&quot;left&quot;&gt;\r\n&lt;tbody&gt;\r\n&lt;tr&gt;\r\n&lt;td style=&quot;font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px;&quot;&gt;&lt;strong&gt;Nutrients&lt;/strong&gt;&lt;/td&gt;\r\n&lt;td style=&quot;font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px;&quot;&gt;&lt;strong&gt;Rich Sources&lt;/strong&gt;&lt;/td&gt;\r\n&lt;/tr&gt;\r\n&lt;tr&gt;\r\n&lt;td style=&quot;font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px;&quot;&gt;&nbsp;&lt;/td&gt;\r\n&lt;td style=&quot;font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px;&quot;&gt;&nbsp;&lt;/td&gt;\r\n&lt;/tr&gt;\r\n&lt;tr&gt;\r\n&lt;td style=&quot;font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px;&quot;&gt;Vitamin A&lt;/td&gt;\r\n&lt;td style=&quot;font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px;&quot;&gt;Fish liver oil, liver, carrots, egg, cheese, butter, milk, green vegetables, Yellow and orange fruits and vegetables.&lt;/td&gt;\r\n&lt;/tr&gt;\r\n&lt;tr&gt;\r\n&lt;td style=&quot;font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px;&quot;&gt;Vitamin B&lt;/td&gt;\r\n&lt;td style=&quot;font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px;&quot;&gt;Brewer&#039;s yeast, yeast extract, wheatgerm, complex wholegrain cereals.&lt;/td&gt;\r\n&lt;/tr&gt;\r\n&lt;tr&gt;\r\n&lt;td style=&quot;font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px;&quot;&gt;Vitamin C&lt;/td&gt;\r\n&lt;td style=&quot;font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px;&quot;&gt;Citrus fruits, other fruits including tomatoes, green vegetables, potatoes.&lt;/td&gt;\r\n&lt;/tr&gt;\r\n&lt;tr&gt;\r\n&lt;td style=&quot;font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px;&quot;&gt;Vitamin E&lt;/td&gt;\r\n&lt;td style=&quot;font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px;&quot;&gt;Wheat germ, vegetable oils, wholegrain bread and cereals, green vegetables.&lt;/td&gt;\r\n&lt;/tr&gt;\r\n&lt;tr&gt;\r\n&lt;td style=&quot;font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px;&quot;&gt;Lutein and Zeaxanthin&lt;/td&gt;\r\n&lt;td style=&quot;font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px;&quot;&gt;Spinach, peas and many yellow/orange fruits and vegetables provide lutein. Corn, orange, peppers and certain leafy greens provide Zeaxanthin.&lt;/td&gt;\r\n&lt;/tr&gt;\r\n&lt;tr&gt;\r\n&lt;td style=&quot;font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px;&quot;&gt;Lycopene&lt;/td&gt;\r\n&lt;td style=&quot;font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px;&quot;&gt;Watermelon, papaya, rosehips, and pink grapefruits or guava.&lt;/td&gt;\r\n&lt;/tr&gt;\r\n&lt;tr&gt;\r\n&lt;td style=&quot;font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px;&quot;&gt;Selenium&lt;/td&gt;\r\n&lt;td style=&quot;font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px;&quot;&gt;Fish and shellfish, sesame and sunflower seeds, wholegrain cereals.&lt;/td&gt;\r\n&lt;/tr&gt;\r\n&lt;tr&gt;\r\n&lt;td style=&quot;font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px;&quot;&gt;Zinc&lt;/td&gt;\r\n&lt;td style=&quot;font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 14px;&quot;&gt;Shellfish, liver, red meats, eggs, nuts and seeds.&lt;/td&gt;\r\n&lt;/tr&gt;\r\n&lt;/tbody&gt;\r\n&lt;/table&gt;\r\n&lt;p style=&quot;text-align: justify;&quot;&gt;&nbsp;&lt;/p&gt;\r\n&lt;p style=&quot;text-align: justify;&quot;&gt;&lt;br /&gt;&lt;br /&gt;&lt;br /&gt;&lt;/p&gt;\r\n&lt;p style=&quot;text-align: justify;&quot;&gt;&lt;strong&gt;Exercise for healthy eyes&lt;/strong&gt;&lt;br /&gt;Eye exercises are beneficial because they reduce eyestrain, help eyes work together and keep eye muscles strong and flexible. Other conditions that appear to benefit from eye exercises are: headaches, fatigue, concentration problems and vision related learning disabilities. Close your eyes tightly for 3-5 seconds and then open them for 3-5 seconds. Repeat this 7-8 times Close your eyes and massage them very lightly with circular movements of your fingers for 1-2 minutes. Sit and relax. Roll your clockwise, then counter-clockwise. Repeat 5 times and blink in between each time. Hold a pencil in front of you at arm&#039;s length. Move your slowly to your nose and follow the pencil with your eyes until you can&#039;t keep it in focus. Repeat 10 times. Focus on a distant object (over 150feet or 50m away) for several seconds and slowly refocus your eyes on a nearby object (less than 30 feet or 10m away) that&#039;s in the same direction. Focus for several seconds and go back to the distant object. Do this for 5 times.&lt;br /&gt;&lt;br /&gt;&lt;strong&gt;Contact Lens &ndash; Cleaning and Care&lt;/strong&gt;&lt;br /&gt;Here are the guidelines to follow in caring for your contact lenses: Never sleep without removing contact lenses unless approved by your eye doctor. Overnight lenses should never be worn for more than 6 nights in a raw. Whenever a lens is removed, it should be cleaned, rinsed and disinfected before being worn again.Always handle your lenses with clean hands. Wash, rinse and dry your hands with a lint-free towel. Be careful to protect your lenses from lotions, creams, and sprays. Lenses should always be inserted before applying makeup and removed after makeup has been removed. Never wet your lenses with saliva, tap water, or any homemade solutions. Always use recommended commercial products.&lt;br /&gt;&lt;br /&gt;&lt;strong&gt;Tips for buying good sunglasses&lt;/strong&gt;&lt;br /&gt;Protect your eyes by wearing sunglasses. Besides making you look pretty slick, a good pair of shades can provide protection from the sun&#039;s harmful effects! Look for a label that tells you how much UV protection the sunglasses offer. Ideally, your shades should block 99% to 100% of UV radiation. Close-fitting sunglasses help to block light more effectively. Look for wraparound shades or large Lenses. Gray, green, and brown lenses usually give better protection then other colours. More expensive shades may be more fashionable, but they don&#039;t provide more protection.&lt;br /&gt;&lt;br /&gt;&lt;strong&gt;Fight the dark circle menace&lt;/strong&gt;&lt;br /&gt;Many people suffer from dark circles under or around the eyes. Dark circles make people look tired and exhausted, if not unhealthy, and can occur due to a wide variation of reasons. Dark circles are seen in all age groups but seem to occur more in women. The major causes attributed o this menace are lack of sleep and stress. However hereditary is also held as a reason often. Try following to get rid of dark circles:&lt;br /&gt;1) Drinking Lots of Water&lt;br /&gt;2) Get Plenty of Sleep&lt;br /&gt;3) Eat Plenty of Proteins, fish, fresh fruit and vegetables (vitamin c and iron) and cut down your salt intake.&lt;br /&gt;&lt;br /&gt;&lt;strong&gt;Things to always remember for healthy eyes&lt;/strong&gt;&lt;br /&gt;Eat lots of fruits, vegetables &amp; carrots which are helpful in maintaining healthy eyes.&nbsp;&lt;br /&gt;1) Press cold cucumber slices gently against eyes 10 minutes before going to sleep at night to prevent puffiness.&lt;br /&gt;2) Wear UV protective sunglasses. Get polarized lenses, not just darker lenses.&nbsp;&lt;br /&gt;3) Try not to spend too much time continuously looking at your Television or computer screen.&nbsp;&lt;br /&gt;4) Be sure to wear goggles or other eye protective while working with chemicals or any place with harmful airborne particulates.&lt;br /&gt;5) Read the labels of eye drops carefully: many drops cannot be used, if you wear contact lenses.&lt;br /&gt;6) Never look into the sun for long.&lt;br /&gt;7) Visit your Ophthalmologist every year.&lt;/p&gt;\r\n&lt;/div&gt;',1,48,'Eye Care',NULL,'','0','0','','2019-07-07 06:52:51','2019-07-07 06:52:51',NULL),(36,'&lt;h2 style=&quot;text-align: center;&quot;&gt;&lt;span style=&quot;color: #339966;&quot;&gt;&lt;strong&gt;Testimonials&lt;/strong&gt;&lt;/span&gt;&lt;/h2&gt;\r\n&lt;p&gt;&nbsp;&lt;/p&gt;\r\n&lt;p&gt;&nbsp;&lt;/p&gt;\r\n&lt;div class=&quot;item&quot;&gt;\r\n&lt;div class=&quot;margin&quot;&gt;\r\n&lt;div class=&quot;s-12 m-12 l-6&quot;&gt;\r\n&lt;div class=&quot;image-border-radius margin-m-bottom&quot;&gt;\r\n&lt;div class=&quot;margin&quot;&gt;\r\n&lt;div class=&quot;s-12 m-12 l-4 margin-m-bottom&quot;&gt;&lt;a class=&quot;image-hover-zoom&quot; href=&quot;../../&quot;&gt;&lt;img src=&quot;../../storage/uploads/hBUdU8Yn5KHQFF0LINJdoFUJPrpPHGobGKEOMQ96.jpeg&quot; width=&quot;154&quot; height=&quot;100&quot; /&gt;&lt;/a&gt;&lt;/div&gt;\r\n&lt;div class=&quot;s-12 m-12 l-8 margin-m-bottom&quot;&gt;\r\n&lt;h3&gt;&lt;a href=&quot;https://www.google.com/maps/contrib/114006639201397961205/reviews?hl=en-IN&amp;sa=X&amp;ved=2ahUKEwiF8u2iqfjkAhVB7HMBHSROCcMQvvQBegQIARAe&quot;&gt;Akash Kamble&lt;/a&gt;&lt;/h3&gt;\r\n&lt;p&gt;Very happy with the treatment for my son. Dr Hemalatha operated him for cataract . We r so glad that he can see us again. Thank you madam..&lt;/p&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;div class=&quot;s-12 m-12 l-6&quot;&gt;\r\n&lt;div class=&quot;image-border-radius&quot;&gt;\r\n&lt;div class=&quot;margin&quot;&gt;\r\n&lt;div class=&quot;s-12 m-12 l-4 margin-m-bottom&quot;&gt;&lt;a class=&quot;image-hover-zoom&quot; href=&quot;../../&quot;&gt;&lt;img src=&quot;../../storage/uploads/AIqeWtMtpe8RWNGt5YUF82jpc5GxyrZ7FNUe8IUu.jpeg&quot; width=&quot;154&quot; height=&quot;100&quot; /&gt;&lt;/a&gt;&lt;/div&gt;\r\n&lt;div class=&quot;s-12 m-12 l-8&quot;&gt;\r\n&lt;h3&gt;&lt;a href=&quot;https://www.google.com/maps/contrib/100157819351348465936/reviews?hl=en-IN&amp;sa=X&amp;ved=2ahUKEwiF8u2iqfjkAhVB7HMBHSROCcMQvvQBegQIARAl&quot;&gt;Swaminathan Ganesan&lt;/a&gt;&lt;/h3&gt;\r\n&lt;p&gt;Dr Hemalatha is an excellent eye doctor. I went to consult her for cataract and was very anxious due to my long standing diabetes. She was very patient, relieved all my anxiety and performed the surgery with utmost care and perfection. May God bless her&lt;/p&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;h2 style=&quot;text-align: center;&quot;&gt;&nbsp;&lt;/h2&gt;\r\n&lt;p&gt;&nbsp;&lt;/p&gt;\r\n&lt;p&gt;&nbsp;&lt;/p&gt;\r\n&lt;div class=&quot;item&quot;&gt;\r\n&lt;div class=&quot;margin&quot;&gt;\r\n&lt;div class=&quot;s-12 m-12 l-6&quot;&gt;\r\n&lt;div class=&quot;image-border-radius margin-m-bottom&quot;&gt;\r\n&lt;div class=&quot;margin&quot;&gt;\r\n&lt;div class=&quot;s-12 m-12 l-4 margin-m-bottom&quot;&gt;&lt;a class=&quot;image-hover-zoom&quot; href=&quot;../../&quot;&gt;&lt;img src=&quot;../../storage/uploads/YgOcvnLsodifQvBHY1OJN0Er6zbcUDBI1ajbugDZ.jpeg&quot; width=&quot;154&quot; height=&quot;100&quot; /&gt;&lt;/a&gt;&lt;/div&gt;\r\n&lt;div class=&quot;s-12 m-12 l-8 margin-m-bottom&quot;&gt;\r\n&lt;h3&gt;&lt;a href=&quot;https://www.google.com/maps/contrib/111383585520480598163/reviews?hl=en-IN&amp;sa=X&amp;ved=2ahUKEwiF8u2iqfjkAhVB7HMBHSROCcMQvvQBegQIARAs&quot;&gt;Balaji Krishnamurthi&lt;/a&gt;&lt;/h3&gt;\r\n&lt;p&gt;Dr Hemalatha is the best eye doctor for kids. My niece and nephew are very fond of her. We are very satisfied with her treatment. Would definitely recommend to all..&lt;/p&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;div class=&quot;s-12 m-12 l-6&quot;&gt;\r\n&lt;div class=&quot;image-border-radius&quot;&gt;\r\n&lt;div class=&quot;margin&quot;&gt;\r\n&lt;div class=&quot;s-12 m-12 l-4 margin-m-bottom&quot;&gt;&lt;a class=&quot;image-hover-zoom&quot; href=&quot;../../&quot;&gt;&lt;img src=&quot;../../storage/uploads/2HzNjHHXuCd5Z7vwvUsyXB7EXDB4PnjDKB1TJ33W.jpeg&quot; width=&quot;154&quot; height=&quot;100&quot; /&gt;&lt;/a&gt;&lt;/div&gt;\r\n&lt;div class=&quot;s-12 m-12 l-8&quot;&gt;\r\n&lt;h3&gt;&lt;a href=&quot;https://www.google.com/maps/contrib/118268598729469330397/reviews?hl=en-IN&amp;sa=X&amp;ved=2ahUKEwiF8u2iqfjkAhVB7HMBHSROCcMQvvQBegQIARAz&quot;&gt;Ramadass S&lt;/a&gt;&lt;/h3&gt;\r\n&lt;p&gt;Dr Hemalatha is an excellent eye doctor , our whole family has been consulting her for many years and we r extremely happy , she is very friendly and humble, recently she operated my nephew for squint and we r thoroughly satisfied with the results. He has become so confident and his whole personality is changed , thank you doctor&lt;/p&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;h2 style=&quot;text-align: center;&quot;&gt;&lt;span style=&quot;color: #339966;&quot;&gt;&lt;strong&gt;&nbsp;&lt;/strong&gt;&lt;/span&gt;&lt;/h2&gt;\r\n&lt;p&gt;&nbsp;&lt;/p&gt;\r\n&lt;p&gt;&nbsp;&lt;/p&gt;\r\n&lt;div class=&quot;item&quot;&gt;\r\n&lt;div class=&quot;margin&quot;&gt;\r\n&lt;div class=&quot;s-12 m-12 l-6&quot;&gt;\r\n&lt;div class=&quot;image-border-radius margin-m-bottom&quot;&gt;\r\n&lt;div class=&quot;margin&quot;&gt;\r\n&lt;div class=&quot;s-12 m-12 l-4 margin-m-bottom&quot;&gt;&lt;a class=&quot;image-hover-zoom&quot; href=&quot;../../&quot;&gt;&lt;img src=&quot;../../storage/uploads/8Rm4shyn8M0hdiObRpqYWVUEw4j1OzDGqn05e0BZ.jpeg&quot; width=&quot;154&quot; height=&quot;100&quot; /&gt;&lt;/a&gt;&lt;/div&gt;\r\n&lt;div class=&quot;s-12 m-12 l-8 margin-m-bottom&quot;&gt;\r\n&lt;h3&gt;&lt;a href=&quot;https://www.google.com/maps/contrib/111821768780592950976/reviews?hl=en-IN&amp;sa=X&amp;ved=2ahUKEwiF8u2iqfjkAhVB7HMBHSROCcMQvvQBegQIARBI&quot;&gt;Nikhita Gune&lt;/a&gt;&lt;/h3&gt;\r\n&lt;p&gt;Dr Hemalatha is of the best pediatric ophthalmologists I have met. Extremely friendly, she makes her patients very comfortable.&lt;/p&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;div class=&quot;s-12 m-12 l-6&quot;&gt;\r\n&lt;div class=&quot;image-border-radius&quot;&gt;\r\n&lt;div class=&quot;margin&quot;&gt;\r\n&lt;div class=&quot;s-12 m-12 l-4 margin-m-bottom&quot;&gt;&lt;a class=&quot;image-hover-zoom&quot; href=&quot;../../&quot;&gt;&lt;img src=&quot;../../storage/uploads/jB8EcyGFJKeuOkWHQGMEXTfsGnxFgMZSEHNrXHQm.jpeg&quot; width=&quot;154&quot; height=&quot;100&quot; /&gt;&lt;/a&gt;&lt;/div&gt;\r\n&lt;div class=&quot;s-12 m-12 l-8&quot;&gt;\r\n&lt;h3&gt;&lt;a href=&quot;https://www.google.com/maps/contrib/117922311823370204248/reviews?hl=en-IN&amp;sa=X&amp;ved=2ahUKEwiF8u2iqfjkAhVB7HMBHSROCcMQvvQBegQIARBP&quot;&gt;Monika Patil&lt;/a&gt;&lt;/h3&gt;\r\n&lt;p&gt;My brother had difficulty in focussing for near objects and recurrent headaches. We consulted Dr.Hemalatha. Doctor was very patient and nice. She examined him in detail and prescribed him glasses and binocular vision therapy. She councelled ...&lt;/p&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;h2 style=&quot;text-align: center;&quot;&gt;&lt;span style=&quot;color: #339966;&quot;&gt;&lt;strong&gt;&nbsp;&lt;/strong&gt;&lt;/span&gt;&lt;/h2&gt;\r\n&lt;p&gt;&nbsp;&lt;/p&gt;\r\n&lt;p&gt;&nbsp;&lt;/p&gt;\r\n&lt;div class=&quot;item&quot;&gt;\r\n&lt;div class=&quot;margin&quot;&gt;\r\n&lt;div class=&quot;s-12 m-12 l-6&quot;&gt;\r\n&lt;div class=&quot;image-border-radius margin-m-bottom&quot;&gt;\r\n&lt;div class=&quot;margin&quot;&gt;\r\n&lt;div class=&quot;s-12 m-12 l-4 margin-m-bottom&quot;&gt;&lt;a class=&quot;image-hover-zoom&quot; href=&quot;../../&quot;&gt;&lt;img src=&quot;../../storage/uploads/8Rm4shyn8M0hdiObRpqYWVUEw4j1OzDGqn05e0BZ.jpeg&quot; width=&quot;154&quot; height=&quot;100&quot; /&gt;&lt;/a&gt;&lt;/div&gt;\r\n&lt;div class=&quot;s-12 m-12 l-8 margin-m-bottom&quot;&gt;\r\n&lt;h3&gt;&lt;a href=&quot;https://www.google.com/maps/contrib/101114640909211451808/reviews?hl=en-IN&amp;sa=X&amp;ved=2ahUKEwiF8u2iqfjkAhVB7HMBHSROCcMQvvQBegQIARBX&quot;&gt;sarvesh kadam&lt;/a&gt;&lt;/h3&gt;\r\n&lt;p&gt;The experience I had over was really good. I was well attended by the staff and there wasn&#039;t much waiting time. I came here with my kids so, they attend my son with utmost care and after the examination they even explained the situation to me very properly and made sure that I won&#039;t be confused in the future. Overall it was a great vist and I would surely recommend it to my family and friends&lt;/p&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;div class=&quot;s-12 m-12 l-6&quot;&gt;\r\n&lt;div class=&quot;image-border-radius&quot;&gt;\r\n&lt;div class=&quot;margin&quot;&gt;\r\n&lt;div class=&quot;s-12 m-12 l-4 margin-m-bottom&quot;&gt;&lt;a class=&quot;image-hover-zoom&quot; href=&quot;../../&quot;&gt;&lt;img src=&quot;../../storage/uploads/jB8EcyGFJKeuOkWHQGMEXTfsGnxFgMZSEHNrXHQm.jpeg&quot; width=&quot;154&quot; height=&quot;100&quot; /&gt;&lt;/a&gt;&lt;/div&gt;\r\n&lt;div class=&quot;s-12 m-12 l-8&quot;&gt;\r\n&lt;h3&gt;&lt;a href=&quot;https://www.google.com/maps/contrib/101947529922834439601/reviews?hl=en-IN&amp;sa=X&amp;ved=2ahUKEwiF8u2iqfjkAhVB7HMBHSROCcMQvvQBegQIARBf&quot;&gt;kavya sriram&lt;/a&gt;&lt;/h3&gt;\r\n&lt;p&gt;Very friendly doctors, had a great experience with my daughter. I would recommend these doctors to all my friends and family..&lt;/p&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;h2 style=&quot;text-align: center;&quot;&gt;&lt;span style=&quot;color: #339966;&quot;&gt;&lt;strong&gt;&nbsp;&lt;/strong&gt;&lt;/span&gt;&lt;/h2&gt;\r\n&lt;p&gt;&nbsp;&lt;/p&gt;\r\n&lt;p&gt;&nbsp;&lt;/p&gt;\r\n&lt;div class=&quot;item&quot;&gt;\r\n&lt;div class=&quot;margin&quot;&gt;\r\n&lt;div class=&quot;s-12 m-12 l-6&quot;&gt;\r\n&lt;div class=&quot;image-border-radius margin-m-bottom&quot;&gt;\r\n&lt;div class=&quot;margin&quot;&gt;\r\n&lt;div class=&quot;s-12 m-12 l-4 margin-m-bottom&quot;&gt;&lt;a class=&quot;image-hover-zoom&quot; href=&quot;../../&quot;&gt;&lt;img src=&quot;../../storage/uploads/8Rm4shyn8M0hdiObRpqYWVUEw4j1OzDGqn05e0BZ.jpeg&quot; width=&quot;154&quot; height=&quot;100&quot; /&gt;&lt;/a&gt;&lt;/div&gt;\r\n&lt;div class=&quot;s-12 m-12 l-8 margin-m-bottom&quot;&gt;\r\n&lt;h3&gt;&lt;a href=&quot;https://www.google.com/maps/contrib/112017570390045235171/reviews?hl=en-IN&amp;sa=X&amp;ved=2ahUKEwiun5WzqfjkAhUIH7cAHRr2A1wQvvQBegQIARAD&quot;&gt;snehal gawade&lt;/a&gt;&lt;/h3&gt;\r\n&lt;p&gt;Excellent doctor couple...Dr vidyashankar is an excellent oculoplasty surgeon. I referred my friend who had disfigurement post a road accident. Sir not only restored her functionally and cosmetically but he provided immense moral support &hellip;&lt;/p&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;div class=&quot;s-12 m-12 l-6&quot;&gt;\r\n&lt;div class=&quot;image-border-radius&quot;&gt;\r\n&lt;div class=&quot;margin&quot;&gt;\r\n&lt;div class=&quot;s-12 m-12 l-4 margin-m-bottom&quot;&gt;&lt;a class=&quot;image-hover-zoom&quot; href=&quot;../../&quot;&gt;&lt;img src=&quot;../../storage/uploads/jB8EcyGFJKeuOkWHQGMEXTfsGnxFgMZSEHNrXHQm.jpeg&quot; width=&quot;154&quot; height=&quot;100&quot; /&gt;&lt;/a&gt;&lt;/div&gt;\r\n&lt;div class=&quot;s-12 m-12 l-8&quot;&gt;\r\n&lt;h3&gt;&lt;a href=&quot;https://www.google.com/maps/contrib/116614839224069362788/reviews?hl=en-IN&amp;sa=X&amp;ved=2ahUKEwiun5WzqfjkAhUIH7cAHRr2A1wQvvQBegQIARAL&quot;&gt;Shivraman Ganesh&lt;/a&gt;&lt;/h3&gt;\r\n&lt;p&gt;I visited Dr.B.Vidyashankar a week ago.He was very soft spoken, compassionate and genuine.My eye was tested without dilatation so my eye power tended to fluctuate immediately.He was very quick to diagnose it and was kind enough to explain the situation and answer all my questions with utter patience.He is so well trained and experienced.I am thankful to the doctor for helping me.&lt;/p&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;h2 style=&quot;text-align: center;&quot;&gt;&lt;span style=&quot;color: #339966;&quot;&gt;&lt;strong&gt;&nbsp;&lt;/strong&gt;&lt;/span&gt;&lt;/h2&gt;\r\n&lt;p&gt;&nbsp;&lt;/p&gt;\r\n&lt;p&gt;&nbsp;&lt;/p&gt;\r\n&lt;div class=&quot;item&quot;&gt;\r\n&lt;div class=&quot;margin&quot;&gt;\r\n&lt;div class=&quot;s-12 m-12 l-6&quot;&gt;\r\n&lt;div class=&quot;image-border-radius margin-m-bottom&quot;&gt;\r\n&lt;div class=&quot;margin&quot;&gt;\r\n&lt;div class=&quot;s-12 m-12 l-4 margin-m-bottom&quot;&gt;&lt;a class=&quot;image-hover-zoom&quot; href=&quot;../../&quot;&gt;&lt;img src=&quot;../../storage/uploads/8Rm4shyn8M0hdiObRpqYWVUEw4j1OzDGqn05e0BZ.jpeg&quot; width=&quot;154&quot; height=&quot;100&quot; /&gt;&lt;/a&gt;&lt;/div&gt;\r\n&lt;div class=&quot;s-12 m-12 l-8 margin-m-bottom&quot;&gt;\r\n&lt;h3&gt;&lt;a href=&quot;https://www.google.com/maps/contrib/114118669064531076746/reviews?hl=en-IN&amp;sa=X&amp;ved=2ahUKEwiun5WzqfjkAhUIH7cAHRr2A1wQvvQBegQIARAT&quot;&gt;grena free fire survival&lt;/a&gt;&lt;/h3&gt;\r\n&lt;p&gt;I am very happy to meet to meet Dr Hemlata Vidyshankar . She is best dr&lt;/p&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;div class=&quot;s-12 m-12 l-6&quot;&gt;\r\n&lt;div class=&quot;image-border-radius&quot;&gt;\r\n&lt;div class=&quot;margin&quot;&gt;\r\n&lt;div class=&quot;s-12 m-12 l-4 margin-m-bottom&quot;&gt;&lt;a class=&quot;image-hover-zoom&quot; href=&quot;../../&quot;&gt;&lt;img src=&quot;../../storage/uploads/jB8EcyGFJKeuOkWHQGMEXTfsGnxFgMZSEHNrXHQm.jpeg&quot; width=&quot;154&quot; height=&quot;100&quot; /&gt;&lt;/a&gt;&lt;/div&gt;\r\n&lt;div class=&quot;s-12 m-12 l-8&quot;&gt;\r\n&lt;h3&gt;&lt;a href=&quot;https://www.google.com/maps/contrib/117646088086030787550/reviews?hl=en-IN&amp;sa=X&amp;ved=2ahUKEwiun5WzqfjkAhUIH7cAHRr2A1wQvvQBegQIARAa&quot;&gt;Ram krishna Mishra&lt;/a&gt;&lt;/h3&gt;\r\n&lt;p&gt;Dr Vidyashankar is a good ophthalmologist in chembur. Always take care of patients eye&lt;/p&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;h2 style=&quot;text-align: center;&quot;&gt;&lt;span style=&quot;color: #339966;&quot;&gt;&lt;strong&gt;&nbsp;&lt;/strong&gt;&lt;/span&gt;&lt;/h2&gt;\r\n&lt;p&gt;&nbsp;&lt;/p&gt;\r\n&lt;p&gt;&nbsp;&lt;/p&gt;\r\n&lt;div class=&quot;item&quot;&gt;\r\n&lt;div class=&quot;margin&quot;&gt;\r\n&lt;div class=&quot;s-12 m-12 l-6&quot;&gt;\r\n&lt;div class=&quot;image-border-radius margin-m-bottom&quot;&gt;\r\n&lt;div class=&quot;margin&quot;&gt;\r\n&lt;div class=&quot;s-12 m-12 l-4 margin-m-bottom&quot;&gt;&lt;a class=&quot;image-hover-zoom&quot; href=&quot;../../&quot;&gt;&lt;img src=&quot;../../storage/uploads/8Rm4shyn8M0hdiObRpqYWVUEw4j1OzDGqn05e0BZ.jpeg&quot; width=&quot;154&quot; height=&quot;100&quot; /&gt;&lt;/a&gt;&lt;/div&gt;\r\n&lt;div class=&quot;s-12 m-12 l-8 margin-m-bottom&quot;&gt;\r\n&lt;h3&gt;&lt;a href=&quot;https://www.google.com/maps/contrib/109196907077442531951/reviews?hl=en-IN&amp;sa=X&amp;ved=2ahUKEwiun5WzqfjkAhUIH7cAHRr2A1wQvvQBegQIARAh&quot;&gt;aniket tale&lt;/a&gt;&lt;/h3&gt;\r\n&lt;p&gt;Tysm doctor for our help you saved my Eye . its just because of you I&#039;m able to see everything properly. I&#039;m so glade that I found a doctor like you Thank You So Much Doctor. And guys please visit Dr Vidyashankar&#039;s center of Vision&lt;/p&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;div class=&quot;s-12 m-12 l-6&quot;&gt;\r\n&lt;div class=&quot;image-border-radius&quot;&gt;\r\n&lt;div class=&quot;margin&quot;&gt;\r\n&lt;div class=&quot;s-12 m-12 l-4 margin-m-bottom&quot;&gt;&lt;a class=&quot;image-hover-zoom&quot; href=&quot;../../&quot;&gt;&lt;img src=&quot;../../storage/uploads/jB8EcyGFJKeuOkWHQGMEXTfsGnxFgMZSEHNrXHQm.jpeg&quot; width=&quot;154&quot; height=&quot;100&quot; /&gt;&lt;/a&gt;&lt;/div&gt;\r\n&lt;div class=&quot;s-12 m-12 l-8&quot;&gt;\r\n&lt;h3&gt;&lt;a href=&quot;https://www.google.com/maps/contrib/117890534317928086154/reviews?hl=en-IN&amp;sa=X&amp;ved=2ahUKEwiun5WzqfjkAhUIH7cAHRr2A1wQvvQBegQIARAo&quot;&gt;S. KALAISELVI&lt;/a&gt;&lt;/h3&gt;\r\n&lt;p&gt;The clinic is vey hygienic, well equipped with latest technology, strategically located for commuting and not much waiting period.Both Dr.Vidyashankar and Dr.Hemalata are down to earth individuals, compassionate towards their patient, very Knowledgeable, very confident, Not Money oriented ,does not rush through the visits and were flexible to my timing issues &hellip;&lt;/p&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;h2 style=&quot;text-align: center;&quot;&gt;&lt;span style=&quot;color: #339966;&quot;&gt;&lt;strong&gt;&nbsp;&lt;/strong&gt;&lt;/span&gt;&lt;/h2&gt;\r\n&lt;p&gt;&nbsp;&lt;/p&gt;\r\n&lt;p&gt;&nbsp;&lt;/p&gt;\r\n&lt;div class=&quot;item&quot;&gt;\r\n&lt;div class=&quot;margin&quot;&gt;\r\n&lt;div class=&quot;s-12 m-12 l-6&quot;&gt;\r\n&lt;div class=&quot;image-border-radius margin-m-bottom&quot;&gt;\r\n&lt;div class=&quot;margin&quot;&gt;\r\n&lt;div class=&quot;s-12 m-12 l-4 margin-m-bottom&quot;&gt;&lt;a class=&quot;image-hover-zoom&quot; href=&quot;../../&quot;&gt;&lt;img src=&quot;../../storage/uploads/8Rm4shyn8M0hdiObRpqYWVUEw4j1OzDGqn05e0BZ.jpeg&quot; width=&quot;154&quot; height=&quot;100&quot; /&gt;&lt;/a&gt;&lt;/div&gt;\r\n&lt;div class=&quot;s-12 m-12 l-8 margin-m-bottom&quot;&gt;\r\n&lt;h3&gt;&lt;a href=&quot;https://www.google.com/maps/contrib/106945217659293770487/reviews?hl=en-IN&amp;sa=X&amp;ved=2ahUKEwiun5WzqfjkAhUIH7cAHRr2A1wQvvQBegQIARAw&quot;&gt;Sana Khan&lt;/a&gt;&lt;/h3&gt;\r\n&lt;p&gt;I had referred my niece for lazy eye therapy to Dr Hemalatha . Doctor was so patient and explained to the condiction sa well. She motivated the child to be regular with exercises and glasses...and now the child is doing really well. Doctor is the best pediatric ophthalmologist in town....must visit for any child with eye problem&lt;/p&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;div class=&quot;s-12 m-12 l-6&quot;&gt;\r\n&lt;div class=&quot;image-border-radius&quot;&gt;\r\n&lt;div class=&quot;margin&quot;&gt;\r\n&lt;div class=&quot;s-12 m-12 l-4 margin-m-bottom&quot;&gt;&lt;a class=&quot;image-hover-zoom&quot; href=&quot;../../&quot;&gt;&lt;img src=&quot;../../storage/uploads/jB8EcyGFJKeuOkWHQGMEXTfsGnxFgMZSEHNrXHQm.jpeg&quot; width=&quot;154&quot; height=&quot;100&quot; /&gt;&lt;/a&gt;&lt;/div&gt;\r\n&lt;div class=&quot;s-12 m-12 l-8&quot;&gt;\r\n&lt;h3&gt;&lt;a href=&quot;https://www.google.com/maps/contrib/104389970029040675147/reviews?hl=en-IN&amp;sa=X&amp;ved=2ahUKEwiun5WzqfjkAhUIH7cAHRr2A1wQvvQBegQIARA3&quot;&gt;Akhilesh B&lt;/a&gt;&lt;/h3&gt;\r\n&lt;p&gt;I was suffering from squint (last 43 years). With age I found deterioration of sight in one of the eyes. I had consulted a few doctors but did not get a firm answer for rectifying the issue. I was referred to Dr. Hemalatha as a renouned squint correction surgeon. ...&lt;/p&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;h2 style=&quot;text-align: center;&quot;&gt;&lt;span style=&quot;color: #339966;&quot;&gt;&lt;strong&gt;&nbsp;&lt;/strong&gt;&lt;/span&gt;&lt;/h2&gt;\r\n&lt;p&gt;&nbsp;&lt;/p&gt;\r\n&lt;p&gt;&nbsp;&lt;/p&gt;\r\n&lt;div class=&quot;item&quot;&gt;\r\n&lt;div class=&quot;margin&quot;&gt;\r\n&lt;div class=&quot;s-12 m-12 l-6&quot;&gt;\r\n&lt;div class=&quot;image-border-radius margin-m-bottom&quot;&gt;\r\n&lt;div class=&quot;margin&quot;&gt;\r\n&lt;div class=&quot;s-12 m-12 l-4 margin-m-bottom&quot;&gt;&lt;a class=&quot;image-hover-zoom&quot; href=&quot;../../&quot;&gt;&lt;img src=&quot;../../storage/uploads/8Rm4shyn8M0hdiObRpqYWVUEw4j1OzDGqn05e0BZ.jpeg&quot; width=&quot;154&quot; height=&quot;100&quot; /&gt;&lt;/a&gt;&lt;/div&gt;\r\n&lt;div class=&quot;s-12 m-12 l-8 margin-m-bottom&quot;&gt;\r\n&lt;h3&gt;&lt;a href=&quot;https://www.google.com/maps/contrib/112433753582996719866/reviews?hl=en-IN&amp;sa=X&amp;ved=2ahUKEwiun5WzqfjkAhUIH7cAHRr2A1wQvvQBegQIARA_&quot;&gt;nitin sarangdhar&lt;/a&gt;&lt;/h3&gt;\r\n&lt;p&gt;Very good doctor, I was treated very well, I appreciate Dr Hemalatha for her patience and explaining the condition to me in very simple way. Will definitely recommend.&lt;/p&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;div class=&quot;s-12 m-12 l-6&quot;&gt;\r\n&lt;div class=&quot;image-border-radius&quot;&gt;\r\n&lt;div class=&quot;margin&quot;&gt;\r\n&lt;div class=&quot;s-12 m-12 l-4 margin-m-bottom&quot;&gt;&lt;a class=&quot;image-hover-zoom&quot; href=&quot;../../&quot;&gt;&lt;img src=&quot;../../storage/uploads/jB8EcyGFJKeuOkWHQGMEXTfsGnxFgMZSEHNrXHQm.jpeg&quot; width=&quot;154&quot; height=&quot;100&quot; /&gt;&lt;/a&gt;&lt;/div&gt;\r\n&lt;div class=&quot;s-12 m-12 l-8&quot;&gt;\r\n&lt;h3&gt;&lt;a href=&quot;https://www.google.com/maps/contrib/114849000267943701482/reviews?hl=en-IN&amp;sa=X&amp;ved=2ahUKEwiun5WzqfjkAhUIH7cAHRr2A1wQvvQBegQIARBG&quot;&gt;Puranik Sanjay&lt;/a&gt;&lt;/h3&gt;\r\n&lt;p&gt;Excellent diagonisis, very good infrastructure, neat and hygenic and cordial approach&lt;/p&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;h2 style=&quot;text-align: center;&quot;&gt;&lt;span style=&quot;color: #339966;&quot;&gt;&lt;strong&gt;&nbsp;&lt;/strong&gt;&lt;/span&gt;&lt;/h2&gt;\r\n&lt;p&gt;&nbsp;&lt;/p&gt;\r\n&lt;p&gt;&nbsp;&lt;/p&gt;\r\n&lt;div class=&quot;item&quot;&gt;\r\n&lt;div class=&quot;margin&quot;&gt;\r\n&lt;div class=&quot;s-12 m-12 l-6&quot;&gt;\r\n&lt;div class=&quot;image-border-radius margin-m-bottom&quot;&gt;\r\n&lt;div class=&quot;margin&quot;&gt;\r\n&lt;div class=&quot;s-12 m-12 l-4 margin-m-bottom&quot;&gt;&lt;a class=&quot;image-hover-zoom&quot; href=&quot;../../&quot;&gt;&lt;img src=&quot;../../storage/uploads/8Rm4shyn8M0hdiObRpqYWVUEw4j1OzDGqn05e0BZ.jpeg&quot; width=&quot;154&quot; height=&quot;100&quot; /&gt;&lt;/a&gt;&lt;/div&gt;\r\n&lt;div class=&quot;s-12 m-12 l-8 margin-m-bottom&quot;&gt;\r\n&lt;h3&gt;&lt;a href=&quot;https://www.google.com/maps/contrib/116697216176419119270/reviews?hl=en-IN&amp;sa=X&amp;ved=2ahUKEwih8c6_qfjkAhWO6XMBHWl-CaIQvvQBegQIARAD&quot;&gt;Rajkumar Kadam&lt;/a&gt;&lt;/h3&gt;\r\n&lt;p&gt;Thanks madam you have done great job for operating one year child from Trible area talasari Maharashtra for bilateral cataract surgery&lt;/p&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;div class=&quot;s-12 m-12 l-6&quot;&gt;\r\n&lt;div class=&quot;image-border-radius&quot;&gt;\r\n&lt;div class=&quot;margin&quot;&gt;\r\n&lt;div class=&quot;s-12 m-12 l-4 margin-m-bottom&quot;&gt;&lt;a class=&quot;image-hover-zoom&quot; href=&quot;../../&quot;&gt;&lt;img src=&quot;../../storage/uploads/jB8EcyGFJKeuOkWHQGMEXTfsGnxFgMZSEHNrXHQm.jpeg&quot; width=&quot;154&quot; height=&quot;100&quot; /&gt;&lt;/a&gt;&lt;/div&gt;\r\n&lt;div class=&quot;s-12 m-12 l-8&quot;&gt;\r\n&lt;h3&gt;&lt;a href=&quot;https://www.google.com/maps/contrib/111951411766579415446/reviews?hl=en-IN&amp;sa=X&amp;ved=2ahUKEwih8c6_qfjkAhWO6XMBHWl-CaIQvvQBegQIARAK&quot;&gt;shaikh shakeel&lt;/a&gt;&lt;/h3&gt;\r\n&lt;p&gt;Nice Doctor and I happy to visit at her clinic, well suggested good tested, and very good quality of material like glass &amp; frames thanks Doctor...&lt;/p&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;h2 style=&quot;text-align: center;&quot;&gt;&lt;span style=&quot;color: #339966;&quot;&gt;&lt;strong&gt;&nbsp;&lt;/strong&gt;&lt;/span&gt;&lt;/h2&gt;\r\n&lt;p&gt;&nbsp;&lt;/p&gt;\r\n&lt;p&gt;&nbsp;&lt;/p&gt;\r\n&lt;div class=&quot;item&quot;&gt;\r\n&lt;div class=&quot;margin&quot;&gt;\r\n&lt;div class=&quot;s-12 m-12 l-6&quot;&gt;\r\n&lt;div class=&quot;image-border-radius margin-m-bottom&quot;&gt;\r\n&lt;div class=&quot;margin&quot;&gt;\r\n&lt;div class=&quot;s-12 m-12 l-4 margin-m-bottom&quot;&gt;&lt;a class=&quot;image-hover-zoom&quot; href=&quot;../../&quot;&gt;&lt;img src=&quot;../../storage/uploads/8Rm4shyn8M0hdiObRpqYWVUEw4j1OzDGqn05e0BZ.jpeg&quot; width=&quot;154&quot; height=&quot;100&quot; /&gt;&lt;/a&gt;&lt;/div&gt;\r\n&lt;div class=&quot;s-12 m-12 l-8 margin-m-bottom&quot;&gt;\r\n&lt;h3&gt;&lt;a href=&quot;https://www.google.com/maps/contrib/110574619182766722266/reviews?hl=en-IN&amp;sa=X&amp;ved=2ahUKEwih8c6_qfjkAhWO6XMBHWl-CaIQvvQBegQIARAR&quot;&gt;Sriram Bharadwajan&lt;/a&gt;&lt;/h3&gt;\r\n&lt;p&gt;Excellent doctor couple with great sense of personal touch.. My mother underwent cataract in both her eyes with Dr.Vidyashankar. He personally made sure that she was comfortable and recovered quickly. Great work&lt;/p&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;div class=&quot;s-12 m-12 l-6&quot;&gt;\r\n&lt;div class=&quot;image-border-radius&quot;&gt;\r\n&lt;div class=&quot;margin&quot;&gt;\r\n&lt;div class=&quot;s-12 m-12 l-4 margin-m-bottom&quot;&gt;&lt;a class=&quot;image-hover-zoom&quot; href=&quot;../../&quot;&gt;&lt;img src=&quot;../../storage/uploads/jB8EcyGFJKeuOkWHQGMEXTfsGnxFgMZSEHNrXHQm.jpeg&quot; width=&quot;154&quot; height=&quot;100&quot; /&gt;&lt;/a&gt;&lt;/div&gt;\r\n&lt;div class=&quot;s-12 m-12 l-8&quot;&gt;\r\n&lt;h3&gt;&lt;a href=&quot;https://www.google.com/maps/contrib/108193733811904512316/reviews?hl=en-IN&amp;sa=X&amp;ved=2ahUKEwih8c6_qfjkAhWO6XMBHWl-CaIQvvQBegQIARAY&quot;&gt;Hiral gajra&lt;/a&gt;&lt;/h3&gt;\r\n&lt;p&gt;Dr. Hemalatha Vidyashakar has been wonderful Doctor to work with. She is extremely passionate about helping her patients and guiding them to the right direction. This is what I really like about her. I highly recommend you to visit her and I 100% assure you that you won&#039;t have any doubts when you are back home! &lt;br /&gt;Thanks Ma&#039;am It has always been a Great learning from you&lt;/p&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;h2 style=&quot;text-align: center;&quot;&gt;&lt;span style=&quot;color: #339966;&quot;&gt;&lt;strong&gt;&nbsp;&lt;/strong&gt;&lt;/span&gt;&lt;/h2&gt;\r\n&lt;p&gt;&nbsp;&lt;/p&gt;\r\n&lt;p&gt;&nbsp;&lt;/p&gt;\r\n&lt;div class=&quot;item&quot;&gt;\r\n&lt;div class=&quot;margin&quot;&gt;\r\n&lt;div class=&quot;s-12 m-12 l-6&quot;&gt;\r\n&lt;div class=&quot;image-border-radius margin-m-bottom&quot;&gt;\r\n&lt;div class=&quot;margin&quot;&gt;\r\n&lt;div class=&quot;s-12 m-12 l-4 margin-m-bottom&quot;&gt;&lt;a class=&quot;image-hover-zoom&quot; href=&quot;../../&quot;&gt;&lt;img src=&quot;../../storage/uploads/8Rm4shyn8M0hdiObRpqYWVUEw4j1OzDGqn05e0BZ.jpeg&quot; width=&quot;154&quot; height=&quot;100&quot; /&gt;&lt;/a&gt;&lt;/div&gt;\r\n&lt;div class=&quot;s-12 m-12 l-8 margin-m-bottom&quot;&gt;\r\n&lt;h3&gt;&lt;a href=&quot;https://www.google.com/maps/contrib/113476160310877385619/reviews?hl=en-IN&amp;sa=X&amp;ved=2ahUKEwih8c6_qfjkAhWO6XMBHWl-CaIQvvQBegQIARAg&quot;&gt;Geeta Meena&lt;/a&gt;&lt;/h3&gt;\r\n&lt;p&gt;I visited Dr.Hemalatha with my daughter, she is exceptionally good with kids. Her friendly approach and calm demeanor put all our anxiety to rest. The clinic is child friendly and the supporting staff are polite. very satisfied . great !&lt;/p&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;div class=&quot;s-12 m-12 l-6&quot;&gt;\r\n&lt;div class=&quot;image-border-radius&quot;&gt;\r\n&lt;div class=&quot;margin&quot;&gt;\r\n&lt;div class=&quot;s-12 m-12 l-4 margin-m-bottom&quot;&gt;&lt;a class=&quot;image-hover-zoom&quot; href=&quot;../../&quot;&gt;&lt;img src=&quot;../../storage/uploads/jB8EcyGFJKeuOkWHQGMEXTfsGnxFgMZSEHNrXHQm.jpeg&quot; width=&quot;154&quot; height=&quot;100&quot; /&gt;&lt;/a&gt;&lt;/div&gt;\r\n&lt;div class=&quot;s-12 m-12 l-8&quot;&gt;\r\n&lt;h3&gt;&lt;a href=&quot;https://www.google.com/maps/contrib/101210704285031742351/reviews?hl=en-IN&amp;sa=X&amp;ved=2ahUKEwih8c6_qfjkAhWO6XMBHWl-CaIQvvQBegQIARAn&quot;&gt;Meetu Agarwal&lt;/a&gt;&lt;/h3&gt;\r\n&lt;p&gt;It is an honour to tap into Dr. Hema&rsquo;s expertise as a knowledgeable doctor. I really appreciate the time and encouragement she gives to all kids and parents. My best wishes are always with her... I would highly recommend Dr. Hema as a solution to all eye problems.&lt;/p&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;h2 style=&quot;text-align: center;&quot;&gt;&lt;span style=&quot;color: #339966;&quot;&gt;&lt;strong&gt;&nbsp;&lt;/strong&gt;&lt;/span&gt;&lt;/h2&gt;\r\n&lt;p&gt;&nbsp;&lt;/p&gt;\r\n&lt;p&gt;&nbsp;&lt;/p&gt;\r\n&lt;div class=&quot;item&quot;&gt;\r\n&lt;div class=&quot;margin&quot;&gt;\r\n&lt;div class=&quot;s-12 m-12 l-6&quot;&gt;\r\n&lt;div class=&quot;image-border-radius margin-m-bottom&quot;&gt;\r\n&lt;div class=&quot;margin&quot;&gt;\r\n&lt;div class=&quot;s-12 m-12 l-4 margin-m-bottom&quot;&gt;&lt;a class=&quot;image-hover-zoom&quot; href=&quot;../../&quot;&gt;&lt;img src=&quot;../../storage/uploads/8Rm4shyn8M0hdiObRpqYWVUEw4j1OzDGqn05e0BZ.jpeg&quot; width=&quot;154&quot; height=&quot;100&quot; /&gt;&lt;/a&gt;&lt;/div&gt;\r\n&lt;div class=&quot;s-12 m-12 l-8 margin-m-bottom&quot;&gt;\r\n&lt;h3&gt;&lt;a href=&quot;https://www.google.com/maps/contrib/101999011135182855612/reviews?hl=en-IN&amp;sa=X&amp;ved=2ahUKEwih8c6_qfjkAhWO6XMBHWl-CaIQvvQBegQIARAu&quot;&gt;Dr Padma Balasubramaniam&lt;/a&gt;&lt;/h3&gt;\r\n&lt;p&gt;I visited Dr.Hemalatha with my grand daughter, she is exceptionally good with kids, Her friendly approach and calm demeanor put all our anxiety to rest. The clinic is child friendly and the supporting staff are polite. very satisfied .&lt;/p&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;div class=&quot;s-12 m-12 l-6&quot;&gt;\r\n&lt;div class=&quot;image-border-radius&quot;&gt;\r\n&lt;div class=&quot;margin&quot;&gt;\r\n&lt;div class=&quot;s-12 m-12 l-4 margin-m-bottom&quot;&gt;&lt;a class=&quot;image-hover-zoom&quot; href=&quot;../../&quot;&gt;&lt;img src=&quot;../../storage/uploads/jB8EcyGFJKeuOkWHQGMEXTfsGnxFgMZSEHNrXHQm.jpeg&quot; width=&quot;154&quot; height=&quot;100&quot; /&gt;&lt;/a&gt;&lt;/div&gt;\r\n&lt;div class=&quot;s-12 m-12 l-8&quot;&gt;\r\n&lt;h3&gt;&lt;a href=&quot;https://www.google.com/maps/contrib/118133658255331752713/reviews?hl=en-IN&amp;sa=X&amp;ved=2ahUKEwih8c6_qfjkAhWO6XMBHWl-CaIQvvQBegQIARA1&quot;&gt;Dharmendra Prajapati&lt;/a&gt;&lt;/h3&gt;\r\n&lt;p&gt;Very good doctor, very good medical facilities in the clinic.&lt;/p&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;h2 style=&quot;text-align: center;&quot;&gt;&lt;span style=&quot;color: #339966;&quot;&gt;&lt;strong&gt;&nbsp;&lt;/strong&gt;&lt;/span&gt;&lt;/h2&gt;\r\n&lt;p&gt;&nbsp;&lt;/p&gt;\r\n&lt;p&gt;&nbsp;&lt;/p&gt;\r\n&lt;div class=&quot;item&quot;&gt;\r\n&lt;div class=&quot;margin&quot;&gt;\r\n&lt;div class=&quot;s-12 m-12 l-6&quot;&gt;\r\n&lt;div class=&quot;image-border-radius margin-m-bottom&quot;&gt;\r\n&lt;div class=&quot;margin&quot;&gt;\r\n&lt;div class=&quot;s-12 m-12 l-4 margin-m-bottom&quot;&gt;&lt;a class=&quot;image-hover-zoom&quot; href=&quot;../../&quot;&gt;&lt;img src=&quot;../../storage/uploads/8Rm4shyn8M0hdiObRpqYWVUEw4j1OzDGqn05e0BZ.jpeg&quot; width=&quot;154&quot; height=&quot;100&quot; /&gt;&lt;/a&gt;&lt;/div&gt;\r\n&lt;div class=&quot;s-12 m-12 l-8 margin-m-bottom&quot;&gt;\r\n&lt;h3&gt;&lt;a href=&quot;https://www.google.com/maps/contrib/112453099053656132792/reviews?hl=en-IN&amp;sa=X&amp;ved=2ahUKEwih8c6_qfjkAhWO6XMBHWl-CaIQvvQBegQIARA8&quot;&gt;Anshul Bansal&lt;/a&gt;&lt;/h3&gt;\r\n&lt;p&gt;Felt satisfied after having treatment with experienced doctors&lt;/p&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;div class=&quot;s-12 m-12 l-6&quot;&gt;\r\n&lt;div class=&quot;image-border-radius&quot;&gt;\r\n&lt;div class=&quot;margin&quot;&gt;\r\n&lt;div class=&quot;s-12 m-12 l-4 margin-m-bottom&quot;&gt;&lt;a class=&quot;image-hover-zoom&quot; href=&quot;../../&quot;&gt;&lt;img src=&quot;../../storage/uploads/jB8EcyGFJKeuOkWHQGMEXTfsGnxFgMZSEHNrXHQm.jpeg&quot; width=&quot;154&quot; height=&quot;100&quot; /&gt;&lt;/a&gt;&lt;/div&gt;\r\n&lt;div class=&quot;s-12 m-12 l-8&quot;&gt;\r\n&lt;h3&gt;&lt;a href=&quot;https://www.google.com/maps/contrib/112716053167829236963/reviews?hl=en-IN&amp;sa=X&amp;ved=2ahUKEwih8c6_qfjkAhWO6XMBHWl-CaIQvvQBegQIARBD&quot;&gt;Pradeep Meena&lt;/a&gt;&lt;/h3&gt;\r\n&lt;p&gt;Thorough check up and proper treatment was given.&lt;/p&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;h2 style=&quot;text-align: center;&quot;&gt;&lt;span style=&quot;color: #339966;&quot;&gt;&lt;strong&gt;&nbsp;&lt;/strong&gt;&lt;/span&gt;&lt;/h2&gt;\r\n&lt;p&gt;&nbsp;&lt;/p&gt;\r\n&lt;p&gt;&nbsp;&lt;/p&gt;\r\n&lt;div class=&quot;item&quot;&gt;\r\n&lt;div class=&quot;margin&quot;&gt;\r\n&lt;div class=&quot;s-12 m-12 l-6&quot;&gt;\r\n&lt;div class=&quot;image-border-radius margin-m-bottom&quot;&gt;\r\n&lt;div class=&quot;margin&quot;&gt;\r\n&lt;div class=&quot;s-12 m-12 l-4 margin-m-bottom&quot;&gt;&lt;a class=&quot;image-hover-zoom&quot; href=&quot;../../&quot;&gt;&lt;img src=&quot;../../storage/uploads/8Rm4shyn8M0hdiObRpqYWVUEw4j1OzDGqn05e0BZ.jpeg&quot; width=&quot;154&quot; height=&quot;100&quot; /&gt;&lt;/a&gt;&lt;/div&gt;\r\n&lt;div class=&quot;s-12 m-12 l-8 margin-m-bottom&quot;&gt;\r\n&lt;h3&gt;&lt;a href=&quot;https://www.google.com/maps/contrib/112547561218939483538/reviews?hl=en-IN&amp;sa=X&amp;ved=2ahUKEwiR1dCGtfjkAhX17HMBHez_CbkQvvQBegQIARAD&quot;&gt;Usman Athani&lt;/a&gt;&lt;/h3&gt;\r\n&lt;p&gt;She is experienced doctor &amp; a good human being.&lt;/p&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;div class=&quot;s-12 m-12 l-6&quot;&gt;\r\n&lt;div class=&quot;image-border-radius&quot;&gt;\r\n&lt;div class=&quot;margin&quot;&gt;\r\n&lt;div class=&quot;s-12 m-12 l-4 margin-m-bottom&quot;&gt;&lt;a class=&quot;image-hover-zoom&quot; href=&quot;../../&quot;&gt;&lt;img src=&quot;../../storage/uploads/jB8EcyGFJKeuOkWHQGMEXTfsGnxFgMZSEHNrXHQm.jpeg&quot; width=&quot;154&quot; height=&quot;100&quot; /&gt;&lt;/a&gt;&lt;/div&gt;\r\n&lt;div class=&quot;s-12 m-12 l-8&quot;&gt;\r\n&lt;h3&gt;&lt;a href=&quot;https://www.google.com/maps/contrib/100124291151684407215/reviews?hl=en-IN&amp;sa=X&amp;ved=2ahUKEwiR1dCGtfjkAhX17HMBHez_CbkQvvQBegQIARAK&quot;&gt;Anuja Jayaraman&lt;/a&gt;&lt;/h3&gt;\r\n&lt;p&gt;Dr Hemalatha is very professional and her diagnosis has always been correct for us. For her priority is the patient in this case my 8 year old daughter. I would highly recommend her. All the best to her.&lt;/p&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;',1,49,'Testimonials',NULL,'','0','0','','2019-08-26 16:52:57','2019-09-30 20:44:05',NULL),(37,'&lt;table style=&quot;height: 379px;&quot; width=&quot;616&quot;&gt;\r\n&lt;tbody&gt;\r\n&lt;tr&gt;\r\n&lt;td style=&quot;width: 300px; text-align: center;&quot;&gt;&lt;img src=&quot;../../storage/uploads/xD1AGcYoIEOhujbNFMQo6ExhJe9iRd6kSfvX8IpX.jpeg&quot; alt=&quot;&quot; width=&quot;300&quot; height=&quot;461&quot; /&gt;&lt;/td&gt;\r\n&lt;td style=&quot;width: 300px; text-align: left;&quot;&gt;\r\n&lt;p&gt;&lt;strong&gt;&ldquo;EVERY CHILD SHOULD HAVE AT LEAST 3 EYE EXAMINATIONS BEFORE HE/SHE STARTS SCHOOL&rdquo;&lt;/strong&gt;&lt;/p&gt;\r\n&lt;p&gt;Ideally a routine examination is performed by a Pediatrician when the child is born and then at least two routine eye examinations should be performed by a Pediatric Ophthalmologist first, when the child is around 2-3 years and the again at the age of 5 years before the child starts formal school.&lt;/p&gt;\r\n&lt;p&gt;RED ALERTS THAT YOUR CHILD NEEDS AN EYE CHECK UP&lt;/p&gt;\r\n&lt;div class=&quot;text_exposed_show&quot;&gt;\r\n&lt;p&gt;If you notice any of the following symptoms, please get their eyes checked at the earliest&lt;/p&gt;\r\n&lt;p&gt;&bull; Holds object or books very close to their eyes?&lt;br /&gt;&bull; Excessively rub their eyes, blink or squint after close visual work?&lt;br /&gt;&bull; Complain of headaches or eyestrain after reading?&lt;br /&gt;&bull; Have difficulty comprehending what they have read?&lt;br /&gt;&bull; Have red or watery eyes or recurrent swellings?&lt;br /&gt;&bull; Performs below expected levels in school?&lt;br /&gt;&bull; Have a short attention span or difficulty staying on task?&lt;br /&gt;&bull; If there is a deviation of the eyes in or out?&lt;br /&gt;&bull; Complaints of blurred vision with schoolwork or reading?&lt;br /&gt;&bull; Have difficulty copying from a textbook or board?&lt;/p&gt;\r\n&lt;p&gt;Children having glasses should undergo an eye check up every 6 months till their glass number stabilizes and then once every year by a Pediatric Ophthalmologist&nbsp;&lt;a class=&quot;_58cn&quot; href=&quot;https://www.facebook.com/hashtag/drhemalathavidyashankar?source=feed_text&amp;epa=HASHTAG&amp;__xts__%5B0%5D=68.ARBZnVch7UVEPA2Fvaelr5yzj5UVZ8ml-5M9qjlm0YFVa5b5YIPMLyqN-Cp16XKIlPnDa7CfBp5w_FTKiAXnNg-bNOzRgANVqQJAU1v9Nc7qVE2z_TZWmXeLVtWTtHBIF-IhQZutA4-Fmekzy1cOnMKlI5XJ_DGRc7MN1pn2S2ZEBM4TMr6-kZHsIniw4Nu1iFqB9HK19iUwP5cNiFkbsy0uh1SZ7OP0S9KkN3gox4m46aaxp_9aoo2JqRSHhjWiwhq0OQNuYS-u_f44btj3yZFlP5R87YZagFqepl5YqQbeqR5syEw2XdD-M-UjFL2islc7XUV7Pnq7qW9iXBdVaT8&amp;__tn__=%2ANK-R&quot; data-ft=&quot;{&quot;type&quot;:104,&quot;tn&quot;:&quot;*N&quot;}&quot;&gt;&lt;span class=&quot;_5afx&quot;&gt;&lt;span class=&quot;_58cl _5afz&quot;&gt;#&lt;/span&gt;&lt;span class=&quot;_58cm&quot;&gt;drhemalathavidyashankar&lt;/span&gt;&lt;/span&gt;&lt;/a&gt;&nbsp;&lt;a class=&quot;_58cn&quot; href=&quot;https://www.facebook.com/hashtag/pediatricophthalmologist?source=feed_text&amp;epa=HASHTAG&amp;__xts__%5B0%5D=68.ARBZnVch7UVEPA2Fvaelr5yzj5UVZ8ml-5M9qjlm0YFVa5b5YIPMLyqN-Cp16XKIlPnDa7CfBp5w_FTKiAXnNg-bNOzRgANVqQJAU1v9Nc7qVE2z_TZWmXeLVtWTtHBIF-IhQZutA4-Fmekzy1cOnMKlI5XJ_DGRc7MN1pn2S2ZEBM4TMr6-kZHsIniw4Nu1iFqB9HK19iUwP5cNiFkbsy0uh1SZ7OP0S9KkN3gox4m46aaxp_9aoo2JqRSHhjWiwhq0OQNuYS-u_f44btj3yZFlP5R87YZagFqepl5YqQbeqR5syEw2XdD-M-UjFL2islc7XUV7Pnq7qW9iXBdVaT8&amp;__tn__=%2ANK-R&quot; data-ft=&quot;{&quot;type&quot;:104,&quot;tn&quot;:&quot;*N&quot;}&quot;&gt;&lt;span class=&quot;_5afx&quot;&gt;&lt;span class=&quot;_58cl _5afz&quot;&gt;#&lt;/span&gt;&lt;span class=&quot;_58cm&quot;&gt;pediatricophthalmologist&lt;/span&gt;&lt;/span&gt;&lt;/a&gt;&nbsp;&lt;a class=&quot;_58cn&quot; href=&quot;https://www.facebook.com/hashtag/eyecareforchildren?source=feed_text&amp;epa=HASHTAG&amp;__xts__%5B0%5D=68.ARBZnVch7UVEPA2Fvaelr5yzj5UVZ8ml-5M9qjlm0YFVa5b5YIPMLyqN-Cp16XKIlPnDa7CfBp5w_FTKiAXnNg-bNOzRgANVqQJAU1v9Nc7qVE2z_TZWmXeLVtWTtHBIF-IhQZutA4-Fmekzy1cOnMKlI5XJ_DGRc7MN1pn2S2ZEBM4TMr6-kZHsIniw4Nu1iFqB9HK19iUwP5cNiFkbsy0uh1SZ7OP0S9KkN3gox4m46aaxp_9aoo2JqRSHhjWiwhq0OQNuYS-u_f44btj3yZFlP5R87YZagFqepl5YqQbeqR5syEw2XdD-M-UjFL2islc7XUV7Pnq7qW9iXBdVaT8&amp;__tn__=%2ANK-R&quot; data-ft=&quot;{&quot;type&quot;:104,&quot;tn&quot;:&quot;*N&quot;}&quot;&gt;&lt;span class=&quot;_5afx&quot;&gt;&lt;span class=&quot;_58cl _5afz&quot;&gt;#&lt;/span&gt;&lt;span class=&quot;_58cm&quot;&gt;eyecareforchildren&lt;/span&gt;&lt;/span&gt;&lt;/a&gt;&nbsp;&lt;a class=&quot;_58cn&quot; href=&quot;https://www.facebook.com/hashtag/refractiveerrorsinchildren?source=feed_text&amp;epa=HASHTAG&amp;__xts__%5B0%5D=68.ARBZnVch7UVEPA2Fvaelr5yzj5UVZ8ml-5M9qjlm0YFVa5b5YIPMLyqN-Cp16XKIlPnDa7CfBp5w_FTKiAXnNg-bNOzRgANVqQJAU1v9Nc7qVE2z_TZWmXeLVtWTtHBIF-IhQZutA4-Fmekzy1cOnMKlI5XJ_DGRc7MN1pn2S2ZEBM4TMr6-kZHsIniw4Nu1iFqB9HK19iUwP5cNiFkbsy0uh1SZ7OP0S9KkN3gox4m46aaxp_9aoo2JqRSHhjWiwhq0OQNuYS-u_f44btj3yZFlP5R87YZagFqepl5YqQbeqR5syEw2XdD-M-UjFL2islc7XUV7Pnq7qW9iXBdVaT8&amp;__tn__=%2ANK-R&quot; data-ft=&quot;{&quot;type&quot;:104,&quot;tn&quot;:&quot;*N&quot;}&quot;&gt;&lt;span class=&quot;_5afx&quot;&gt;&lt;span class=&quot;_58cl _5afz&quot;&gt;#&lt;/span&gt;&lt;span class=&quot;_58cm&quot;&gt;refractiveerrorsinchildren&lt;/span&gt;&lt;/span&gt;&lt;/a&gt;&nbsp;&lt;a class=&quot;_58cn&quot; href=&quot;https://www.facebook.com/hashtag/preventableblindnessinchildren?source=feed_text&amp;epa=HASHTAG&amp;__xts__%5B0%5D=68.ARBZnVch7UVEPA2Fvaelr5yzj5UVZ8ml-5M9qjlm0YFVa5b5YIPMLyqN-Cp16XKIlPnDa7CfBp5w_FTKiAXnNg-bNOzRgANVqQJAU1v9Nc7qVE2z_TZWmXeLVtWTtHBIF-IhQZutA4-Fmekzy1cOnMKlI5XJ_DGRc7MN1pn2S2ZEBM4TMr6-kZHsIniw4Nu1iFqB9HK19iUwP5cNiFkbsy0uh1SZ7OP0S9KkN3gox4m46aaxp_9aoo2JqRSHhjWiwhq0OQNuYS-u_f44btj3yZFlP5R87YZagFqepl5YqQbeqR5syEw2XdD-M-UjFL2islc7XUV7Pnq7qW9iXBdVaT8&amp;__tn__=%2ANK-R&quot; data-ft=&quot;{&quot;type&quot;:104,&quot;tn&quot;:&quot;*N&quot;}&quot;&gt;&lt;span class=&quot;_5afx&quot;&gt;&lt;span class=&quot;_58cl _5afz&quot;&gt;#&lt;/span&gt;&lt;span class=&quot;_58cm&quot;&gt;preventableblindnessinchildren&lt;/span&gt;&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;\r\n&lt;/div&gt;\r\n&lt;/td&gt;\r\n&lt;/tr&gt;\r\n&lt;tr&gt;\r\n&lt;td style=&quot;width: 300px;&quot;&gt;&nbsp;&lt;/td&gt;\r\n&lt;td style=&quot;width: 300px;&quot;&gt;&nbsp;&lt;/td&gt;\r\n&lt;/tr&gt;\r\n&lt;tr&gt;\r\n&lt;td style=&quot;width: 300px;&quot;&gt;&nbsp;&lt;/td&gt;\r\n&lt;td style=&quot;width: 300px;&quot;&gt;&nbsp;&lt;/td&gt;\r\n&lt;/tr&gt;\r\n&lt;/tbody&gt;\r\n&lt;/table&gt;',1,50,'Blog',NULL,'','0','0','','2019-10-31 20:51:37','2019-10-31 20:57:27',NULL),(38,'&lt;p&gt;&lt;img src=&quot;../../storage/uploads/byuO9n0lE2Bh9U7irEbUKX9gXyyDYLFI4oRB7kzK.png&quot; alt=&quot;&quot; width=&quot;72&quot; height=&quot;101&quot; /&gt;&lt;/p&gt;',1,51,'CULTURE',NULL,'','0','0','','2019-11-03 23:28:47','2019-11-03 23:28:47',NULL),(39,'',1,20,NULL,NULL,'','0','0','\0','2020-01-15 12:54:35','2020-01-15 12:54:35',NULL),(43,'',1,56,'Test',NULL,NULL,NULL,NULL,'\0','2020-10-02 20:01:39','2020-10-02 20:01:39',NULL),(44,'&lt;p&gt;rwere&lt;/p&gt;',1,57,'erwwe',NULL,NULL,NULL,NULL,'','2020-10-02 20:25:34','2020-10-02 20:25:34',NULL),(45,'&lt;p&gt;fgsfgsd&lt;/p&gt;',1,58,'seema',NULL,NULL,'dfdf','dfsdf','','2020-10-08 14:50:41','2020-10-08 14:50:41',NULL),(46,'&lt;p&gt;&lt;img src=&quot;../../storage/uploads/4kva4q9Ce67fiLwdyL7gk8oUdyTe5pxLqbWaXni1.jpeg&quot; alt=&quot;&quot; width=&quot;225&quot; height=&quot;225&quot; /&gt;&lt;/p&gt;\r\n&lt;p&gt;sgafgFGSafghsfghgdghgdasghsga&lt;/p&gt;',1,60,'Prasad',NULL,NULL,'ddd','ffff','','2020-11-11 04:27:17','2020-11-11 04:27:46',NULL),(47,'&lt;p&gt;ffgfgfhgfy&lt;/p&gt;',1,62,'Tejas',NULL,NULL,'tyt','rtyrty','','2021-01-17 07:06:07','2021-01-17 07:06:07',NULL),(48,'&lt;p style=&quot;text-align: left;&quot;&gt;gjhguyjgjhggjhgjhgjhgjhg&lt;/p&gt;\r\n&lt;p&gt;&lt;img src=&quot;../../storage/uploads/78mUMj5wNCQ7PG8PyMOWeCIdoSIHG0H42KsDYVtH.jpeg&quot; alt=&quot;&quot; width=&quot;300&quot; height=&quot;190&quot; /&gt;&lt;/p&gt;\r\n&lt;p&gt;&nbsp;&lt;/p&gt;\r\n&lt;p style=&quot;text-align: right;&quot;&gt;jhgjhgjhghghghghfghfhgfhgfhfhj&lt;/p&gt;',1,63,'test',NULL,NULL,'ttt','ttt','','2021-01-28 08:20:17','2021-01-28 08:22:36',NULL),(49,'&lt;p&gt;&lt;img src=&quot;../../storage/uploads/jIIQj6lfJq63IoK8FdbSoWLbQNRHU5wUIgDlwG2g.jpeg&quot; alt=&quot;&quot; width=&quot;1024&quot; height=&quot;768&quot; /&gt;&lt;/p&gt;',1,64,NULL,NULL,NULL,NULL,NULL,'','2021-02-26 08:49:06','2021-02-26 08:49:06',NULL),(50,'&lt;div class=&quot;single-Blog&quot;&gt;\r\n&lt;div class=&quot;single-blog-left&quot;&gt;\r\n&lt;ul class=&quot;blog-comments-box&quot;&gt;\r\n&lt;li&gt;\r\n&lt;div class=&quot;bt_bb_row_wrapper&quot;&gt;\r\n&lt;div class=&quot;bt_bb_row&quot; data-structure=&quot;12&quot;&gt;\r\n&lt;div class=&quot;bt_bb_column col-xl-12 col-xs-12 col-sm-12 col-md-12 col-lg-12 bt_bb_align_left bt_bb_vertical_align_top bt_bb_padding_normal&quot; data-width=&quot;12&quot; data-bt-override-class=&quot;{}&quot;&gt;\r\n&lt;div class=&quot;bt_bb_column_content&quot;&gt;\r\n&lt;div class=&quot;bt_bb_column_content_inner&quot;&gt;&lt;header class=&quot;bt_bb_headline bt_bb_font_weight_bolder bt_bb_dash_none bt_bb_size_normal bt_bb_align_center bt_bb_animation_fade_in bt_bb_animation_move_left animate animated&quot;&gt;\r\n&lt;h5&gt;&lt;span class=&quot;bt_bb_headline_content&quot;&gt;&lt;u&gt;Retinal Detachment&lt;/u&gt;&lt;/span&gt;&lt;/h5&gt;\r\n&lt;/header&gt;\r\n&lt;div class=&quot;bt_bb_separator bt_bb_border_style_none bt_bb_top_spacing_normal bt_bb_bottom_spacing_none&quot; data-bt-override-class=&quot;{&quot;bt_bb_top_spacing_&quot;:{&quot;current_class&quot;:&quot;bt_bb_top_spacing_normal&quot;,&quot;xl&quot;:&quot;normal&quot;},&quot;bt_bb_bottom_spacing_&quot;:{&quot;current_class&quot;:&quot;bt_bb_bottom_spacing_none&quot;,&quot;xl&quot;:&quot;none&quot;}}&quot;&gt;&nbsp;&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;div class=&quot;bt_bb_row_wrapper&quot;&gt;\r\n&lt;div class=&quot;bt_bb_row&quot; data-structure=&quot;6-6&quot;&gt;\r\n&lt;div class=&quot;bt_bb_column col-xl-6 col-xs-12 col-sm-6 col-md-6 col-lg-6 bt_bb_align_left bt_bb_vertical_align_top bt_bb_padding_normal&quot; data-width=&quot;6&quot; data-bt-override-class=&quot;{}&quot;&gt;\r\n&lt;div class=&quot;bt_bb_column_content&quot;&gt;\r\n&lt;div class=&quot;bt_bb_column_content_inner&quot;&gt;\r\n&lt;div class=&quot;bt_bb_separator bt_bb_border_style_none bt_bb_top_spacing_normal bt_bb_bottom_spacing_none&quot; data-bt-override-class=&quot;{&quot;bt_bb_top_spacing_&quot;:{&quot;current_class&quot;:&quot;bt_bb_top_spacing_normal&quot;,&quot;xl&quot;:&quot;normal&quot;},&quot;bt_bb_bottom_spacing_&quot;:{&quot;current_class&quot;:&quot;bt_bb_bottom_spacing_none&quot;,&quot;xl&quot;:&quot;none&quot;}}&quot;&gt;&nbsp;&lt;/div&gt;\r\n&lt;div class=&quot;bt_bb_image bt_bb_shape_square bt_bb_hover_style_simple bt_bb_content_display_hide-on-hover bt_bb_content_align_middle bt_bb_align_center&quot; data-bt-override-class=&quot;{&quot;bt_bb_align_&quot;:{&quot;current_class&quot;:&quot;bt_bb_align_center&quot;,&quot;xl&quot;:&quot;center&quot;}}&quot;&gt;&lt;img class=&quot;attachment-full size-full&quot; title=&quot;idealeyey&quot; src=&quot;https://mllavbw17tid.i.optimole.com/CO1lQoQ.EoGw~11f2d/w:360/h:360/q:auto/https://idealeyeclinic.com/wp-content/uploads/2022/03/idealeyey-1.png&quot; alt=&quot;https://mllavbw17tid.i.optimole.com/CO1lQoQ.EoGw~11f2d/w:auto/h:auto/q:auto/https://idealeyeclinic.com/wp-content/uploads/2022/03/idealeyey-1.png&quot; width=&quot;360&quot; height=&quot;360&quot; data-opt-src=&quot;https://mllavbw17tid.i.optimole.com/CO1lQoQ.EoGw~11f2d/w:360/h:360/q:auto/https://idealeyeclinic.com/wp-content/uploads/2022/03/idealeyey-1.png&quot; data-full_image_src=&quot;https://mllavbw17tid.i.optimole.com/CO1lQoQ.EoGw~11f2d/w:auto/h:auto/q:auto/https://idealeyeclinic.com/wp-content/uploads/2022/03/idealeyey-1.png&quot; data-opt-lazy-loaded=&quot;true&quot; data-opt-otimized-width=&quot;360&quot; data-opt-optimized-height=&quot;360&quot; /&gt;&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;div class=&quot;bt_bb_column col-xl-6 col-xs-12 col-sm-6 col-md-6 col-lg-6 bt_bb_align_left bt_bb_vertical_align_top bt_bb_padding_normal&quot; data-width=&quot;6&quot; data-bt-override-class=&quot;{}&quot;&gt;\r\n&lt;div class=&quot;bt_bb_column_content&quot;&gt;\r\n&lt;div class=&quot;bt_bb_column_content_inner&quot;&gt;\r\n&lt;div class=&quot;bt_bb_separator bt_bb_border_style_none bt_bb_top_spacing_normal bt_bb_bottom_spacing_none&quot; data-bt-override-class=&quot;{&quot;bt_bb_top_spacing_&quot;:{&quot;current_class&quot;:&quot;bt_bb_top_spacing_normal&quot;,&quot;xl&quot;:&quot;normal&quot;},&quot;bt_bb_bottom_spacing_&quot;:{&quot;current_class&quot;:&quot;bt_bb_bottom_spacing_none&quot;,&quot;xl&quot;:&quot;none&quot;}}&quot;&gt;&nbsp;&lt;/div&gt;\r\n&lt;div class=&quot;bt_bb_text&quot;&gt;\r\n&lt;p&gt;Your retina is the light-sensitive tissue on the inner surface of your eye. A light that enters your eye lands on your retina and sends visual messages to your brain through the optic nerve.&lt;br /&gt;Retinal detachment occurs when the retina becomes separated from the pigmented cell layer that nourishes it. The condition may start as a retinal tear and then detach completely. This can occur due to:&lt;/p&gt;\r\n&lt;ul&gt;\r\n&lt;li&gt;Vitreous gel inside the eye shrinking and contracting, pulling on the retina&lt;/li&gt;\r\n&lt;li&gt;Fluid gets underneath the retina due to retinal tears&lt;/li&gt;\r\n&lt;li&gt;Trauma or injury to the eye that causes fluid to collect under the retina\\&lt;/li&gt;\r\n&lt;li&gt;The contraction of scar tissue on the retina&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;/div&gt;\r\n&lt;div class=&quot;single-blog-right&quot;&gt;&nbsp;&lt;/div&gt;\r\n&lt;/div&gt;',1,67,'Dr Pandit',NULL,NULL,NULL,NULL,'','2021-04-12 06:30:35','2022-04-20 05:02:29',NULL),(51,'&lt;div class=&quot;nav nav-pills justify-content-center left-tab&quot;&gt;&lt;div class=&quot;nav nav-pills justify-content-center left-tab&quot;&gt;&lt;a class=&quot;nav-link&quot; href=&quot;https://www.swanandpathology.com/pathology-test.html#tab-A&quot; data-toggle=&quot;pill&quot;&gt;GENERAL PATHOLOGY&lt;/a&gt;&lt;a class=&quot;nav-link&quot; href=&quot;https://www.swanandpathology.com/pathology-test.html#tab-B&quot; data-toggle=&quot;pill&quot;&gt;BIOCHEMISTRY&lt;/a&gt;&lt;a class=&quot;nav-link&quot; href=&quot;https://www.swanandpathology.com/pathology-test.html#tab-C&quot; data-toggle=&quot;pill&quot;&gt;MICROBIOLOGY&lt;/a&gt;&lt;a class=&quot;nav-link&quot; href=&quot;https://www.swanandpathology.com/pathology-test.html#tab-D&quot; data-toggle=&quot;pill&quot;&gt;IMMUNOASSAY&lt;/a&gt;&lt;a class=&quot;nav-link&quot; href=&quot;https://www.swanandpathology.com/pathology-test.html#tab-E&quot; data-toggle=&quot;pill&quot;&gt;SPECIAL TESTS&lt;/a&gt;&lt;a class=&quot;nav-link&quot; href=&quot;https://www.swanandpathology.com/pathology-test.html#tab-F&quot; data-toggle=&quot;pill&quot;&gt;SONOGRAPHY&lt;/a&gt;&lt;a class=&quot;nav-link active&quot; href=&quot;https://www.swanandpathology.com/pathology-test.html#tab-G&quot; data-toggle=&quot;pill&quot;&gt;MOLECULAR BIOLOGY&lt;/a&gt;&lt;/div&gt;&lt;br /&gt;&lt;div id=&quot;tab-content&quot; class=&quot;tab-content right-tab&quot;&gt;&lt;br /&gt;&lt;div id=&quot;tab-G&quot; class=&quot;tab-pane fade active show&quot;&gt;&lt;br /&gt;&lt;div class=&quot;table-scroll&quot;&gt;&lt;br /&gt;&lt;div class=&quot;table-wrap two-digit-table&quot;&gt;&lt;br /&gt;&lt;h5&gt;MOLECULAR BIOLOGY TESTS:&lt;/h5&gt;&lt;br /&gt;&lt;div class=&quot;h-decor&quot;&gt;&amp;nbsp;&lt;/div&gt;&lt;br /&gt;&lt;table class=&quot;table table-test-heading price-table&quot;&gt;&lt;br /&gt;&lt;tbody&gt;&lt;br /&gt;&lt;tr&gt;&lt;br /&gt;&lt;th&gt;Sno&lt;/th&gt;&lt;br /&gt;&lt;th&gt;&amp;nbsp;&amp;nbsp;&amp;nbsp;Tests Name&lt;/th&gt;&lt;br /&gt;&lt;/tr&gt;&lt;br /&gt;&lt;/tbody&gt;&lt;br /&gt;&lt;/table&gt;&lt;br /&gt;&lt;table class=&quot;table table-test&quot;&gt;&lt;br /&gt;&lt;tbody&gt;&lt;br /&gt;&lt;tr&gt;&lt;br /&gt;&lt;td&gt;&amp;nbsp;&lt;/td&gt;&lt;br /&gt;&lt;td&gt;BCR - ABL (RT-PCR) 6000 TEST&lt;/td&gt;&lt;br /&gt;&lt;/tr&gt;&lt;br /&gt;&lt;tr&gt;&lt;br /&gt;&lt;td&gt;&amp;nbsp;&lt;/td&gt;&lt;br /&gt;&lt;td&gt;BCR - ABL (RT-PCR) 6000 TEST&lt;/td&gt;&lt;br /&gt;&lt;/tr&gt;&lt;br /&gt;&lt;tr&gt;&lt;br /&gt;&lt;td&gt;&amp;nbsp;&lt;/td&gt;&lt;br /&gt;&lt;td&gt;CMV QUANTITATIVE (RT-PCR) 5500 TEST&lt;/td&gt;&lt;br /&gt;&lt;/tr&gt;&lt;br /&gt;&lt;tr&gt;&lt;br /&gt;&lt;td&gt;&amp;nbsp;&lt;/td&gt;&lt;br /&gt;&lt;td&gt;CMV QUANTITATIVE (RT-PCR) 5500 TEST&lt;/td&gt;&lt;br /&gt;&lt;/tr&gt;&lt;br /&gt;&lt;tr&gt;&lt;br /&gt;&lt;td&gt;&amp;nbsp;&lt;/td&gt;&lt;br /&gt;&lt;td&gt;COVID-19 TEST 0 TEST&lt;/td&gt;&lt;br /&gt;&lt;/tr&gt;&lt;br /&gt;&lt;tr&gt;&lt;br /&gt;&lt;td&gt;&amp;nbsp;&lt;/td&gt;&lt;br /&gt;&lt;td&gt;COVID-19 TEST 0 TEST&lt;/td&gt;&lt;br /&gt;&lt;/tr&gt;&lt;br /&gt;&lt;tr&gt;&lt;br /&gt;&lt;td&gt;&amp;nbsp;&lt;/td&gt;&lt;br /&gt;&lt;td&gt;H1N1 QUALITATIVE PCR 4500 TEST&lt;/td&gt;&lt;br /&gt;&lt;/tr&gt;&lt;br /&gt;&lt;tr&gt;&lt;br /&gt;&lt;td&gt;&amp;nbsp;&lt;/td&gt;&lt;br /&gt;&lt;td&gt;H1N1 QUALITATIVE PCR 4500 TEST&lt;/td&gt;&lt;br /&gt;&lt;/tr&gt;&lt;br /&gt;&lt;tr&gt;&lt;br /&gt;&lt;td&gt;&amp;nbsp;&lt;/td&gt;&lt;br /&gt;&lt;td&gt;HBV VIRAL LOAD(RT PCR) 4500 TEST&lt;/td&gt;&lt;br /&gt;&lt;/tr&gt;&lt;br /&gt;&lt;tr&gt;&lt;br /&gt;&lt;td&gt;&amp;nbsp;&lt;/td&gt;&lt;br /&gt;&lt;td&gt;HBV VIRAL LOAD(RT PCR) 4500 TEST&lt;/td&gt;&lt;br /&gt;&lt;/tr&gt;&lt;br /&gt;&lt;tr&gt;&lt;br /&gt;&lt;td&gt;&amp;nbsp;&lt;/td&gt;&lt;br /&gt;&lt;td&gt;HCV PCR(QUALITATIVE) 3700 TEST&lt;/td&gt;&lt;br /&gt;&lt;/tr&gt;&lt;br /&gt;&lt;tr&gt;&lt;br /&gt;&lt;td&gt;&amp;nbsp;&lt;/td&gt;&lt;br /&gt;&lt;td&gt;HCV PCR(QUALITATIVE) 3700 TEST&lt;/td&gt;&lt;br /&gt;&lt;/tr&gt;&lt;br /&gt;&lt;tr&gt;&lt;br /&gt;&lt;td&gt;&amp;nbsp;&lt;/td&gt;&lt;br /&gt;&lt;td&gt;HCV VIRAL LOAD (RT PCR) 4500 TEST&lt;/td&gt;&lt;br /&gt;&lt;/tr&gt;&lt;br /&gt;&lt;tr&gt;&lt;br /&gt;&lt;td&gt;&amp;nbsp;&lt;/td&gt;&lt;br /&gt;&lt;td&gt;HCV VIRAL LOAD (RT PCR) 4500 TEST&lt;/td&gt;&lt;br /&gt;&lt;/tr&gt;&lt;br /&gt;&lt;tr&gt;&lt;br /&gt;&lt;td&gt;&amp;nbsp;&lt;/td&gt;&lt;br /&gt;&lt;td&gt;HLA B-27 BY PCR 3100 TEST&lt;/td&gt;&lt;br /&gt;&lt;/tr&gt;&lt;br /&gt;&lt;tr&gt;&lt;br /&gt;&lt;td&gt;&amp;nbsp;&lt;/td&gt;&lt;br /&gt;&lt;td&gt;HLA B-27 BY PCR 3100 TEST&lt;/td&gt;&lt;br /&gt;&lt;/tr&gt;&lt;br /&gt;&lt;tr&gt;&lt;br /&gt;&lt;td&gt;&amp;nbsp;&lt;/td&gt;&lt;br /&gt;&lt;td&gt;JAK-2 (RT PCR) 6000 TEST&lt;/td&gt;&lt;br /&gt;&lt;/tr&gt;&lt;br /&gt;&lt;tr&gt;&lt;br /&gt;&lt;td&gt;&amp;nbsp;&lt;/td&gt;&lt;br /&gt;&lt;td&gt;JAK-2 (RT PCR) 6000 TEST&lt;/td&gt;&lt;br /&gt;&lt;/tr&gt;&lt;br /&gt;&lt;tr&gt;&lt;br /&gt;&lt;td&gt;&amp;nbsp;&lt;/td&gt;&lt;br /&gt;&lt;td&gt;NUCLEIC ACID TESTING (HIV,HBV,HCV Screening) 2900 TEST&lt;/td&gt;&lt;br /&gt;&lt;/tr&gt;&lt;br /&gt;&lt;tr&gt;&lt;br /&gt;&lt;td&gt;&amp;nbsp;&lt;/td&gt;&lt;br /&gt;&lt;td&gt;NUCLEIC ACID TESTING (HIV,HBV,HCV Screening) 2900 TEST&lt;/td&gt;&lt;br /&gt;&lt;/tr&gt;&lt;br /&gt;&lt;tr&gt;&lt;br /&gt;&lt;td&gt;&amp;nbsp;&lt;/td&gt;&lt;br /&gt;&lt;td&gt;SARS-CoV-2 RT PCR ASSAY 2100 TEST&lt;/td&gt;&lt;br /&gt;&lt;/tr&gt;&lt;br /&gt;&lt;tr&gt;&lt;br /&gt;&lt;td&gt;&amp;nbsp;&lt;/td&gt;&lt;br /&gt;&lt;td&gt;SARS-CoV-2 RT PCR ASSAY 2100 TEST&lt;/td&gt;&lt;br /&gt;&lt;/tr&gt;&lt;br /&gt;&lt;/tbody&gt;&lt;br /&gt;&lt;/table&gt;&lt;br /&gt;&lt;/div&gt;&lt;br /&gt;&lt;/div&gt;&lt;br /&gt;&lt;/div&gt;&lt;br /&gt;&lt;/div&gt;&lt;/div&gt;',1,68,'1234',NULL,NULL,NULL,NULL,'','2021-04-15 13:09:11','2022-06-09 06:49:21',NULL),(52,'&lt;p&gt;&lt;img src=&quot;../../storage/uploads/cymWowbHgAsQnJdsHaNMVXajJPukZp8rtdf3fcwq.jpeg&quot; alt=&quot;&quot; width=&quot;1024&quot; height=&quot;768&quot; /&gt;&lt;/p&gt;\r\n&lt;p&gt;&nbsp;&lt;/p&gt;\r\n&lt;p&gt;&nbsp;&lt;/p&gt;\r\n&lt;p&gt;ghjghjghjgjhgjhgjhgjhghjghjghjgj&lt;/p&gt;',1,69,'test1234',NULL,NULL,NULL,NULL,'','2021-04-22 11:54:05','2021-04-22 11:54:51',NULL),(53,'&lt;table&gt;\r\n&lt;tbody&gt;\r\n&lt;tr&gt;\r\n&lt;td width=&quot;234&quot;&gt;\r\n&lt;p&gt;Dtfjgwuft&lt;/p&gt;\r\n&lt;/td&gt;\r\n&lt;td width=&quot;234&quot;&gt;\r\n&lt;p&gt;Fyfyfh&lt;/p&gt;\r\n&lt;/td&gt;\r\n&lt;td width=&quot;234&quot;&gt;\r\n&lt;p&gt;Yryr&lt;/p&gt;\r\n&lt;/td&gt;\r\n&lt;td width=&quot;234&quot;&gt;\r\n&lt;p&gt;jfhfh&lt;/p&gt;\r\n&lt;/td&gt;\r\n&lt;/tr&gt;\r\n&lt;tr&gt;\r\n&lt;td width=&quot;234&quot;&gt;\r\n&lt;p&gt;&nbsp;&lt;/p&gt;\r\n&lt;/td&gt;\r\n&lt;td width=&quot;234&quot;&gt;\r\n&lt;p&gt;&nbsp;&lt;/p&gt;\r\n&lt;/td&gt;\r\n&lt;td width=&quot;234&quot;&gt;\r\n&lt;p&gt;&nbsp;&lt;/p&gt;\r\n&lt;/td&gt;\r\n&lt;td width=&quot;234&quot;&gt;\r\n&lt;p&gt;&nbsp;&lt;/p&gt;\r\n&lt;/td&gt;\r\n&lt;/tr&gt;\r\n&lt;tr&gt;\r\n&lt;td width=&quot;234&quot;&gt;\r\n&lt;p&gt;&nbsp;&lt;/p&gt;\r\n&lt;/td&gt;\r\n&lt;td width=&quot;234&quot;&gt;\r\n&lt;p&gt;&nbsp;&lt;/p&gt;\r\n&lt;/td&gt;\r\n&lt;td width=&quot;234&quot;&gt;\r\n&lt;p&gt;&nbsp;&lt;/p&gt;\r\n&lt;/td&gt;\r\n&lt;td width=&quot;234&quot;&gt;\r\n&lt;p&gt;&nbsp;&lt;/p&gt;\r\n&lt;/td&gt;\r\n&lt;/tr&gt;\r\n&lt;/tbody&gt;\r\n&lt;/table&gt;\r\n&lt;p&gt;&nbsp;&lt;/p&gt;',1,70,'Dada',NULL,NULL,NULL,NULL,'','2021-08-01 09:49:35','2022-04-26 12:31:02',NULL),(54,'&lt;p&gt;&lt;img src=&quot;../../storage/uploads/B1cvQebMdDWi3vDq2Kw9NkGBh1QhDTUnGLMgfiyd.jpeg&quot; alt=&quot;&quot; width=&quot;288&quot; height=&quot;416&quot; /&gt;&lt;/p&gt;',1,71,'Raj',NULL,NULL,NULL,NULL,'','2021-10-23 15:23:46','2021-10-23 15:24:04',NULL),(55,'&lt;table&gt;\r\n&lt;tbody&gt;\r\n&lt;tr&gt;\r\n&lt;td width=&quot;234&quot;&gt;\r\n&lt;p&gt;Dtfjgwuft&lt;/p&gt;\r\n&lt;/td&gt;\r\n&lt;td width=&quot;234&quot;&gt;\r\n&lt;p&gt;Fyfyfh&lt;/p&gt;\r\n&lt;/td&gt;\r\n&lt;td width=&quot;234&quot;&gt;\r\n&lt;p&gt;Yryr&lt;/p&gt;\r\n&lt;/td&gt;\r\n&lt;td width=&quot;234&quot;&gt;\r\n&lt;p&gt;jfhfh&lt;/p&gt;\r\n&lt;/td&gt;\r\n&lt;/tr&gt;\r\n&lt;tr&gt;\r\n&lt;td width=&quot;234&quot;&gt;\r\n&lt;p&gt;&nbsp;&lt;/p&gt;\r\n&lt;/td&gt;\r\n&lt;td width=&quot;234&quot;&gt;\r\n&lt;p&gt;&nbsp;&lt;/p&gt;\r\n&lt;/td&gt;\r\n&lt;td width=&quot;234&quot;&gt;\r\n&lt;p&gt;&nbsp;&lt;/p&gt;\r\n&lt;/td&gt;\r\n&lt;td width=&quot;234&quot;&gt;\r\n&lt;p&gt;&nbsp;&lt;/p&gt;\r\n&lt;/td&gt;\r\n&lt;/tr&gt;\r\n&lt;tr&gt;\r\n&lt;td width=&quot;234&quot;&gt;\r\n&lt;p&gt;&nbsp;&lt;/p&gt;\r\n&lt;/td&gt;\r\n&lt;td width=&quot;234&quot;&gt;\r\n&lt;p&gt;&nbsp;&lt;/p&gt;\r\n&lt;/td&gt;\r\n&lt;td width=&quot;234&quot;&gt;\r\n&lt;p&gt;&nbsp;&lt;/p&gt;\r\n&lt;/td&gt;\r\n&lt;td width=&quot;234&quot;&gt;\r\n&lt;p&gt;&nbsp;&lt;/p&gt;\r\n&lt;/td&gt;\r\n&lt;/tr&gt;\r\n&lt;/tbody&gt;\r\n&lt;/table&gt;\r\n&lt;p&gt;&nbsp;&lt;/p&gt;',1,72,'vnbvbnvn',NULL,NULL,NULL,NULL,'','2021-11-29 16:05:17','2022-04-26 12:31:38',NULL),(56,'&lt;p&gt;&lt;img src=&quot;../../storage/uploads/a16qguvM8jRzYEsZkDwIJVNOmqQbIVpDUalpYGxN.png&quot; alt=&quot;&quot; width=&quot;715&quot; height=&quot;314&quot; /&gt;&lt;/p&gt;\r\n&lt;p&gt;ghjgjghjgjhgjh&lt;/p&gt;\r\n&lt;p&gt;kjbkbjkbjkbkhbk&lt;/p&gt;',1,73,'12',NULL,NULL,NULL,NULL,'','2021-12-13 09:10:41','2021-12-13 09:11:03',NULL),(57,'&lt;p&gt;yfjgugjhgj&lt;/p&gt;\r\n&lt;p&gt;&lt;img src=&quot;../../storage/uploads/G9GCKnduU3LtkH6w58inOJsLoyzzI3vJkmL9ruqz.jpeg&quot; alt=&quot;&quot; width=&quot;1920&quot; height=&quot;2560&quot; /&gt;&lt;/p&gt;',1,74,NULL,NULL,NULL,NULL,NULL,'','2022-06-13 10:51:19','2022-06-13 10:51:19',NULL),(58,'&lt;p&gt;&lt;img src=&quot;../../storage/uploads/HtT4MuCzLpIwBTKz5GPLzPVS9bo4tB9UOalyxCI8.jpeg&quot; alt=&quot;&quot; width=&quot;690&quot; height=&quot;690&quot; /&gt;&lt;/p&gt;\r\n&lt;p style=&quot;text-align: center;&quot;&gt;hjhjhjhjgjhgjhgjhgj&lt;/p&gt;',1,75,NULL,NULL,NULL,NULL,NULL,'','2022-11-03 05:24:28','2022-11-03 05:24:28',NULL),(59,'&lt;p&gt;ngdhgjegjhf rkhfk3rhkh3kh3 kh3 khk&lt;/p&gt;',1,76,'Saibaba',NULL,NULL,NULL,NULL,'','2022-11-25 10:18:04','2022-11-25 10:18:04',NULL),(60,'&lt;p&gt;&lt;img src=&quot;../../storage/uploads/pI0MfWrPbdIRIWd7mZ5kqEv4H8ndM0BeKJbFvbUd.png&quot; alt=&quot;&quot; width=&quot;2522&quot; height=&quot;2253&quot; /&gt;&lt;/p&gt;',1,77,'Suresh',NULL,NULL,NULL,NULL,'','2022-12-19 14:47:57','2023-02-07 17:03:09','1675789389.jpg'),(61,'&lt;p&gt;&nbsp;&lt;/p&gt;\r\n&lt;div class=&quot;col-sm-6&quot;&gt;\r\n&lt;div class=&quot;title mb-30&quot;&gt;\r\n&lt;h2&gt;&lt;img src=&quot;../../storage/uploads/V6swNGCZoV3Of3vP5DP2fOH1ARJy3uUUfwd6TObI.jpeg&quot; width=&quot;372&quot; height=&quot;219&quot; /&gt;&lt;/h2&gt;\r\n&lt;/div&gt;\r\n&lt;p class=&quot;mt-30 text-justify&quot;&gt;&nbsp;&lt;/p&gt;\r\n&lt;/div&gt;\r\n&lt;div class=&quot;col-sm-6&quot;&gt;\r\n&lt;div class=&quot;title mb-30&quot;&gt;\r\n&lt;h2 style=&quot;text-align: left;&quot;&gt;Contact Us&lt;/h2&gt;\r\n&lt;h2 style=&quot;text-align: left;&quot;&gt;&lt;strong&gt;Aadi Eye Clinic&lt;/strong&gt;&lt;/h2&gt;\r\n&lt;p style=&quot;text-align: left;&quot;&gt;1&lt;/p&gt;\r\n&lt;p style=&quot;text-align: left;&quot;&gt;5&lt;/p&gt;\r\n&lt;p style=&quot;text-align: left;&quot;&gt;6&lt;/p&gt;\r\n&lt;p style=&quot;text-align: left;&quot;&gt;7&lt;/p&gt;\r\n&lt;/div&gt;\r\n&lt;div class=&quot;&quot; style=&quot;text-align: left;&quot;&gt;&nbsp;&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;p&gt;&nbsp;&lt;/p&gt;',1,80,NULL,NULL,NULL,NULL,NULL,'','2023-01-22 15:28:02','2023-01-22 15:42:12',NULL),(62,'&lt;div class=&quot;col-sm-4&quot;&gt;\r\n&lt;div class=&quot;title mb-30&quot;&gt;&lt;br /&gt; &lt;iframe style=&quot;border: 0;&quot; src=&quot;https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d15071.212979452093!2d73.0065052!3d19.2037942!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x6be200bcd91d94f2!2sHexa%20Cure%20Hospital!5e0!3m2!1sen!2sin!4v1675150200384!5m2!1sen!2sin&quot; width=&quot;300&quot; height=&quot;225&quot; allowfullscreen=&quot;allowfullscreen&quot;&gt;&lt;/iframe&gt;&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;div class=&quot;col-sm-8&quot;&gt;\r\n&lt;div class=&quot;title mb-30&quot;&gt;&lt;br /&gt;\r\n&lt;p style=&quot;text-align: left;&quot;&gt;Healthcare is a vast field of opportunities. So grab one!!!!!&lt;br /&gt;Become a certified Nurse/Pharmacist/Lab technician or even a Doctor.&lt;br /&gt;We guide you for your future.&lt;br /&gt;To get started in a field of Healthcare do contact us.&lt;br /&gt;We are always there for you.&lt;br /&gt;Courses offered by us follow the link.&lt;br /&gt;Other courses guidance,&lt;br /&gt;ANM, GNM, Bsc Nursing, Msc Nursing, D.Pharmacy, B.Pharmacy, M.Pharmacy, P.H.D&lt;/p&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;p&gt;&nbsp;&lt;/p&gt;',1,78,NULL,NULL,NULL,NULL,NULL,'','2023-01-31 07:55:11','2023-01-31 07:59:13',NULL),(63,'&lt;p&gt;ABCDEFGHIJKLMNOPQRSTUVWXYZ&lt;/p&gt;',1,81,'Nikam',NULL,NULL,NULL,NULL,'','2023-03-04 12:05:27','2023-03-05 12:47:35','1677931574.jpg');
/*!40000 ALTER TABLE `dynamic_text` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dynamic_text_type`
--

DROP TABLE IF EXISTS `dynamic_text_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dynamic_text_type` (
  `text_typeId` int(11) NOT NULL AUTO_INCREMENT,
  `name` text,
  `description` text,
  `tableName` text,
  `isActive` bit(1) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`text_typeId`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dynamic_text_type`
--

LOCK TABLES `dynamic_text_type` WRITE;
/*!40000 ALTER TABLE `dynamic_text_type` DISABLE KEYS */;
INSERT INTO `dynamic_text_type` VALUES (1,'menu_data',NULL,NULL,NULL,'2017-03-12 18:01:11','2017-03-12 18:01:11'),(2,'site_logo',NULL,NULL,NULL,'2017-03-12 18:01:11','2017-03-12 18:01:11'),(3,'body_one',NULL,NULL,NULL,'2017-03-12 18:01:11','2017-03-12 18:01:11'),(4,'body_two',NULL,NULL,NULL,'2017-03-12 18:01:11','2017-03-12 18:01:11'),(5,'footer',NULL,NULL,NULL,'2017-03-12 18:01:11','2017-03-12 18:01:11'),(6,'footer_address',NULL,NULL,NULL,'2017-03-12 18:01:11','2017-03-12 18:01:11');
/*!40000 ALTER TABLE `dynamic_text_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ent_form_dropdowns`
--

DROP TABLE IF EXISTS `ent_form_dropdowns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ent_form_dropdowns` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `formName` text,
  `fieldName` text,
  `ddText` text,
  `ddValue` text,
  `isdefault` bit(1) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=73 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ent_form_dropdowns`
--

LOCK TABLES `ent_form_dropdowns` WRITE;
/*!40000 ALTER TABLE `ent_form_dropdowns` DISABLE KEYS */;
INSERT INTO `ent_form_dropdowns` VALUES (58,'ent_prescription','Times a day','1--------1-------1','1--------1-------1',NULL,'2023-05-27 14:42:25',NULL),(59,'ent_prescription','Times a day','1-------0-------1','1-------0-------1',NULL,'2023-05-27 14:42:25',NULL),(60,'ent_prescription','Times a day','0--------1--------0','0--------1--------0',NULL,'2023-05-27 14:42:25',NULL),(61,'ent_prescription','Quantity','1','1',NULL,'2023-05-27 14:43:05',NULL),(62,'ent_prescription','Quantity','2','2',NULL,'2023-05-27 14:43:05',NULL),(63,'ent_prescription','Quantity','3','3',NULL,'2023-05-27 14:43:05',NULL),(64,'ent_prescription','Quantity','4','4',NULL,'2023-05-27 14:43:05',NULL),(65,'ent_prescription','Quantity','5','5',NULL,'2023-05-27 14:43:05',NULL),(66,'ent_prescription','Quantity','6','6',NULL,'2023-05-27 14:43:05',NULL),(67,'ent_prescription','Quantity','7','7',NULL,'2023-05-27 14:43:05',NULL),(68,'ent_prescription','Strength','1','1',NULL,'2023-05-27 14:43:32',NULL),(69,'ent_prescription','Strength','2','2',NULL,'2023-05-27 14:43:32',NULL),(70,'ent_prescription','Strength','3','3',NULL,'2023-05-27 14:43:32',NULL),(71,'ent_prescription','Strength','4','4',NULL,'2023-05-27 14:43:32',NULL),(72,'ent_prescription','Strength','5','5',NULL,'2023-05-27 14:43:32',NULL);
/*!40000 ALTER TABLE `ent_form_dropdowns` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ent_prescription_lists`
--

DROP TABLE IF EXISTS `ent_prescription_lists`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ent_prescription_lists` (
  `id` bigint(10) NOT NULL AUTO_INCREMENT,
  `case_number` text NOT NULL,
  `medicine_id` bigint(20) NOT NULL,
  `medicine_Quntity` text NOT NULL,
  `per_unit_cost` decimal(10,2) NOT NULL,
  `numberoftimes` text,
  `no_of_days` text,
  `strength` text,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `case_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=78 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ent_prescription_lists`
--

LOCK TABLES `ent_prescription_lists` WRITE;
/*!40000 ALTER TABLE `ent_prescription_lists` DISABLE KEYS */;
INSERT INTO `ent_prescription_lists` VALUES (73,'p_00001445',236,'3',0.00,'1--------1-------1',NULL,'2','2023-05-27 20:20:38','2023-05-27 20:20:38',140),(74,'p_00001445',237,'4',0.00,'1-------0-------1',NULL,'3','2023-05-27 20:21:08','2023-05-27 20:21:08',140),(75,'p_00001445',236,'2',0.00,'1--------1-------1',NULL,'2','2023-05-27 20:25:15','2023-05-27 20:25:15',140),(76,'p_00001445',237,'4',0.00,'1-------0-------1',NULL,'2','2023-05-27 20:25:15','2023-05-27 20:25:15',140),(77,'p_00001445',238,'5',0.00,'0--------1--------0',NULL,'3','2023-05-27 20:25:15','2023-05-27 20:25:15',140);
/*!40000 ALTER TABLE `ent_prescription_lists` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ent_prescription_templates`
--

DROP TABLE IF EXISTS `ent_prescription_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ent_prescription_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent` int(11) DEFAULT '0',
  `template_name` varchar(255) DEFAULT NULL,
  `medicine_id` int(11) DEFAULT NULL,
  `medicine_Quntity` text,
  `numberoftimes` text,
  `no_of_days` text,
  `strength` varchar(255) DEFAULT NULL,
  `status` enum('0','1') DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ent_prescription_templates`
--

LOCK TABLES `ent_prescription_templates` WRITE;
/*!40000 ALTER TABLE `ent_prescription_templates` DISABLE KEYS */;
INSERT INTO `ent_prescription_templates` VALUES (19,0,'test',236,'2','1--------1-------1',NULL,'2','1'),(20,19,'test',237,'4','1-------0-------1',NULL,'2','1'),(21,19,'test',238,'5','0--------1--------0',NULL,'3','1');
/*!40000 ALTER TABLE `ent_prescription_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `entform`
--

DROP TABLE IF EXISTS `entform`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `entform` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `case_id` bigint(20) DEFAULT NULL,
  `case_number` text,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `uveiitis_chk` int(10) NOT NULL,
  `preoperative_chk` int(11) NOT NULL,
  `ear1_chk` int(11) NOT NULL,
  `ear2_chk` int(11) NOT NULL,
  `nose_chk` int(11) NOT NULL,
  `neck_chk` int(11) NOT NULL,
  `throat_chk` int(11) NOT NULL,
  `leftear` text,
  `rightear` text,
  `nose` text,
  `neck` text,
  `throat` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entform`
--

LOCK TABLES `entform` WRITE;
/*!40000 ALTER TABLE `entform` DISABLE KEYS */;
/*!40000 ALTER TABLE `entform` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `entformmultipleentry`
--

DROP TABLE IF EXISTS `entformmultipleentry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `entformmultipleentry` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `eyeformid` bigint(20) DEFAULT NULL,
  `field_name` text,
  `field_value_OD` text,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=67 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entformmultipleentry`
--

LOCK TABLES `entformmultipleentry` WRITE;
/*!40000 ALTER TABLE `entformmultipleentry` DISABLE KEYS */;
/*!40000 ALTER TABLE `entformmultipleentry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `entmedical_store`
--

DROP TABLE IF EXISTS `entmedical_store`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `entmedical_store` (
  `id` bigint(100) NOT NULL AUTO_INCREMENT,
  `medicine_name` varchar(5000) NOT NULL,
  `generic_name` text,
  `available_quantity` bigint(20) NOT NULL,
  `unit_price` decimal(10,2) NOT NULL,
  `balance_quantity` bigint(20) NOT NULL,
  `isactive` bit(1) NOT NULL,
  `created_dt` datetime NOT NULL,
  `updated_dt` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=239 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entmedical_store`
--

LOCK TABLES `entmedical_store` WRITE;
/*!40000 ALTER TABLE `entmedical_store` DISABLE KEYS */;
INSERT INTO `entmedical_store` VALUES (236,'levepil 500',NULL,0,0.00,1,'','0000-00-00 00:00:00','0000-00-00 00:00:00'),(237,'naprad',NULL,0,0.00,1,'','0000-00-00 00:00:00','0000-00-00 00:00:00'),(238,'hahkkaskg',NULL,0,0.00,1,'','0000-00-00 00:00:00','0000-00-00 00:00:00');
/*!40000 ALTER TABLE `entmedical_store` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `entreport_images`
--

DROP TABLE IF EXISTS `entreport_images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `entreport_images` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reportFileName` varchar(500) DEFAULT NULL,
  `case_id` text NOT NULL,
  `filePath` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entreport_images`
--

LOCK TABLES `entreport_images` WRITE;
/*!40000 ALTER TABLE `entreport_images` DISABLE KEYS */;
/*!40000 ALTER TABLE `entreport_images` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_comments`
--

DROP TABLE IF EXISTS `event_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `event_id` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `mobile` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `comment` longtext,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` enum('0','1') NOT NULL DEFAULT '0',
  `is_deleted` enum('0','1') NOT NULL DEFAULT '0',
  `ip_address` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_comments`
--

LOCK TABLES `event_comments` WRITE;
/*!40000 ALTER TABLE `event_comments` DISABLE KEYS */;
INSERT INTO `event_comments` VALUES (1,1,'Suresh',NULL,NULL,'Vey Nice event','2022-04-08 05:35:41','1','0','122.169.115.118'),(2,2,'Suresh',NULL,NULL,'I Enjoy Holi','2022-04-08 05:40:59','1','0','122.169.115.118');
/*!40000 ALTER TABLE `event_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_likes`
--

DROP TABLE IF EXISTS `event_likes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_likes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `event_id` int(11) NOT NULL,
  `first_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `ip_address` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_likes`
--

LOCK TABLES `event_likes` WRITE;
/*!40000 ALTER TABLE `event_likes` DISABLE KEYS */;
INSERT INTO `event_likes` VALUES (1,1,'Suresh',NULL,'122.169.115.118','2022-04-08 05:36:23'),(2,1,'Deepak',NULL,'122.169.115.118','2022-04-08 05:36:33'),(3,2,'Deepak',NULL,'122.169.115.118','2022-04-08 05:40:45');
/*!40000 ALTER TABLE `event_likes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `events`
--

DROP TABLE IF EXISTS `events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `events` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `events`
--

LOCK TABLES `events` WRITE;
/*!40000 ALTER TABLE `events` DISABLE KEYS */;
/*!40000 ALTER TABLE `events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eye_blood_investigation`
--

DROP TABLE IF EXISTS `eye_blood_investigation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `eye_blood_investigation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `case_id` int(11) DEFAULT NULL,
  `blood_title_id` text NOT NULL,
  `blood_value` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eye_blood_investigation`
--

LOCK TABLES `eye_blood_investigation` WRITE;
/*!40000 ALTER TABLE `eye_blood_investigation` DISABLE KEYS */;
/*!40000 ALTER TABLE `eye_blood_investigation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eye_examination_drpdwn`
--

DROP TABLE IF EXISTS `eye_examination_drpdwn`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `eye_examination_drpdwn` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dd_text` text,
  `dd_value` text,
  `dd_type` text,
  `isActive` bit(1) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eye_examination_drpdwn`
--

LOCK TABLES `eye_examination_drpdwn` WRITE;
/*!40000 ALTER TABLE `eye_examination_drpdwn` DISABLE KEYS */;
/*!40000 ALTER TABLE `eye_examination_drpdwn` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eye_examination_od_os`
--

DROP TABLE IF EXISTS `eye_examination_od_os`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `eye_examination_od_os` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `case_id` bigint(20) DEFAULT NULL,
  `od_os` text,
  `vertical` text,
  `horizontal` text,
  `axis` text,
  `ugva_1` text,
  `ugva_2` text,
  `va_1` text,
  `va_2` text,
  `phva` text,
  `bcva_1` text,
  `bcva_2` text,
  `old_glass_spherical` text,
  `old_glass_cylendrical` text,
  `old_glass_axis` text,
  `old_glass_add` text,
  `new_glass_spherical` text,
  `new_glass_cylendrical` text,
  `new_glass_axis` text,
  `new_glass_add` text,
  `dialated_retrac_1` text,
  `dialated_retrac_2` text,
  `dialated_retrac_3` text,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eye_examination_od_os`
--

LOCK TABLES `eye_examination_od_os` WRITE;
/*!40000 ALTER TABLE `eye_examination_od_os` DISABLE KEYS */;
/*!40000 ALTER TABLE `eye_examination_od_os` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eye_examination_vision`
--

DROP TABLE IF EXISTS `eye_examination_vision`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `eye_examination_vision` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `case_id` bigint(20) DEFAULT NULL,
  `dd_ref_type` text,
  `dd_undialated` text,
  `dd_normal` text,
  `dd_withglass_1` text,
  `ipd` text,
  `dd_glass_for_cost_use` text,
  `dd_glass_single_pair` text,
  `dd_white_glass_2` text,
  `dd_glass_other` text,
  `results` text,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eye_examination_vision`
--

LOCK TABLES `eye_examination_vision` WRITE;
/*!40000 ALTER TABLE `eye_examination_vision` DISABLE KEYS */;
/*!40000 ALTER TABLE `eye_examination_vision` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eye_history`
--

DROP TABLE IF EXISTS `eye_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `eye_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `case_id` bigint(20) DEFAULT NULL,
  `history_type_id` bigint(20) DEFAULT NULL,
  `name` text,
  `dd` bit(1) DEFAULT NULL,
  `os` bit(1) DEFAULT NULL,
  `ou` bit(1) DEFAULT NULL,
  `na` bit(1) DEFAULT NULL,
  `since_number` decimal(10,0) DEFAULT NULL,
  `since_unit` text,
  `additional_comment` text,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eye_history`
--

LOCK TABLES `eye_history` WRITE;
/*!40000 ALTER TABLE `eye_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `eye_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eye_history_memory`
--

DROP TABLE IF EXISTS `eye_history_memory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `eye_history_memory` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `history_type_id` bigint(20) DEFAULT NULL,
  `name` text,
  `dd` bit(1) DEFAULT NULL,
  `os` bit(1) DEFAULT NULL,
  `ou` bit(1) DEFAULT NULL,
  `na` bit(1) DEFAULT NULL,
  `since_number` decimal(10,0) DEFAULT NULL,
  `since_unit` text,
  `additional_comment` text,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eye_history_memory`
--

LOCK TABLES `eye_history_memory` WRITE;
/*!40000 ALTER TABLE `eye_history_memory` DISABLE KEYS */;
/*!40000 ALTER TABLE `eye_history_memory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eye_history_type`
--

DROP TABLE IF EXISTS `eye_history_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `eye_history_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eye_history_type`
--

LOCK TABLES `eye_history_type` WRITE;
/*!40000 ALTER TABLE `eye_history_type` DISABLE KEYS */;
INSERT INTO `eye_history_type` VALUES (1,'Complaints','2017-07-01 00:00:00','2017-07-01 00:00:00'),(2,'OpthalHistory','2017-07-01 00:00:00','2017-07-01 00:00:00'),(3,'SystemicHistory','2017-07-01 00:00:00','2017-07-01 00:00:00'),(4,'Rx','2017-07-01 00:00:00','2017-07-01 00:00:00');
/*!40000 ALTER TABLE `eye_history_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eye_op_nt_anesthetist_notes`
--

DROP TABLE IF EXISTS `eye_op_nt_anesthetist_notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `eye_op_nt_anesthetist_notes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `eye_op_nt_id` bigint(20) NOT NULL,
  `an_history` text,
  `an_allergies` text,
  `an_pulse` text,
  `an_cardiac_history` text,
  `an_bp` text,
  `an_investigations` text,
  `an_nbm_notnbm` text,
  `an_dentition` text,
  `ion_anesthesia_topical_peribular_given_by` text,
  `ion_pulse` text,
  `ion_o_saturation` text,
  `ion_bp` text,
  `pon_pulse` text,
  `pon_bp` text,
  `pon_o_saturation` text,
  `pon_additional_note` text,
  `anesthetist_name` text,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eye_op_nt_anesthetist_notes`
--

LOCK TABLES `eye_op_nt_anesthetist_notes` WRITE;
/*!40000 ALTER TABLE `eye_op_nt_anesthetist_notes` DISABLE KEYS */;
/*!40000 ALTER TABLE `eye_op_nt_anesthetist_notes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eye_op_nt_surgery_details`
--

DROP TABLE IF EXISTS `eye_op_nt_surgery_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `eye_op_nt_surgery_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `eye_op_nt_id` bigint(20) DEFAULT NULL,
  `surgery_details` text,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eye_op_nt_surgery_details`
--

LOCK TABLES `eye_op_nt_surgery_details` WRITE;
/*!40000 ALTER TABLE `eye_op_nt_surgery_details` DISABLE KEYS */;
INSERT INTO `eye_op_nt_surgery_details` VALUES (2,5,'G','2021-08-02 06:22:07','2021-08-02 06:22:07');
/*!40000 ALTER TABLE `eye_op_nt_surgery_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eye_operation_notes`
--

DROP TABLE IF EXISTS `eye_operation_notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `eye_operation_notes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `case_id` bigint(20) NOT NULL,
  `case_number` text,
  `surgery_name` text,
  `notes` text,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eye_operation_notes`
--

LOCK TABLES `eye_operation_notes` WRITE;
/*!40000 ALTER TABLE `eye_operation_notes` DISABLE KEYS */;
/*!40000 ALTER TABLE `eye_operation_notes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eye_operation_record`
--

DROP TABLE IF EXISTS `eye_operation_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `eye_operation_record` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `case_id` bigint(20) DEFAULT NULL,
  `case_number` text,
  `IPD_no` text,
  `uhid` text,
  `Surgery` text,
  `admission_date_time` text,
  `surgery_date_time` text,
  `discharge_date_time` text,
  `Surgeon` text,
  `classes` text,
  `referedby` text,
  `discharge_sts` text,
  `final_diagnosis` text,
  `Anaesthes_name` text,
  `diagnosis` text,
  `upload_image` text,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eye_operation_record`
--

LOCK TABLES `eye_operation_record` WRITE;
/*!40000 ALTER TABLE `eye_operation_record` DISABLE KEYS */;
/*!40000 ALTER TABLE `eye_operation_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eyeform`
--

DROP TABLE IF EXISTS `eyeform`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `eyeform` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `case_id` bigint(20) DEFAULT NULL,
  `case_number` text,
  `dvn_od` text,
  `dvn_os` text,
  `nvn_od` text,
  `nvn_os` text,
  `lids_od` text,
  `lids_os` text,
  `conjunctive_od` text,
  `conjunctive_os` text,
  `iris_od` text,
  `iris_os` text,
  `pupil_od` text,
  `pupil_os` text,
  `fundus_od` text,
  `fundus_os` text,
  `k1_od` text,
  `k1_os` text,
  `k2_od` text,
  `k2_os` text,
  `lenspower_od` text,
  `lenspower_os` text,
  `axial_length_OD` text,
  `axial_length_OS` text,
  `sac_od` text,
  `sac_os` text,
  `generalExamination` text,
  `Other` text,
  `otherDetailsDiagnosis` text,
  `otherDetailsAnteriorSegment` text,
  `otherDetailsPosteriorSegment` text,
  `systanicExamination` text,
  `CNS` text,
  `localExamReport` text,
  `treatmentAdvice` text,
  `OdImg1` text,
  `OsImg1` text,
  `OdImg2` text,
  `OsImg2` text,
  `IOP_OD` text,
  `IOP_OS` text,
  `opticdisc_OD` text,
  `opticdisc_OS` text,
  `withglasses_OD` text,
  `withglasses_OS` text,
  `withpinhole_OD` text,
  `withpinhole_OS` text,
  `colour_vision_OS` text,
  `colour_vision_OD` text,
  `perimetry_sp_os` text,
  `perimetry_sp_od` text,
  `laser_sp_os` text,
  `laser_sp_od` text,
  `oculizer_sp_os` text,
  `oculizer_sp_od` text,
  `ffa_sp_os` text,
  `ffa_sp_od` text,
  `visualacuity_OD` text,
  `visualacuity_OS` text,
  `colour_OD` text,
  `colour_OS` text,
  `shape_OD` text,
  `shape_OS` text,
  `size_OS` text,
  `size_OD` text,
  `Ratio_OD` text,
  `Ratio_OS` text,
  `Pachymetry_OD` text,
  `Pachymetry_OS` text,
  `schimerTest1_OD` text,
  `schimerTest1_OS` text,
  `schimerTest2_OD` text,
  `schimerTest2_OS` text,
  `surgery` text,
  `advance_amount` text,
  `advance_payment_type` int(11) DEFAULT NULL,
  `advance_payment_reference` varchar(255) DEFAULT NULL,
  `advance_date` timestamp NULL DEFAULT NULL,
  `sph_r_undi` text,
  `sph_r_di` text,
  `sph_l_undi` text,
  `sph_l_di` text,
  `cyl_r_undi` text,
  `cyl_r_di` text,
  `cyl_l_undi` text,
  `cyl_l_di` text,
  `Axis_r_undi` text,
  `Axis_r_di` text,
  `Axis_l_undi` text,
  `Axis_l_di` text,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `retino_scopy_OD` text,
  `retino_scopy_OS` text,
  `CCT_OD` text,
  `CCT_OS` text,
  `Advice_OD` text,
  `Advice_OS` text,
  `BloodInvestigation` text,
  `uveiitis_chk` int(10) NOT NULL,
  `preoperative_chk` int(11) NOT NULL,
  `KC_OD` text,
  `KC_OS` text,
  `vision_l_sa` text,
  `vision_r_sa` text,
  `vision_l_pga` text,
  `vision_r_pga` text,
  `Add_l_sa` text,
  `Add_r_sa` text,
  `Add_l_pga` text,
  `Add_r_pga` text,
  `Nvision_l_sa` text,
  `Nvision_r_sa` text,
  `Nvision_l_pga` text,
  `Nvision_r_pga` text,
  `gonio_od` text,
  `gonio_os` text,
  `familyHistory` text,
  `birthHistory` text,
  `lens_type_OD` text,
  `lens_type_OS` text,
  `sph_r_undi_sub` text,
  `cyl_r_undi_sub` text,
  `Axis_r_undi_sub` text,
  `sph_l_undi_sub` text,
  `cyl_l_undi_sub` text,
  `Axis_l_undi_sub` text,
  `sph_r_di_sub` text,
  `cyl_r_di_sub` text,
  `Axis_r_di_sub` text,
  `sph_l_di_sub` text,
  `cyl_l_di_sub` text,
  `Axis_l_di_sub` text,
  `iop_od_time` varchar(255) DEFAULT NULL,
  `iop_os_time` varchar(255) DEFAULT NULL,
  `Vision_r_undi` varchar(255) DEFAULT NULL,
  `Vision_l_undi` varchar(255) DEFAULT NULL,
  `Vision_r_undi_sub` varchar(255) DEFAULT NULL,
  `Vision_l_undi_sub` varchar(255) DEFAULT NULL,
  `Vision_r_di` varchar(255) DEFAULT NULL,
  `Vision_l_di` varchar(255) DEFAULT NULL,
  `Vision_r_di_sub` varchar(255) DEFAULT NULL,
  `Vision_l_di_sub` varchar(255) DEFAULT NULL,
  `r_retinoscopy_sph` varchar(255) DEFAULT NULL,
  `r_retinoscopy_cyl` varchar(255) DEFAULT NULL,
  `r_retinoscopy_axi` varchar(255) DEFAULT NULL,
  `r_retinoscopy_vision` varchar(255) DEFAULT NULL,
  `l_retinoscopy_sph` varchar(255) DEFAULT NULL,
  `l_retinoscopy_cyl` varchar(255) DEFAULT NULL,
  `l_retinoscopy_axi` varchar(255) DEFAULT NULL,
  `l_retinoscopy_vision` varchar(255) DEFAULT NULL,
  `pastTreatmentHistory` longtext,
  `other_details_comment` longtext,
  `with_glass_dilated_os` varchar(255) DEFAULT NULL,
  `with_glass_dilated_od` varchar(255) DEFAULT NULL,
  `OdImg1_comment` text,
  `OsImg1_comment` text,
  `OdImg2_comment` text,
  `OsImg2_comment` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=133 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eyeform`
--

LOCK TABLES `eyeform` WRITE;
/*!40000 ALTER TABLE `eyeform` DISABLE KEYS */;
/*!40000 ALTER TABLE `eyeform` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eyeformmultipleentry`
--

DROP TABLE IF EXISTS `eyeformmultipleentry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `eyeformmultipleentry` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `eyeformid` bigint(20) DEFAULT NULL,
  `field_name` text,
  `field_value_OD` text,
  `field_value_OS` text,
  `duration_od` varchar(255) DEFAULT NULL,
  `duration_os` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2621 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eyeformmultipleentry`
--

LOCK TABLES `eyeformmultipleentry` WRITE;
/*!40000 ALTER TABLE `eyeformmultipleentry` DISABLE KEYS */;
/*!40000 ALTER TABLE `eyeformmultipleentry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eyform_refraction_retina_scopy`
--

DROP TABLE IF EXISTS `eyform_refraction_retina_scopy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `eyform_refraction_retina_scopy` (
  `refraction_id` int(11) NOT NULL AUTO_INCREMENT,
  `eyeformid` int(11) NOT NULL,
  `retinaCopy_refraction_dv_sph_r` varchar(255) DEFAULT NULL,
  `retinaCopy_refraction_dv_cyl_r` varchar(255) DEFAULT NULL,
  `retinaCopy_refraction_dv_axis_r` varchar(255) DEFAULT NULL,
  `retinaCopy_refraction_dv_vision_r` varchar(255) DEFAULT NULL,
  `retinaCopy_refraction_dv_sph_l` varchar(255) DEFAULT NULL,
  `retinaCopy_refraction_dv_cyl_l` varchar(255) DEFAULT NULL,
  `retinaCopy_refraction_dv_axis_l` varchar(255) DEFAULT NULL,
  `retinaCopy_refraction_dv_vision_l` varchar(255) DEFAULT NULL,
  `retinaCopy_refraction_nv_sph_r` varchar(255) DEFAULT NULL,
  `retinaCopy_refraction_nv_cyl_r` varchar(255) DEFAULT NULL,
  `retinaCopy_refraction_nv_axis_r` varchar(255) DEFAULT NULL,
  `retinaCopy_refraction_nv_vision_r` varchar(255) DEFAULT NULL,
  `retinaCopy_refraction_nv_sph_l` varchar(255) DEFAULT NULL,
  `retinaCopy_refraction_nv_cyl_l` varchar(255) DEFAULT NULL,
  `retinaCopy_refraction_nv_axis_l` varchar(255) DEFAULT NULL,
  `retinaCopy_refraction_nv_vision_l` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`refraction_id`)
) ENGINE=InnoDB AUTO_INCREMENT=107 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eyform_refraction_retina_scopy`
--

LOCK TABLES `eyform_refraction_retina_scopy` WRITE;
/*!40000 ALTER TABLE `eyform_refraction_retina_scopy` DISABLE KEYS */;
/*!40000 ALTER TABLE `eyform_refraction_retina_scopy` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eyform_vision_pgp`
--

DROP TABLE IF EXISTS `eyform_vision_pgp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `eyform_vision_pgp` (
  `pgp_id` int(11) NOT NULL AUTO_INCREMENT,
  `eyeformid` int(11) NOT NULL,
  `vision_pgp_dv_sph_r` varchar(255) DEFAULT NULL,
  `vision_pgp_dv_cyl_r` varchar(255) DEFAULT NULL,
  `vision_pgp_dv_axis_r` varchar(255) DEFAULT NULL,
  `vision_pgp_dv_vision_r` varchar(255) DEFAULT NULL,
  `vision_pgp_dv_sph_l` varchar(255) DEFAULT NULL,
  `vision_pgp_dv_cyl_l` varchar(255) DEFAULT NULL,
  `vision_pgp_dv_axis_l` varchar(255) DEFAULT NULL,
  `vision_pgp_dv_vision_l` varchar(255) DEFAULT NULL,
  `vision_pgp_nv_sph_r` varchar(255) DEFAULT NULL,
  `vision_pgp_nv_cyl_r` varchar(255) DEFAULT NULL,
  `vision_pgp_nv_axis_r` varchar(255) DEFAULT NULL,
  `vision_pgp_nv_vision_r` varchar(255) DEFAULT NULL,
  `vision_pgp_nv_sph_l` varchar(255) DEFAULT NULL,
  `vision_pgp_nv_cyl_l` varchar(255) DEFAULT NULL,
  `vision_pgp_nv_axis_l` varchar(255) DEFAULT NULL,
  `vision_pgp_nv_vision_l` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`pgp_id`)
) ENGINE=InnoDB AUTO_INCREMENT=106 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eyform_vision_pgp`
--

LOCK TABLES `eyform_vision_pgp` WRITE;
/*!40000 ALTER TABLE `eyform_vision_pgp` DISABLE KEYS */;
/*!40000 ALTER TABLE `eyform_vision_pgp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `field_type_data`
--

DROP TABLE IF EXISTS `field_type_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `field_type_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `field_type_id` int(11) DEFAULT NULL,
  `case_id` bigint(20) DEFAULT NULL,
  `field_data` text,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `field_type_data`
--

LOCK TABLES `field_type_data` WRITE;
/*!40000 ALTER TABLE `field_type_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `field_type_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `field_type_memory`
--

DROP TABLE IF EXISTS `field_type_memory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `field_type_memory` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `field_type_id` int(11) DEFAULT NULL,
  `title` text,
  `data` text,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `field_type_memory`
--

LOCK TABLES `field_type_memory` WRITE;
/*!40000 ALTER TABLE `field_type_memory` DISABLE KEYS */;
/*!40000 ALTER TABLE `field_type_memory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `field_types`
--

DROP TABLE IF EXISTS `field_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `field_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `field_types`
--

LOCK TABLES `field_types` WRITE;
/*!40000 ALTER TABLE `field_types` DISABLE KEYS */;
INSERT INTO `field_types` VALUES (1,'Complaints','2017-07-09 00:00:00','2017-07-09 00:00:00'),(2,'Diagnosis','2017-07-09 00:00:00','2017-07-09 00:00:00'),(3,'Treatment','2017-07-09 00:00:00','2017-07-09 00:00:00');
/*!40000 ALTER TABLE `field_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `finding_template`
--

DROP TABLE IF EXISTS `finding_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `finding_template` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `finding_template`
--

LOCK TABLES `finding_template` WRITE;
/*!40000 ALTER TABLE `finding_template` DISABLE KEYS */;
/*!40000 ALTER TABLE `finding_template` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `finding_template_data`
--

DROP TABLE IF EXISTS `finding_template_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `finding_template_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `template_id` varchar(255) DEFAULT NULL,
  `key_text` varchar(255) DEFAULT NULL,
  `od` varchar(255) DEFAULT NULL,
  `os` varchar(255) DEFAULT NULL,
  `duration_od` varchar(255) DEFAULT NULL,
  `duration_os` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `finding_template_data`
--

LOCK TABLES `finding_template_data` WRITE;
/*!40000 ALTER TABLE `finding_template_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `finding_template_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `form_dropdowns`
--

DROP TABLE IF EXISTS `form_dropdowns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `form_dropdowns` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) DEFAULT NULL,
  `formName` text,
  `fieldName` text,
  `ddText` text,
  `ddValue` text,
  `isdefault` bit(1) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4603 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `form_dropdowns`
--

LOCK TABLES `form_dropdowns` WRITE;
/*!40000 ALTER TABLE `form_dropdowns` DISABLE KEYS */;
/*!40000 ALTER TABLE `form_dropdowns` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `form_field_master`
--

DROP TABLE IF EXISTS `form_field_master`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `form_field_master` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `formName` text,
  `fieldName` text,
  `form_field_code` bigint(20) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=290 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `form_field_master`
--

LOCK TABLES `form_field_master` WRITE;
/*!40000 ALTER TABLE `form_field_master` DISABLE KEYS */;
INSERT INTO `form_field_master` VALUES (1,'EyeForm','DVN OD',NULL,NULL,NULL),(2,'EyeForm','DVN OS',NULL,NULL,NULL),(3,'EyeForm','DVN OD',NULL,NULL,NULL),(4,'EyeForm','DVN OS',NULL,NULL,NULL),(5,'EyeForm','NVN OD',NULL,NULL,NULL),(6,'EyeForm','NVN OS',NULL,NULL,NULL),(7,'EyeForm','LIDS OD',NULL,NULL,NULL),(8,'EyeForm','LIDS OS',NULL,NULL,NULL),(9,'EyeForm','Conjunctiva OD',NULL,NULL,NULL),(10,'EyeForm','Conjunctiva OS',NULL,NULL,NULL),(11,'EyeForm','Cornea OD',NULL,NULL,NULL),(12,'EyeForm','Cornea OS',NULL,NULL,NULL),(13,'EyeForm','lens OD',NULL,NULL,NULL),(14,'EyeForm','lens OS',NULL,NULL,NULL),(15,'EyeForm','IRIS OD',NULL,NULL,NULL),(16,'EyeForm','IRIS OS',NULL,NULL,NULL),(17,'EyeForm','Pupil OD',NULL,NULL,NULL),(18,'EyeForm','Pupil OS',NULL,NULL,NULL),(19,'EyeForm','Fundus OD',NULL,NULL,NULL),(20,'EyeForm','Fundus OS',NULL,NULL,NULL),(21,'EyeForm','Diagnosis OD',NULL,NULL,NULL),(22,'EyeForm','Diagnosis OS',NULL,NULL,NULL),(23,'EyeForm','General Examination',NULL,NULL,NULL),(24,'EyeForm','Other',NULL,NULL,NULL),(25,'EyeForm','Systemic Examination',NULL,NULL,NULL),(26,'EyeForm','CNS',NULL,NULL,NULL),(27,'EyeForm','Local Examination Report',NULL,NULL,NULL),(28,'EyeForm','Treatment Advice',NULL,NULL,NULL),(29,'Dentist','Treatment Advice',NULL,NULL,NULL),(30,'EyeForm','K1 OD',NULL,NULL,NULL),(31,'EyeForm','K1 OS',NULL,NULL,NULL),(32,'EyeForm','K2 OD',NULL,NULL,NULL),(33,'EyeForm','K2 OS',NULL,NULL,NULL),(34,'EyeForm','LensPower OD',NULL,NULL,NULL),(35,'EyeForm','LensPower OS',NULL,NULL,NULL),(36,'EyeForm','sac OD',NULL,NULL,NULL),(37,'EyeForm','sac OS',NULL,NULL,NULL),(38,'EyeOperationForm','Anaesthes Name',39,NULL,NULL),(39,'EyeOperationForm','Surgery',40,NULL,'2019-03-04 15:15:11'),(40,'GlassPrescription','SPH DV Right',NULL,NULL,NULL),(41,'GlassPrescription','SPH DV Left',NULL,NULL,NULL),(42,'GlassPrescription','CYL DV Right',NULL,NULL,NULL),(43,'GlassPrescription','CYL DV Left',NULL,NULL,NULL),(44,'GlassPrescription','AXI DV Right',NULL,NULL,NULL),(45,'GlassPrescription','AXI DV Left',NULL,NULL,NULL),(46,'GlassPrescription','Vision DV Right',NULL,NULL,NULL),(47,'GlassPrescription','Vision DV Left',NULL,NULL,NULL),(48,'GlassPrescription','SPH NV Right',NULL,NULL,NULL),(49,'GlassPrescription','SPH NV Left',NULL,NULL,NULL),(50,'GlassPrescription','CYL NV Right',NULL,NULL,NULL),(51,'GlassPrescription','CYL NV Left',NULL,NULL,NULL),(52,'GlassPrescription','AXI NV Right',NULL,NULL,NULL),(53,'GlassPrescription','AXI NV Left',NULL,NULL,NULL),(54,'GlassPrescription','Vision NV Right',NULL,NULL,NULL),(55,'GlassPrescription','Vision NV Left',NULL,NULL,NULL),(56,'EyeForm','Opthal History OD',NULL,NULL,NULL),(57,'EyeForm','Systemic History OD',NULL,NULL,NULL),(58,'EyeForm','optic disc OS',NULL,NULL,NULL),(59,'EyeForm','size OD',NULL,NULL,NULL),(60,'EyeForm','size OS',NULL,NULL,NULL),(61,'EyeForm','shape OS',NULL,NULL,NULL),(62,'EyeForm','shape OD',NULL,NULL,NULL),(63,'EyeForm','colour OS',NULL,NULL,NULL),(64,'EyeForm','colour OD',NULL,NULL,NULL),(65,'EyeForm','visual acuity OS',NULL,NULL,NULL),(66,'EyeForm','visual acuity OD',NULL,NULL,NULL),(67,'EyeForm','with pinhole OS',NULL,NULL,NULL),(68,'EyeForm','with pinhole OD',NULL,NULL,NULL),(69,'EyeForm','with glasses OS',NULL,NULL,NULL),(70,'EyeForm','with glasses OD',NULL,NULL,NULL),(71,'EyeForm','Conj And Lids OD',NULL,NULL,NULL),(72,'EyeForm','OrbitSacsEyeMotility OD',NULL,NULL,NULL),(73,'EyeForm','pupilIrisac OD',NULL,NULL,NULL),(74,'EyeForm','lens',NULL,NULL,NULL),(75,'EyeForm','vitreoretinal OD',NULL,NULL,NULL),(76,'EyeForm','Chief Complaint OD',NULL,NULL,NULL),(77,'EyeForm','Chief Complaint OS',NULL,NULL,NULL),(78,'EyeForm','Opthal History OS',NULL,NULL,NULL),(79,'EyeForm','Systemic History OS',NULL,NULL,NULL),(80,'EyeForm','Systemic History OS',NULL,NULL,NULL),(81,'EyeForm','Conj And Lids OS',NULL,NULL,NULL),(82,'EyeForm','OrbitSacsEyeMotility OS',NULL,NULL,NULL),(83,'EyeForm','pupilIrisac OS',NULL,NULL,NULL),(84,'EyeForm','vitreoretinal OS',NULL,NULL,NULL),(85,'EyeForm','Ratio OD',NULL,NULL,NULL),(86,'EyeForm','Ratio OS',NULL,NULL,NULL),(87,'EyeForm','Pachymetry OD',NULL,NULL,NULL),(88,'EyeForm','Pachymetry OS',NULL,NULL,NULL),(89,'EyeForm','schimerTest1 OD',NULL,NULL,NULL),(90,'EyeForm','schimerTest1 OS',NULL,NULL,NULL),(91,'EyeForm','schimerTest2 OD',NULL,NULL,NULL),(92,'EyeForm','schimerTest2 OS',NULL,NULL,NULL),(93,'EyeForm','IOP OD',NULL,NULL,NULL),(94,'EyeForm','IOP OS',NULL,NULL,NULL),(95,NULL,'Operation',97,NULL,NULL),(96,NULL,'Anaesthesia',98,NULL,NULL),(97,NULL,'outcome_wentDama',99,NULL,NULL),(98,NULL,'outcome_on',100,NULL,NULL),(99,NULL,'obstetric_history',101,NULL,NULL),(100,NULL,'LMP',102,'2019-02-16 19:43:11','2019-02-16 19:43:11'),(101,NULL,'GRAVIDA',103,'2019-02-16 19:56:21','2019-02-16 19:56:21'),(102,NULL,'EDD',104,'2019-02-16 19:56:22','2019-02-16 19:56:22'),(103,NULL,'PARA',105,'2019-02-16 19:56:22','2019-02-16 19:56:22'),(104,NULL,'MTP',106,'2019-02-16 19:56:22','2019-02-16 19:56:22'),(105,NULL,'ABORTION',107,'2019-02-16 19:56:22','2019-02-16 19:56:22'),(106,NULL,'PHYSICAL EXAMINATION',108,'2019-02-16 19:56:22','2019-02-16 19:56:22'),(107,NULL,'Vital Parameter',109,'2019-02-16 19:56:22','2019-02-16 19:56:22'),(108,NULL,'pulse',110,'2019-02-16 19:56:22','2019-02-16 19:56:22'),(109,NULL,'BP',111,'2019-02-16 19:56:22','2019-02-16 19:56:22'),(110,NULL,'respiratory rate',112,'2019-02-16 19:56:22','2019-02-16 19:56:22'),(111,NULL,'general examination',113,'2019-02-16 19:56:22','2019-02-16 19:56:22'),(112,NULL,'pallor',114,'2019-02-16 19:56:22','2019-02-16 19:56:22'),(113,NULL,'icterus',115,'2019-02-16 19:56:22','2019-02-16 19:56:22'),(114,NULL,'rash',116,'2019-02-16 19:56:22','2019-02-16 19:56:22'),(115,NULL,'cyanosis',117,'2019-02-16 19:56:22','2019-02-16 19:56:22'),(116,NULL,'ent',118,'2019-02-16 19:56:22','2019-02-16 19:56:22'),(117,NULL,'lymhadenopathy',119,'2019-02-16 19:56:22','2019-02-16 19:56:22'),(118,NULL,'edema_feet',120,'2019-02-16 19:56:22','2019-02-16 19:56:22'),(119,NULL,'others',121,'2019-02-16 19:56:22','2019-02-16 19:56:22'),(120,NULL,'systemic examination',122,'2019-02-16 19:56:22','2019-02-16 19:56:22'),(121,NULL,'respiratory_system_air_entry',123,'2019-02-16 19:56:22','2019-02-16 19:56:22'),(122,NULL,'foreign_sounds_pleural_rub',124,'2019-02-16 19:56:22','2019-02-16 19:56:22'),(123,NULL,'cardiovascular_heart_sound',125,'2019-02-16 19:56:22','2019-02-16 19:56:22'),(124,NULL,'cardiovascular_heart_sound_s1',126,'2019-02-16 19:56:22','2019-02-16 19:56:22'),(125,NULL,'cardiovascular_heart_sound_s2',127,'2019-02-16 19:56:22','2019-02-16 19:56:22'),(126,NULL,'cardiac_murmur',128,'2019-02-16 19:56:22','2019-02-16 19:56:22'),(127,NULL,'central_nervous_system',129,'2019-02-16 19:56:22','2019-02-16 19:56:22'),(128,NULL,'shape_of_abdomen',130,'2019-02-16 19:56:22','2019-02-16 19:56:22'),(129,NULL,'organomegaly',131,'2019-02-16 19:56:22','2019-02-16 19:56:22'),(130,NULL,'free_fluid_in_abdomen',132,'2019-02-16 19:56:22','2019-02-16 19:56:22'),(131,NULL,'tenderness',133,'2019-02-16 19:56:22','2019-02-16 19:56:22'),(132,NULL,'guarding',134,'2019-02-16 19:56:23','2019-02-16 19:56:23'),(133,NULL,'rigidity',135,'2019-02-16 19:56:23','2019-02-16 19:56:23'),(134,NULL,'faetal_heart_sound',136,'2019-02-16 19:56:23','2019-02-16 19:56:23'),(135,NULL,'pre_vaginal_examination',137,'2019-02-16 19:56:23','2019-02-16 19:56:23'),(136,NULL,'informed_consent_rejected_consented',138,'2019-02-16 19:56:23','2019-02-16 19:56:23'),(137,NULL,'BIRTH HISTORY',139,'2019-02-17 17:23:52','2019-02-17 17:23:52'),(138,NULL,'CONSCIOUSNESS',140,'2019-02-17 17:23:52','2019-02-17 17:23:52'),(139,NULL,'OXYGEN SATURATION',141,'2019-02-17 17:23:52','2019-02-17 17:23:52'),(140,NULL,'HEART RATE',142,'2019-02-17 17:23:53','2019-02-17 17:23:53'),(141,NULL,'PULSE',143,'2019-02-17 17:23:53','2019-02-17 17:23:53'),(142,NULL,'PERIPHERAL PULSATION',144,'2019-02-17 17:23:53','2019-02-17 17:23:53'),(143,NULL,'BLOOD PRESSURE',145,'2019-02-17 17:23:53','2019-02-17 17:23:53'),(144,NULL,'CAPILLARI REFILLING',146,'2019-02-17 17:23:53','2019-02-17 17:23:53'),(145,NULL,'TEMPURATURE',147,'2019-02-17 17:23:53','2019-02-17 17:23:53'),(146,NULL,'NEONATE CRY',148,'2019-02-17 17:23:53','2019-02-17 17:23:53'),(147,NULL,'ACTIVITY',149,'2019-02-17 17:23:53','2019-02-17 17:23:53'),(148,NULL,'REFLEXES',150,'2019-02-17 17:23:53','2019-02-17 17:23:53'),(149,NULL,'COLOUR',151,'2019-02-17 17:23:53','2019-02-17 17:23:53'),(150,NULL,'OBVIOUS CONG ANAMOLY',152,'2019-02-17 17:23:53','2019-02-17 17:23:53'),(151,NULL,'DEHYDRATION',153,'2019-02-17 17:23:53','2019-02-17 17:23:53'),(152,NULL,'SCLEREMA',154,'2019-02-17 17:23:53','2019-02-17 17:23:53'),(153,NULL,'LYMPHADENOPATHY',155,'2019-02-17 17:23:53','2019-02-17 17:23:53'),(154,NULL,'RESPIRATORY SYSTEM',156,'2019-02-17 17:23:53','2019-02-17 17:23:53'),(155,NULL,'FOREIGN SOUND ',157,'2019-02-17 17:23:53','2019-02-17 17:23:53'),(156,NULL,'MENINGEAL SIGN',158,'2019-02-17 17:23:53','2019-02-17 17:23:53'),(157,NULL,'CRANIAL NERVES',159,'2019-02-17 17:23:53','2019-02-17 17:23:53'),(158,NULL,'MOTOR SYSTEMS',160,'2019-02-17 17:23:53','2019-02-17 17:23:53'),(159,NULL,'SENSORY SYSTEMS',161,'2019-02-17 17:23:53','2019-02-17 17:23:53'),(160,NULL,'PLANTERS',162,'2019-02-17 17:23:53','2019-02-17 17:23:53'),(161,NULL,'DelivaryNotes_Date',167,'2019-03-04 12:17:43','2019-03-04 12:17:44'),(162,NULL,'DelivaryNotes_Time',168,'2019-03-04 12:18:10','2019-03-04 12:18:11'),(163,NULL,'NatureOfDelivary',169,'2019-03-04 12:20:56','2019-03-04 12:20:56'),(164,NULL,'SexOfBaby',170,'2019-03-04 12:21:21','2019-03-04 12:21:21'),(165,NULL,'BabyWeight',171,'2019-03-04 12:21:44','2019-03-04 12:21:44'),(166,NULL,'PostNatalPeriod',172,'2019-03-04 12:22:26','2019-03-04 12:22:26'),(167,NULL,'IndicationOfLSCS',173,'2019-03-04 12:23:07','2019-03-04 12:23:07'),(168,NULL,'TypeOfAnaesthesia',174,'2019-03-04 12:29:44','2019-03-04 12:29:44'),(169,NULL,'ComplicationAnaesthesia',175,'2019-03-04 12:30:01','2019-03-04 12:30:01'),(170,NULL,'HystecrectomyVaginalAbdominal',176,'2019-03-04 12:30:16','2019-03-04 15:24:51'),(171,NULL,'OtherSurgery',177,'2019-03-04 15:47:45','2019-03-04 15:47:45'),(172,NULL,'TubalLigation',178,'2019-03-04 16:30:53','2019-03-04 16:30:53'),(173,NULL,'LAPTL',179,'2019-03-04 16:31:06','2019-03-04 16:31:06'),(174,NULL,'Operative',180,'2019-03-04 16:31:59','2019-03-04 16:31:59'),(175,NULL,'RecoveryFromAnaesthesia',181,'2019-03-04 16:36:37','2019-03-04 16:36:37'),(176,NULL,'LSCS',182,'2019-03-04 16:38:26','2019-03-04 16:38:26'),(177,NULL,'Complaints',183,'2019-03-04 18:35:38','2019-03-04 18:35:38'),(178,NULL,'GeneralCondition',184,'2019-03-04 18:37:06','2019-03-04 18:37:06'),(179,NULL,'RR',185,'2019-03-04 18:38:45','2019-03-04 18:38:45'),(180,NULL,'SpO2',186,'2019-03-04 18:43:31','2019-03-04 18:43:31'),(181,NULL,'systemicExaminationRS',187,'2019-03-04 18:46:17','2019-03-04 18:46:17'),(182,NULL,'systemicExaminationCVS',188,'2019-03-04 18:46:24','2019-03-04 18:46:24'),(183,NULL,'systemicExaminationCNS',189,'2019-03-04 18:46:35','2019-03-04 18:46:35'),(184,NULL,'systemicExaminationPA',190,'2019-03-04 18:46:42','2019-03-04 18:46:42'),(185,'Prescription','Eye',NULL,NULL,NULL),(186,'Prescription','Day',NULL,NULL,NULL),(187,'Prescription','Times a day',NULL,NULL,NULL),(188,NULL,'FaceTurnChinRight',194,'2019-08-25 15:41:19','2019-08-25 15:41:20'),(189,NULL,'FaceTurnChinLeft',195,'2019-08-25 15:41:40','2019-08-25 15:41:40'),(190,NULL,'FaceTurnHeadTiltRight',196,'2019-08-25 15:41:57','2019-08-25 15:41:57'),(191,NULL,'FaceTurnHeadTiltLeft',197,'2019-08-25 15:42:08','2019-08-25 15:42:08'),(192,NULL,'HirschbergTest',198,'2019-08-25 15:42:41','2019-08-25 15:42:41'),(193,NULL,'CoverTest',199,'2019-08-25 15:42:54','2019-08-25 15:42:54'),(194,NULL,'PrismBarCoverTestDistance',200,'2019-08-25 15:43:44','2019-08-25 15:43:44'),(195,NULL,'NineGazes1',201,'2019-08-25 15:44:07','2019-08-25 15:44:07'),(196,NULL,'NineGazes2',202,'2019-08-25 15:44:14','2019-08-25 15:44:14'),(197,NULL,'NineGazes3',203,'2019-08-25 15:44:22','2019-08-25 15:44:22'),(198,NULL,'NineGazes4',204,'2019-08-25 15:44:29','2019-08-25 15:44:29'),(199,NULL,'NineGazes5',205,'2019-08-25 15:44:34','2019-08-25 15:44:34'),(200,NULL,'NineGazes6',206,'2019-08-25 15:44:40','2019-08-25 15:44:40'),(201,NULL,'NineGazes7',207,'2019-08-25 15:44:45','2019-08-25 15:44:45'),(202,NULL,'NineGazes8',208,'2019-08-25 15:44:51','2019-08-25 15:44:51'),(203,NULL,'NineGazes9',209,'2019-08-25 15:44:57','2019-08-25 15:44:57'),(204,NULL,'PrimaryDeviation',210,'2019-08-25 15:45:21','2019-08-25 15:45:21'),(205,NULL,'SecondaryDeviation',211,'2019-08-25 15:45:36','2019-08-25 15:45:36'),(206,NULL,'OcularMotility',212,'2019-08-25 15:45:53','2019-08-25 15:45:53'),(207,NULL,'WorthFourDotTest',213,'2019-08-25 15:46:09','2019-08-25 15:46:09'),(208,NULL,'Stereopsis',214,'2019-08-25 15:46:15','2019-08-25 15:46:15'),(209,NULL,'MaddoxRod',215,'2019-08-25 15:46:27','2019-08-25 15:46:27'),(210,NULL,'DipopiaCharting1',216,'2019-08-25 15:46:44','2019-08-25 15:46:44'),(211,NULL,'DipopiaCharting2',217,'2019-08-25 15:46:50','2019-08-25 15:46:50'),(212,NULL,'DipopiaCharting3',218,'2019-08-25 15:46:55','2019-08-25 15:46:55'),(213,NULL,'DipopiaCharting4',219,'2019-08-25 15:47:01','2019-08-25 15:47:01'),(214,NULL,'DipopiaCharting5',220,'2019-08-25 15:47:07','2019-08-25 15:47:07'),(215,NULL,'DipopiaCharting6',221,'2019-08-25 15:47:13','2019-08-25 15:47:13'),(216,NULL,'DipopiaCharting7',222,'2019-08-25 15:47:18','2019-08-25 15:47:18'),(217,NULL,'DipopiaCharting8',223,'2019-08-25 15:47:24','2019-08-25 15:47:24'),(218,NULL,'DipopiaCharting9',224,'2019-08-25 15:47:29','2019-08-25 15:47:29'),(219,NULL,'HeadPosture',225,'2019-08-25 16:04:17','2019-08-25 16:04:17'),(220,NULL,'FixesFollowsRight',226,'2019-08-25 23:00:08','2019-08-25 23:00:08'),(221,NULL,'FixesFollowsLeft',227,'2019-08-25 23:00:24','2019-08-25 23:00:24'),(222,NULL,'ResistsOcclusionRight',228,'2019-08-25 23:00:40','2019-08-25 23:00:40'),(223,NULL,'ResistsOcclusionLeft',229,'2019-08-25 23:00:48','2019-08-25 23:00:48'),(224,NULL,'FixationPatternRight',230,'2019-08-25 23:01:02','2019-08-25 23:01:02'),(225,NULL,'FixationPatternLeft',231,'2019-08-25 23:01:10','2019-08-25 23:01:10'),(226,NULL,'NystagmusRight',232,'2019-08-25 23:01:20','2019-08-25 23:01:20'),(227,NULL,'NystagmusLeft',233,'2019-08-25 23:01:28','2019-08-25 23:01:29'),(228,NULL,'PtosisRight',234,'2019-08-25 23:01:41','2019-08-25 23:01:42'),(229,NULL,'PtosisLeft',235,'2019-08-25 23:01:48','2019-08-25 23:01:48'),(230,NULL,'HeadPostureRight',236,'2019-08-25 23:02:00','2019-08-25 23:02:00'),(231,NULL,'HeadPostureLeft',237,'2019-08-25 23:02:08','2019-08-25 23:02:08'),(232,NULL,'SquintRight',238,'2019-08-25 23:02:16','2019-08-25 23:02:16'),(233,NULL,'SquintLeft',239,'2019-08-25 23:02:24','2019-08-25 23:02:24'),(234,NULL,'BrucknersReflexRight',240,'2019-08-25 23:02:41','2019-08-25 23:02:41'),(235,NULL,'BrucknersReflexLeft',241,'2019-08-25 23:02:48','2019-08-25 23:02:48'),(236,NULL,'MRD1Right',242,'2019-08-25 23:43:55','2019-08-25 23:43:55'),(237,NULL,'MRD1Left',243,'2019-08-25 23:44:02','2019-08-25 23:44:02'),(238,NULL,'MRD2Right',244,'2019-08-25 23:44:12','2019-08-25 23:44:12'),(239,NULL,'MRD2Left',245,'2019-08-25 23:44:18','2019-08-25 23:44:18'),(240,NULL,'PFHRight',246,'2019-08-25 23:44:32','2019-08-25 23:44:32'),(241,NULL,'PFHLeft',247,'2019-08-25 23:44:42','2019-08-25 23:44:42'),(242,NULL,'LPSACTIONRight',248,'2019-08-25 23:44:55','2019-08-25 23:44:55'),(243,NULL,'LPSACTIONLeft',249,'2019-08-25 23:45:01','2019-08-25 23:45:01'),(244,NULL,'FRONTALISOVERACTIONRight',250,'2019-08-25 23:45:15','2019-08-25 23:45:15'),(245,NULL,'FRONTALISOVERACTIONLeft',251,'2019-08-25 23:45:21','2019-08-25 23:45:21'),(246,NULL,'LIDCREASERight',252,'2019-08-25 23:45:35','2019-08-25 23:45:35'),(247,NULL,'LIDCREASELeft',253,'2019-08-25 23:45:41','2019-08-25 23:45:41'),(248,NULL,'BELLSPHENOMEMNONRight',254,'2019-08-25 23:45:58','2019-08-25 23:45:58'),(249,NULL,'BELLSPHENOMEMNONLeft',255,'2019-08-25 23:46:04','2019-08-25 23:46:04'),(250,NULL,'CORNEALSENSATIONRight',256,'2019-08-25 23:46:19','2019-08-25 23:46:19'),(251,NULL,'CORNEALSENSATIONLeft',257,'2019-08-25 23:46:27','2019-08-25 23:46:27'),(252,NULL,'ORBICULARISACTIONRight',258,'2019-08-25 23:46:43','2019-08-25 23:46:43'),(253,NULL,'ORBICULARISACTIONLeft',259,'2019-08-25 23:46:50','2019-08-25 23:46:51'),(254,NULL,'MGJWRight',260,'2019-08-25 23:47:01','2019-08-25 23:47:01'),(255,NULL,'MGJWLeft',261,'2019-08-25 23:47:07','2019-08-25 23:47:08'),(256,NULL,'FATIGUETESTRight',262,'2019-08-25 23:47:21','2019-08-25 23:47:21'),(257,NULL,'FATIGUETESTLeft',263,'2019-08-25 23:47:28','2019-08-25 23:47:28'),(258,NULL,'ICETESTRight',264,'2019-08-25 23:47:39','2019-08-25 23:47:39'),(259,NULL,'ICETESTLeft',265,'2019-08-25 23:47:45','2019-08-25 23:47:45'),(260,NULL,'EDROPHONIUMNEOSTIGMINETESTRight',266,'2019-08-25 23:47:59','2019-08-25 23:47:59'),(261,NULL,'EDROPHONIUMNEOSTIGMINETESTLeft',267,'2019-08-25 23:48:07','2019-08-25 23:48:07'),(262,NULL,'TEARFUNCTIONRight',268,'2019-08-25 23:48:21','2019-08-25 23:48:21'),(263,NULL,'TEARFUNCTIONLeft',269,'2019-08-25 23:48:28','2019-08-25 23:48:28'),(264,NULL,'PtosisRight',270,'2019-08-26 00:01:46','2019-08-26 00:01:46'),(265,NULL,'PtosisLeft',271,'2019-08-26 00:01:53','2019-08-26 00:01:53'),(266,NULL,'SquintRight',272,'2019-08-26 00:02:03','2019-08-26 00:02:03'),(267,NULL,'SquintLeft',273,'2019-08-26 00:02:09','2019-08-26 00:02:09'),(268,'Prescription','Strength',NULL,NULL,NULL),(269,'Prescription','Quantity',NULL,NULL,NULL),(270,'EyeForm','AC OD',NULL,NULL,NULL),(271,'EyeForm','AC OS',NULL,NULL,NULL),(272,'EyeForm','Retina OD',NULL,NULL,NULL),(273,'EyeForm','Retina OS',NULL,NULL,NULL),(274,'EyeForm','Macula OD',NULL,NULL,NULL),(275,'EyeForm','Macula OS',NULL,NULL,NULL),(276,'EyeForm','ONH OD',NULL,NULL,NULL),(277,'EyeForm','ONH OS',NULL,NULL,NULL),(278,'skinOpd','Symptom',286,'2019-08-26 05:32:09','2019-08-26 05:32:09'),(279,'skinOpd','Duration',287,'2019-08-26 05:32:09','2019-08-26 05:32:09'),(280,'skinOpd','OtherIssue',288,'2019-08-26 05:32:09','2019-08-26 05:32:09'),(281,'skinOpd','PastHistory',289,'2019-08-26 05:32:09','2019-08-26 05:32:09'),(282,'skinOpd','PersonalHistory',290,'2019-08-26 05:32:09','2019-08-26 05:32:09'),(283,'skinOpd','MedicalHistory',291,'2019-08-26 05:32:09','2019-08-26 05:32:09'),(284,'skinOpd','FamilyHistory',292,'2019-08-26 05:32:09','2019-08-26 05:32:09'),(285,'skinOpd','Examination',293,'2019-08-26 05:32:09','2019-08-26 05:32:09'),(286,'skinOpd','Investigation',294,'2019-08-26 05:32:09','2019-08-26 05:32:09'),(287,'skinOpd','Procedure',295,'2019-08-26 05:32:09','2019-08-26 05:32:09'),(288,'skinOpd','Consent',296,'2019-08-26 05:32:09','2019-08-26 05:32:09'),(289,'skinOpd','Diagnosis',297,'2019-08-26 05:32:09','2019-08-26 05:32:09');
/*!40000 ALTER TABLE `form_field_master` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `form_field_values`
--

DROP TABLE IF EXISTS `form_field_values`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `form_field_values` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `register_id` bigint(20) DEFAULT NULL,
  `opd_case_master_id` bigint(20) DEFAULT NULL,
  `form_field_code` bigint(20) DEFAULT NULL,
  `field_data` text,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=569 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `form_field_values`
--

LOCK TABLES `form_field_values` WRITE;
/*!40000 ALTER TABLE `form_field_values` DISABLE KEYS */;
INSERT INTO `form_field_values` VALUES (1,11,NULL,97,NULL,'2019-04-21 00:55:55','2019-04-21 00:55:55'),(2,11,NULL,98,NULL,'2019-04-21 00:55:55','2019-04-21 00:55:55'),(3,11,NULL,99,NULL,'2019-04-21 00:55:55','2019-04-21 00:55:55'),(4,11,NULL,100,NULL,'2019-04-21 00:55:55','2019-04-21 00:55:55'),(5,11,NULL,101,NULL,'2019-04-21 00:56:09','2019-04-21 00:56:09'),(6,11,NULL,102,NULL,'2019-04-21 00:56:09','2019-04-21 00:56:09'),(7,11,NULL,103,NULL,'2019-04-21 00:56:09','2019-04-21 00:56:09'),(8,11,NULL,104,NULL,'2019-04-21 00:56:09','2019-04-21 00:56:09'),(9,11,NULL,105,NULL,'2019-04-21 00:56:09','2019-04-21 00:56:09'),(10,11,NULL,106,NULL,'2019-04-21 00:56:09','2019-04-21 00:56:09'),(11,11,NULL,107,NULL,'2019-04-21 00:56:09','2019-04-21 00:56:09'),(12,11,NULL,108,NULL,'2019-04-21 00:56:09','2019-04-21 00:56:09'),(13,11,NULL,109,NULL,'2019-04-21 00:56:09','2019-04-21 00:56:09'),(14,11,NULL,110,NULL,'2019-04-21 00:56:09','2019-04-21 00:56:09'),(15,11,NULL,111,NULL,'2019-04-21 00:56:09','2019-04-21 00:56:09'),(16,11,NULL,112,NULL,'2019-04-21 00:56:09','2019-04-21 00:56:09'),(17,11,NULL,113,NULL,'2019-04-21 00:56:09','2019-04-21 00:56:09'),(18,11,NULL,114,NULL,'2019-04-21 00:56:09','2019-04-21 00:56:09'),(19,11,NULL,115,NULL,'2019-04-21 00:56:09','2019-04-21 00:56:09'),(20,11,NULL,116,NULL,'2019-04-21 00:56:09','2019-04-21 00:56:09'),(21,11,NULL,117,NULL,'2019-04-21 00:56:09','2019-04-21 00:56:09'),(22,11,NULL,118,NULL,'2019-04-21 00:56:09','2019-04-21 00:56:09'),(23,11,NULL,119,NULL,'2019-04-21 00:56:09','2019-04-21 00:56:09'),(24,11,NULL,120,NULL,'2019-04-21 00:56:09','2019-04-21 00:56:09'),(25,11,NULL,121,NULL,'2019-04-21 00:56:09','2019-04-21 00:56:09'),(26,11,NULL,122,NULL,'2019-04-21 00:56:09','2019-04-21 00:56:09'),(27,11,NULL,123,NULL,'2019-04-21 00:56:09','2019-04-21 00:56:09'),(28,11,NULL,124,NULL,'2019-04-21 00:56:09','2019-04-21 00:56:09'),(29,11,NULL,125,NULL,'2019-04-21 00:56:09','2019-04-21 00:56:09'),(30,11,NULL,126,NULL,'2019-04-21 00:56:09','2019-04-21 00:56:09'),(31,11,NULL,127,NULL,'2019-04-21 00:56:09','2019-04-21 00:56:09'),(32,11,NULL,128,NULL,'2019-04-21 00:56:09','2019-04-21 00:56:09'),(33,11,NULL,129,NULL,'2019-04-21 00:56:09','2019-04-21 00:56:09'),(34,11,NULL,130,NULL,'2019-04-21 00:56:09','2019-04-21 00:56:09'),(35,11,NULL,131,NULL,'2019-04-21 00:56:09','2019-04-21 00:56:09'),(36,11,NULL,132,NULL,'2019-04-21 00:56:09','2019-04-21 00:56:09'),(37,11,NULL,133,NULL,'2019-04-21 00:56:09','2019-04-21 00:56:09'),(38,11,NULL,134,NULL,'2019-04-21 00:56:09','2019-04-21 00:56:09'),(39,11,NULL,135,NULL,'2019-04-21 00:56:09','2019-04-21 00:56:09'),(40,11,NULL,136,NULL,'2019-04-21 00:56:09','2019-04-21 00:56:09'),(41,11,NULL,137,NULL,'2019-04-21 00:56:09','2019-04-21 00:56:09'),(42,11,NULL,138,NULL,'2019-04-21 00:56:09','2019-04-21 00:56:09'),(43,1,NULL,139,NULL,'2019-04-21 01:12:56','2019-04-21 01:12:56'),(44,1,NULL,108,NULL,'2019-04-21 01:12:56','2019-04-21 01:12:56'),(45,1,NULL,140,NULL,'2019-04-21 01:12:56','2019-04-21 01:12:56'),(46,1,NULL,109,NULL,'2019-04-21 01:12:56','2019-04-21 01:12:56'),(47,1,NULL,141,NULL,'2019-04-21 01:12:56','2019-04-21 01:12:56'),(48,1,NULL,142,NULL,'2019-04-21 01:12:56','2019-04-21 01:12:56'),(49,1,NULL,143,NULL,'2019-04-21 01:12:56','2019-04-21 01:12:56'),(50,1,NULL,144,NULL,'2019-04-21 01:12:56','2019-04-21 01:12:56'),(51,1,NULL,112,NULL,'2019-04-21 01:12:56','2019-04-21 01:12:56'),(52,1,NULL,145,NULL,'2019-04-21 01:12:56','2019-04-21 01:12:56'),(53,1,NULL,146,NULL,'2019-04-21 01:12:56','2019-04-21 01:12:56'),(54,1,NULL,147,NULL,'2019-04-21 01:12:56','2019-04-21 01:12:56'),(55,1,NULL,148,NULL,'2019-04-21 01:12:56','2019-04-21 01:12:56'),(56,1,NULL,149,NULL,'2019-04-21 01:12:56','2019-04-21 01:12:56'),(57,1,NULL,150,NULL,'2019-04-21 01:12:56','2019-04-21 01:12:56'),(58,1,NULL,151,NULL,'2019-04-21 01:12:56','2019-04-21 01:12:56'),(59,1,NULL,152,NULL,'2019-04-21 01:12:56','2019-04-21 01:12:56'),(60,1,NULL,153,NULL,'2019-04-21 01:12:56','2019-04-21 01:12:56'),(61,1,NULL,114,NULL,'2019-04-21 01:12:56','2019-04-21 01:12:56'),(62,1,NULL,115,NULL,'2019-04-21 01:12:56','2019-04-21 01:12:56'),(63,1,NULL,117,NULL,'2019-04-21 01:12:56','2019-04-21 01:12:56'),(64,1,NULL,116,NULL,'2019-04-21 01:12:56','2019-04-21 01:12:56'),(65,1,NULL,154,NULL,'2019-04-21 01:12:56','2019-04-21 01:12:56'),(66,1,NULL,118,NULL,'2019-04-21 01:12:56','2019-04-21 01:12:56'),(67,1,NULL,119,NULL,'2019-04-21 01:12:56','2019-04-21 01:12:56'),(68,1,NULL,120,NULL,'2019-04-21 01:12:56','2019-04-21 01:12:56'),(69,1,NULL,122,NULL,'2019-04-21 01:12:56','2019-04-21 01:12:56'),(70,1,NULL,156,NULL,'2019-04-21 01:12:56','2019-04-21 01:12:56'),(71,1,NULL,123,NULL,'2019-04-21 01:12:56','2019-04-21 01:12:56'),(72,1,NULL,124,NULL,'2019-04-21 01:12:56','2019-04-21 01:12:56'),(73,1,NULL,126,NULL,'2019-04-21 01:12:56','2019-04-21 01:12:56'),(74,1,NULL,127,NULL,'2019-04-21 01:12:56','2019-04-21 01:12:56'),(75,1,NULL,128,NULL,'2019-04-21 01:12:56','2019-04-21 01:12:56'),(76,1,NULL,129,NULL,'2019-04-21 01:12:56','2019-04-21 01:12:56'),(77,1,NULL,158,NULL,'2019-04-21 01:12:56','2019-04-21 01:12:56'),(78,1,NULL,159,NULL,'2019-04-21 01:12:56','2019-04-21 01:12:56'),(79,1,NULL,160,NULL,'2019-04-21 01:12:56','2019-04-21 01:12:56'),(80,1,NULL,161,NULL,'2019-04-21 01:12:56','2019-04-21 01:12:56'),(81,1,NULL,162,NULL,'2019-04-21 01:12:56','2019-04-21 01:12:56'),(82,1,NULL,130,NULL,'2019-04-21 01:12:56','2019-04-21 01:12:56'),(83,1,NULL,131,NULL,'2019-04-21 01:12:56','2019-04-21 01:12:56'),(84,1,NULL,132,NULL,'2019-04-21 01:12:56','2019-04-21 01:12:56'),(85,1,NULL,133,NULL,'2019-04-21 01:12:56','2019-04-21 01:12:56'),(86,1,NULL,134,NULL,'2019-04-21 01:12:56','2019-04-21 01:12:56'),(87,1,NULL,135,NULL,'2019-04-21 01:12:56','2019-04-21 01:12:56'),(88,2,NULL,167,NULL,'2019-04-21 01:14:27','2019-04-21 01:14:27'),(89,2,NULL,168,NULL,'2019-04-21 01:14:27','2019-04-21 01:14:27'),(90,2,NULL,169,NULL,'2019-04-21 01:14:27','2019-04-21 01:14:27'),(91,2,NULL,170,NULL,'2019-04-21 01:14:27','2019-04-21 01:14:27'),(92,2,NULL,171,NULL,'2019-04-21 01:14:27','2019-04-21 01:14:27'),(93,2,NULL,172,NULL,'2019-04-21 01:14:27','2019-04-21 01:14:27'),(94,2,NULL,173,NULL,'2019-04-21 01:14:27','2019-04-21 01:14:27'),(95,2,NULL,39,NULL,'2019-04-21 01:14:27','2019-04-21 01:14:27'),(96,2,NULL,174,NULL,'2019-04-21 01:14:27','2019-04-21 01:14:27'),(97,2,NULL,175,NULL,'2019-04-21 01:14:27','2019-04-21 01:14:27'),(98,2,NULL,181,NULL,'2019-04-21 01:14:27','2019-04-21 01:14:27'),(99,2,NULL,40,NULL,'2019-04-21 01:14:27','2019-04-21 01:14:27'),(100,2,NULL,106,NULL,'2019-04-21 01:14:27','2019-04-21 01:14:27'),(101,2,NULL,178,NULL,'2019-04-21 01:14:27','2019-04-21 01:14:27'),(102,2,NULL,179,NULL,'2019-04-21 01:14:27','2019-04-21 01:14:27'),(103,2,NULL,180,NULL,'2019-04-21 01:14:27','2019-04-21 01:14:27'),(104,2,NULL,182,NULL,'2019-04-21 01:14:27','2019-04-21 01:14:27'),(105,2,NULL,176,NULL,'2019-04-21 01:14:27','2019-04-21 01:14:27'),(106,2,NULL,177,NULL,'2019-04-21 01:14:27','2019-04-21 01:14:27'),(107,2,NULL,183,NULL,'2019-04-21 01:15:26','2019-04-21 01:15:26'),(108,2,NULL,184,NULL,'2019-04-21 01:15:26','2019-04-21 01:15:26'),(109,2,NULL,109,NULL,'2019-04-21 01:15:26','2019-04-21 01:15:26'),(110,2,NULL,146,NULL,'2019-04-21 01:15:26','2019-04-21 01:15:26'),(111,2,NULL,185,NULL,'2019-04-21 01:15:26','2019-04-21 01:15:26'),(112,2,NULL,147,NULL,'2019-04-21 01:15:26','2019-04-21 01:15:26'),(113,2,NULL,111,NULL,'2019-04-21 01:15:26','2019-04-21 01:15:26'),(114,2,NULL,186,NULL,'2019-04-21 01:15:26','2019-04-21 01:15:26'),(115,2,NULL,113,NULL,'2019-04-21 01:15:26','2019-04-21 01:15:26'),(116,2,NULL,187,NULL,'2019-04-21 01:15:26','2019-04-21 01:15:26'),(117,2,NULL,188,NULL,'2019-04-21 01:15:26','2019-04-21 01:15:26'),(118,2,NULL,189,NULL,'2019-04-21 01:15:26','2019-04-21 01:15:26'),(119,2,NULL,190,NULL,'2019-04-21 01:15:26','2019-04-21 01:15:26'),(120,0,NULL,97,NULL,'2019-04-22 12:10:07','2019-04-22 12:10:07'),(121,0,NULL,98,NULL,'2019-04-22 12:10:07','2019-04-22 12:10:07'),(122,0,NULL,99,NULL,'2019-04-22 12:10:07','2019-04-22 12:10:07'),(123,0,NULL,100,NULL,'2019-04-22 12:10:07','2019-04-22 12:10:07'),(124,7,NULL,101,NULL,'2019-04-22 12:10:35','2019-04-22 12:10:35'),(125,7,NULL,102,NULL,'2019-04-22 12:10:35','2019-04-22 12:10:35'),(126,7,NULL,103,NULL,'2019-04-22 12:10:35','2019-04-22 12:10:35'),(127,7,NULL,104,NULL,'2019-04-22 12:10:35','2019-04-22 12:10:35'),(128,7,NULL,105,NULL,'2019-04-22 12:10:35','2019-04-22 12:10:35'),(129,7,NULL,106,NULL,'2019-04-22 12:10:35','2019-04-22 12:10:35'),(130,7,NULL,107,NULL,'2019-04-22 12:10:35','2019-04-22 12:10:35'),(131,7,NULL,108,NULL,'2019-04-22 12:10:35','2019-04-22 12:10:35'),(132,7,NULL,109,NULL,'2019-04-22 12:10:35','2019-04-22 12:10:35'),(133,7,NULL,110,NULL,'2019-04-22 12:10:35','2019-04-22 12:10:35'),(134,7,NULL,111,NULL,'2019-04-22 12:10:35','2019-04-22 12:10:35'),(135,7,NULL,112,NULL,'2019-04-22 12:10:35','2019-04-22 12:10:35'),(136,7,NULL,113,NULL,'2019-04-22 12:10:35','2019-04-22 12:10:35'),(137,7,NULL,114,NULL,'2019-04-22 12:10:35','2019-04-22 12:10:35'),(138,7,NULL,115,NULL,'2019-04-22 12:10:35','2019-04-22 12:10:35'),(139,7,NULL,116,NULL,'2019-04-22 12:10:35','2019-04-22 12:10:35'),(140,7,NULL,117,NULL,'2019-04-22 12:10:35','2019-04-22 12:10:35'),(141,7,NULL,118,NULL,'2019-04-22 12:10:35','2019-04-22 12:10:35'),(142,7,NULL,119,NULL,'2019-04-22 12:10:35','2019-04-22 12:10:35'),(143,7,NULL,120,NULL,'2019-04-22 12:10:35','2019-04-22 12:10:35'),(144,7,NULL,121,NULL,'2019-04-22 12:10:35','2019-04-22 12:10:35'),(145,7,NULL,122,NULL,'2019-04-22 12:10:35','2019-04-22 12:10:35'),(146,7,NULL,123,NULL,'2019-04-22 12:10:35','2019-04-22 12:10:35'),(147,7,NULL,124,NULL,'2019-04-22 12:10:35','2019-04-22 12:10:35'),(148,7,NULL,125,NULL,'2019-04-22 12:10:35','2019-04-22 12:10:35'),(149,7,NULL,126,NULL,'2019-04-22 12:10:35','2019-04-22 12:10:35'),(150,7,NULL,127,NULL,'2019-04-22 12:10:35','2019-04-22 12:10:35'),(151,7,NULL,128,NULL,'2019-04-22 12:10:35','2019-04-22 12:10:35'),(152,7,NULL,129,NULL,'2019-04-22 12:10:35','2019-04-22 12:10:35'),(153,7,NULL,130,NULL,'2019-04-22 12:10:35','2019-04-22 12:10:35'),(154,7,NULL,131,NULL,'2019-04-22 12:10:35','2019-04-22 12:10:35'),(155,7,NULL,132,NULL,'2019-04-22 12:10:35','2019-04-22 12:10:35'),(156,7,NULL,133,NULL,'2019-04-22 12:10:35','2019-04-22 12:10:35'),(157,7,NULL,134,NULL,'2019-04-22 12:10:35','2019-04-22 12:10:35'),(158,7,NULL,135,NULL,'2019-04-22 12:10:35','2019-04-22 12:10:35'),(159,7,NULL,136,NULL,'2019-04-22 12:10:35','2019-04-22 12:10:35'),(160,7,NULL,137,NULL,'2019-04-22 12:10:35','2019-04-22 12:10:35'),(161,7,NULL,138,NULL,'2019-04-22 12:10:35','2019-04-22 12:10:35'),(162,3,NULL,139,NULL,'2019-04-22 12:10:46','2019-04-22 12:10:46'),(163,3,NULL,108,NULL,'2019-04-22 12:10:46','2019-04-22 12:10:46'),(164,3,NULL,140,NULL,'2019-04-22 12:10:46','2019-04-22 12:10:46'),(165,3,NULL,109,NULL,'2019-04-22 12:10:46','2019-04-22 12:10:46'),(166,3,NULL,141,NULL,'2019-04-22 12:10:46','2019-04-22 12:10:46'),(167,3,NULL,142,NULL,'2019-04-22 12:10:46','2019-04-22 12:10:46'),(168,3,NULL,143,NULL,'2019-04-22 12:10:46','2019-04-22 12:10:46'),(169,3,NULL,144,NULL,'2019-04-22 12:10:46','2019-04-22 12:10:46'),(170,3,NULL,112,NULL,'2019-04-22 12:10:46','2019-04-22 12:10:46'),(171,3,NULL,145,NULL,'2019-04-22 12:10:46','2019-04-22 12:10:46'),(172,3,NULL,146,NULL,'2019-04-22 12:10:46','2019-04-22 12:10:46'),(173,3,NULL,147,NULL,'2019-04-22 12:10:46','2019-04-22 12:10:46'),(174,3,NULL,148,NULL,'2019-04-22 12:10:46','2019-04-22 12:10:46'),(175,3,NULL,149,NULL,'2019-04-22 12:10:46','2019-04-22 12:10:46'),(176,3,NULL,150,NULL,'2019-04-22 12:10:46','2019-04-22 12:10:46'),(177,3,NULL,151,NULL,'2019-04-22 12:10:46','2019-04-22 12:10:46'),(178,3,NULL,152,NULL,'2019-04-22 12:10:46','2019-04-22 12:10:46'),(179,3,NULL,153,NULL,'2019-04-22 12:10:46','2019-04-22 12:10:46'),(180,3,NULL,114,NULL,'2019-04-22 12:10:46','2019-04-22 12:10:46'),(181,3,NULL,115,NULL,'2019-04-22 12:10:46','2019-04-22 12:10:46'),(182,3,NULL,117,NULL,'2019-04-22 12:10:46','2019-04-22 12:10:46'),(183,3,NULL,116,NULL,'2019-04-22 12:10:46','2019-04-22 12:10:46'),(184,3,NULL,154,NULL,'2019-04-22 12:10:46','2019-04-22 12:10:46'),(185,3,NULL,118,NULL,'2019-04-22 12:10:46','2019-04-22 12:10:46'),(186,3,NULL,119,NULL,'2019-04-22 12:10:46','2019-04-22 12:10:46'),(187,3,NULL,120,NULL,'2019-04-22 12:10:46','2019-04-22 12:10:46'),(188,3,NULL,122,NULL,'2019-04-22 12:10:46','2019-04-22 12:10:46'),(189,3,NULL,156,NULL,'2019-04-22 12:10:46','2019-04-22 12:10:46'),(190,3,NULL,123,NULL,'2019-04-22 12:10:46','2019-04-22 12:10:46'),(191,3,NULL,124,NULL,'2019-04-22 12:10:46','2019-04-22 12:10:46'),(192,3,NULL,126,NULL,'2019-04-22 12:10:46','2019-04-22 12:10:46'),(193,3,NULL,127,NULL,'2019-04-22 12:10:46','2019-04-22 12:10:46'),(194,3,NULL,128,NULL,'2019-04-22 12:10:46','2019-04-22 12:10:46'),(195,3,NULL,129,NULL,'2019-04-22 12:10:46','2019-04-22 12:10:46'),(196,3,NULL,158,NULL,'2019-04-22 12:10:46','2019-04-22 12:10:46'),(197,3,NULL,159,NULL,'2019-04-22 12:10:46','2019-04-22 12:10:46'),(198,3,NULL,160,NULL,'2019-04-22 12:10:46','2019-04-22 12:10:46'),(199,3,NULL,161,NULL,'2019-04-22 12:10:46','2019-04-22 12:10:46'),(200,3,NULL,162,NULL,'2019-04-22 12:10:46','2019-04-22 12:10:46'),(201,3,NULL,130,NULL,'2019-04-22 12:10:46','2019-04-22 12:10:46'),(202,3,NULL,131,NULL,'2019-04-22 12:10:46','2019-04-22 12:10:46'),(203,3,NULL,132,NULL,'2019-04-22 12:10:46','2019-04-22 12:10:46'),(204,3,NULL,133,NULL,'2019-04-22 12:10:46','2019-04-22 12:10:46'),(205,3,NULL,134,NULL,'2019-04-22 12:10:46','2019-04-22 12:10:46'),(206,3,NULL,135,NULL,'2019-04-22 12:10:46','2019-04-22 12:10:46'),(207,1,NULL,167,NULL,'2019-04-22 12:10:56','2019-04-22 12:10:56'),(208,1,NULL,168,NULL,'2019-04-22 12:10:56','2019-04-22 12:10:56'),(209,1,NULL,169,NULL,'2019-04-22 12:10:56','2019-04-22 12:10:56'),(210,1,NULL,170,NULL,'2019-04-22 12:10:56','2019-04-22 12:10:56'),(211,1,NULL,171,NULL,'2019-04-22 12:10:56','2019-04-22 12:10:56'),(212,1,NULL,172,NULL,'2019-04-22 12:10:56','2019-04-22 12:10:56'),(213,1,NULL,173,NULL,'2019-04-22 12:10:56','2019-04-22 12:10:56'),(214,1,NULL,39,NULL,'2019-04-22 12:10:56','2019-04-22 12:10:56'),(215,1,NULL,174,NULL,'2019-04-22 12:10:56','2019-04-22 12:10:56'),(216,1,NULL,175,NULL,'2019-04-22 12:10:56','2019-04-22 12:10:56'),(217,1,NULL,181,NULL,'2019-04-22 12:10:56','2019-04-22 12:10:56'),(218,1,NULL,40,NULL,'2019-04-22 12:10:56','2019-04-22 12:10:56'),(219,1,NULL,106,NULL,'2019-04-22 12:10:56','2019-04-22 12:10:56'),(220,1,NULL,178,NULL,'2019-04-22 12:10:56','2019-04-22 12:10:56'),(221,1,NULL,179,NULL,'2019-04-22 12:10:56','2019-04-22 12:10:56'),(222,1,NULL,180,NULL,'2019-04-22 12:10:56','2019-04-22 12:10:56'),(223,1,NULL,182,NULL,'2019-04-22 12:10:56','2019-04-22 12:10:56'),(224,1,NULL,176,NULL,'2019-04-22 12:10:56','2019-04-22 12:10:56'),(225,1,NULL,177,NULL,'2019-04-22 12:10:56','2019-04-22 12:10:56'),(226,13,NULL,97,NULL,'2019-04-22 21:55:22','2019-04-22 21:55:22'),(227,13,NULL,98,NULL,'2019-04-22 21:55:22','2019-04-22 21:55:22'),(228,13,NULL,99,NULL,'2019-04-22 21:55:22','2019-04-22 21:55:22'),(229,13,NULL,100,NULL,'2019-04-22 21:55:22','2019-04-22 21:55:22'),(230,NULL,796,270,'PRESENT','2019-08-30 00:34:25','2019-08-30 00:34:25'),(231,NULL,796,271,'ABSENT','2019-08-30 00:34:25','2019-08-30 00:34:25'),(232,NULL,796,242,'-5','2019-08-30 00:34:25','2019-08-30 00:34:25'),(233,NULL,796,243,NULL,'2019-08-30 00:34:25','2019-08-30 00:34:25'),(234,NULL,796,244,NULL,'2019-08-30 00:34:25','2019-08-30 00:34:25'),(235,NULL,796,245,NULL,'2019-08-30 00:34:25','2019-08-30 00:34:25'),(236,NULL,796,246,'1mm','2019-08-30 00:34:25','2019-08-30 00:34:25'),(237,NULL,796,247,'12mm','2019-08-30 00:34:25','2019-08-30 00:34:25'),(238,NULL,796,248,'Poor','2019-08-30 00:34:25','2019-08-30 00:34:25'),(239,NULL,796,249,'Good','2019-08-30 00:34:25','2019-08-30 00:34:25'),(240,NULL,796,250,NULL,'2019-08-30 00:34:25','2019-08-30 00:34:25'),(241,NULL,796,251,NULL,'2019-08-30 00:34:25','2019-08-30 00:34:25'),(242,NULL,796,252,NULL,'2019-08-30 00:34:25','2019-08-30 00:34:25'),(243,NULL,796,253,NULL,'2019-08-30 00:34:25','2019-08-30 00:34:25'),(244,NULL,796,254,'Absent','2019-08-30 00:34:25','2019-08-30 00:34:25'),(245,NULL,796,255,'Present','2019-08-30 00:34:25','2019-08-30 00:34:25'),(246,NULL,796,256,'Present','2019-08-30 00:34:25','2019-08-30 00:34:25'),(247,NULL,796,257,'Present','2019-08-30 00:34:25','2019-08-30 00:34:25'),(248,NULL,796,258,NULL,'2019-08-30 00:34:25','2019-08-30 00:34:25'),(249,NULL,796,259,NULL,'2019-08-30 00:34:25','2019-08-30 00:34:25'),(250,NULL,796,260,'Absent','2019-08-30 00:34:25','2019-08-30 00:34:25'),(251,NULL,796,261,'Absent','2019-08-30 00:34:25','2019-08-30 00:34:25'),(252,NULL,796,262,NULL,'2019-08-30 00:34:25','2019-08-30 00:34:25'),(253,NULL,796,263,NULL,'2019-08-30 00:34:25','2019-08-30 00:34:25'),(254,NULL,796,264,NULL,'2019-08-30 00:34:25','2019-08-30 00:34:25'),(255,NULL,796,265,NULL,'2019-08-30 00:34:25','2019-08-30 00:34:25'),(256,NULL,796,266,NULL,'2019-08-30 00:34:25','2019-08-30 00:34:25'),(257,NULL,796,267,NULL,'2019-08-30 00:34:25','2019-08-30 00:34:25'),(258,NULL,796,272,NULL,'2019-08-30 00:34:25','2019-08-30 00:34:25'),(259,NULL,796,273,'Hypertropia','2019-08-30 00:34:25','2019-08-30 00:34:25'),(260,NULL,796,268,NULL,'2019-08-30 00:34:25','2019-08-30 00:34:25'),(261,NULL,796,269,NULL,'2019-08-30 00:34:25','2019-08-30 00:34:25'),(262,NULL,805,225,'NORMAL','2019-08-31 21:12:56','2019-08-31 21:12:56'),(263,NULL,805,195,NULL,'2019-08-31 21:12:56','2019-08-31 21:12:56'),(264,NULL,805,194,NULL,'2019-08-31 21:12:56','2019-08-31 21:12:56'),(265,NULL,805,197,NULL,'2019-08-31 21:12:56','2019-08-31 21:12:56'),(266,NULL,805,196,NULL,'2019-08-31 21:12:56','2019-08-31 21:12:56'),(267,NULL,805,198,'RCS','2019-08-31 21:12:56','2019-08-31 21:12:56'),(268,NULL,805,199,'RCS TO ACS  WITH V PATTERN ET','2019-08-31 21:12:56','2019-08-31 21:12:56'),(269,NULL,805,200,'35-40 PD BO (PRIMARY GAZE)','2019-08-31 21:12:56','2019-08-31 21:12:56'),(270,NULL,805,201,NULL,'2019-08-31 21:12:56','2019-08-31 21:12:56'),(271,NULL,805,202,NULL,'2019-08-31 21:12:56','2019-08-31 21:12:56'),(272,NULL,805,203,NULL,'2019-08-31 21:12:56','2019-08-31 21:12:56'),(273,NULL,805,204,NULL,'2019-08-31 21:12:56','2019-08-31 21:12:56'),(274,NULL,805,205,NULL,'2019-08-31 21:12:56','2019-08-31 21:12:56'),(275,NULL,805,206,NULL,'2019-08-31 21:12:56','2019-08-31 21:12:56'),(276,NULL,805,207,NULL,'2019-08-31 21:12:56','2019-08-31 21:12:56'),(277,NULL,805,208,NULL,'2019-08-31 21:12:56','2019-08-31 21:12:56'),(278,NULL,805,209,NULL,'2019-08-31 21:12:56','2019-08-31 21:12:56'),(279,NULL,805,210,NULL,'2019-08-31 21:12:56','2019-08-31 21:12:56'),(280,NULL,805,211,NULL,'2019-08-31 21:12:56','2019-08-31 21:12:56'),(281,NULL,805,212,'IO OA','2019-08-31 21:12:56','2019-08-31 21:12:56'),(282,NULL,805,213,'ALT SUPPRESSION','2019-08-31 21:12:56','2019-08-31 21:12:56'),(283,NULL,805,214,'>3000 ARC SED','2019-08-31 21:12:56','2019-08-31 21:12:56'),(284,NULL,805,215,NULL,'2019-08-31 21:12:56','2019-08-31 21:12:56'),(285,NULL,805,216,NULL,'2019-08-31 21:12:56','2019-08-31 21:12:56'),(286,NULL,805,217,NULL,'2019-08-31 21:12:56','2019-08-31 21:12:56'),(287,NULL,805,218,NULL,'2019-08-31 21:12:56','2019-08-31 21:12:56'),(288,NULL,805,219,NULL,'2019-08-31 21:12:56','2019-08-31 21:12:56'),(289,NULL,805,220,NULL,'2019-08-31 21:12:56','2019-08-31 21:12:56'),(290,NULL,805,221,NULL,'2019-08-31 21:12:56','2019-08-31 21:12:56'),(291,NULL,805,222,NULL,'2019-08-31 21:12:56','2019-08-31 21:12:56'),(292,NULL,805,223,NULL,'2019-08-31 21:12:56','2019-08-31 21:12:56'),(293,NULL,805,224,NULL,'2019-08-31 21:12:56','2019-08-31 21:12:56'),(294,NULL,860,225,'prefers Rt gaze','2019-09-16 14:38:14','2019-09-16 14:38:14'),(295,NULL,860,195,NULL,'2019-09-16 14:38:14','2019-09-16 14:38:14'),(296,NULL,860,194,NULL,'2019-09-16 14:38:14','2019-09-16 14:38:14'),(297,NULL,860,197,NULL,'2019-09-16 14:38:14','2019-09-16 14:38:14'),(298,NULL,860,196,NULL,'2019-09-16 14:38:14','2019-09-16 14:38:14'),(299,NULL,860,198,'RCS','2019-09-16 14:38:14','2019-09-16 14:38:14'),(300,NULL,860,199,'RCS TO ACS  WITH V PATTERN ET','2019-09-16 14:38:14','2019-09-16 14:38:14'),(301,NULL,860,200,'35-40 PD BO (PRIMARY GAZE)','2019-09-16 14:38:14','2019-09-16 14:38:14'),(302,NULL,860,201,NULL,'2019-09-16 14:38:14','2019-09-16 14:38:14'),(303,NULL,860,202,NULL,'2019-09-16 14:38:14','2019-09-16 14:38:14'),(304,NULL,860,203,NULL,'2019-09-16 14:38:14','2019-09-16 14:38:14'),(305,NULL,860,204,NULL,'2019-09-16 14:38:14','2019-09-16 14:38:14'),(306,NULL,860,205,NULL,'2019-09-16 14:38:14','2019-09-16 14:38:14'),(307,NULL,860,206,NULL,'2019-09-16 14:38:14','2019-09-16 14:38:14'),(308,NULL,860,207,NULL,'2019-09-16 14:38:14','2019-09-16 14:38:14'),(309,NULL,860,208,NULL,'2019-09-16 14:38:14','2019-09-16 14:38:14'),(310,NULL,860,209,NULL,'2019-09-16 14:38:14','2019-09-16 14:38:14'),(311,NULL,860,210,NULL,'2019-09-16 14:38:14','2019-09-16 14:38:14'),(312,NULL,860,211,NULL,'2019-09-16 14:38:14','2019-09-16 14:38:14'),(313,NULL,860,212,'IO OA','2019-09-16 14:38:14','2019-09-16 14:38:14'),(314,NULL,860,213,NULL,'2019-09-16 14:38:14','2019-09-16 14:38:14'),(315,NULL,860,214,NULL,'2019-09-16 14:38:14','2019-09-16 14:38:14'),(316,NULL,860,215,NULL,'2019-09-16 14:38:14','2019-09-16 14:38:14'),(317,NULL,860,216,NULL,'2019-09-16 14:38:14','2019-09-16 14:38:14'),(318,NULL,860,217,NULL,'2019-09-16 14:38:14','2019-09-16 14:38:14'),(319,NULL,860,218,NULL,'2019-09-16 14:38:14','2019-09-16 14:38:14'),(320,NULL,860,219,NULL,'2019-09-16 14:38:14','2019-09-16 14:38:14'),(321,NULL,860,220,NULL,'2019-09-16 14:38:14','2019-09-16 14:38:14'),(322,NULL,860,221,NULL,'2019-09-16 14:38:14','2019-09-16 14:38:14'),(323,NULL,860,222,NULL,'2019-09-16 14:38:14','2019-09-16 14:38:14'),(324,NULL,860,223,NULL,'2019-09-16 14:38:14','2019-09-16 14:38:14'),(325,NULL,860,224,NULL,'2019-09-16 14:38:14','2019-09-16 14:38:14'),(326,NULL,890,225,NULL,'2019-09-21 16:08:48','2019-09-21 16:08:48'),(327,NULL,890,195,NULL,'2019-09-21 16:08:48','2019-09-21 16:08:48'),(328,NULL,890,194,NULL,'2019-09-21 16:08:48','2019-09-21 16:08:48'),(329,NULL,890,197,NULL,'2019-09-21 16:08:48','2019-09-21 16:08:48'),(330,NULL,890,196,NULL,'2019-09-21 16:08:48','2019-09-21 16:08:48'),(331,NULL,890,198,NULL,'2019-09-21 16:08:48','2019-09-21 16:08:48'),(332,NULL,890,199,NULL,'2019-09-21 16:08:48','2019-09-21 16:08:48'),(333,NULL,890,200,NULL,'2019-09-21 16:08:48','2019-09-21 16:08:48'),(334,NULL,890,201,NULL,'2019-09-21 16:08:48','2019-09-21 16:08:48'),(335,NULL,890,202,NULL,'2019-09-21 16:08:48','2019-09-21 16:08:48'),(336,NULL,890,203,NULL,'2019-09-21 16:08:48','2019-09-21 16:08:48'),(337,NULL,890,204,NULL,'2019-09-21 16:08:48','2019-09-21 16:08:48'),(338,NULL,890,205,NULL,'2019-09-21 16:08:48','2019-09-21 16:08:48'),(339,NULL,890,206,NULL,'2019-09-21 16:08:48','2019-09-21 16:08:48'),(340,NULL,890,207,NULL,'2019-09-21 16:08:48','2019-09-21 16:08:48'),(341,NULL,890,208,NULL,'2019-09-21 16:08:48','2019-09-21 16:08:48'),(342,NULL,890,209,NULL,'2019-09-21 16:08:48','2019-09-21 16:08:48'),(343,NULL,890,210,NULL,'2019-09-21 16:08:48','2019-09-21 16:08:48'),(344,NULL,890,211,NULL,'2019-09-21 16:08:48','2019-09-21 16:08:48'),(345,NULL,890,212,NULL,'2019-09-21 16:08:48','2019-09-21 16:08:48'),(346,NULL,890,213,'FUSION PRESENT','2019-09-21 16:08:48','2019-09-21 16:08:48'),(347,NULL,890,214,'50 SECONDS OF ARC','2019-09-21 16:08:48','2019-09-21 16:08:48'),(348,NULL,890,215,NULL,'2019-09-21 16:08:48','2019-09-21 16:08:48'),(349,NULL,890,216,NULL,'2019-09-21 16:08:48','2019-09-21 16:08:48'),(350,NULL,890,217,NULL,'2019-09-21 16:08:48','2019-09-21 16:08:48'),(351,NULL,890,218,NULL,'2019-09-21 16:08:48','2019-09-21 16:08:48'),(352,NULL,890,219,NULL,'2019-09-21 16:08:48','2019-09-21 16:08:48'),(353,NULL,890,220,NULL,'2019-09-21 16:08:48','2019-09-21 16:08:48'),(354,NULL,890,221,NULL,'2019-09-21 16:08:48','2019-09-21 16:08:48'),(355,NULL,890,222,NULL,'2019-09-21 16:08:48','2019-09-21 16:08:48'),(356,NULL,890,223,NULL,'2019-09-21 16:08:48','2019-09-21 16:08:48'),(357,NULL,890,224,NULL,'2019-09-21 16:08:48','2019-09-21 16:08:48'),(358,NULL,921,225,'NORMAL','2019-09-28 14:46:48','2019-09-28 14:46:48'),(359,NULL,921,195,NULL,'2019-09-28 14:46:48','2019-09-28 14:46:48'),(360,NULL,921,194,NULL,'2019-09-28 14:46:48','2019-09-28 14:46:48'),(361,NULL,921,197,NULL,'2019-09-28 14:46:48','2019-09-28 14:46:48'),(362,NULL,921,196,NULL,'2019-09-28 14:46:48','2019-09-28 14:46:48'),(363,NULL,921,198,'without glasses ACS, with glasses Ortho','2019-09-28 14:46:48','2019-09-28 14:46:48'),(364,NULL,921,199,'without glasses ACS, with glasses Ortho','2019-09-28 14:46:48','2019-09-28 14:46:48'),(365,NULL,921,200,'without glasses 35 PDBO, with glasses 6 PD BO','2019-09-28 14:46:48','2019-09-28 14:46:48'),(366,NULL,921,201,NULL,'2019-09-28 14:46:48','2019-09-28 14:46:48'),(367,NULL,921,202,NULL,'2019-09-28 14:46:48','2019-09-28 14:46:48'),(368,NULL,921,203,NULL,'2019-09-28 14:46:48','2019-09-28 14:46:48'),(369,NULL,921,204,NULL,'2019-09-28 14:46:48','2019-09-28 14:46:48'),(370,NULL,921,205,NULL,'2019-09-28 14:46:48','2019-09-28 14:46:48'),(371,NULL,921,206,NULL,'2019-09-28 14:46:48','2019-09-28 14:46:48'),(372,NULL,921,207,NULL,'2019-09-28 14:46:48','2019-09-28 14:46:48'),(373,NULL,921,208,NULL,'2019-09-28 14:46:48','2019-09-28 14:46:48'),(374,NULL,921,209,NULL,'2019-09-28 14:46:48','2019-09-28 14:46:48'),(375,NULL,921,210,NULL,'2019-09-28 14:46:48','2019-09-28 14:46:48'),(376,NULL,921,211,NULL,'2019-09-28 14:46:48','2019-09-28 14:46:48'),(377,NULL,921,212,'full','2019-09-28 14:46:48','2019-09-28 14:46:48'),(378,NULL,921,213,'Fusion','2019-09-28 14:46:48','2019-09-28 14:46:48'),(379,NULL,921,214,'80 arc sec','2019-09-28 14:46:48','2019-09-28 14:46:48'),(380,NULL,921,215,NULL,'2019-09-28 14:46:48','2019-09-28 14:46:48'),(381,NULL,921,216,NULL,'2019-09-28 14:46:48','2019-09-28 14:46:48'),(382,NULL,921,217,NULL,'2019-09-28 14:46:48','2019-09-28 14:46:48'),(383,NULL,921,218,NULL,'2019-09-28 14:46:48','2019-09-28 14:46:48'),(384,NULL,921,219,NULL,'2019-09-28 14:46:48','2019-09-28 14:46:48'),(385,NULL,921,220,NULL,'2019-09-28 14:46:48','2019-09-28 14:46:48'),(386,NULL,921,221,NULL,'2019-09-28 14:46:48','2019-09-28 14:46:48'),(387,NULL,921,222,NULL,'2019-09-28 14:46:48','2019-09-28 14:46:48'),(388,NULL,921,223,NULL,'2019-09-28 14:46:48','2019-09-28 14:46:48'),(389,NULL,921,224,NULL,'2019-09-28 14:46:48','2019-09-28 14:46:48'),(390,NULL,1193,225,'NO','2019-11-20 20:24:44','2019-11-20 20:24:44'),(391,NULL,1193,195,NULL,'2019-11-20 20:24:44','2019-11-20 20:24:44'),(392,NULL,1193,194,NULL,'2019-11-20 20:24:44','2019-11-20 20:24:44'),(393,NULL,1193,197,NULL,'2019-11-20 20:24:44','2019-11-20 20:24:44'),(394,NULL,1193,196,NULL,'2019-11-20 20:24:44','2019-11-20 20:24:44'),(395,NULL,1193,198,'45 PRISM DIOPTER (EXOTROPIA)','2019-11-20 20:24:44','2019-11-20 20:24:44'),(396,NULL,1193,199,'ALTERNATE EXOTROPIA','2019-11-20 20:24:44','2019-11-20 20:24:44'),(397,NULL,1193,200,NULL,'2019-11-20 20:24:44','2019-11-20 20:24:44'),(398,NULL,1193,201,NULL,'2019-11-20 20:24:44','2019-11-20 20:24:44'),(399,NULL,1193,202,NULL,'2019-11-20 20:24:44','2019-11-20 20:24:44'),(400,NULL,1193,203,NULL,'2019-11-20 20:24:44','2019-11-20 20:24:44'),(401,NULL,1193,204,NULL,'2019-11-20 20:24:44','2019-11-20 20:24:44'),(402,NULL,1193,205,NULL,'2019-11-20 20:24:44','2019-11-20 20:24:44'),(403,NULL,1193,206,NULL,'2019-11-20 20:24:44','2019-11-20 20:24:44'),(404,NULL,1193,207,NULL,'2019-11-20 20:24:44','2019-11-20 20:24:44'),(405,NULL,1193,208,NULL,'2019-11-20 20:24:44','2019-11-20 20:24:44'),(406,NULL,1193,209,NULL,'2019-11-20 20:24:44','2019-11-20 20:24:44'),(407,NULL,1193,210,'ORTHO','2019-11-20 20:24:44','2019-11-20 20:24:44'),(408,NULL,1193,211,'ALTERNATE EXOTROPIA','2019-11-20 20:24:44','2019-11-20 20:24:44'),(409,NULL,1193,212,'ORTHO','2019-11-20 20:24:44','2019-11-20 20:24:44'),(410,NULL,1193,213,'DIPLOPIA .RE DOMINANT AT A TIME','2019-11-20 20:24:44','2019-11-20 20:24:44'),(411,NULL,1193,214,'40 SECONDS OF ARC','2019-11-20 20:24:44','2019-11-20 20:24:44'),(412,NULL,1193,215,'DIPLOPIA','2019-11-20 20:24:44','2019-11-20 20:24:44'),(413,NULL,1193,216,NULL,'2019-11-20 20:24:44','2019-11-20 20:24:44'),(414,NULL,1193,217,NULL,'2019-11-20 20:24:44','2019-11-20 20:24:44'),(415,NULL,1193,218,NULL,'2019-11-20 20:24:44','2019-11-20 20:24:44'),(416,NULL,1193,219,NULL,'2019-11-20 20:24:44','2019-11-20 20:24:44'),(417,NULL,1193,220,NULL,'2019-11-20 20:24:44','2019-11-20 20:24:44'),(418,NULL,1193,221,NULL,'2019-11-20 20:24:44','2019-11-20 20:24:44'),(419,NULL,1193,222,NULL,'2019-11-20 20:24:44','2019-11-20 20:24:44'),(420,NULL,1193,223,NULL,'2019-11-20 20:24:44','2019-11-20 20:24:44'),(421,NULL,1193,224,NULL,'2019-11-20 20:24:44','2019-11-20 20:24:44'),(430,1,NULL,97,NULL,'2020-08-29 19:31:53','2020-08-29 19:31:53'),(431,1,NULL,98,NULL,'2020-08-29 19:31:53','2020-08-29 19:31:53'),(432,1,NULL,99,NULL,'2020-08-29 19:31:53','2020-08-29 19:31:53'),(433,1,NULL,100,NULL,'2020-08-29 19:31:53','2020-08-29 19:31:53'),(434,0,NULL,167,NULL,'2020-08-29 20:22:36','2020-08-29 20:22:36'),(435,0,NULL,168,NULL,'2020-08-29 20:22:36','2020-08-29 20:22:36'),(436,0,NULL,169,NULL,'2020-08-29 20:22:36','2020-08-29 20:22:36'),(437,0,NULL,170,NULL,'2020-08-29 20:22:36','2020-08-29 20:22:36'),(438,0,NULL,171,NULL,'2020-08-29 20:22:36','2020-08-29 20:22:36'),(439,0,NULL,172,NULL,'2020-08-29 20:22:36','2020-08-29 20:22:36'),(440,0,NULL,173,NULL,'2020-08-29 20:22:36','2020-08-29 20:22:36'),(441,0,NULL,39,NULL,'2020-08-29 20:22:36','2020-08-29 20:22:36'),(442,0,NULL,174,NULL,'2020-08-29 20:22:36','2020-08-29 20:22:36'),(443,0,NULL,175,NULL,'2020-08-29 20:22:36','2020-08-29 20:22:36'),(444,0,NULL,181,NULL,'2020-08-29 20:22:36','2020-08-29 20:22:36'),(445,0,NULL,40,NULL,'2020-08-29 20:22:36','2020-08-29 20:22:36'),(446,0,NULL,106,NULL,'2020-08-29 20:22:36','2020-08-29 20:22:36'),(447,0,NULL,178,NULL,'2020-08-29 20:22:36','2020-08-29 20:22:36'),(448,0,NULL,179,NULL,'2020-08-29 20:22:36','2020-08-29 20:22:36'),(449,0,NULL,180,NULL,'2020-08-29 20:22:36','2020-08-29 20:22:36'),(450,0,NULL,182,NULL,'2020-08-29 20:22:36','2020-08-29 20:22:36'),(451,0,NULL,176,NULL,'2020-08-29 20:22:36','2020-08-29 20:22:36'),(452,0,NULL,177,NULL,'2020-08-29 20:22:36','2020-08-29 20:22:36'),(453,0,NULL,101,NULL,'2020-08-29 20:32:12','2020-08-29 20:32:12'),(454,0,NULL,102,NULL,'2020-08-29 20:32:12','2020-08-29 20:32:12'),(455,0,NULL,103,NULL,'2020-08-29 20:32:12','2020-08-29 20:32:12'),(456,0,NULL,104,NULL,'2020-08-29 20:32:12','2020-08-29 20:32:12'),(457,0,NULL,105,NULL,'2020-08-29 20:32:12','2020-08-29 20:32:12'),(458,0,NULL,107,NULL,'2020-08-29 20:32:12','2020-08-29 20:32:12'),(459,0,NULL,108,NULL,'2020-08-29 20:32:12','2020-08-29 20:32:12'),(460,0,NULL,109,NULL,'2020-08-29 20:32:12','2020-08-29 20:32:12'),(461,0,NULL,110,NULL,'2020-08-29 20:32:12','2020-08-29 20:32:12'),(462,0,NULL,111,NULL,'2020-08-29 20:32:12','2020-08-29 20:32:12'),(463,0,NULL,112,NULL,'2020-08-29 20:32:12','2020-08-29 20:32:12'),(464,0,NULL,113,NULL,'2020-08-29 20:32:12','2020-08-29 20:32:12'),(465,0,NULL,114,NULL,'2020-08-29 20:32:12','2020-08-29 20:32:12'),(466,0,NULL,115,NULL,'2020-08-29 20:32:12','2020-08-29 20:32:12'),(467,0,NULL,116,NULL,'2020-08-29 20:32:12','2020-08-29 20:32:12'),(468,0,NULL,117,NULL,'2020-08-29 20:32:12','2020-08-29 20:32:12'),(469,0,NULL,118,NULL,'2020-08-29 20:32:12','2020-08-29 20:32:12'),(470,0,NULL,119,NULL,'2020-08-29 20:32:12','2020-08-29 20:32:12'),(471,0,NULL,120,NULL,'2020-08-29 20:32:12','2020-08-29 20:32:12'),(472,0,NULL,121,NULL,'2020-08-29 20:32:12','2020-08-29 20:32:12'),(473,0,NULL,122,NULL,'2020-08-29 20:32:12','2020-08-29 20:32:12'),(474,0,NULL,123,NULL,'2020-08-29 20:32:12','2020-08-29 20:32:12'),(475,0,NULL,124,NULL,'2020-08-29 20:32:12','2020-08-29 20:32:12'),(476,0,NULL,125,NULL,'2020-08-29 20:32:12','2020-08-29 20:32:12'),(477,0,NULL,126,NULL,'2020-08-29 20:32:12','2020-08-29 20:32:12'),(478,0,NULL,127,NULL,'2020-08-29 20:32:12','2020-08-29 20:32:12'),(479,0,NULL,128,NULL,'2020-08-29 20:32:12','2020-08-29 20:32:12'),(480,0,NULL,129,NULL,'2020-08-29 20:32:12','2020-08-29 20:32:12'),(481,0,NULL,130,NULL,'2020-08-29 20:32:12','2020-08-29 20:32:12'),(482,0,NULL,131,NULL,'2020-08-29 20:32:12','2020-08-29 20:32:12'),(483,0,NULL,132,NULL,'2020-08-29 20:32:12','2020-08-29 20:32:12'),(484,0,NULL,133,NULL,'2020-08-29 20:32:12','2020-08-29 20:32:12'),(485,0,NULL,134,NULL,'2020-08-29 20:32:12','2020-08-29 20:32:12'),(486,0,NULL,135,NULL,'2020-08-29 20:32:12','2020-08-29 20:32:12'),(487,0,NULL,136,NULL,'2020-08-29 20:32:12','2020-08-29 20:32:12'),(488,0,NULL,137,NULL,'2020-08-29 20:32:12','2020-08-29 20:32:12'),(489,0,NULL,138,NULL,'2020-08-29 20:32:12','2020-08-29 20:32:12'),(490,3,NULL,97,NULL,'2020-08-31 18:58:18','2020-08-31 18:58:18'),(491,3,NULL,98,NULL,'2020-08-31 18:58:18','2020-08-31 18:58:18'),(492,3,NULL,99,NULL,'2020-08-31 18:58:18','2020-08-31 18:58:18'),(493,3,NULL,100,NULL,'2020-08-31 18:58:18','2020-08-31 18:58:18'),(494,4,NULL,97,'fg','2020-10-08 14:43:34','2020-10-08 14:47:28'),(495,4,NULL,98,NULL,'2020-10-08 14:43:34','2020-10-08 14:43:34'),(496,4,NULL,99,NULL,'2020-10-08 14:43:34','2020-10-08 14:43:34'),(497,4,NULL,100,NULL,'2020-10-08 14:43:34','2020-10-08 14:43:34'),(498,4,NULL,167,'2020-10-08','2020-10-08 14:47:56','2020-10-08 14:47:56'),(499,4,NULL,168,'11 Am','2020-10-08 14:47:56','2020-10-08 14:47:56'),(500,4,NULL,169,'we','2020-10-08 14:47:56','2020-10-08 14:47:56'),(501,4,NULL,170,'male','2020-10-08 14:47:56','2020-10-08 14:47:56'),(502,4,NULL,171,'11','2020-10-08 14:47:56','2020-10-08 14:47:56'),(503,4,NULL,172,'ds','2020-10-08 14:47:56','2020-10-08 14:47:56'),(504,4,NULL,173,'sds','2020-10-08 14:47:56','2020-10-08 14:47:56'),(505,4,NULL,39,'sds','2020-10-08 14:47:56','2020-10-08 14:47:56'),(506,4,NULL,174,'fsdsf','2020-10-08 14:47:56','2020-10-08 14:47:56'),(507,4,NULL,175,'dfdsf','2020-10-08 14:47:56','2020-10-08 14:47:56'),(508,4,NULL,181,'dfd','2020-10-08 14:47:56','2020-10-08 14:47:56'),(509,4,NULL,40,'dfsd','2020-10-08 14:47:56','2020-10-08 14:47:56'),(510,4,NULL,106,'rg','2020-10-08 14:47:56','2020-10-08 14:47:56'),(511,4,NULL,178,'dfds','2020-10-08 14:47:56','2020-10-08 14:47:56'),(512,4,NULL,179,'dfds','2020-10-08 14:47:56','2020-10-08 14:47:56'),(513,4,NULL,180,'hghb','2020-10-08 14:47:56','2020-10-08 14:47:56'),(514,4,NULL,182,'dfhdf','2020-10-08 14:47:56','2020-10-08 14:47:56'),(515,4,NULL,176,'fhd','2020-10-08 14:47:56','2020-10-08 14:47:56'),(516,4,NULL,177,'fdhs','2020-10-08 14:47:56','2020-10-08 14:47:56'),(517,5,NULL,97,NULL,'2021-02-04 14:50:19','2021-02-04 14:50:19'),(518,5,NULL,98,NULL,'2021-02-04 14:50:19','2021-02-04 14:50:19'),(519,5,NULL,99,NULL,'2021-02-04 14:50:19','2021-02-04 14:50:19'),(520,5,NULL,100,NULL,'2021-02-04 14:50:19','2021-02-04 14:50:19'),(521,NULL,2259,225,'a','2021-03-04 06:11:16','2021-03-04 06:11:16'),(522,NULL,2259,195,NULL,'2021-03-04 06:11:16','2021-03-04 06:11:16'),(523,NULL,2259,194,NULL,'2021-03-04 06:11:16','2021-03-04 06:11:16'),(524,NULL,2259,197,NULL,'2021-03-04 06:11:16','2021-03-04 06:11:16'),(525,NULL,2259,196,NULL,'2021-03-04 06:11:16','2021-03-04 06:11:16'),(526,NULL,2259,198,NULL,'2021-03-04 06:11:16','2021-03-04 06:11:16'),(527,NULL,2259,199,NULL,'2021-03-04 06:11:16','2021-03-04 06:11:16'),(528,NULL,2259,200,NULL,'2021-03-04 06:11:16','2021-03-04 06:11:16'),(529,NULL,2259,201,NULL,'2021-03-04 06:11:16','2021-03-04 06:11:16'),(530,NULL,2259,202,NULL,'2021-03-04 06:11:16','2021-03-04 06:11:16'),(531,NULL,2259,203,NULL,'2021-03-04 06:11:16','2021-03-04 06:11:16'),(532,NULL,2259,204,NULL,'2021-03-04 06:11:16','2021-03-04 06:11:16'),(533,NULL,2259,205,NULL,'2021-03-04 06:11:16','2021-03-04 06:11:16'),(534,NULL,2259,206,NULL,'2021-03-04 06:11:16','2021-03-04 06:11:16'),(535,NULL,2259,207,NULL,'2021-03-04 06:11:16','2021-03-04 06:11:16'),(536,NULL,2259,208,NULL,'2021-03-04 06:11:16','2021-03-04 06:11:16'),(537,NULL,2259,209,NULL,'2021-03-04 06:11:16','2021-03-04 06:11:16'),(538,NULL,2259,210,NULL,'2021-03-04 06:11:16','2021-03-04 06:11:16'),(539,NULL,2259,211,NULL,'2021-03-04 06:11:16','2021-03-04 06:11:16'),(540,NULL,2259,212,NULL,'2021-03-04 06:11:16','2021-03-04 06:11:16'),(541,NULL,2259,213,NULL,'2021-03-04 06:11:16','2021-03-04 06:11:16'),(542,NULL,2259,214,NULL,'2021-03-04 06:11:16','2021-03-04 06:11:16'),(543,NULL,2259,215,NULL,'2021-03-04 06:11:16','2021-03-04 06:11:16'),(544,NULL,2259,216,NULL,'2021-03-04 06:11:16','2021-03-04 06:11:16'),(545,NULL,2259,217,NULL,'2021-03-04 06:11:16','2021-03-04 06:11:16'),(546,NULL,2259,218,NULL,'2021-03-04 06:11:16','2021-03-04 06:11:16'),(547,NULL,2259,219,NULL,'2021-03-04 06:11:16','2021-03-04 06:11:16'),(548,NULL,2259,220,NULL,'2021-03-04 06:11:16','2021-03-04 06:11:16'),(549,NULL,2259,221,NULL,'2021-03-04 06:11:16','2021-03-04 06:11:16'),(550,NULL,2259,222,NULL,'2021-03-04 06:11:16','2021-03-04 06:11:16'),(551,NULL,2259,223,NULL,'2021-03-04 06:11:16','2021-03-04 06:11:16'),(552,NULL,2259,224,NULL,'2021-03-04 06:11:16','2021-03-04 06:11:16'),(553,NULL,2259,226,'5','2021-03-08 04:26:02','2021-03-08 04:26:02'),(554,NULL,2259,227,'4','2021-03-08 04:26:02','2021-03-08 04:26:02'),(555,NULL,2259,228,NULL,'2021-03-08 04:26:02','2021-03-08 04:26:02'),(556,NULL,2259,229,NULL,'2021-03-08 04:26:02','2021-03-08 04:26:02'),(557,NULL,2259,230,NULL,'2021-03-08 04:26:02','2021-03-08 04:26:02'),(558,NULL,2259,231,NULL,'2021-03-08 04:26:02','2021-03-08 04:26:02'),(559,NULL,2259,232,NULL,'2021-03-08 04:26:02','2021-03-08 04:26:02'),(560,NULL,2259,233,NULL,'2021-03-08 04:26:02','2021-03-08 04:26:02'),(561,NULL,2259,234,NULL,'2021-03-08 04:26:02','2021-03-08 04:26:02'),(562,NULL,2259,235,NULL,'2021-03-08 04:26:02','2021-03-08 04:26:02'),(563,NULL,2259,236,NULL,'2021-03-08 04:26:02','2021-03-08 04:26:02'),(564,NULL,2259,237,NULL,'2021-03-08 04:26:02','2021-03-08 04:26:02'),(565,NULL,2259,238,NULL,'2021-03-08 04:26:02','2021-03-08 04:26:02'),(566,NULL,2259,239,NULL,'2021-03-08 04:26:02','2021-03-08 04:26:02'),(567,NULL,2259,240,NULL,'2021-03-08 04:26:02','2021-03-08 04:26:02'),(568,NULL,2259,241,NULL,'2021-03-08 04:26:02','2021-03-08 04:26:02');
/*!40000 ALTER TABLE `form_field_values` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `form_master`
--

DROP TABLE IF EXISTS `form_master`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `form_master` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `form_name` text,
  `form_description` text,
  `view_path` text,
  `add_edit_path` text,
  `print_path` text,
  `index_path` text,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `form_master`
--

LOCK TABLES `form_master` WRITE;
/*!40000 ALTER TABLE `form_master` DISABLE KEYS */;
INSERT INTO `form_master` VALUES (1,'ipd_Admission','Admission Paper & Consent letter','ipd_Admission.view','ipd_Admission.addEdit','ipd_Admission.print','ipd_Admission.index','2019-02-03 21:05:01','2019-02-03 21:05:01'),(2,'ipd_SeenByMdDgo','S/B MD, DGO','ipd_SeenByMdDgo.view','ipd_SeenByMdDgo.addEdit','ipd_SeenByMdDgo.print','ipd_SeenByMdDgo.index','2019-02-03 21:05:01','2019-02-03 21:05:01'),(3,'ipd_seenByMdDchLlb','S/B MD, DGO','ipd_seenByMdDchLlb.view','ipd_seenByMdDchLlb.addEdit','ipd_seenByMdDchLlb.print','ipd_seenByMdDchLlb.index','2019-02-03 21:05:01','2019-02-03 21:05:01'),(4,'ipd_surgeryNotes','Surgery Operative Notes','ipd_surgeryNotes.view','ipd_surgeryNotes.addEdit','ipd_surgeryNotes.print','ipd_surgeryNotes.index','2019-02-03 21:05:01','2019-02-03 21:05:01'),(5,'ipd_dailyTreatment','Daily Treatment','ipd_dailyTreatment.view','ipd_dailyTreatment.addEdit','ipd_dailyTreatment.print','ipd_dailyTreatment.index','2019-02-03 21:05:01','2019-02-03 21:05:01'),(6,'squint_evalutation','eye form Squint Evalutaion','EyeForm.squint_view','EyeForm.squint_addEdit','EyeForm.squint_print','EyeForm.squint_index','2019-02-03 00:00:00','2019-02-03 00:00:00'),(7,'Paediatric_Eye_Evaluation','Paediatric Eye Evaluation','EyeForm.Paediatric_view','EyeForm.Paediatric_addEdit','EyeForm.Paediatric_print','EyeForm.Paediatric_index','2019-02-03 00:00:00','2019-02-03 00:00:00'),(8,'Ptosis_Proforma','Ptosis Proforma','EyeForm.PtosisProforma_view','EyeForm.PtosisProforma_addEdit','EyeForm.PtosisProforma_print','EyeForm.PtosisProforma_index','2019-02-03 00:00:00','2019-02-03 00:00:00');
/*!40000 ALTER TABLE `form_master` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `form_master_form_field`
--

DROP TABLE IF EXISTS `form_master_form_field`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `form_master_form_field` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `form_master_id` bigint(20) DEFAULT NULL,
  `form_field_code` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=203 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `form_master_form_field`
--

LOCK TABLES `form_master_form_field` WRITE;
/*!40000 ALTER TABLE `form_master_form_field` DISABLE KEYS */;
INSERT INTO `form_master_form_field` VALUES (1,1,97),(2,1,98),(3,1,99),(4,1,100),(5,2,101),(6,2,102),(7,2,103),(8,2,104),(9,2,105),(10,2,106),(11,2,107),(12,2,108),(13,2,109),(14,2,110),(15,2,111),(16,2,112),(17,2,113),(18,2,114),(19,2,115),(20,2,116),(21,2,117),(22,2,118),(23,2,119),(24,2,120),(25,2,121),(26,2,122),(27,2,123),(28,2,124),(29,2,125),(30,2,126),(31,2,127),(32,2,128),(33,2,129),(34,2,130),(35,2,131),(36,2,132),(37,2,133),(38,2,134),(39,2,135),(40,2,136),(41,2,137),(42,2,138),(43,3,108),(44,3,109),(45,3,112),(46,3,114),(47,3,115),(48,3,116),(49,3,117),(50,3,118),(51,3,119),(52,3,122),(53,3,123),(54,3,124),(55,3,126),(56,3,127),(57,3,128),(58,3,129),(59,3,130),(60,3,131),(61,3,133),(62,3,134),(63,3,135),(64,3,139),(65,3,140),(66,3,141),(67,3,142),(68,3,143),(69,3,144),(70,3,145),(71,3,146),(72,3,147),(73,3,148),(74,3,149),(75,3,150),(76,3,151),(77,3,152),(78,3,153),(79,3,154),(80,3,155),(81,3,156),(82,3,157),(83,3,158),(84,3,159),(85,3,160),(86,3,161),(87,3,162),(88,3,120),(89,3,132),(90,3,138),(91,4,39),(92,4,106),(93,4,176),(94,4,173),(95,4,40),(96,4,177),(97,4,169),(98,4,168),(99,4,167),(100,4,170),(101,4,171),(102,4,172),(103,4,175),(104,4,174),(105,4,178),(106,4,179),(107,4,180),(108,4,181),(109,4,182),(110,5,183),(111,5,184),(112,5,109),(113,5,146),(114,5,185),(115,5,147),(116,5,111),(117,5,186),(118,5,113),(119,5,187),(120,5,188),(121,5,189),(122,5,190),(123,6,194),(124,6,195),(125,6,196),(126,6,197),(127,6,198),(128,6,199),(129,6,200),(130,6,201),(131,6,202),(132,6,203),(133,6,204),(134,6,205),(135,6,206),(136,6,207),(137,6,208),(138,6,209),(139,6,210),(140,6,211),(141,6,212),(142,6,213),(143,6,214),(144,6,215),(145,6,216),(146,6,217),(147,6,218),(148,6,219),(149,6,220),(150,6,221),(151,6,222),(152,6,223),(153,6,224),(154,6,225),(155,7,226),(156,7,227),(157,7,228),(158,7,229),(159,7,230),(160,7,231),(161,7,232),(162,7,233),(163,7,234),(164,7,235),(165,7,236),(166,7,237),(167,7,238),(168,7,239),(169,7,240),(170,7,241),(171,8,242),(172,8,243),(173,8,244),(174,8,245),(175,8,246),(176,8,247),(177,8,248),(178,8,249),(179,8,250),(180,8,251),(181,8,252),(182,8,253),(183,8,254),(184,8,255),(185,8,256),(186,8,257),(187,8,258),(188,8,259),(189,8,260),(190,8,261),(191,8,262),(192,8,263),(193,8,264),(194,8,265),(195,8,266),(196,8,267),(197,8,268),(198,8,269),(199,8,270),(200,8,271),(201,8,272),(202,8,273);
/*!40000 ALTER TABLE `form_master_form_field` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fundus_images`
--

DROP TABLE IF EXISTS `fundus_images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fundus_images` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `case_id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `eye` varchar(255) DEFAULT NULL,
  `description` longtext,
  `image` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fundus_images`
--

LOCK TABLES `fundus_images` WRITE;
/*!40000 ALTER TABLE `fundus_images` DISABLE KEYS */;
/*!40000 ALTER TABLE `fundus_images` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glass_prescriptions`
--

DROP TABLE IF EXISTS `glass_prescriptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glass_prescriptions` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `case_id` bigint(20) DEFAULT NULL,
  `case_number` text,
  `r_dv_sph` text,
  `r_dv_cyl` text,
  `r_dv_axi` text,
  `r_dv_vision` text,
  `l_dv_sph` text,
  `l_dv_cyl` text,
  `l_dv_axi` text,
  `l_dv_vision` text,
  `r_nv_sph` text,
  `r_nv_cyl` text,
  `r_nv_axi` text,
  `r_nv_vision` text,
  `l_nv_sph` text,
  `l_nv_cyl` text,
  `l_nv_axi` text,
  `l_nv_vision` text,
  `Report_1` text,
  `Report_2` text,
  `Report_3` text,
  `retino_scopy_OD` text,
  `retino_scopy_OS` text,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  `r_add_sph` varchar(255) DEFAULT NULL,
  `l_add_sph` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=107 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `glass_prescriptions`
--

LOCK TABLES `glass_prescriptions` WRITE;
/*!40000 ALTER TABLE `glass_prescriptions` DISABLE KEYS */;
/*!40000 ALTER TABLE `glass_prescriptions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gyn_form_dropdowns`
--

DROP TABLE IF EXISTS `gyn_form_dropdowns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gyn_form_dropdowns` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `formName` varchar(200) NOT NULL,
  `fieldName` varchar(200) NOT NULL,
  `ddText` varchar(200) NOT NULL,
  `ddValue` varchar(200) NOT NULL,
  `isdefault` bit(1) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gyn_form_dropdowns`
--

LOCK TABLES `gyn_form_dropdowns` WRITE;
/*!40000 ALTER TABLE `gyn_form_dropdowns` DISABLE KEYS */;
/*!40000 ALTER TABLE `gyn_form_dropdowns` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `homepage_data`
--

DROP TABLE IF EXISTS `homepage_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `homepage_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` enum('section_slider_footer','section_departments','section_work','section_paper_cutting','section_welcome','section_slider_footer2','section_slider2') DEFAULT NULL,
  `img_url` text,
  `title` text,
  `description` text,
  `read_more_link` text,
  `is_active` enum('0','1') DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `displayed_in` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `homepage_data`
--

LOCK TABLES `homepage_data` WRITE;
/*!40000 ALTER TABLE `homepage_data` DISABLE KEYS */;
INSERT INTO `homepage_data` VALUES (1,'section_slider_footer','uploads/hh4EsZ8HnlkYXOEgG2tKqyKIOvdSMSLiQ39s8LJ4.png',NULL,NULL,NULL,'1','2022-04-07 10:59:04','2022-04-07 10:59:04',NULL),(2,'section_departments','uploads/IACFOkEVhBbrG6K2VYD1Gal7y46IZ0aUqYbBULda.png','vnvbn','bvnnbvnvb       ffg hfh fgh',NULL,'1','2022-04-07 15:42:44','2022-04-07 15:42:44',NULL),(3,'section_departments','uploads/DkcfLlEWkdOhPrYCQQsNFkuVQ4mgy1iGpifSdbP8.gif','5t45','Shri Sai Baba Bhandara and Sai Palkhi Ceremony',NULL,'1','2022-04-07 15:43:28','2022-04-07 15:43:28',NULL),(4,'section_slider_footer','uploads/QiMYGfo4Vk7D0zG6x8iPgJIu2qcXbaakhZm83xMI.gif','test','bvnnbvnvb       ffg hfh fgh',NULL,'1','2022-04-07 15:48:26','2022-04-07 15:48:26',NULL),(5,'section_work','uploads/BRPxLzX0dUHf8908KxVEUVWSPnm0k3b1uIzfyNSe.jpeg','Work 1','asd asd a','https://google.com','1','2022-04-10 14:26:47','2022-04-10 14:26:47',NULL),(6,'section_work','uploads/AVTutXGlVaRTI2xF6ldXXM9zctrTqcyxuHKv5JRK.jpeg','Work 2','asad sad a','https://google.com','1','2022-04-10 14:27:02','2022-04-10 14:27:02',NULL),(7,'section_paper_cutting','uploads/eYDpR0G2bp3XHdFqUASxoQ4RhVSz85lS3CxmpCWD.jpeg,uploads/9mGmIeN4X0qssDQyGknOl4ceatjEzAmADbZ3Orxi.jpeg,uploads/KukVtGJDWkiwIZywQPtk5Dk5dH4OJYXWyrH7rSJT.jpeg,uploads/2ucaR3KTLLxyvwV6BueIm5P38b9Lu7wIUMZ6BpZ4.jpeg','Cutting 1','aaa','https://google.com','1','2022-04-10 14:27:39','2022-04-10 14:27:39',NULL),(8,'section_paper_cutting','uploads/Dvkt1CbSojE295pLgQyFcKA7s9QgrfbO2uOrUbI4.jpeg,uploads/XCYBJkOS1hB4j9E0CtiHcUaETDTFDTY9PYbC9nU0.jpeg,uploads/7K8lMNDY4xbQYhCVmwglUyNKDzlLfckOyu4ecKgH.jpeg,uploads/snmd6A7ID2LBPP7nQ03rmLMq9rtYDqZVEHgqHjf7.jpeg','Cutting 2','hhh','https://google.com','1','2022-04-10 14:27:58','2022-04-10 14:27:58',NULL),(9,'section_welcome','uploads/WnKQHxcQudpIeHPq0yQxLcymH7RYJ6nQTLbVzKoa.png','rrr','gfhfghgfhfgcvcxv dfh dfh df hdhfhfhfhgfhf hfhf h rd fj gg jkg jguj gy gjh fhg fh fhf hgf hgf hgfhg fh fgh fh fgh f fhgf  dhdfhdfhdfvcbhvbcv yuggjgjgjgjg jgjgjh gjgjg jgjh gjgjh gjg jghj gjg jghj gjg jggj ghjg jgj gjh gjhg jhg jhg jg jgj ghj ghj gjh hgjh gjhg jgj gjh gjg jgjh gjg jg jg jhg jg jg jg hjg j g jg jg hj ghj gjhg jg hjg jg g yur r yrty t d fhg fjfj  jg dhfhdfhd','https://google.com','1','2022-04-19 16:10:50','2022-06-09 06:32:45',NULL),(10,'section_slider_footer',NULL,'ccvbc','bvcbvcbcv','https://www.google.com/','1','2022-05-05 05:00:11','2022-05-05 05:00:11',NULL),(11,'section_slider_footer2','uploads/h7hWD3kCb7SDDKikkLD6xPFedYL9XjrpWA4qUr95.png','SSS','As you navigate our website, I hope you learn more about the qualities that make our Laboratory an outstanding provider of various essential services with Fastest diagnostic reports all around  15+ Years of experience Highly Equipped Clinic Laboratory Good quality care & service','https://www.google.com/','1','2022-05-06 13:53:10','2022-05-08 06:46:07',NULL),(12,'section_slider_footer2','uploads/W5wWST4zBn5wt8rF1qVSVR9hHd4dkzpEQMWRlt8J.jpeg','bbbb','gfhfghgfhfgcvcxv dfh dfh df hd dhdfhdfhdf dhfhdfhd',NULL,'1','2022-05-06 13:54:01','2022-05-06 13:54:01',NULL),(13,'section_slider_footer2','uploads/5fdSID3iE7qNpm5nTvb51qkOUWj6dh5JTHDuioru.jpeg','ppppp','gfhfghgfhfgcvcxv dfh dfh df hd dhdfhdfhdf dhfhdfhd',NULL,'1','2022-05-06 13:55:03','2022-05-06 13:55:03',NULL),(14,'section_slider2','uploads/y45bse74jHLgMCU8T53aIjitrJK6d3jYlcr8n1L4.jpeg','One','test description',NULL,'1','2022-05-12 04:50:38','2022-05-12 04:50:38',NULL),(15,'section_slider2','uploads/bZANZgw4TAEiHIaIDswOej0WBQY51OrJXT7luueM.jpeg','Two','Another testimonial',NULL,'1','2022-05-12 04:51:05','2022-05-12 04:51:05',NULL);
/*!40000 ALTER TABLE `homepage_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hospital_charges_particulars_template`
--

DROP TABLE IF EXISTS `hospital_charges_particulars_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hospital_charges_particulars_template` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `template_name` varchar(255) DEFAULT NULL,
  `parent` int(11) DEFAULT NULL,
  `particular_id` int(11) DEFAULT NULL,
  `amount` varchar(255) DEFAULT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hospital_charges_particulars_template`
--

LOCK TABLES `hospital_charges_particulars_template` WRITE;
/*!40000 ALTER TABLE `hospital_charges_particulars_template` DISABLE KEYS */;
INSERT INTO `hospital_charges_particulars_template` VALUES (1,'test',0,24,'500','1'),(2,'test',1,26,'1500','1'),(3,'test',1,53,'790','1'),(4,'xzy',0,60,'500','1'),(5,'xzy',4,61,'1000','1'),(6,'xzy',4,66,'400','1'),(7,'sai',0,93,'1000','1'),(8,'sai',7,95,'3000','1'),(9,'sai',7,96,'1500','1'),(10,'sai',7,98,'800','1'),(11,'sai',7,128,'300','1');
/*!40000 ALTER TABLE `hospital_charges_particulars_template` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `image_gallery`
--

DROP TABLE IF EXISTS `image_gallery`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `image_gallery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `imgTypeId` int(11) NOT NULL,
  `imgUrl` text NOT NULL,
  `Name` text,
  `Description` text,
  `read_more_link` text,
  `isActive` bit(1) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `displayed_in` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=64 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `image_gallery`
--

LOCK TABLES `image_gallery` WRITE;
/*!40000 ALTER TABLE `image_gallery` DISABLE KEYS */;
/*!40000 ALTER TABLE `image_gallery` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `insurance_bill`
--

DROP TABLE IF EXISTS `insurance_bill`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `insurance_bill` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `case_id` bigint(20) DEFAULT NULL,
  `case_number` text,
  `name_of_patient` text,
  `procedure_surgery_done` text,
  `ipd_no` text,
  `bill_no` text,
  `uhid_no` text,
  `bill_date` text,
  `admission_date_time` text,
  `classes` text,
  `discharge_date_time` text,
  `surgon_name` text,
  `tpa_company` text,
  `referedby` text,
  `left_eye` tinyint(2) DEFAULT NULL,
  `right_eye` tinyint(2) DEFAULT NULL,
  `final_diagnosis` text,
  `discharge_sts` text,
  `surgery_date_time` text,
  `insurance_company` text,
  `advance_amount` text,
  `discount_amount` text,
  `sub_total` double(10,2) DEFAULT NULL,
  `total_bill_amount` text,
  `amount_senction_by_tpa` text,
  `balance_amount_by_patient` text,
  `declaration_patient_balance_amt` text,
  `balance_paid_by_patient` text,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `insurance_bill`
--

LOCK TABLES `insurance_bill` WRITE;
/*!40000 ALTER TABLE `insurance_bill` DISABLE KEYS */;
/*!40000 ALTER TABLE `insurance_bill` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `insurance_surgery_dropdown`
--

DROP TABLE IF EXISTS `insurance_surgery_dropdown`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `insurance_surgery_dropdown` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `case_id` int(11) NOT NULL,
  `text` text NOT NULL,
  `eye_operated` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=71 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `insurance_surgery_dropdown`
--

LOCK TABLES `insurance_surgery_dropdown` WRITE;
/*!40000 ALTER TABLE `insurance_surgery_dropdown` DISABLE KEYS */;
/*!40000 ALTER TABLE `insurance_surgery_dropdown` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ipd_bill_payments`
--

DROP TABLE IF EXISTS `ipd_bill_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ipd_bill_payments` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `case_number` text CHARACTER SET utf8 NOT NULL,
  `paid_amount` decimal(10,2) DEFAULT NULL,
  `payment_date` date DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `case_id` bigint(20) NOT NULL,
  `payment_mode` varchar(100) NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `is_deleted` enum('0','1') NOT NULL DEFAULT '0',
  `deleted_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ipd_bill_payments`
--

LOCK TABLES `ipd_bill_payments` WRITE;
/*!40000 ALTER TABLE `ipd_bill_payments` DISABLE KEYS */;
/*!40000 ALTER TABLE `ipd_bill_payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ipd_discharge`
--

DROP TABLE IF EXISTS `ipd_discharge`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ipd_discharge` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `patient_id` bigint(20) DEFAULT NULL,
  `doctor_id` bigint(20) DEFAULT NULL,
  `doa` datetime DEFAULT NULL,
  `doatime` text,
  `dod` datetime DEFAULT NULL,
  `dodtime` text,
  `diagnosis` text,
  `clinical_notes` text,
  `investigation_findings` text,
  `treatment_given` text,
  `operative_notes` text,
  `treatment_advice` text,
  `next_visit` text,
  `status` text,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ipd_discharge`
--

LOCK TABLES `ipd_discharge` WRITE;
/*!40000 ALTER TABLE `ipd_discharge` DISABLE KEYS */;
/*!40000 ALTER TABLE `ipd_discharge` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ipd_patient_bill`
--

DROP TABLE IF EXISTS `ipd_patient_bill`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ipd_patient_bill` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `register_id` bigint(20) DEFAULT NULL,
  `tpa_company` text,
  `insurance_company` text,
  `bill_no` text,
  `bill_towards` text,
  `room_no` text,
  `advance_amount` text,
  `discount_amount` text,
  `bill_date` datetime DEFAULT NULL,
  `admit_date` datetime DEFAULT NULL,
  `discharge_date` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ipd_patient_bill`
--

LOCK TABLES `ipd_patient_bill` WRITE;
/*!40000 ALTER TABLE `ipd_patient_bill` DISABLE KEYS */;
/*!40000 ALTER TABLE `ipd_patient_bill` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ipd_patient_bill_items`
--

DROP TABLE IF EXISTS `ipd_patient_bill_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ipd_patient_bill_items` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `bill_id` bigint(20) DEFAULT NULL,
  `particular` text,
  `day` text,
  `rate` text,
  `amount` text,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ipd_patient_bill_items`
--

LOCK TABLES `ipd_patient_bill_items` WRITE;
/*!40000 ALTER TABLE `ipd_patient_bill_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `ipd_patient_bill_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ipd_patient_medicine`
--

DROP TABLE IF EXISTS `ipd_patient_medicine`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ipd_patient_medicine` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `register_id` bigint(20) DEFAULT NULL,
  `medicine_id` bigint(20) DEFAULT NULL,
  `date_of_mgf` datetime DEFAULT NULL,
  `date_of_exp` datetime DEFAULT NULL,
  `batch_no` text,
  `price` text,
  `quantity` text,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ipd_patient_medicine`
--

LOCK TABLES `ipd_patient_medicine` WRITE;
/*!40000 ALTER TABLE `ipd_patient_medicine` DISABLE KEYS */;
/*!40000 ALTER TABLE `ipd_patient_medicine` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ipd_patient_register`
--

DROP TABLE IF EXISTS `ipd_patient_register`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ipd_patient_register` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `case_id` bigint(20) DEFAULT NULL,
  `name` text,
  `guardian_name` text,
  `address` text,
  `mobile_no` text,
  `phone_no` text,
  `email_id` text,
  `blood_group` text,
  `gender` text,
  `date_of_birth` datetime DEFAULT NULL,
  `age` text,
  `weight` text,
  `maritial_status` text,
  `registration_date` datetime DEFAULT NULL,
  `registration_time` text,
  `discharge_date` text,
  `discharge_time` text,
  `room_no` text,
  `package` text,
  `uhid_no` text,
  `ipd_no` text,
  `case` text,
  `ref_doctor` text,
  `consultant_doctor` text,
  `department` text,
  `specialisation` text,
  `presenting_complaint` text,
  `drug_sensitivity` text,
  `family_history` text,
  `past_history` text,
  `remark` text,
  `advance` text,
  `payment_mode` text,
  `debit_ac` text,
  `status` text,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ipd_patient_register`
--

LOCK TABLES `ipd_patient_register` WRITE;
/*!40000 ALTER TABLE `ipd_patient_register` DISABLE KEYS */;
/*!40000 ALTER TABLE `ipd_patient_register` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ipd_patients_dropdowns`
--

DROP TABLE IF EXISTS `ipd_patients_dropdowns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ipd_patients_dropdowns` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `value` varchar(255) DEFAULT NULL,
  `parent` int(11) DEFAULT '0',
  `type` varchar(255) DEFAULT NULL,
  `status` enum('0','1') DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=191 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ipd_patients_dropdowns`
--

LOCK TABLES `ipd_patients_dropdowns` WRITE;
/*!40000 ALTER TABLE `ipd_patients_dropdowns` DISABLE KEYS */;
INSERT INTO `ipd_patients_dropdowns` VALUES (57,'Cash',NULL,0,'ipd_payment_mode','1'),(58,'UPI',NULL,0,'ipd_payment_mode','1'),(59,'Card',NULL,0,'ipd_payment_mode','1'),(67,'Twin Sharing Room',NULL,0,'ipd_ward_type','1'),(68,'Deluxe Room',NULL,0,'ipd_ward_type','1'),(69,'ICU',NULL,0,'ipd_ward_type','1'),(70,'1',NULL,0,'ipd_bed_number','1'),(71,'2',NULL,0,'ipd_bed_number','1'),(72,'3',NULL,0,'ipd_bed_number','1'),(73,'4',NULL,0,'ipd_bed_number','1'),(74,'5',NULL,0,'ipd_bed_number','1'),(75,'6',NULL,0,'ipd_bed_number','1'),(76,'7',NULL,0,'ipd_bed_number','1'),(77,'8',NULL,0,'ipd_bed_number','1'),(90,'General Ward',NULL,0,'ipd_ward_type','1'),(91,'Semi Deluxe Room',NULL,0,'ipd_ward_type','1'),(92,'HOSPITAL',NULL,0,'ipd_particulars','1'),(150,'Lab',NULL,0,'ipd_particulars','1'),(152,'Gpay',NULL,0,'ipd_payment_mode','1'),(153,'Phone Pay',NULL,0,'ipd_payment_mode','1'),(154,'Dr. Jitendra Chandurkar',NULL,0,'ipd_doctor','1'),(155,'Dr. Manisha Chandurkar',NULL,0,'ipd_doctor','1'),(156,'Consultation charges','500',92,'ipd_particulars','1'),(159,'visit/ follwoup charges Dr. Jitendra Chandurkar','1000',92,'ipd_particulars','1'),(160,'visit/ follwoup charges Dr. Manisha Chandurkar','1000',92,'ipd_particulars','1'),(161,'Out side Dr. visit charges','1000',92,'ipd_particulars','1'),(162,'Bed charges - Genral Ward','1500',92,'ipd_particulars','1'),(163,'Bed charges Twin sharing','2000',92,'ipd_particulars','1'),(164,'Special room charges','3000',92,'ipd_particulars','1'),(165,'Delux room charges','3500',92,'ipd_particulars','1'),(166,'Nursing charges','500',92,'ipd_particulars','1'),(167,'Oxygen charges','500',92,'ipd_particulars','1'),(168,'IV Fluids charges','200',92,'ipd_particulars','1'),(169,'ECG charges','300',92,'ipd_particulars','1'),(170,'Monitor  charges','500',92,'ipd_particulars','1'),(171,'Ward Medicines','0',92,'ipd_particulars','1'),(172,'Dressing Minor','200',92,'ipd_particulars','1'),(173,'Dressing Major','400',92,'ipd_particulars','1'),(174,'Operation Theater charges','0',92,'ipd_particulars','1'),(175,'Surgeons charges','0',92,'ipd_particulars','1'),(176,'Assistant charges','0',92,'ipd_particulars','1'),(177,'Anesthetists Charges','0',92,'ipd_particulars','1'),(178,'Hospital IPD Registration Charges','500',92,'ipd_particulars','1'),(179,'Nebulizer charges','100',92,'ipd_particulars','1'),(180,'Bio-medical waste charges','100',92,'ipd_particulars','1'),(181,'RMO charges','500',92,'ipd_particulars','1'),(182,'Cost of disposables','0',92,'ipd_particulars','1'),(183,'Other charges','0',92,'ipd_particulars','1'),(184,'Followup','400',92,'ipd_particulars','1'),(185,'Consultation charges','500',92,'ipd_particulars','1'),(186,'Dressing  Small','200',92,'ipd_particulars','1'),(187,'Dressing Big','400',92,'ipd_particulars','1'),(188,'Catheterization','0',92,'ipd_particulars','1'),(189,'Blood Transfusion charges','1500',92,'ipd_particulars','1'),(190,'Tapping charges','0',92,'ipd_particulars','1');
/*!40000 ALTER TABLE `ipd_patients_dropdowns` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ipd_patients_estimate_bills`
--

DROP TABLE IF EXISTS `ipd_patients_estimate_bills`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ipd_patients_estimate_bills` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `registration_id` varchar(255) NOT NULL,
  `date_time` varchar(255) NOT NULL,
  `diagnosis` longtext NOT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '1',
  `is_deleted` enum('0','1') NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` varchar(255) NOT NULL,
  `updated_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ipd_patients_estimate_bills`
--

LOCK TABLES `ipd_patients_estimate_bills` WRITE;
/*!40000 ALTER TABLE `ipd_patients_estimate_bills` DISABLE KEYS */;
/*!40000 ALTER TABLE `ipd_patients_estimate_bills` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ipd_patients_particulars`
--

DROP TABLE IF EXISTS `ipd_patients_particulars`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ipd_patients_particulars` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `registration_id` int(11) DEFAULT NULL,
  `date_time` varchar(255) DEFAULT NULL,
  `particular` varchar(255) DEFAULT NULL,
  `amount` varchar(255) DEFAULT NULL,
  `quantity` varchar(255) DEFAULT NULL,
  `total_amount` varchar(255) DEFAULT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '1',
  `is_deleted` enum('0','1') NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` varchar(255) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=194 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ipd_patients_particulars`
--

LOCK TABLES `ipd_patients_particulars` WRITE;
/*!40000 ALTER TABLE `ipd_patients_particulars` DISABLE KEYS */;
INSERT INTO `ipd_patients_particulars` VALUES (189,28,'2023-05-24 - 09:28 PM','162','1500','2','3000','1','0','2023-05-24 15:59:05',2,NULL,NULL),(190,28,'2023-05-29 - 12:44 PM','163','2000','5','10000','1','0','2023-05-29 07:14:51',2,NULL,NULL),(191,28,'2023-05-29 - 12:44 PM','164','3000','5','15000','1','0','2023-05-29 07:15:01',2,NULL,NULL),(192,28,'2023-05-29 - 12:45 PM','171','4788','5','23940','1','0','2023-05-29 07:15:24',2,NULL,NULL),(193,28,'2023-05-29 - 12:45 PM','183','4545','2','9090','1','0','2023-05-29 07:15:39',2,NULL,NULL);
/*!40000 ALTER TABLE `ipd_patients_particulars` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ipd_prescription`
--

DROP TABLE IF EXISTS `ipd_prescription`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ipd_prescription` (
  `id` bigint(20) NOT NULL,
  `register_id` text NOT NULL,
  `medicine_id` bigint(20) NOT NULL,
  `medicine_Quntity` text NOT NULL,
  `per_unit_cost` decimal(10,2) NOT NULL,
  `numberoftimes` text,
  `no_of_days` text,
  `strength` text,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ipd_prescription`
--

LOCK TABLES `ipd_prescription` WRITE;
/*!40000 ALTER TABLE `ipd_prescription` DISABLE KEYS */;
INSERT INTO `ipd_prescription` VALUES (0,'2',202,'दो दिन',0.00,'One drop 5 times a day','22','Cap. Macushield','2022-03-01 00:04:37','2022-03-01 00:04:37');
/*!40000 ALTER TABLE `ipd_prescription` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ipd_treatment_daily_notes`
--

DROP TABLE IF EXISTS `ipd_treatment_daily_notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ipd_treatment_daily_notes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ipd_patient_id` bigint(20) DEFAULT NULL,
  `time` text,
  `temp` text,
  `spo2` text,
  `bp` text,
  `rr` text,
  `fhs` text,
  `treatment` text,
  `morning` text,
  `evening` text,
  `night` text,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ipd_treatment_daily_notes`
--

LOCK TABLES `ipd_treatment_daily_notes` WRITE;
/*!40000 ALTER TABLE `ipd_treatment_daily_notes` DISABLE KEYS */;
/*!40000 ALTER TABLE `ipd_treatment_daily_notes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ipdbill_item_template`
--

DROP TABLE IF EXISTS `ipdbill_item_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ipdbill_item_template` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `template_type` varchar(255) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ipdbill_item_template`
--

LOCK TABLES `ipdbill_item_template` WRITE;
/*!40000 ALTER TABLE `ipdbill_item_template` DISABLE KEYS */;
/*!40000 ALTER TABLE `ipdbill_item_template` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ipdbill_item_template_data`
--

DROP TABLE IF EXISTS `ipdbill_item_template_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ipdbill_item_template_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `template_id` int(11) DEFAULT NULL,
  `label` varchar(255) DEFAULT NULL,
  `value` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ipdbill_item_template_data`
--

LOCK TABLES `ipdbill_item_template_data` WRITE;
/*!40000 ALTER TABLE `ipdbill_item_template_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `ipdbill_item_template_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ivf_agonist_data`
--

DROP TABLE IF EXISTS `ivf_agonist_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ivf_agonist_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reference_id` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `date` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ivf_agonist_data`
--

LOCK TABLES `ivf_agonist_data` WRITE;
/*!40000 ALTER TABLE `ivf_agonist_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `ivf_agonist_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ivf_icsi`
--

DROP TABLE IF EXISTS `ivf_icsi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ivf_icsi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `case_id` varchar(255) DEFAULT NULL,
  `pre_ivf_hysteroscopy` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `age` varchar(255) DEFAULT NULL,
  `lmp_date` date DEFAULT NULL,
  `amh` varchar(255) DEFAULT NULL,
  `opu_date_time` datetime DEFAULT NULL,
  `ivf_followup_1` date DEFAULT NULL,
  `ivf_followup_2` date DEFAULT NULL,
  `ivf_followup_3` date DEFAULT NULL,
  `ivf_followup_4` date DEFAULT NULL,
  `stimulated` varchar(255) DEFAULT NULL,
  `ivf_icsi_ovary_date` date DEFAULT NULL,
  `ivf_icsi_ovary_right` varchar(255) DEFAULT NULL,
  `ivf_icsi_ovary_left` varchar(255) DEFAULT NULL,
  `ivf_icsi_ovary_mi` varchar(255) DEFAULT NULL,
  `embryology_formed` longtext,
  `fresh_et` longtext,
  `notes` longtext,
  `status` enum('0','1') NOT NULL DEFAULT '1',
  `is_deleted` enum('0','1') NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `ivf_followup_time_1` varchar(255) DEFAULT NULL,
  `ivf_followup_time_2` varchar(255) DEFAULT NULL,
  `ivf_followup_time_3` varchar(255) DEFAULT NULL,
  `ivf_followup_time_4` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ivf_icsi`
--

LOCK TABLES `ivf_icsi` WRITE;
/*!40000 ALTER TABLE `ivf_icsi` DISABLE KEYS */;
/*!40000 ALTER TABLE `ivf_icsi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ivf_icsi_medicine`
--

DROP TABLE IF EXISTS `ivf_icsi_medicine`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ivf_icsi_medicine` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `case_id` varchar(255) DEFAULT NULL,
  `sop_hcg_ing_trigger_date_time` varchar(255) DEFAULT NULL,
  `rmo_name` varchar(255) DEFAULT NULL,
  `reception_informed` varchar(255) DEFAULT NULL,
  `pt_instruction` longtext,
  `real_time_video_sent_to_sir` longtext,
  `is_deleted` enum('0','1') NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ivf_icsi_medicine`
--

LOCK TABLES `ivf_icsi_medicine` WRITE;
/*!40000 ALTER TABLE `ivf_icsi_medicine` DISABLE KEYS */;
/*!40000 ALTER TABLE `ivf_icsi_medicine` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ivf_icsi_medicine_details`
--

DROP TABLE IF EXISTS `ivf_icsi_medicine_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ivf_icsi_medicine_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `case_id` varchar(255) DEFAULT NULL,
  `medicine_name` varchar(255) DEFAULT NULL,
  `time` varchar(255) DEFAULT NULL,
  `batch_number` varchar(255) DEFAULT NULL,
  `expiry_date` varchar(255) DEFAULT NULL,
  `is_deleted` enum('0','1') NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ivf_icsi_medicine_details`
--

LOCK TABLES `ivf_icsi_medicine_details` WRITE;
/*!40000 ALTER TABLE `ivf_icsi_medicine_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `ivf_icsi_medicine_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ivf_icsi_menses`
--

DROP TABLE IF EXISTS `ivf_icsi_menses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ivf_icsi_menses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `case_id` varchar(255) DEFAULT NULL,
  `menses_injection_date` date DEFAULT NULL,
  `menses_day` varchar(255) DEFAULT NULL,
  `menses_injection_day` varchar(255) DEFAULT NULL,
  `menses_injection_time` varchar(255) DEFAULT NULL,
  `menses_injection_inj_folisurge_150` varchar(255) DEFAULT NULL,
  `menses_injection_inj_hmg_150` varchar(255) DEFAULT NULL,
  `menses_injection_inj_cetorflix_150` varchar(255) DEFAULT NULL,
  `is_deleted` enum('0','1') DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ivf_icsi_menses`
--

LOCK TABLES `ivf_icsi_menses` WRITE;
/*!40000 ALTER TABLE `ivf_icsi_menses` DISABLE KEYS */;
/*!40000 ALTER TABLE `ivf_icsi_menses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ivf_icsi_ovary`
--

DROP TABLE IF EXISTS `ivf_icsi_ovary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ivf_icsi_ovary` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `case_id` varchar(255) DEFAULT NULL,
  `ivf_icsi_ovary_date` date DEFAULT NULL,
  `ivf_icsi_ovary_right` varchar(255) DEFAULT NULL,
  `ivf_icsi_ovary_left` varchar(255) DEFAULT NULL,
  `ivf_icsi_ovary_mi` varchar(255) DEFAULT NULL,
  `is_deleted` enum('0','1') NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ivf_icsi_ovary`
--

LOCK TABLES `ivf_icsi_ovary` WRITE;
/*!40000 ALTER TABLE `ivf_icsi_ovary` DISABLE KEYS */;
/*!40000 ALTER TABLE `ivf_icsi_ovary` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ivf_menses_data`
--

DROP TABLE IF EXISTS `ivf_menses_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ivf_menses_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reference_id` int(11) DEFAULT NULL,
  `menses_injection_date` varchar(255) DEFAULT NULL,
  `menses_day` varchar(255) DEFAULT NULL,
  `menses_tablet_day` varchar(255) DEFAULT NULL,
  `menses_et` varchar(255) DEFAULT NULL,
  `notes` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ivf_menses_data`
--

LOCK TABLES `ivf_menses_data` WRITE;
/*!40000 ALTER TABLE `ivf_menses_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `ivf_menses_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ivf_menses_dosage_data`
--

DROP TABLE IF EXISTS `ivf_menses_dosage_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ivf_menses_dosage_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reference_id` int(11) DEFAULT NULL,
  `medicine` varchar(255) DEFAULT NULL,
  `duration` varchar(255) DEFAULT NULL,
  `time` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ivf_menses_dosage_data`
--

LOCK TABLES `ivf_menses_dosage_data` WRITE;
/*!40000 ALTER TABLE `ivf_menses_dosage_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `ivf_menses_dosage_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ivf_od_ed_eft`
--

DROP TABLE IF EXISTS `ivf_od_ed_eft`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ivf_od_ed_eft` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `case_id` varchar(255) DEFAULT NULL,
  `ivf_type` varchar(255) DEFAULT NULL,
  `ivf_od_lmp` varchar(255) DEFAULT NULL,
  `ivf_od_pre_ivf_heteroscopy` longtext,
  `ivf_od_cycle_type` varchar(255) DEFAULT NULL,
  `ivf_od_injection` varchar(255) DEFAULT NULL,
  `ivf_followup_1` date DEFAULT NULL,
  `ivf_followup_2` date DEFAULT NULL,
  `ivf_followup_3` date DEFAULT NULL,
  `ivf_followup_4` date DEFAULT NULL,
  `ivf_od_notes` longtext,
  `is_deleted` enum('0','1') NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `ivf_followup_time_1` varchar(255) DEFAULT NULL,
  `ivf_followup_time_2` varchar(255) DEFAULT NULL,
  `ivf_followup_time_3` varchar(255) DEFAULT NULL,
  `ivf_followup_time_4` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ivf_od_ed_eft`
--

LOCK TABLES `ivf_od_ed_eft` WRITE;
/*!40000 ALTER TABLE `ivf_od_ed_eft` DISABLE KEYS */;
/*!40000 ALTER TABLE `ivf_od_ed_eft` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_activities`
--

DROP TABLE IF EXISTS `log_activities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_activities` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `subject` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `method` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ip` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `agent` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_activities`
--

LOCK TABLES `log_activities` WRITE;
/*!40000 ALTER TABLE `log_activities` DISABLE KEYS */;
INSERT INTO `log_activities` VALUES (1,'Patient Kyc updated successfully','https://eye.tejasinfotech.in/patientDetails/EditKYC','POST','103.58.154.154','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.74 Safari/537.36',2,'2022-03-20 12:14:33','2022-03-20 12:14:33');
/*!40000 ALTER TABLE `log_activities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `md_form_dropdowns`
--

DROP TABLE IF EXISTS `md_form_dropdowns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `md_form_dropdowns` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `formName` varchar(200) NOT NULL,
  `fieldName` varchar(200) NOT NULL,
  `ddText` varchar(200) NOT NULL,
  `ddValue` varchar(200) NOT NULL,
  `isdefault` bit(1) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `md_form_dropdowns`
--

LOCK TABLES `md_form_dropdowns` WRITE;
/*!40000 ALTER TABLE `md_form_dropdowns` DISABLE KEYS */;
/*!40000 ALTER TABLE `md_form_dropdowns` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `medical_store`
--

DROP TABLE IF EXISTS `medical_store`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `medical_store` (
  `id` bigint(100) NOT NULL AUTO_INCREMENT,
  `medicine_name` varchar(5000) NOT NULL,
  `generic_name` text,
  `is_generic` enum('0','1') NOT NULL DEFAULT '0',
  `available_quantity` bigint(20) NOT NULL,
  `unit_price` decimal(10,2) NOT NULL,
  `balance_quantity` bigint(20) NOT NULL,
  `isactive` bit(1) NOT NULL,
  `created_dt` datetime NOT NULL,
  `updated_dt` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=243 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `medical_store`
--

LOCK TABLES `medical_store` WRITE;
/*!40000 ALTER TABLE `medical_store` DISABLE KEYS */;
/*!40000 ALTER TABLE `medical_store` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `medicalspeciality`
--

DROP TABLE IF EXISTS `medicalspeciality`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `medicalspeciality` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `specialityName` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `isActive` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `medicalspeciality`
--

LOCK TABLES `medicalspeciality` WRITE;
/*!40000 ALTER TABLE `medicalspeciality` DISABLE KEYS */;
INSERT INTO `medicalspeciality` VALUES (1,'Heart specailist','Heart specailist',1,'2017-02-11 10:11:03','2017-02-11 10:11:03'),(2,'skin specialist','skin specialist',1,'2017-02-11 10:11:03','2017-02-11 10:11:03'),(3,'kidney specialisy','kidney specialisy',1,'2017-02-11 10:11:03','2017-02-11 10:11:03');
/*!40000 ALTER TABLE `medicalspeciality` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `medicinestock`
--

DROP TABLE IF EXISTS `medicinestock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `medicinestock` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `medicine_name` text NOT NULL,
  `Remaining_Stock_Qty` int(11) DEFAULT NULL,
  `Mfg_date` text,
  `Exp_date` text,
  `Stock_in_date` text,
  `Stock_Out_date` text,
  `Cost` text,
  `unit_Received` text,
  `unit_issued` text,
  `created_at` timestamp(6) NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `medicinestock`
--

LOCK TABLES `medicinestock` WRITE;
/*!40000 ALTER TABLE `medicinestock` DISABLE KEYS */;
/*!40000 ALTER TABLE `medicinestock` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menu_list`
--

DROP TABLE IF EXISTS `menu_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `menu_list` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text,
  `description` text,
  `parentId` int(11) DEFAULT NULL,
  `menu_type` int(11) DEFAULT NULL,
  `orderNo` int(11) DEFAULT NULL,
  `isActive` bit(1) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `orientation` enum('portrait','landscape') NOT NULL DEFAULT 'portrait',
  `link` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=82 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menu_list`
--

LOCK TABLES `menu_list` WRITE;
/*!40000 ALTER TABLE `menu_list` DISABLE KEYS */;
/*!40000 ALTER TABLE `menu_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menu_section`
--

DROP TABLE IF EXISTS `menu_section`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `menu_section` (
  `sectionid` int(100) NOT NULL AUTO_INCREMENT,
  `sectionname` varchar(200) NOT NULL,
  `menu_title` varchar(255) DEFAULT NULL,
  `parent_menu` int(11) DEFAULT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`sectionid`)
) ENGINE=InnoDB AUTO_INCREMENT=83 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menu_section`
--

LOCK TABLES `menu_section` WRITE;
/*!40000 ALTER TABLE `menu_section` DISABLE KEYS */;
INSERT INTO `menu_section` VALUES (1,'1_AddPatient_Details/0','OPD Patient Register',1,'1','2021-02-14 09:36:53',NULL),(2,'1_appointmentlist/0','Appointment Details',1,'1','2021-02-14 09:36:53',NULL),(3,'1_followupappoinment/0','Follow-up Appointment',1,'1','2021-02-14 09:36:53',NULL),(4,'1_appointmentslot','Appointment Time Slot',1,'1','2021-02-14 09:36:53',NULL),(5,'1_appointment','Create Appointment',1,'1','2021-02-14 09:36:53',NULL),(6,'1_stop_appointments','Stopped Appointment',1,'1','2021-02-14 09:36:53',NULL),(7,'1_bill_details','OPD Patient Bill',1,'1','2021-02-14 09:36:53',NULL),(8,'1_MedicineStock','Medicine Stock',1,'0','2021-02-14 09:36:53',NULL),(9,'2_case_masters','Patient Case History',2,'1','2021-02-14 09:36:53',NULL),(10,'2_case_masters/prescriptionlst','Eye Prescription',2,'0','2021-02-14 09:36:53',NULL),(11,'2_glassPrescription','Glass Prescription',2,'0','2021-02-14 09:36:53',NULL),(12,'2_report_files','Add Report',2,'1','2021-02-14 09:36:53',NULL),(13,'2_patient/report','Patient Report',2,'0','2021-02-14 09:36:53',NULL),(14,'15_LogoAddEdit/4','Add Letter Head Top',15,'1','2021-02-14 09:36:53',NULL),(15,'15_LogoAddEdit/5','Add Letter Head Footer',15,'1','2021-02-14 09:36:53',NULL),(16,'2_bill_details','OPD Patient Bill / Report',2,'0','2021-02-14 09:36:53',NULL),(17,'2_MedicineStock','Medicine Stock',2,'0','2021-02-14 09:36:53',NULL),(18,'2_admin/doctor/create','Add Doctor',2,'1','2021-02-14 09:36:53',NULL),(19,'3_ipd_details','IPD Patient',3,'1','2021-02-14 09:36:53',NULL),(20,'3_operation_rec','Operation Record',3,'1','2021-02-14 09:36:53',NULL),(21,'3_eyeipd_operation_rec','Operation Theater Notes',3,'1','2021-02-14 09:36:53',NULL),(22,'3_ipdbill_index','IPD Patient Bill',3,'1','2021-02-14 09:36:53',NULL),(23,'3_discharge_index','Discharge(1)',3,'1','2021-02-14 09:36:53',NULL),(24,'3_discharge2','Discharge(2)',3,'1','2021-02-14 09:36:53',NULL),(25,'3_doctorbill/report/SurgeryReport','Surgery Report',3,'1','2021-02-14 09:36:53',NULL),(26,'3_operative_notes','Operative Notes',3,'1','2021-02-14 09:36:53',NULL),(27,'4_case_masters','Patient Details',4,'1','2021-02-14 09:36:53',NULL),(28,'4_case_masters/prescriptionlstother','Prescription',2,'1','2021-02-14 09:36:53',NULL),(29,'4_glassPrescription','Glass Prescription',4,'1','2021-02-14 09:36:53',NULL),(30,'4_report_files','Add Report',4,'1','2021-02-14 09:36:53',NULL),(31,'4_patient/report','Patient Report',4,'1','2021-02-14 09:36:53',NULL),(32,'4_dynamicForm/4','Add Letter Head Top',4,'1','2021-02-14 09:36:53',NULL),(33,'4_dynamicForm/5','Add Letter Head Footer',4,'1','2021-02-14 09:36:53',NULL),(34,'4_bill_details','OPD Patient Bill / Report',4,'1','2021-02-14 09:36:53',NULL),(35,'4_MedicineStock','Medicine Stock',4,'1','2021-02-14 09:36:53',NULL),(36,'4_admin/doctor/create','Add Doctor',4,'1','2021-02-14 09:36:53',NULL),(37,'5_ipd_patient_details','IPD Patient',5,'1','2021-02-14 09:36:53',NULL),(38,'5_consent_letter','CONSENT LETTER',5,'1','2021-02-14 09:36:53',NULL),(39,'5_IPD/patientBill','IPD Patient Bill',5,'1','2021-02-14 09:36:53',NULL),(40,'5_medicine_details','Medicine Details',5,'1','2021-02-14 09:36:53',NULL),(41,'5_medicine_presction','Medicine Prescription',5,'1','2021-02-14 09:36:53',NULL),(42,'5_IPD/Discharge','Discharges',5,'1','2021-02-14 09:36:53',NULL),(43,'5_dynamicForm/4','Surgery Notes',5,'1','2021-02-14 09:36:53',NULL),(44,'5_dynamicForm/5','Treatment Chart',5,'1','2021-02-14 09:36:53',NULL),(45,'5_dynamicForm/2','Seen By',5,'1','2021-02-14 09:36:53',NULL),(46,'website','Website',6,'1','2021-02-14 09:36:53',NULL),(47,'rating/list','Approve Ratings',6,'1','2021-02-14 09:36:53',NULL),(48,'staff_member','Add Member Contact',7,'1','2021-02-14 09:36:53',NULL),(49,'member_sms','Member SMS',7,'1','2021-02-14 09:36:53',NULL),(50,'bulk_sms','Send Bulk SMS',7,'1','2021-02-14 09:36:53',NULL),(51,'users','Add User',8,'1','2021-02-14 09:36:53',NULL),(52,'user_permissions','User Access',8,'1','2021-02-14 09:36:53',NULL),(53,'downloaddatabase','Back-up  Databse',8,'1','2021-02-14 09:36:53',NULL),(54,'15_settings','Settings',15,'1','2021-02-17 06:39:31',NULL),(55,'10_opd-bill-report','Opd Bill Report',10,'1','2022-07-30 19:34:09',NULL),(56,'10_opd-bill-payment-report','Opd Bill Payment Report',10,'1','2022-07-30 19:34:09',NULL),(57,'10_opd-bill-balance-report','Opd Bill Balance Report',10,'1','2022-07-30 19:34:09',NULL),(58,'11_register','Register',11,'1','2022-07-30 19:34:09',NULL),(59,'11_patients-listing','Listing',11,'1','2022-07-30 19:34:09',NULL),(60,'11_ipd-settings','Ipd Settings',11,'1','2022-07-30 19:34:09',NULL),(61,'12_new-ipd-bill-report','Ipd Bill Report',12,'1','2022-07-30 19:34:09',NULL),(62,'12_new-ipd-bill-payment-report','Ipd Bill Payment Report',12,'1','2022-07-30 19:34:09',NULL),(63,'12_new-ipd-bill-balance-report','Ipd Bill Balance Report',12,'1','2022-07-30 19:34:09',NULL),(64,'15_prescription-templates-listing','Prescription Templates',15,'1','2023-04-05 03:13:19',NULL),(65,'15_list-finding-templates','Finding Templates',15,'1','2023-04-05 03:13:19',NULL),(66,'16_new_website','New Web Site',16,'1','2023-04-05 03:28:12',NULL),(67,'17_home_page_settings','Home Page Settings',17,'1','2023-04-05 03:28:12',NULL),(68,'11_upload-document-listing',' Upload Documents',11,'1','2023-04-05 03:43:39',NULL),(69,'2_patientDetails/patient/report','Patient Report',2,'1','2023-04-09 16:39:09',NULL),(70,'2_ivf-icsi','Ivf icsi',2,'1','2023-04-09 16:51:21',NULL),(71,'2_admin/payment-modes','Payment Modes',2,'1','2023-04-09 17:54:29',NULL),(72,'11_add-ipd-payment','Add Payment receipt',11,'1','2023-04-09 18:10:47',NULL),(73,'11_edit-hospital-charges-particulars','Hospital Charges Particulars',11,'1','2023-04-09 18:10:47',NULL),(74,'11_ipd-estimate-bill','Estimate Bill',11,'1','2023-04-09 18:10:47',NULL),(75,'11_ipd-summary-final-bill','IPD Summary Final Bill',11,'1','2023-04-09 18:10:47',NULL),(76,'11_patients/discharge','DISCHARGE SUMMARY',11,'1','2023-04-09 18:10:47',NULL),(77,'11_patients_history_sheet','Past History',11,'1','2023-04-09 18:10:47',NULL),(78,'11_daily-order-sheet','Daily Order Shee',11,'1','2023-04-09 18:10:47',NULL),(79,'11_tpr-monitoring-chart','TPR Monitoring Chart',11,'1','2023-04-09 18:10:47',NULL),(80,'11_treatment-medication-sheet','Treatment/Medication Sheet',11,'1','2023-04-09 18:10:47',NULL),(81,'11_nurses-over-report','Nurses Over Report ',11,'1','2023-04-09 18:10:47',NULL),(82,'11_rbs-insulin-chart','RBS & Insulin Chart',11,'1','2023-04-09 18:10:47',NULL);
/*!40000 ALTER TABLE `menu_section` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menu_section_bk_10apr2023`
--

DROP TABLE IF EXISTS `menu_section_bk_10apr2023`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `menu_section_bk_10apr2023` (
  `sectionid` int(100) NOT NULL AUTO_INCREMENT,
  `sectionname` varchar(200) NOT NULL,
  `menu_title` varchar(255) DEFAULT NULL,
  `parent_menu` int(11) DEFAULT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`sectionid`)
) ENGINE=InnoDB AUTO_INCREMENT=69 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menu_section_bk_10apr2023`
--

LOCK TABLES `menu_section_bk_10apr2023` WRITE;
/*!40000 ALTER TABLE `menu_section_bk_10apr2023` DISABLE KEYS */;
INSERT INTO `menu_section_bk_10apr2023` VALUES (1,'1_AddPatient_Details/0','Add Patient Details',1,'1','2021-02-14 09:36:53',NULL),(2,'1_appointmentlist/0','Appointment Details',1,'1','2021-02-14 09:36:53',NULL),(3,'1_followupappoinment/0','Follow-up Appointment',1,'1','2021-02-14 09:36:53',NULL),(4,'1_appointmentslot','Appointment Time Slot',1,'1','2021-02-14 09:36:53',NULL),(5,'1_appointment','Create Appointment',1,'1','2021-02-14 09:36:53',NULL),(6,'1_stop_appointments','Stopped Appointment',1,'1','2021-02-14 09:36:53',NULL),(7,'1_bill_details','OPD Patient Bill',1,'1','2021-02-14 09:36:53',NULL),(8,'1_MedicineStock','Medicine Stock',1,'0','2021-02-14 09:36:53',NULL),(9,'2_case_masters','Add Patient Details',2,'1','2021-02-14 09:36:53',NULL),(10,'2_case_masters/prescriptionlst','Eye Prescription',2,'1','2021-02-14 09:36:53',NULL),(11,'2_glassPrescription','Glass Prescription',2,'1','2021-02-14 09:36:53',NULL),(12,'2_report_files','Add Report',2,'1','2021-02-14 09:36:53',NULL),(13,'2_patient/report','Patient Report',2,'1','2021-02-14 09:36:53',NULL),(14,'2_LogoAddEdit/4','Add Letter Head Top',15,'1','2021-02-14 09:36:53',NULL),(15,'2_LogoAddEdit/5','Add Letter Head Footer',15,'1','2021-02-14 09:36:53',NULL),(16,'2_bill_details','OPD Patient Bill / Report',2,'1','2021-02-14 09:36:53',NULL),(17,'2_MedicineStock','Medicine Stock',2,'1','2021-02-14 09:36:53',NULL),(18,'2_admin/doctor/create','Add Doctor',2,'1','2021-02-14 09:36:53',NULL),(19,'3_ipd_details','IPD Patient',3,'1','2021-02-14 09:36:53',NULL),(20,'3_operation_rec','Operation Record',3,'1','2021-02-14 09:36:53',NULL),(21,'3_eyeipd_operation_rec','Operation Theater Notes',3,'1','2021-02-14 09:36:53',NULL),(22,'3_ipdbill_index','IPD Patient Bill',3,'1','2021-02-14 09:36:53',NULL),(23,'3_discharge_index','Discharge(1)',3,'1','2021-02-14 09:36:53',NULL),(24,'3_discharge2','Discharge(2)',3,'1','2021-02-14 09:36:53',NULL),(25,'3_doctorbill/report/SurgeryReport','Surgery Report',3,'1','2021-02-14 09:36:53',NULL),(26,'3_operative_notes','Operative Notes',3,'1','2021-02-14 09:36:53',NULL),(27,'4_case_masters','Patient Details',4,'1','2021-02-14 09:36:53',NULL),(28,'4_case_masters/prescriptionlstother','Prescription',2,'1','2021-02-14 09:36:53',NULL),(29,'4_glassPrescription','Glass Prescription',4,'1','2021-02-14 09:36:53',NULL),(30,'4_report_files','Add Report',4,'1','2021-02-14 09:36:53',NULL),(31,'4_patient/report','Patient Report',4,'1','2021-02-14 09:36:53',NULL),(32,'4_dynamicForm/4','Add Letter Head Top',4,'1','2021-02-14 09:36:53',NULL),(33,'4_dynamicForm/5','Add Letter Head Footer',4,'1','2021-02-14 09:36:53',NULL),(34,'4_bill_details','OPD Patient Bill / Report',4,'1','2021-02-14 09:36:53',NULL),(35,'4_MedicineStock','Medicine Stock',4,'1','2021-02-14 09:36:53',NULL),(36,'4_admin/doctor/create','Add Doctor',4,'1','2021-02-14 09:36:53',NULL),(37,'5_ipd_patient_details','IPD Patient',5,'1','2021-02-14 09:36:53',NULL),(38,'5_consent_letter','CONSENT LETTER',5,'1','2021-02-14 09:36:53',NULL),(39,'5_IPD/patientBill','IPD Patient Bill',5,'1','2021-02-14 09:36:53',NULL),(40,'5_medicine_details','Medicine Details',5,'1','2021-02-14 09:36:53',NULL),(41,'5_medicine_presction','Medicine Prescription',5,'1','2021-02-14 09:36:53',NULL),(42,'5_IPD/Discharge','Discharges',5,'1','2021-02-14 09:36:53',NULL),(43,'5_dynamicForm/4','Surgery Notes',5,'1','2021-02-14 09:36:53',NULL),(44,'5_dynamicForm/5','Treatment Chart',5,'1','2021-02-14 09:36:53',NULL),(45,'5_dynamicForm/2','Seen By',5,'1','2021-02-14 09:36:53',NULL),(46,'website','Website',6,'1','2021-02-14 09:36:53',NULL),(47,'rating/list','Approve Ratings',6,'1','2021-02-14 09:36:53',NULL),(48,'staff_member','Add Member Contact',7,'1','2021-02-14 09:36:53',NULL),(49,'member_sms','Member SMS',7,'1','2021-02-14 09:36:53',NULL),(50,'bulk_sms','Send Bulk SMS',7,'1','2021-02-14 09:36:53',NULL),(51,'users','Add User',8,'1','2021-02-14 09:36:53',NULL),(52,'user_permissions','User Access',8,'1','2021-02-14 09:36:53',NULL),(53,'downloaddatabase','Back-up  Databse',8,'1','2021-02-14 09:36:53',NULL),(54,'15_settings','Settings',15,'1','2021-02-17 06:39:31',NULL),(55,'10_opd-bill-report','Opd Bill Report',10,'1','2022-07-30 19:34:09',NULL),(56,'10_opd-bill-payment-report','Opd Bill Payment Report',10,'1','2022-07-30 19:34:09',NULL),(57,'10_opd-bill-balance-report','Opd Bill Balance Report',10,'1','2022-07-30 19:34:09',NULL),(58,'11_register','Register',11,'1','2022-07-30 19:34:09',NULL),(59,'11_patients-listing','Listing',11,'1','2022-07-30 19:34:09',NULL),(60,'11_ipd-settings','Ipd Settings',11,'1','2022-07-30 19:34:09',NULL),(61,'12_new-ipd-bill-report','Ipd Bill Report',12,'1','2022-07-30 19:34:09',NULL),(62,'12_new-ipd-bill-payment-report','Ipd Bill Payment Report',12,'1','2022-07-30 19:34:09',NULL),(63,'12_new-ipd-bill-balance-report','Ipd Bill Balance Report',12,'1','2022-07-30 19:34:09',NULL),(64,'15_prescription-templates-listing','Prescription Templates',15,'1','2023-04-05 03:13:19',NULL),(65,'15_list-finding-templates','Finding Templates',15,'1','2023-04-05 03:13:19',NULL),(66,'16_new_website','New Web Site',16,'1','2023-04-05 03:28:12',NULL),(67,'17_home_page_settings','Home Page Settings',17,'1','2023-04-05 03:28:12',NULL),(68,'11_upload-document-listing',' Upload Documents',11,'1','2023-04-05 03:43:39',NULL);
/*!40000 ALTER TABLE `menu_section_bk_10apr2023` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menu_section_bk_5apr2023`
--

DROP TABLE IF EXISTS `menu_section_bk_5apr2023`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `menu_section_bk_5apr2023` (
  `sectionid` int(100) NOT NULL AUTO_INCREMENT,
  `sectionname` varchar(200) NOT NULL,
  `menu_title` varchar(255) DEFAULT NULL,
  `parent_menu` varchar(255) DEFAULT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`sectionid`)
) ENGINE=InnoDB AUTO_INCREMENT=81 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menu_section_bk_5apr2023`
--

LOCK TABLES `menu_section_bk_5apr2023` WRITE;
/*!40000 ALTER TABLE `menu_section_bk_5apr2023` DISABLE KEYS */;
INSERT INTO `menu_section_bk_5apr2023` VALUES (1,'1_AddPatient_Details/0','Add Patient Details','1','1','2021-02-14 09:36:53',NULL),(2,'1_appointmentlist/0','Appointment Details','1','1','2021-02-14 09:36:53',NULL),(3,'1_followupappoinment/0','Follow-up Appointment','1','1','2021-02-14 09:36:53',NULL),(4,'1_appointmentslot','Appointment Time Slot','1','1','2021-02-14 09:36:53',NULL),(5,'1_appointment','Create Appointment','1','1','2021-02-14 09:36:53',NULL),(6,'1_stop_appointments','Stopped Appointment','1','1','2021-02-14 09:36:53',NULL),(7,'1_bill_details','OPD Patient Bill','1','1','2021-02-14 09:36:53',NULL),(8,'1_MedicineStock','Medicine Stock','1','1','2021-02-14 09:36:53',NULL),(9,'2_case_masters','Add Patient Details','2','1','2021-02-14 09:36:53',NULL),(10,'2_case_masters/prescriptionlst','Eye Prescription','2','1','2021-02-14 09:36:53',NULL),(11,'2_glassPrescription','Glass Prescription','2','1','2021-02-14 09:36:53',NULL),(12,'2_report_files','Add Report','2','1','2021-02-14 09:36:53',NULL),(13,'2_patient/report','Patient Report','2','1','2021-02-14 09:36:53',NULL),(14,'2_LogoAddEdit/4','Add Letter Head Top','2','1','2021-02-14 09:36:53',NULL),(15,'2_LogoAddEdit/5','Add Letter Head Footer','2','1','2021-02-14 09:36:53',NULL),(16,'2_bill_details','OPD Patient Bill / Report','2','1','2021-02-14 09:36:53',NULL),(17,'2_MedicineStock','Medicine Stock','2','1','2021-02-14 09:36:53',NULL),(18,'2_admin/doctor/create','Add Doctor','2','1','2021-02-14 09:36:53',NULL),(19,'3_ipd_details','IPD Patient','3','1','2021-02-14 09:36:53',NULL),(20,'3_operation_rec','Operation Record','3','1','2021-02-14 09:36:53',NULL),(21,'3_eyeipd_operation_rec','Operation Theater Notes','3','1','2021-02-14 09:36:53',NULL),(22,'3_ipdbill_index','IPD Patient Bill','3','1','2021-02-14 09:36:53',NULL),(23,'3_discharge_index','Discharge(1)','3','1','2021-02-14 09:36:53',NULL),(24,'3_discharge2','Discharge(2)','3','1','2021-02-14 09:36:53',NULL),(25,'3_doctorbill/report/SurgeryReport','Surgery Report','3','1','2021-02-14 09:36:53',NULL),(26,'3_operative_notes','Operative Notes','3','1','2021-02-14 09:36:53',NULL),(27,'4_case_masters','Patient Details','4','1','2021-02-14 09:36:53',NULL),(28,'4_case_masters/prescriptionlstother','Prescription','4','1','2021-02-14 09:36:53',NULL),(29,'4_glassPrescription','Glass Prescription','4','1','2021-02-14 09:36:53',NULL),(30,'4_report_files','Add Report','4','1','2021-02-14 09:36:53',NULL),(31,'4_patient/report','Patient Report','4','1','2021-02-14 09:36:53',NULL),(32,'4_dynamicForm/4','Add Letter Head Top','4','1','2021-02-14 09:36:53',NULL),(33,'4_dynamicForm/5','Add Letter Head Footer','4','1','2021-02-14 09:36:53',NULL),(34,'4_bill_details','OPD Patient Bill / Report','4','1','2021-02-14 09:36:53',NULL),(35,'4_MedicineStock','Medicine Stock','4','1','2021-02-14 09:36:53',NULL),(36,'4_admin/doctor/create','Add Doctor','4','1','2021-02-14 09:36:53',NULL),(37,'5_ipd_patient_details','IPD Patient','5','1','2021-02-14 09:36:53',NULL),(38,'5_consent_letter','CONSENT LETTER','5','1','2021-02-14 09:36:53',NULL),(39,'5_IPD/patientBill','IPD Patient Bill','5','1','2021-02-14 09:36:53',NULL),(40,'5_medicine_details','Medicine Details','5','1','2021-02-14 09:36:53',NULL),(41,'5_medicine_presction','Medicine Prescription','5','1','2021-02-14 09:36:53',NULL),(42,'5_IPD/Discharge','Discharges','5','1','2021-02-14 09:36:53',NULL),(43,'5_dynamicForm/4','Surgery Notes','5','1','2021-02-14 09:36:53',NULL),(44,'5_dynamicForm/5','Treatment Chart','5','1','2021-02-14 09:36:53',NULL),(45,'5_dynamicForm/2','Seen By','5','1','2021-02-14 09:36:53',NULL),(46,'website','Website','6','1','2021-02-14 09:36:53',NULL),(47,'rating/list','Approve Ratings','6','1','2021-02-14 09:36:53',NULL),(48,'staff_member','Add Member Contact','7','1','2021-02-14 09:36:53',NULL),(49,'member_sms','Member SMS','7','1','2021-02-14 09:36:53',NULL),(50,'bulk_sms','Send Bulk SMS','7','1','2021-02-14 09:36:53',NULL),(51,'users','Add User','8','1','2021-02-14 09:36:53',NULL),(52,'user_permissions','User Access','8','1','2021-02-14 09:36:53',NULL),(53,'downloaddatabase','Back-up  Databse','8','1','2021-02-14 09:36:53',NULL),(54,'settings','Settings','9','1','2021-02-17 06:39:31',NULL),(55,'10_opd-bill-report','Opd Bill Report','10','1','2022-07-30 19:34:09',NULL),(56,'10_opd-bill-payment-report','Opd Bill Payment Report','10','1','2022-07-30 19:34:09',NULL),(57,'10_opd-bill-balance-report','Opd Bill Balance Report','10','1','2022-07-30 19:34:09',NULL),(58,'11_register','Register','11','1','2022-07-30 19:34:09',NULL),(59,'11_patients-listing','Listing','11','1','2022-07-30 19:34:09',NULL),(60,'11_ipd-settings','Ipd Settings','11','1','2022-07-30 19:34:09',NULL),(61,'12_new-ipd-bill-report','Ipd Bill Report','12','1','2022-07-30 19:34:09',NULL),(62,'12_new-ipd-bill-payment-report','Ipd Bill Payment Report','12','1','2022-07-30 19:34:09',NULL),(63,'12_new-ipd-bill-balance-report','Ipd Bill Balance Report','12','1','2022-07-30 19:34:09',NULL),(64,'10_opd-bill-balance-report','Opd Bill Balance Report','10','1','2022-07-30 14:04:09',NULL),(65,'10_opd-bill-payment-report','Opd Bill Payment Report','10','1','2022-07-30 14:04:09',NULL),(66,'10_opd-bill-report','Opd Bill Report','10','1','2022-07-30 14:04:09',NULL),(67,'13_covid-consent-form','Covid 19 Consent Form','13','1','2023-03-12 23:09:10',NULL),(68,'14_patient-activity','Patient View','14','1','2023-03-12 23:10:49',NULL),(69,'1_dilation','Dilation','1','1','2023-03-12 23:33:30',NULL),(70,'2_certificate','Certificate','2','1','2023-03-12 23:44:57',NULL),(71,'3_upload-document-listing','Upload Documents','3','1','2023-03-12 23:57:52',NULL),(72,'3_cataract-operative-notes','Cataract Operative Notes','3','1','2023-03-13 00:05:19',NULL),(73,'3_cataract-consent-form','Cataract Consent Form','3','1','2023-03-13 00:05:51',NULL),(74,'3_cataract-surgey','Cataract Surgery','3','1','2023-03-13 00:06:18',NULL),(75,'15_settings','General Settings','15','1','2023-03-13 00:39:23',NULL),(76,'15_set-dropdown-options','Set Dropdowns','15','1','2023-03-13 00:40:16',NULL),(77,'15_prescription-templates-listing','Prescription Template','15','1','2023-03-13 00:40:52',NULL),(78,'15_list-finding-templates','Finding Templates','15','1','2023-03-13 00:41:14',NULL),(79,'16_new_website','New Website','16','1','2023-03-13 00:51:38',NULL),(80,'2_admin/payment-modes','Payment Modes','2','1','2021-02-14 04:06:53',NULL);
/*!40000 ALTER TABLE `menu_section_bk_5apr2023` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2020_02_15_110647_create_log_activity_table',3),(2,'2014_10_12_000000_create_users_table',1),(3,'2014_10_12_100000_create_password_resets_table',1),(4,'2018_03_03_090023_create_events_table',2);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `new_discharge_summary`
--

DROP TABLE IF EXISTS `new_discharge_summary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `new_discharge_summary` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `registration_id` varchar(255) NOT NULL,
  `field_name` varchar(255) DEFAULT NULL,
  `value_1` longtext,
  `value_2` longtext,
  `value_3` longtext,
  `value_4` longtext,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=363 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `new_discharge_summary`
--

LOCK TABLES `new_discharge_summary` WRITE;
/*!40000 ALTER TABLE `new_discharge_summary` DISABLE KEYS */;
/*!40000 ALTER TABLE `new_discharge_summary` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `new_events`
--

DROP TABLE IF EXISTS `new_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `new_events` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` enum('general') DEFAULT 'general',
  `img_url` text,
  `title` text,
  `description` text,
  `read_more_link` text,
  `is_active` enum('0','1') DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `displayed_in` varchar(100) DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `start_time` varchar(255) DEFAULT NULL,
  `end_time` varchar(255) DEFAULT NULL,
  `address` text,
  `google_map_link` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `new_events`
--

LOCK TABLES `new_events` WRITE;
/*!40000 ALTER TABLE `new_events` DISABLE KEYS */;
INSERT INTO `new_events` VALUES (1,'general','uploads/kowVOHyCFZ3vsYjUIHm0hu37QrsWqmxlRD9FtMV4.jpeg,uploads/JgTMKbgxnRjrvvRyuAn7kbvp7kjpTQzNpSfH8v4G.png,uploads/sEIgihfrI6aF1eXjV1MLYYshUd2D5utNrDzXnJju.png','asdsad','a sd da','asd sd','1','2022-04-05 06:02:37','2022-04-13 16:04:11',NULL,'2022-04-05',NULL,NULL,NULL,NULL,NULL),(2,'general','uploads/QqUXLM1dOPxgpppd7zQl1zxVPqL0aWsdsnzKPCAp.jpeg','Happy Holi','Holi is a popular ancient Hindu festival, also known as the Festival of Spring, the Festival of Colours or the Festival of Love. The festival celebrates the eternal and divine love of Radha Krishna.','https://google.com','1','2022-04-08 05:37:58','2022-04-08 05:37:58',NULL,'2022-04-08','2022-04-09',NULL,NULL,NULL,NULL),(3,'general','uploads/dxxzjZYxLe7frihbu97R0zvTV0OYwnlhsRjnMHCO.png,uploads/258wl7FWHfOehK4yo4YZyBr09nw7Bf4QaWF2iyuF.png','dsfsdfsd','dsfdsf',NULL,NULL,'2022-04-13 16:03:27','2022-04-13 16:03:27',NULL,'2022-04-13',NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `new_events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `new_settings`
--

DROP TABLE IF EXISTS `new_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `new_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `value` longtext,
  `updated_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `new_settings`
--

LOCK TABLES `new_settings` WRITE;
/*!40000 ALTER TABLE `new_settings` DISABLE KEYS */;
INSERT INTO `new_settings` VALUES (1,'top_slider_text','SUSHRUT HOSPITAL.............................Near Khatri Building, Ram Nagar, Aapte wadi, Badlapur (E).....................Contact : 9881204068...........................................................................SUSHRUT HOSPITAL.............................Near Khatri Building, Ram Nagar, Aapte wadi, Badlapur (E).....................Contact : 9881204068...........................................................................SUSHRUT HOSPITAL.............................Near Khatri Building, Ram Nagar, Aapte wadi, Badlapur (E).....................Contact : 9881204068...........................................................................SUSHRUT HOSPITAL.............................Near Khatri Building, Ram Nagar, Aapte wadi, Badlapur (E).....................Contact : 9881204068...........................................................................',NULL,NULL,NULL),(2,'twitter_link','twitter.com',NULL,NULL,NULL),(3,'fb_link','facebook.com',NULL,NULL,NULL),(4,'linkedin_link','linkedin.com',NULL,NULL,NULL),(5,'insta_link','instagram.com',NULL,NULL,NULL),(6,'hospital_logo','new_logo.png',NULL,NULL,NULL),(7,'appointment_link','http://sushruthospitalbadlapur.in//appointment',NULL,NULL,NULL),(8,'call_now','9881204068',NULL,NULL,NULL),(9,'whatsapp','9881204068',NULL,NULL,NULL),(10,'google_map','<iframe src=\"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d119981.37657232156!2d73.80348084999999!3d19.99096305!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bddd290b09914b3%3A0xcb07845d9d28215c!2sNashik%2C%20Maharashtra!5e0!3m2!1sen!2sin!4v1674899415755!5m2!1sen!2sin\" width=\"300\" height=\"225\" style=\"border:0;\" allowfullscreen=\"\" loading=\"lazy\" referrerpolicy=\"no-referrer-when-downgrade\"></iframe>',NULL,NULL,NULL);
/*!40000 ALTER TABLE `new_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `new_wbsite_dynamic_text`
--

DROP TABLE IF EXISTS `new_wbsite_dynamic_text`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `new_wbsite_dynamic_text` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `html_text` text,
  `html_content` longtext,
  `textType` varchar(255) DEFAULT NULL,
  `relationshipKey` int(11) DEFAULT NULL,
  `name` text,
  `description` text,
  `meta_title` text,
  `meta_desc` text,
  `meta_key` text,
  `isActive` bit(1) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `new_wbsite_dynamic_text`
--

LOCK TABLES `new_wbsite_dynamic_text` WRITE;
/*!40000 ALTER TABLE `new_wbsite_dynamic_text` DISABLE KEYS */;
INSERT INTO `new_wbsite_dynamic_text` VALUES (8,'&lt;div class=&quot;col-sm-4&quot;&gt;\r\n&lt;div class=&quot;title mb-30&quot;&gt;\r\n&lt;h2&gt;&lt;img src=&quot;../storage/uploads/sFlo3jZxdGpBQQOogbsGG5gWqXrunHKkhvbzePrt.jpeg&quot; width=&quot;372&quot; height=&quot;219&quot; /&gt;&lt;/h2&gt;\r\n&lt;/div&gt;\r\n&lt;p class=&quot;mt-30 text-justify&quot;&gt;Blemish yourself with the Hexa Cure Luxury experience, that includes everything you desire to have a splendid experience. After all, we are the best maternity hospital in Thane and will make sure you are gratified with superlative care.&lt;/p&gt;\r\n&lt;br /&gt;\r\n&lt;div class=&quot;&quot;&gt;&lt;a class=&quot;btn1&quot; href=&quot;#/&quot;&gt;Read More &lt;/a&gt;&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;div class=&quot;col-sm-4&quot;&gt;\r\n&lt;div class=&quot;title mb-30&quot;&gt;\r\n&lt;h2&gt;&lt;img src=&quot;../storage/uploads/RaYhypyqiGX1lovagcQXvsnORfN9R3g92FXRXuVN.jpeg&quot; width=&quot;372&quot; height=&quot;219&quot; /&gt;&lt;/h2&gt;\r\n&lt;/div&gt;\r\n&lt;p class=&quot;mt-30 text-justify&quot;&gt;We believe that children need a special treatment, as children are not miniature adults. We aim to continue to be better hospital, where paediatricians and support staff are not only experienced and experts but also have desire to care when it comes to treating and caring for children and critical cases.&lt;/p&gt;\r\n&lt;div class=&quot;&quot;&gt;&lt;a class=&quot;btn1&quot; href=&quot;#/&quot;&gt;Read More &lt;/a&gt;&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;div class=&quot;col-sm-4&quot;&gt;\r\n&lt;div class=&quot;title mb-30&quot;&gt;\r\n&lt;h2&gt;&lt;img src=&quot;../storage/uploads/B3x1oGnUTTQTex3cE3S0mLBLe6zXvu2nElRFfYZ8.jpeg&quot; width=&quot;372&quot; height=&quot;219&quot; /&gt;&lt;/h2&gt;\r\n&lt;/div&gt;\r\n&lt;p class=&quot;mt-30 text-justify&quot;&gt;Why Hexa Cure Hair &amp; Skin Clinic?&nbsp; &nbsp; &nbsp; &nbsp;We offers affordable medical treatment for hair transplant, hair prp, gfc, hair trearment.&nbsp; &nbsp; We believe in good skincare for all. from dermatologists formulated products to specialised services, we offer personalized skin care to meet your needs on any given day.&lt;/p&gt;\r\n&lt;br /&gt;\r\n&lt;div class=&quot;&quot;&gt;&lt;a class=&quot;btn1&quot; href=&quot;#/&quot;&gt;Read More &lt;/a&gt;&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;p&gt;&nbsp;&lt;/p&gt;','<div class=\"col-sm-4\">\r\n<div class=\"title mb-30\">\r\n<h2><img src=\"../storage/uploads/sFlo3jZxdGpBQQOogbsGG5gWqXrunHKkhvbzePrt.jpeg\" width=\"372\" height=\"219\" /></h2>\r\n</div>\r\n<p class=\"mt-30 text-justify\">Blemish yourself with the Hexa Cure Luxury experience, that includes everything you desire to have a splendid experience. After all, we are the best maternity hospital in Thane and will make sure you are gratified with superlative care.</p>\r\n<br />\r\n<div class=\"\"><a class=\"btn1\" href=\"#/\">Read More </a></div>\r\n</div>\r\n<div class=\"col-sm-4\">\r\n<div class=\"title mb-30\">\r\n<h2><img src=\"../storage/uploads/RaYhypyqiGX1lovagcQXvsnORfN9R3g92FXRXuVN.jpeg\" width=\"372\" height=\"219\" /></h2>\r\n</div>\r\n<p class=\"mt-30 text-justify\">We believe that children need a special treatment, as children are not miniature adults. We aim to continue to be better hospital, where paediatricians and support staff are not only experienced and experts but also have desire to care when it comes to treating and caring for children and critical cases.</p>\r\n<div class=\"\"><a class=\"btn1\" href=\"#/\">Read More </a></div>\r\n</div>\r\n<div class=\"col-sm-4\">\r\n<div class=\"title mb-30\">\r\n<h2><img src=\"../storage/uploads/B3x1oGnUTTQTex3cE3S0mLBLe6zXvu2nElRFfYZ8.jpeg\" width=\"372\" height=\"219\" /></h2>\r\n</div>\r\n<p class=\"mt-30 text-justify\">Why Hexa Cure Hair &amp; Skin Clinic?&nbsp; &nbsp; &nbsp; &nbsp;We offers affordable medical treatment for hair transplant, hair prp, gfc, hair trearment.&nbsp; &nbsp; We believe in good skincare for all. from dermatologists formulated products to specialised services, we offer personalized skin care to meet your needs on any given day.</p>\r\n<br />\r\n<div class=\"\"><a class=\"btn1\" href=\"#/\">Read More </a></div>\r\n</div>\r\n<p>&nbsp;</p>','section_1',NULL,'asdads',NULL,NULL,'adsasd','asdasd','',NULL,NULL),(9,'&lt;footer class=&quot;footer_area&quot;&gt;\r\n&lt;div class=&quot;footer_widget&quot;&gt;\r\n&lt;div class=&quot;container&quot;&gt;\r\n&lt;div class=&quot;row&quot;&gt;\r\n&lt;div class=&quot;col-md-3 col-sm-12 col-xs-12&quot;&gt;\r\n&lt;aside class=&quot;f_widget about_widget&quot;&gt;\r\n&lt;h1&gt;Logo&lt;/h1&gt;\r\n&lt;/aside&gt;\r\n&lt;/div&gt;\r\n&lt;!--?php //echo htmlspecialchars_decode(get_footer($conn)); ?--&gt;\r\n&lt;div class=&quot;col-md-3 col-sm-4 col-xs-12&quot;&gt;\r\n&lt;aside class=&quot;f_widget padd-l-60&quot;&gt;\r\n&lt;div class=&quot;f_title&quot;&gt;\r\n&lt;h3&gt;Services&lt;/h3&gt;\r\n&lt;/div&gt;\r\n&lt;div class=&quot;link_widget&quot;&gt;\r\n&lt;ul&gt;\r\n&lt;li&gt;&lt;a href=&quot;services.php&quot;&gt;X-ray&lt;/a&gt;&lt;/li&gt;\r\n&lt;li&gt;&lt;a href=&quot;services.php&quot;&gt;USG&lt;/a&gt;&lt;/li&gt;\r\n&lt;li&gt;&lt;a href=&quot;services.php&quot;&gt;2D Echo&lt;/a&gt;&lt;/li&gt;\r\n&lt;li&gt;&lt;a href=&quot;services.php&quot;&gt;Stress Test&lt;/a&gt;&lt;/li&gt;\r\n&lt;li&gt;&lt;a href=&quot;services.php&quot;&gt;Doppler&lt;/a&gt;&lt;/li&gt;\r\n&lt;li&gt;&lt;a href=&quot;services.php&quot;&gt;PFT&lt;/a&gt;&lt;/li&gt;\r\n&lt;li&gt;&lt;a href=&quot;services.php&quot;&gt;Dental Clinic&lt;/a&gt;&lt;/li&gt;\r\n&lt;li&gt;&lt;a href=&quot;services.php&quot;&gt;Ophthalmology&lt;/a&gt;&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;/div&gt;\r\n&lt;/aside&gt;\r\n&lt;/div&gt;\r\n&lt;div class=&quot;col-md-3 col-sm-4 col-xs-12&quot;&gt;\r\n&lt;aside class=&quot;f_widget&quot;&gt;\r\n&lt;div class=&quot;f_title&quot;&gt;\r\n&lt;h3&gt;Quick Links&lt;/h3&gt;\r\n&lt;/div&gt;\r\n&lt;div class=&quot;link_widget&quot;&gt;\r\n&lt;ul&gt;\r\n&lt;li&gt;&lt;a href=&quot;index.php&quot;&gt;Home&lt;/a&gt;&lt;/li&gt;\r\n&lt;li&gt;&lt;a href=&quot;about.php&quot;&gt;About Us&lt;/a&gt;&lt;/li&gt;\r\n&lt;li&gt;&lt;a href=&quot;gallery.php&quot;&gt;Gallery&lt;/a&gt;&lt;/li&gt;\r\n&lt;li&gt;&lt;a href=&quot;contact.php&quot;&gt; Contact Us&lt;/a&gt;&lt;/li&gt;\r\n&lt;/ul&gt;\r\n&lt;/div&gt;\r\n&lt;/aside&gt;\r\n&lt;/div&gt;\r\n&lt;div class=&quot;col-md-3 col-sm-4 col-xs-12&quot;&gt;\r\n&lt;aside class=&quot;f_widget contact_widget&quot;&gt;\r\n&lt;div class=&quot;f_title&quot;&gt;\r\n&lt;h3&gt;get in touch&lt;/h3&gt;\r\n&lt;/div&gt;\r\n&lt;div class=&quot;contact_inner&quot;&gt;\r\n&lt;div class=&quot;media&quot;&gt;\r\n&lt;div class=&quot;media-left&quot;&gt;&nbsp;&lt;/div&gt;\r\n&lt;div class=&quot;media-body&quot;&gt;\r\n&lt;p&gt;cs-10, Metro Plaza, Metro Mall, Kalyan(E) 421 306&lt;/p&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;div class=&quot;media&quot;&gt;\r\n&lt;div class=&quot;media-left&quot;&gt;&nbsp;&lt;/div&gt;\r\n&lt;div class=&quot;media-body&quot;&gt;&lt;a href=&quot;tel:+911234567890&quot;&gt;+91 1234567890&lt;/a&gt;&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;div class=&quot;media&quot;&gt;\r\n&lt;div class=&quot;media-left&quot;&gt;&nbsp;&lt;/div&gt;\r\n&lt;div class=&quot;media-body&quot;&gt;&lt;a href=&quot;mailto:info@examplemail.com&quot;&gt;info@examplemail.com&lt;/a&gt;&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/aside&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;div class=&quot;footer_copyright&quot;&gt;\r\n&lt;div class=&quot;container-fluid&quot;&gt;\r\n&lt;div class=&quot;footer_copyright_inner&quot;&gt;\r\n&lt;div class=&quot;text-center copy-right&quot;&gt;Copyright &copy; 2022 Hospital All rights reserved&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;/footer&gt;','<footer class=\"footer_area\">\r\n<div class=\"footer_widget\">\r\n<div class=\"container\">\r\n<div class=\"row\">\r\n<div class=\"col-md-3 col-sm-12 col-xs-12\">\r\n<aside class=\"f_widget about_widget\">\r\n<h1>Logo</h1>\r\n</aside>\r\n</div>\r\n<!--?php //echo htmlspecialchars_decode(get_footer($conn)); ?-->\r\n<div class=\"col-md-3 col-sm-4 col-xs-12\">\r\n<aside class=\"f_widget padd-l-60\">\r\n<div class=\"f_title\">\r\n<h3>Services</h3>\r\n</div>\r\n<div class=\"link_widget\">\r\n<ul>\r\n<li><a href=\"services.php\">X-ray</a></li>\r\n<li><a href=\"services.php\">USG</a></li>\r\n<li><a href=\"services.php\">2D Echo</a></li>\r\n<li><a href=\"services.php\">Stress Test</a></li>\r\n<li><a href=\"services.php\">Doppler</a></li>\r\n<li><a href=\"services.php\">PFT</a></li>\r\n<li><a href=\"services.php\">Dental Clinic</a></li>\r\n<li><a href=\"services.php\">Ophthalmology</a></li>\r\n</ul>\r\n</div>\r\n</aside>\r\n</div>\r\n<div class=\"col-md-3 col-sm-4 col-xs-12\">\r\n<aside class=\"f_widget\">\r\n<div class=\"f_title\">\r\n<h3>Quick Links</h3>\r\n</div>\r\n<div class=\"link_widget\">\r\n<ul>\r\n<li><a href=\"index.php\">Home</a></li>\r\n<li><a href=\"about.php\">About Us</a></li>\r\n<li><a href=\"gallery.php\">Gallery</a></li>\r\n<li><a href=\"contact.php\"> Contact Us</a></li>\r\n</ul>\r\n</div>\r\n</aside>\r\n</div>\r\n<div class=\"col-md-3 col-sm-4 col-xs-12\">\r\n<aside class=\"f_widget contact_widget\">\r\n<div class=\"f_title\">\r\n<h3>get in touch</h3>\r\n</div>\r\n<div class=\"contact_inner\">\r\n<div class=\"media\">\r\n<div class=\"media-left\">&nbsp;</div>\r\n<div class=\"media-body\">\r\n<p>cs-10, Metro Plaza, Metro Mall, Kalyan(E) 421 306</p>\r\n</div>\r\n</div>\r\n<div class=\"media\">\r\n<div class=\"media-left\">&nbsp;</div>\r\n<div class=\"media-body\"><a href=\"tel:+911234567890\">+91 1234567890</a></div>\r\n</div>\r\n<div class=\"media\">\r\n<div class=\"media-left\">&nbsp;</div>\r\n<div class=\"media-body\"><a href=\"mailto:info@examplemail.com\">info@examplemail.com</a></div>\r\n</div>\r\n</div>\r\n</aside>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n<div class=\"footer_copyright\">\r\n<div class=\"container-fluid\">\r\n<div class=\"footer_copyright_inner\">\r\n<div class=\"text-center copy-right\">Copyright &copy; 2022 Hospital All rights reserved</div>\r\n</div>\r\n</div>\r\n</div>\r\n</footer>','footer',NULL,'asdads',NULL,NULL,'adsasd','asdasd','',NULL,NULL);
/*!40000 ALTER TABLE `new_wbsite_dynamic_text` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `new_web_image_gallery`
--

DROP TABLE IF EXISTS `new_web_image_gallery`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `new_web_image_gallery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `imgTypeId` int(11) NOT NULL,
  `imgUrl` text NOT NULL,
  `Name` text,
  `Description` text,
  `read_more_link` text,
  `isActive` bit(1) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `displayed_in` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `new_web_image_gallery`
--

LOCK TABLES `new_web_image_gallery` WRITE;
/*!40000 ALTER TABLE `new_web_image_gallery` DISABLE KEYS */;
INSERT INTO `new_web_image_gallery` VALUES (3,2,'new_slider1674400882.jpeg','Test','Test2',NULL,'',NULL,NULL,'galleryPage');
/*!40000 ALTER TABLE `new_web_image_gallery` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `number_of_times_dropdown`
--

DROP TABLE IF EXISTS `number_of_times_dropdown`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `number_of_times_dropdown` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text,
  `is_active` bit(1) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `update_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `number_of_times_dropdown`
--

LOCK TABLES `number_of_times_dropdown` WRITE;
/*!40000 ALTER TABLE `number_of_times_dropdown` DISABLE KEYS */;
/*!40000 ALTER TABLE `number_of_times_dropdown` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nurses_over_report`
--

DROP TABLE IF EXISTS `nurses_over_report`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `nurses_over_report` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `registration_id` int(11) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `from_time` varchar(255) DEFAULT NULL,
  `to_time` varchar(255) DEFAULT NULL,
  `medication` text,
  `nurse_name` varchar(255) DEFAULT NULL,
  `notes` longtext,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nurses_over_report`
--

LOCK TABLES `nurses_over_report` WRITE;
/*!40000 ALTER TABLE `nurses_over_report` DISABLE KEYS */;
/*!40000 ALTER TABLE `nurses_over_report` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `old_register`
--

DROP TABLE IF EXISTS `old_register`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `old_register` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ipd_no` text,
  `patient_name` text,
  `patient_address` text,
  `date_of_admission` text,
  `date_of_discharge` text,
  `mobile_no` text,
  `consulting_doctor` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `old_register`
--

LOCK TABLES `old_register` WRITE;
/*!40000 ALTER TABLE `old_register` DISABLE KEYS */;
/*!40000 ALTER TABLE `old_register` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `opd_bill`
--

DROP TABLE IF EXISTS `opd_bill`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `opd_bill` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `case_number` text CHARACTER SET utf8 NOT NULL,
  `department` text CHARACTER SET utf8,
  `doctor_id` int(11) DEFAULT NULL,
  `bill_no` text CHARACTER SET utf8,
  `bill_item` text CHARACTER SET utf8,
  `bill_Amount` decimal(10,2) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `case_id` bigint(20) NOT NULL,
  `payment_mode` varchar(100) NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `is_deleted` enum('0','1') NOT NULL DEFAULT '0',
  `deleted_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=347 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `opd_bill`
--

LOCK TABLES `opd_bill` WRITE;
/*!40000 ALTER TABLE `opd_bill` DISABLE KEYS */;
/*!40000 ALTER TABLE `opd_bill` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `opd_bill_payments`
--

DROP TABLE IF EXISTS `opd_bill_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `opd_bill_payments` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `case_number` text CHARACTER SET utf8 NOT NULL,
  `paid_Amount` decimal(10,2) DEFAULT NULL,
  `payment_date` date DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `case_id` bigint(20) NOT NULL,
  `payment_mode` varchar(100) NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `is_deleted` enum('0','1') NOT NULL DEFAULT '0',
  `deleted_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=159 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `opd_bill_payments`
--

LOCK TABLES `opd_bill_payments` WRITE;
/*!40000 ALTER TABLE `opd_bill_payments` DISABLE KEYS */;
/*!40000 ALTER TABLE `opd_bill_payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `parent_menu`
--

DROP TABLE IF EXISTS `parent_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `parent_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_title` varchar(255) DEFAULT NULL,
  `position` int(11) DEFAULT NULL,
  `status` enum('0','1') DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `parent_menu`
--

LOCK TABLES `parent_menu` WRITE;
/*!40000 ALTER TABLE `parent_menu` DISABLE KEYS */;
INSERT INTO `parent_menu` VALUES (1,'Patient Reg., Appointment & OPD Bill',1,'1'),(2,'Opd Patients',2,'1'),(3,'IPD Patients',3,'0'),(4,'Patient',4,'0'),(5,'IPD',5,'0'),(6,'Website',6,'1'),(7,'SMS',7,'0'),(8,'User',8,'1'),(9,'Other',9,'1'),(10,'Opd Reports',10,'1'),(11,'Ipd Patients',11,'1'),(12,'Ipd Reports',12,'1'),(13,'Covid 19',13,'0'),(14,'Patient View',14,'0'),(15,'Settings',NULL,'1'),(16,'New Website',NULL,'1'),(17,'Home page Settings',NULL,'1');
/*!40000 ALTER TABLE `parent_menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `parent_menu_bk_5apr2023`
--

DROP TABLE IF EXISTS `parent_menu_bk_5apr2023`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `parent_menu_bk_5apr2023` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_title` varchar(255) DEFAULT NULL,
  `position` int(11) DEFAULT NULL,
  `status` enum('0','1') DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `parent_menu_bk_5apr2023`
--

LOCK TABLES `parent_menu_bk_5apr2023` WRITE;
/*!40000 ALTER TABLE `parent_menu_bk_5apr2023` DISABLE KEYS */;
INSERT INTO `parent_menu_bk_5apr2023` VALUES (1,'Patient Reg., Appointment & OPD Bill',1,'1'),(2,'Eye Patient',2,'1'),(3,'Eye IPD',3,'1'),(4,'Patient',4,'0'),(5,'IPD',5,'0'),(6,'Website',6,'1'),(7,'SMS',7,'1'),(8,'User',8,'1'),(9,'Other',9,'1'),(10,'Opd Reports',10,'1'),(11,'Ipd Patients',11,'1'),(12,'Ipd Reports',12,'1');
/*!40000 ALTER TABLE `parent_menu_bk_5apr2023` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`(191)),
  KEY `password_resets_token_index` (`token`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_resets`
--

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
INSERT INTO `password_resets` VALUES ('sutarseema32@gmail.com','$2y$10$AeZnC8ktq0Sxo/kI1bi.YuhstUXMC2.un1YM4RHZpR3o38g9BBUeS','2020-02-21 07:47:15');
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patient_activity`
--

DROP TABLE IF EXISTS `patient_activity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `patient_activity` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `case_id` varchar(255) DEFAULT NULL,
  `activity_type` varchar(255) DEFAULT NULL,
  `status` enum('In','Out') DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `in_created_date` date DEFAULT NULL,
  `in_created_time` varchar(255) DEFAULT NULL,
  `in_created_by` int(11) DEFAULT NULL,
  `out_created_date` date DEFAULT NULL,
  `out_created_time` varchar(255) DEFAULT NULL,
  `out_created_by` int(11) DEFAULT NULL,
  `in_timestamp` timestamp NULL DEFAULT NULL,
  `out_timestamp` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patient_activity`
--

LOCK TABLES `patient_activity` WRITE;
/*!40000 ALTER TABLE `patient_activity` DISABLE KEYS */;
/*!40000 ALTER TABLE `patient_activity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patient_details`
--

DROP TABLE IF EXISTS `patient_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `patient_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `case_id` bigint(20) NOT NULL,
  `case_number` text,
  `Complaints` text,
  `History` text,
  `PastPersonalHistory` text,
  `ObstetricMenstruution` text,
  `ObstetricMarriedSice` text,
  `ObstetricCMP` text,
  `ObstetricEDD` text,
  `MensturationHistory` text,
  `menarch` text,
  `menarch_two` text,
  `ObstetricG` text,
  `ObstetricP` text,
  `ObstetricL` text,
  `ObstetricA` text,
  `ObstetricD` text,
  `ObstetricText` text,
  `presentPregnecyLMP` text,
  `presentPregnencyEDD` text,
  `presentPregnencyUSG` text,
  `presentPregnencyDate` text,
  `Education` text,
  `GenExamBuild` text,
  `GenExamHeight` text,
  `GenExamWeight` text,
  `GenExamPulse` text,
  `GenExamBP` text,
  `GenExamBP_lower` text,
  `GenExamRR` text,
  `GenExamPallor` text,
  `GenExamCyanosis` text,
  `GenExamIcterus` text,
  `GenExamEdema` text,
  `GenExamSkin` text,
  `SysExamCVS` text,
  `SysExamRS` text,
  `SysExamPA` text,
  `SysExamLocalExam` text,
  `ProvisionalDiagnosis` text,
  `InvestigationAdvice` text,
  `TreatmentAdvice` text,
  `Remark` text,
  `Text` text,
  `reportFilePath` text,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `BMI` text,
  `Temp` text,
  `AG` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patient_details`
--

LOCK TABLES `patient_details` WRITE;
/*!40000 ALTER TABLE `patient_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `patient_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patient_payments`
--

DROP TABLE IF EXISTS `patient_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `patient_payments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `registration_id` int(11) DEFAULT NULL,
  `receipt_number` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `advance_towards` varchar(255) DEFAULT NULL,
  `payment_mode` varchar(255) DEFAULT NULL,
  `advance_amount` varchar(255) DEFAULT NULL,
  `payment_id_number` varchar(255) DEFAULT NULL,
  `date_time` varchar(255) DEFAULT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '1',
  `is_deleted` enum('0','1') NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` varchar(255) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=83 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patient_payments`
--

LOCK TABLES `patient_payments` WRITE;
/*!40000 ALTER TABLE `patient_payments` DISABLE KEYS */;
INSERT INTO `patient_payments` VALUES (81,28,'0001','bill_payment',NULL,'58','5000','fhfnghg','2023-05-29 - 12:44 PM','1','0','2023-05-29 07:14:28',2,NULL,NULL),(82,28,'0002','bill_payment',NULL,'57','53030',NULL,'2023-05-29 - 12:47 PM','1','0','2023-05-29 07:17:30',2,NULL,NULL);
/*!40000 ALTER TABLE `patient_payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patient_prescription_lists`
--

DROP TABLE IF EXISTS `patient_prescription_lists`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `patient_prescription_lists` (
  `id` bigint(10) NOT NULL AUTO_INCREMENT,
  `case_number` text NOT NULL,
  `medicine_id` bigint(20) NOT NULL,
  `medicine_Quntity` text NOT NULL,
  `per_unit_cost` decimal(10,2) NOT NULL,
  `numberoftimes` text,
  `no_of_days` text,
  `strength` text,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `case_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patient_prescription_lists`
--

LOCK TABLES `patient_prescription_lists` WRITE;
/*!40000 ALTER TABLE `patient_prescription_lists` DISABLE KEYS */;
/*!40000 ALTER TABLE `patient_prescription_lists` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patients`
--

DROP TABLE IF EXISTS `patients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `patients` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `registration_date_time` varchar(255) DEFAULT NULL,
  `ipd_number` varchar(255) DEFAULT NULL,
  `uhid_number` varchar(255) DEFAULT NULL,
  `first_name` varchar(255) DEFAULT NULL,
  `middle_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `date_of_birth` varchar(255) DEFAULT NULL,
  `age` varchar(255) DEFAULT NULL,
  `gender` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `area` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `district` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `contact` varchar(255) DEFAULT NULL,
  `responsible_realtive_name` varchar(255) DEFAULT NULL,
  `responsible_realtive_relation` varchar(255) DEFAULT NULL,
  `relative_address` varchar(255) DEFAULT NULL,
  `relative_contact_number` varchar(255) DEFAULT NULL,
  `blood_group` varchar(255) DEFAULT NULL,
  `marital_status` varchar(255) DEFAULT NULL,
  `weight` varchar(255) DEFAULT NULL,
  `height` varchar(255) DEFAULT NULL,
  `admission_date_time` varchar(255) DEFAULT NULL,
  `consulting_doctor` varchar(255) DEFAULT NULL,
  `referring_doctor` varchar(255) DEFAULT NULL,
  `ward_type` varchar(255) DEFAULT NULL,
  `bed_number` varchar(255) DEFAULT NULL,
  `advance_amount` double(10,2) DEFAULT NULL,
  `payment_mode` varchar(255) DEFAULT NULL,
  `payment_id_number` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` varchar(255) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '1',
  `icu_out_date` varchar(255) DEFAULT NULL,
  `discharge_date_time` varchar(255) DEFAULT NULL,
  `provisional_diagnosis` varchar(255) DEFAULT NULL,
  `transfered` varchar(255) DEFAULT NULL,
  `transferred_date_time` varchar(255) DEFAULT NULL,
  `ipd_number_used` int(11) DEFAULT NULL,
  `uhid_number_used` varchar(255) DEFAULT NULL,
  `ipd_number_format` varchar(255) DEFAULT NULL,
  `ipd_number_prefix` varchar(255) DEFAULT NULL,
  `uhid_number_format` varchar(255) DEFAULT NULL,
  `uhid_number_prefix` varchar(255) DEFAULT NULL,
  `ipd_bill_number_format` varchar(255) DEFAULT NULL,
  `ipd_bill_prefix` varchar(255) DEFAULT NULL,
  `ipd_summary_bill_number_format` varchar(255) DEFAULT NULL,
  `ipd_bill_number_used` varchar(255) DEFAULT NULL,
  `ipd_summary_bill_number_used` varchar(255) DEFAULT NULL,
  `ipd_summary_bill_prefix` varchar(255) DEFAULT NULL,
  `estimated_bill_diagnosis` longtext,
  `ipd_bill_number` varchar(255) DEFAULT NULL,
  `ipd_summary_bill_number` varchar(255) DEFAULT NULL,
  `ipd_bill_date_time` varchar(255) DEFAULT NULL,
  `ipd_bill_summary_date_time` varchar(255) DEFAULT NULL,
  `adhar_card_number` varchar(255) DEFAULT NULL,
  `admission_type` varchar(255) DEFAULT NULL,
  `tpa_company` varchar(255) DEFAULT NULL,
  `insurance_company` varchar(255) DEFAULT NULL,
  `is_deleted` enum('0','1') NOT NULL DEFAULT '0',
  `registration_year` varchar(255) DEFAULT NULL,
  `uhid_suggested` varchar(255) DEFAULT NULL,
  `ipd_number_suggested` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patients`
--

LOCK TABLES `patients` WRITE;
/*!40000 ALTER TABLE `patients` DISABLE KEYS */;
INSERT INTO `patients` VALUES (28,'2023-05-24 - 09:24 PM','SH_/0001/2023','SH/2023/0003','Ganesh','M','Patil',NULL,'30','Male','45 sudama','vrindavan','Thane','Thane',NULL,'5468795486','Mahesh Patil','Father',NULL,'5481236548',NULL,NULL,NULL,NULL,'2023-05-24 - 21:28 PM','154',NULL,NULL,NULL,NULL,NULL,NULL,'2023-05-24 15:55:29',2,'2023-05-24 21:25:29',NULL,'1',NULL,NULL,NULL,NULL,NULL,1,'1','0001','SH/','0001','SH /',NULL,NULL,'0030',NULL,'30','SH/',NULL,NULL,'SH/0030',NULL,NULL,NULL,NULL,NULL,NULL,'0','2023','SH/2023/0003','SH_/0001/2023');
/*!40000 ALTER TABLE `patients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patients_discharge`
--

DROP TABLE IF EXISTS `patients_discharge`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `patients_discharge` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `registration_id` int(11) DEFAULT NULL,
  `discharge_summary_date_time` longtext,
  `discharge_date_time` varchar(255) DEFAULT NULL,
  `diagnosis` longtext,
  `history_clinical_findings` longtext,
  `on_examination` longtext,
  `operative_procedure` longtext,
  `investigation` longtext,
  `surgical_maternity_notes` longtext,
  `treatment_given` longtext,
  `treatment_advice` longtext,
  `treatment_on_discharge` longtext,
  `followup_1` varchar(255) DEFAULT NULL,
  `followup_2` varchar(255) DEFAULT NULL,
  `followup_3` varchar(255) DEFAULT NULL,
  `followup_4` varchar(255) DEFAULT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '1',
  `is_deleted` enum('0','1') NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` varchar(255) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patients_discharge`
--

LOCK TABLES `patients_discharge` WRITE;
/*!40000 ALTER TABLE `patients_discharge` DISABLE KEYS */;
INSERT INTO `patients_discharge` VALUES (20,28,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1','0','2023-05-29 07:16:43',NULL,NULL,NULL);
/*!40000 ALTER TABLE `patients_discharge` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patients_form_dropdowns`
--

DROP TABLE IF EXISTS `patients_form_dropdowns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `patients_form_dropdowns` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `formName` text,
  `fieldName` text,
  `ddText` text,
  `ddValue` text,
  `isdefault` bit(1) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patients_form_dropdowns`
--

LOCK TABLES `patients_form_dropdowns` WRITE;
/*!40000 ALTER TABLE `patients_form_dropdowns` DISABLE KEYS */;
/*!40000 ALTER TABLE `patients_form_dropdowns` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patients_history_sheet`
--

DROP TABLE IF EXISTS `patients_history_sheet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `patients_history_sheet` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `registration_id` varchar(255) NOT NULL,
  `field_name` varchar(255) DEFAULT NULL,
  `value_1` longtext,
  `value_2` longtext,
  `value_3` longtext,
  `value_4` longtext,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=67 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patients_history_sheet`
--

LOCK TABLES `patients_history_sheet` WRITE;
/*!40000 ALTER TABLE `patients_history_sheet` DISABLE KEYS */;
/*!40000 ALTER TABLE `patients_history_sheet` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patients_ipd_discharge`
--

DROP TABLE IF EXISTS `patients_ipd_discharge`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `patients_ipd_discharge` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `patient_id` bigint(20) DEFAULT NULL,
  `doctor_id` bigint(20) DEFAULT NULL,
  `doa` datetime DEFAULT NULL,
  `doatime` text,
  `dod` datetime DEFAULT NULL,
  `dodtime` text,
  `diagnosis` text,
  `clinical_notes` text,
  `investigation_findings` text,
  `treatment_given` text,
  `operative_notes` text,
  `treatment_advice` text,
  `next_visit` text,
  `status` text,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patients_ipd_discharge`
--

LOCK TABLES `patients_ipd_discharge` WRITE;
/*!40000 ALTER TABLE `patients_ipd_discharge` DISABLE KEYS */;
/*!40000 ALTER TABLE `patients_ipd_discharge` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patients_ipd_patient_bill`
--

DROP TABLE IF EXISTS `patients_ipd_patient_bill`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `patients_ipd_patient_bill` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `register_id` bigint(20) DEFAULT NULL,
  `tpa_company` text,
  `insurance_company` text,
  `bill_no` text,
  `bill_towards` text,
  `room_no` text,
  `ward` varchar(255) DEFAULT NULL,
  `bed` varchar(255) DEFAULT NULL,
  `advance_amount` text,
  `discount_amount` text,
  `bill_date` date DEFAULT NULL,
  `admit_date` datetime DEFAULT NULL,
  `discharge_date` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patients_ipd_patient_bill`
--

LOCK TABLES `patients_ipd_patient_bill` WRITE;
/*!40000 ALTER TABLE `patients_ipd_patient_bill` DISABLE KEYS */;
INSERT INTO `patients_ipd_patient_bill` VALUES (22,28,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'3000',NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `patients_ipd_patient_bill` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patients_ipd_patient_bill_items`
--

DROP TABLE IF EXISTS `patients_ipd_patient_bill_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `patients_ipd_patient_bill_items` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `bill_id` bigint(20) DEFAULT NULL,
  `particular` text,
  `day` text,
  `rate` text,
  `amount` text,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patients_ipd_patient_bill_items`
--

LOCK TABLES `patients_ipd_patient_bill_items` WRITE;
/*!40000 ALTER TABLE `patients_ipd_patient_bill_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `patients_ipd_patient_bill_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patients_ipd_patient_medicine`
--

DROP TABLE IF EXISTS `patients_ipd_patient_medicine`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `patients_ipd_patient_medicine` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `register_id` bigint(20) DEFAULT NULL,
  `medicine_id` bigint(20) DEFAULT NULL,
  `date_of_mgf` datetime DEFAULT NULL,
  `date_of_exp` datetime DEFAULT NULL,
  `batch_no` text,
  `price` text,
  `quantity` text,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patients_ipd_patient_medicine`
--

LOCK TABLES `patients_ipd_patient_medicine` WRITE;
/*!40000 ALTER TABLE `patients_ipd_patient_medicine` DISABLE KEYS */;
/*!40000 ALTER TABLE `patients_ipd_patient_medicine` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patients_ipd_patients_estimate_bills`
--

DROP TABLE IF EXISTS `patients_ipd_patients_estimate_bills`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `patients_ipd_patients_estimate_bills` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `registration_id` varchar(255) NOT NULL,
  `date_time` varchar(255) NOT NULL,
  `diagnosis` longtext NOT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '1',
  `is_deleted` enum('0','1') NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` varchar(255) NOT NULL,
  `updated_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patients_ipd_patients_estimate_bills`
--

LOCK TABLES `patients_ipd_patients_estimate_bills` WRITE;
/*!40000 ALTER TABLE `patients_ipd_patients_estimate_bills` DISABLE KEYS */;
/*!40000 ALTER TABLE `patients_ipd_patients_estimate_bills` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patients_ipd_prescription`
--

DROP TABLE IF EXISTS `patients_ipd_prescription`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `patients_ipd_prescription` (
  `id` bigint(20) NOT NULL,
  `register_id` text NOT NULL,
  `medicine_id` bigint(20) NOT NULL,
  `medicine_Quntity` text NOT NULL,
  `per_unit_cost` decimal(10,2) NOT NULL,
  `numberoftimes` text,
  `no_of_days` text,
  `strength` text,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patients_ipd_prescription`
--

LOCK TABLES `patients_ipd_prescription` WRITE;
/*!40000 ALTER TABLE `patients_ipd_prescription` DISABLE KEYS */;
/*!40000 ALTER TABLE `patients_ipd_prescription` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patients_ipd_treatment_daily_notes`
--

DROP TABLE IF EXISTS `patients_ipd_treatment_daily_notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `patients_ipd_treatment_daily_notes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ipd_patient_id` bigint(20) DEFAULT NULL,
  `time` text,
  `temp` text,
  `spo2` text,
  `bp` text,
  `rr` text,
  `fhs` text,
  `treatment` text,
  `morning` text,
  `evening` text,
  `night` text,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patients_ipd_treatment_daily_notes`
--

LOCK TABLES `patients_ipd_treatment_daily_notes` WRITE;
/*!40000 ALTER TABLE `patients_ipd_treatment_daily_notes` DISABLE KEYS */;
/*!40000 ALTER TABLE `patients_ipd_treatment_daily_notes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patients_medical_store`
--

DROP TABLE IF EXISTS `patients_medical_store`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `patients_medical_store` (
  `id` bigint(100) NOT NULL AUTO_INCREMENT,
  `medicine_name` varchar(5000) NOT NULL,
  `generic_name` text,
  `available_quantity` bigint(20) NOT NULL,
  `unit_price` decimal(10,2) NOT NULL,
  `balance_quantity` bigint(20) NOT NULL,
  `isactive` bit(1) NOT NULL,
  `created_dt` datetime NOT NULL,
  `updated_dt` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patients_medical_store`
--

LOCK TABLES `patients_medical_store` WRITE;
/*!40000 ALTER TABLE `patients_medical_store` DISABLE KEYS */;
/*!40000 ALTER TABLE `patients_medical_store` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patients_prescription_lists`
--

DROP TABLE IF EXISTS `patients_prescription_lists`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `patients_prescription_lists` (
  `id` bigint(10) NOT NULL AUTO_INCREMENT,
  `registration_id` varchar(255) DEFAULT NULL,
  `medicine_id` bigint(20) NOT NULL,
  `medicine_Quntity` text NOT NULL,
  `per_unit_cost` decimal(10,2) NOT NULL,
  `numberoftimes` text,
  `no_of_days` text,
  `strength` text,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `case_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patients_prescription_lists`
--

LOCK TABLES `patients_prescription_lists` WRITE;
/*!40000 ALTER TABLE `patients_prescription_lists` DISABLE KEYS */;
/*!40000 ALTER TABLE `patients_prescription_lists` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patients_prescription_templates`
--

DROP TABLE IF EXISTS `patients_prescription_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `patients_prescription_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent` int(11) DEFAULT '0',
  `template_name` varchar(255) DEFAULT NULL,
  `medicine_id` int(11) DEFAULT NULL,
  `medicine_Quntity` text,
  `numberoftimes` text,
  `no_of_days` text,
  `strength` varchar(255) DEFAULT NULL,
  `status` enum('0','1') DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patients_prescription_templates`
--

LOCK TABLES `patients_prescription_templates` WRITE;
/*!40000 ALTER TABLE `patients_prescription_templates` DISABLE KEYS */;
/*!40000 ALTER TABLE `patients_prescription_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patients_systemic_history`
--

DROP TABLE IF EXISTS `patients_systemic_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `patients_systemic_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `case_id` varchar(255) DEFAULT NULL,
  `value` text,
  `duration` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patients_systemic_history`
--

LOCK TABLES `patients_systemic_history` WRITE;
/*!40000 ALTER TABLE `patients_systemic_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `patients_systemic_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment_modes`
--

DROP TABLE IF EXISTS `payment_modes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payment_modes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `status` enum('0','1') DEFAULT '1',
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment_modes`
--

LOCK TABLES `payment_modes` WRITE;
/*!40000 ALTER TABLE `payment_modes` DISABLE KEYS */;
INSERT INTO `payment_modes` VALUES (1,'CASH','1',2,'2021-02-15 04:16:23','2021-02-15 08:44:23'),(2,'Phone Pe','1',2,'2021-02-15 08:47:10','2021-02-15 08:47:10'),(3,'UPI','1',2,'2021-02-15 08:47:18','2021-02-15 08:47:18'),(5,'Cheque','1',2,'2021-04-05 15:56:58','2021-04-05 15:56:58'),(6,'Card','1',2,'2021-04-05 15:57:10','2021-04-05 15:57:10'),(7,'Google Pay','1',2,'2021-04-05 15:58:16','2021-04-05 15:58:16');
/*!40000 ALTER TABLE `payment_modes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `paymentfor`
--

DROP TABLE IF EXISTS `paymentfor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `paymentfor` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `dentist_bill_id` bigint(20) NOT NULL,
  `case_id` bigint(20) NOT NULL,
  `treatmentDone` text NOT NULL,
  `date` text NOT NULL,
  `amountPaid` text NOT NULL,
  `payment_mode` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `paymentfor`
--

LOCK TABLES `paymentfor` WRITE;
/*!40000 ALTER TABLE `paymentfor` DISABLE KEYS */;
/*!40000 ALTER TABLE `paymentfor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prescription_data`
--

DROP TABLE IF EXISTS `prescription_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `prescription_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `prescription_id` int(11) DEFAULT NULL,
  `case_id` varchar(255) DEFAULT NULL,
  `frequency` varchar(255) DEFAULT NULL,
  `date_from` varchar(255) DEFAULT NULL,
  `date_to` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=80 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prescription_data`
--

LOCK TABLES `prescription_data` WRITE;
/*!40000 ALTER TABLE `prescription_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `prescription_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prescription_lists`
--

DROP TABLE IF EXISTS `prescription_lists`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `prescription_lists` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `case_number` text NOT NULL,
  `medicine_id` bigint(20) NOT NULL,
  `generic_medicine_id` int(11) DEFAULT NULL,
  `medicine_Quntity` text NOT NULL,
  `per_unit_cost` decimal(10,2) NOT NULL,
  `numberoftimes` text,
  `no_of_days` text,
  `strength` text,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `case_id` bigint(20) NOT NULL,
  `from_date` date DEFAULT NULL,
  `to_date` date DEFAULT NULL,
  `medicine_timing` text,
  `notes` longtext,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=200 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prescription_lists`
--

LOCK TABLES `prescription_lists` WRITE;
/*!40000 ALTER TABLE `prescription_lists` DISABLE KEYS */;
/*!40000 ALTER TABLE `prescription_lists` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prescription_notes`
--

DROP TABLE IF EXISTS `prescription_notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `prescription_notes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `prescription_type` varchar(255) DEFAULT NULL,
  `case_id` varchar(255) DEFAULT NULL,
  `notes` longtext,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prescription_notes`
--

LOCK TABLES `prescription_notes` WRITE;
/*!40000 ALTER TABLE `prescription_notes` DISABLE KEYS */;
INSERT INTO `prescription_notes` VALUES (8,'ent','140','gfhgfgfhgfgh iyuihyiu yuih uioi oiio uioio oi uio\r\n kjhkh khk hkh\r\n jijkl jnkljkljl');
/*!40000 ALTER TABLE `prescription_notes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prescription_templates`
--

DROP TABLE IF EXISTS `prescription_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `prescription_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent` int(11) DEFAULT '0',
  `template_name` varchar(255) DEFAULT NULL,
  `medicine_id` int(11) DEFAULT NULL,
  `generic_medicine_id` int(11) DEFAULT NULL,
  `medicine_timing` text,
  `frequency` text,
  `duration` varchar(255) DEFAULT NULL,
  `status` enum('0','1') DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prescription_templates`
--

LOCK TABLES `prescription_templates` WRITE;
/*!40000 ALTER TABLE `prescription_templates` DISABLE KEYS */;
/*!40000 ALTER TABLE `prescription_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `print_page_settings`
--

DROP TABLE IF EXISTS `print_page_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `print_page_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `form_type` varchar(255) DEFAULT NULL,
  `value` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=213 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `print_page_settings`
--

LOCK TABLES `print_page_settings` WRITE;
/*!40000 ALTER TABLE `print_page_settings` DISABLE KEYS */;
INSERT INTO `print_page_settings` VALUES (67,'eyeform','birthHistory'),(79,'eyeform','retinoscopy_refraction_page'),(129,'eyeform','lens_thickness'),(132,'eyeform','iol_cilinder'),(133,'eyeform','EOM'),(134,'eyeform','OCT'),(181,'eyeform','pastTreatmentHistory'),(193,'eyeform','familyHistory'),(194,'eyeform','nvn_od'),(205,'eyeform','CNS'),(207,'eyeform','refraction1'),(210,'eyeform','pastHistory'),(211,'eyeform','patients_systemic_history'),(212,'eyeform','ChiefComplaint');
/*!40000 ALTER TABLE `print_page_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `procedure_template`
--

DROP TABLE IF EXISTS `procedure_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `procedure_template` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `template_type` varchar(255) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `procedure_template`
--

LOCK TABLES `procedure_template` WRITE;
/*!40000 ALTER TABLE `procedure_template` DISABLE KEYS */;
/*!40000 ALTER TABLE `procedure_template` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `procedure_template_data`
--

DROP TABLE IF EXISTS `procedure_template_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `procedure_template_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `template_id` varchar(255) DEFAULT NULL,
  `key_text` varchar(255) DEFAULT NULL,
  `od` varchar(255) DEFAULT NULL,
  `os` varchar(255) DEFAULT NULL,
  `duration_od` varchar(255) DEFAULT NULL,
  `duration_os` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `procedure_template_data`
--

LOCK TABLES `procedure_template_data` WRITE;
/*!40000 ALTER TABLE `procedure_template_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `procedure_template_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `procedures`
--

DROP TABLE IF EXISTS `procedures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `procedures` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `procedures`
--

LOCK TABLES `procedures` WRITE;
/*!40000 ALTER TABLE `procedures` DISABLE KEYS */;
/*!40000 ALTER TABLE `procedures` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `psychiatrist_case_form_family_history`
--

DROP TABLE IF EXISTS `psychiatrist_case_form_family_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `psychiatrist_case_form_family_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `relation` varchar(255) DEFAULT NULL,
  `name` text,
  `doctor` text,
  `psychiatrist_form_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `psychiatrist_case_form_family_history`
--

LOCK TABLES `psychiatrist_case_form_family_history` WRITE;
/*!40000 ALTER TABLE `psychiatrist_case_form_family_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `psychiatrist_case_form_family_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `psychiatrist_case_form_files`
--

DROP TABLE IF EXISTS `psychiatrist_case_form_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `psychiatrist_case_form_files` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `psychiatrist_form_id` int(11) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `file` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `psychiatrist_case_form_files`
--

LOCK TABLES `psychiatrist_case_form_files` WRITE;
/*!40000 ALTER TABLE `psychiatrist_case_form_files` DISABLE KEYS */;
/*!40000 ALTER TABLE `psychiatrist_case_form_files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `psychiatrist_case_paper`
--

DROP TABLE IF EXISTS `psychiatrist_case_paper`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `psychiatrist_case_paper` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `case_id` varchar(255) DEFAULT NULL,
  `patient_registration` varchar(255) DEFAULT NULL,
  `patient_registration_date` varchar(255) DEFAULT NULL,
  `first_name` varchar(255) DEFAULT NULL,
  `middle_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `patient_age` varchar(255) DEFAULT NULL,
  `patient_gender` varchar(255) DEFAULT NULL,
  `patient_address_1` text,
  `patient_address_2` text,
  `patient_address_3` text,
  `patient_education` varchar(255) DEFAULT NULL,
  `patient_occupation` varchar(255) DEFAULT NULL,
  `patient_contact_number` varchar(255) DEFAULT NULL,
  `patient_marital_status` varchar(255) DEFAULT NULL,
  `relative_first_name` varchar(255) DEFAULT NULL,
  `relative_middle_name` varchar(255) DEFAULT NULL,
  `relative_last_name` varchar(255) DEFAULT NULL,
  `question_1` text,
  `question_2` text,
  `question_1_duration` varchar(255) DEFAULT NULL,
  `question_2_duration` varchar(255) DEFAULT NULL,
  `question_3` text,
  `question_4` text,
  `question_5` text,
  `question_6` text,
  `question_7` text,
  `question_8` text,
  `question_9` text,
  `undersigned_first_name` varchar(255) DEFAULT NULL,
  `undersigned_middle_name` varchar(255) DEFAULT NULL,
  `undersigned_last_name` varchar(255) DEFAULT NULL,
  `about_person` varchar(255) DEFAULT NULL,
  `about_person_first_name` varchar(255) DEFAULT NULL,
  `about_person_middle_name` varchar(255) DEFAULT NULL,
  `about_person_last_name` varchar(255) DEFAULT NULL,
  `status` enum('0','1') DEFAULT '1',
  `is_deleted` enum('0','1') DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `psychiatrist_case_paper`
--

LOCK TABLES `psychiatrist_case_paper` WRITE;
/*!40000 ALTER TABLE `psychiatrist_case_paper` DISABLE KEYS */;
/*!40000 ALTER TABLE `psychiatrist_case_paper` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `psychiatrist_notes`
--

DROP TABLE IF EXISTS `psychiatrist_notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `psychiatrist_notes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `case_id` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `notes` longtext,
  `is_deleted` enum('0','1') DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `psychiatrist_notes`
--

LOCK TABLES `psychiatrist_notes` WRITE;
/*!40000 ALTER TABLE `psychiatrist_notes` DISABLE KEYS */;
INSERT INTO `psychiatrist_notes` VALUES (1,'30','treatment_notes','Treatment Note 1','0'),(2,'30','treatment_notes','Treatment Note 2','0'),(3,'30','treatment_notes','Treatment Note 3','0'),(4,'30','doctor_notes','These\r\nare\r\ndoctor\r\nnotes','0'),(5,'31','treatment_notes','Treatment Note 1','0'),(6,'31','doctor_notes','kjhkhgkghkghk gfhfghfgh','0'),(7,'31','prescription_notes','mbmbvmnvbnvb','0');
/*!40000 ALTER TABLE `psychiatrist_notes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quantity_dropdown`
--

DROP TABLE IF EXISTS `quantity_dropdown`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quantity_dropdown` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text,
  `is_active` bit(1) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quantity_dropdown`
--

LOCK TABLES `quantity_dropdown` WRITE;
/*!40000 ALTER TABLE `quantity_dropdown` DISABLE KEYS */;
/*!40000 ALTER TABLE `quantity_dropdown` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rating`
--

DROP TABLE IF EXISTS `rating`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rating` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `mobileno` varchar(200) NOT NULL,
  `userimage` varchar(200) NOT NULL,
  `feedback` text,
  `ratingscore` text,
  `isActive` bit(1) DEFAULT b'0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=23 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rating`
--

LOCK TABLES `rating` WRITE;
/*!40000 ALTER TABLE `rating` DISABLE KEYS */;
INSERT INTO `rating` VALUES (22,'ghsfhgfhg','4564567896','1685192354.jpeg','iudgfj uiy uiy uiyug ouiog ioeogiog o','5','','2023-05-27 12:59:14','2023-05-27 12:59:38');
/*!40000 ALTER TABLE `rating` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rbs_insulin_chart`
--

DROP TABLE IF EXISTS `rbs_insulin_chart`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rbs_insulin_chart` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `registration_id` varchar(255) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` enum('0','1') NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rbs_insulin_chart`
--

LOCK TABLES `rbs_insulin_chart` WRITE;
/*!40000 ALTER TABLE `rbs_insulin_chart` DISABLE KEYS */;
/*!40000 ALTER TABLE `rbs_insulin_chart` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rbs_insulin_chart_data`
--

DROP TABLE IF EXISTS `rbs_insulin_chart_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rbs_insulin_chart_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rbs_insulin_chart_id` int(11) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `time` varchar(255) DEFAULT NULL,
  `hgt` text,
  `u_sugar` text,
  `u_acetone` text,
  `insuline_given` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rbs_insulin_chart_data`
--

LOCK TABLES `rbs_insulin_chart_data` WRITE;
/*!40000 ALTER TABLE `rbs_insulin_chart_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `rbs_insulin_chart_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `refraction_dropdown`
--

DROP TABLE IF EXISTS `refraction_dropdown`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `refraction_dropdown` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key_value` varchar(255) DEFAULT NULL,
  `os` varchar(255) DEFAULT NULL,
  `od` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=240 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `refraction_dropdown`
--

LOCK TABLES `refraction_dropdown` WRITE;
/*!40000 ALTER TABLE `refraction_dropdown` DISABLE KEYS */;
/*!40000 ALTER TABLE `refraction_dropdown` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `report_file`
--

DROP TABLE IF EXISTS `report_file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `report_file` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `case_number` text NOT NULL,
  `report_description` text,
  `report_title` text,
  `file_path` text,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `case_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `report_file`
--

LOCK TABLES `report_file` WRITE;
/*!40000 ALTER TABLE `report_file` DISABLE KEYS */;
/*!40000 ALTER TABLE `report_file` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `report_images`
--

DROP TABLE IF EXISTS `report_images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `report_images` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reportFileName` varchar(500) DEFAULT NULL,
  `case_id` text NOT NULL,
  `filePath` text NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=106 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `report_images`
--

LOCK TABLES `report_images` WRITE;
/*!40000 ALTER TABLE `report_images` DISABLE KEYS */;
/*!40000 ALTER TABLE `report_images` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role` varchar(255) DEFAULT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'Admin','0'),(2,'Doctor','1'),(3,'Receptionist','1'),(4,'IPD','1'),(5,'Counselor','1');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `section`
--

DROP TABLE IF EXISTS `section`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `section` (
  `sectionid` int(100) NOT NULL AUTO_INCREMENT,
  `sectionname` varchar(200) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`sectionid`)
) ENGINE=InnoDB AUTO_INCREMENT=103 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `section`
--

LOCK TABLES `section` WRITE;
/*!40000 ALTER TABLE `section` DISABLE KEYS */;
INSERT INTO `section` VALUES (1,'doctor','2020-02-08 06:40:17','2020-02-08 06:40:17'),(2,'aptpatientDetails1','2020-02-08 06:40:17','2020-02-08 06:40:17'),(3,'appointmentlist','2020-02-08 06:41:12','2020-02-08 06:41:12'),(4,'followupappoinment','2020-02-08 06:41:26','2020-02-08 06:41:26'),(5,'appointment','2020-02-08 06:41:36','2020-02-08 06:41:36'),(6,'stop_appointments','2020-02-08 06:41:55','2020-02-08 06:41:55'),(7,'appointmentslot','2020-02-08 06:42:10','2020-02-08 06:42:10'),(8,'case_masters','2020-02-08 06:42:36','2020-02-08 06:42:36'),(9,'patient/report','2020-02-08 06:43:09','2020-02-08 06:43:09'),(10,'case_masters/prescriptionlst','2020-02-08 06:55:43','2020-02-08 06:55:43'),(11,'report_files','2020-02-08 06:55:43','2020-02-08 06:55:43'),(12,'formDropDown','2020-02-11 07:31:00','2020-02-11 07:31:00'),(13,'bill_details','2020-02-11 07:31:00','2020-02-11 07:31:00'),(14,'doctorbill','2020-02-11 07:32:54','2020-02-11 07:32:54'),(15,'insuranceBill','2020-02-11 07:32:54','2020-02-11 07:32:54'),(16,'glassPrescription','2020-02-11 07:34:53','2020-02-11 07:34:53'),(17,'Medicine','2020-02-11 07:34:53','2020-02-11 07:34:53'),(18,'rating/list','2020-02-11 07:36:39','2020-02-11 07:36:39'),(19,'oldregister','2020-02-11 07:36:39','2020-02-11 07:36:39'),(20,'seo/add','2020-02-12 11:58:40','2020-02-12 11:58:40'),(21,'menu_lists','2020-02-12 11:59:46','2020-02-12 11:59:46'),(22,'bulk_sms','2020-02-12 11:59:46','2020-02-12 11:59:46'),(23,'member_sms','2020-02-12 12:00:16','2020-02-12 12:00:16'),(24,'staff_users','2020-02-12 12:00:16','2020-02-12 12:00:16'),(25,'downloaddatabase','2020-02-12 12:00:34','2020-02-12 12:00:34'),(26,'EyeDetails_Complaint','2020-02-13 11:16:03','2020-02-13 11:16:03'),(27,'EyeDetails_Vision','2020-02-13 11:16:03','2020-02-13 11:16:03'),(28,'EyeDetails_Refraction','2020-02-13 11:16:32','2020-02-13 11:16:32'),(29,'EyeDetails_Findings','2020-02-13 11:16:32','2020-02-13 11:16:32'),(30,'EyeDetails_Glaucoma','2020-02-13 11:17:00','2020-02-13 11:17:00'),(31,'EyeDetails_AScan','2020-02-13 11:17:00','2020-02-13 11:17:00'),(32,'EyeDetails_SPTests','2020-02-13 11:17:20','2020-02-13 11:17:20'),(33,'doctor/edit','2020-02-13 12:22:36','2020-02-13 12:22:36'),(34,'doctor/create','2020-02-13 12:27:24','2020-02-13 12:27:24'),(35,'useraccess','2020-02-13 12:33:37','2020-02-13 12:33:37'),(36,'appointment/acceptdeny','2020-02-13 12:48:43','2020-02-13 12:48:43'),(37,'aptpatientDetails','2020-02-13 13:22:12','2020-02-13 13:22:12'),(38,'stop_appointments/create','2020-02-13 13:58:49','2020-02-13 13:58:49'),(39,'stop_appointments/edit','2020-02-13 13:58:49','2020-02-13 13:58:49'),(40,'patient/report','2020-02-13 13:59:51','2020-02-13 13:59:51'),(41,'case_masters/edit','2020-02-13 14:00:35','2020-02-13 14:00:35'),(42,'patientreport/AddEditEyeDetails','2020-02-13 14:01:28','2020-02-13 14:01:28'),(43,'AddEdit/prescription','2020-02-13 14:01:54','2020-02-13 14:01:54'),(44,'print/prescription','2020-02-13 14:02:08','2020-02-13 14:02:08'),(45,'report_files/edit','2020-02-13 14:02:31','2020-02-13 14:02:31'),(46,'bill_details/edit','2020-02-13 14:02:40','2020-02-13 14:02:40'),(47,'bill_details/print','2020-02-13 14:02:49','2020-02-13 14:02:49'),(48,'opdpatientbill/report','2020-02-13 14:02:58','2020-02-13 14:02:58'),(49,'doctordetail/doctorbill/report/BillReport','2020-02-13 14:03:10','2020-02-13 14:03:10'),(50,'doctordetail/doctorbill/report/SurgeryReport','2020-02-13 14:03:19','2020-02-13 14:03:19'),(51,'doctordetail/doctorbill/AddBill','2020-02-13 14:03:33','2020-02-13 14:03:33'),(52,'Eyeipdbill/insuranceBill/edit','2020-02-13 14:03:41','2020-02-13 14:03:41'),(53,'Eyeipdbill/insuranceBill/print','2020-02-13 14:03:50','2020-02-13 14:03:50'),(54,'Eyeglass/glassPrescription/edit','2020-02-13 14:03:57','2020-02-13 14:03:57'),(55,'Eyeglass/glassPrescription/print','2020-02-13 14:04:12','2020-02-13 14:04:12'),(56,'Medicine/create','2020-02-13 14:04:21','2020-02-13 14:04:21'),(57,'Medicine/edit','2020-02-13 14:04:30','2020-02-13 14:04:30'),(58,'rating/list/ApproveRejectRating','2020-02-13 14:05:01','2020-02-13 14:05:01'),(59,'oldregister/edit','2020-02-13 14:05:13','2020-02-13 14:05:13'),(60,'oldregister/create','2020-02-13 14:05:57','2020-02-13 14:05:57'),(61,'menu_lists/create','2020-02-13 14:06:10','2020-02-13 14:06:10'),(62,'menu_lists/edit','2020-02-13 14:06:27','2020-02-13 14:06:27'),(63,'menu_lists/dynamic_text','2020-02-13 14:06:37','2020-02-13 14:06:37'),(64,'bulk_sms/create','2020-02-13 14:06:48','2020-02-13 14:06:48'),(65,'membercontact/staff_users/create','2020-02-13 14:06:57','2020-02-13 14:06:57'),(66,'membercontact/staff_users/edit','2020-02-13 14:07:10','2020-02-13 14:07:10'),(67,'followupacceptdenyappointment','2020-02-14 06:12:13','2020-02-14 06:12:13'),(68,'followuppatientDetails','2020-02-14 06:12:13','2020-02-14 06:12:13'),(69,'case_master/AddPatient_Details','2020-02-14 07:16:35','2020-02-14 07:16:35'),(70,'patientDetails/patient/report','2020-02-14 07:38:24','2020-02-14 07:38:24'),(71,'case_master/patientno_info','2020-02-14 08:05:08','2020-02-14 08:05:08'),(73,'menu_lists/number','2020-02-15 10:12:46','2020-02-15 10:12:46'),(74,'homepage/image_galleries','2020-02-15 12:00:37','2020-02-15 12:00:37'),(75,'homepage/LogoAddEdit','2020-02-15 12:01:08','2020-02-15 12:01:08'),(76,'homepage/editletterhead','2020-02-15 12:02:02','2020-02-15 12:02:02'),(77,'homepage/editletterfooter','2020-02-15 12:02:27','2020-02-15 12:02:27'),(78,'homepage/body_editor','2020-02-15 12:03:08','2020-02-15 12:03:08'),(79,'homepage/body_layer2editor','2020-02-15 12:05:30','2020-02-15 12:05:30'),(80,'homepage/body_layer3editor\r\n','2020-02-15 12:05:51','2020-02-15 12:05:51'),(81,'homepage/body_layer4editor','2020-02-15 12:06:12','2020-02-15 12:06:12'),(82,'homepage/body_layer5editor','2020-02-15 12:06:22','2020-02-15 12:06:22'),(83,'homepage/body_layer6editor','2020-02-15 12:06:31','2020-02-15 12:06:31'),(84,'homepage/body_layer7editor','2020-02-15 12:06:40','2020-02-15 12:06:40'),(85,'homepage/body_layer8editor','2020-02-15 12:06:48','2020-02-15 12:06:48'),(86,'homepage/footer_editor','2020-02-15 12:06:56','2020-02-15 12:06:56'),(87,'bulk_sms/send_sms','2020-02-19 08:29:16','2020-02-19 08:29:16'),(88,'bulk_sms/edit','2020-02-19 08:29:16','2020-02-19 08:29:16'),(89,'patientdetails/casemaster/editPatientDetials','2020-02-19 10:46:59','2020-02-19 10:46:59'),(93,'writingCasePaper','2020-02-22 10:43:26','2020-02-22 10:43:26'),(94,'writingCasePaper/edit','2020-02-22 10:43:26','2020-02-22 10:43:26'),(95,'writingCasePaper/print','2020-02-22 10:43:45','2020-02-22 10:43:45'),(96,'writingCasePaper/view','2020-02-22 10:43:45','2020-02-22 10:43:45'),(99,'staff_member','2020-02-25 05:36:03','2020-02-25 05:36:03'),(100,'staff_member/create','2020-02-25 05:38:15','2020-02-25 05:38:15'),(101,'staff_member/edit','2020-02-25 05:38:15','2020-02-25 05:38:15'),(102,'imagegallary','2020-03-04 11:40:47','2020-03-04 11:40:47');
/*!40000 ALTER TABLE `section` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `seo_masters`
--

DROP TABLE IF EXISTS `seo_masters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `seo_masters` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `url` text CHARACTER SET utf8 NOT NULL,
  `meta_title` text CHARACTER SET utf8 NOT NULL,
  `meta_desc` text CHARACTER SET utf8 NOT NULL,
  `meta_key` text CHARACTER SET utf8 NOT NULL,
  `status` enum('1','0') CHARACTER SET utf8 NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by` int(10) NOT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `modification_by` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `seo_masters`
--

LOCK TABLES `seo_masters` WRITE;
/*!40000 ALTER TABLE `seo_masters` DISABLE KEYS */;
/*!40000 ALTER TABLE `seo_masters` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `value` varchar(255) NOT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` VALUES (1,'hospital_name','SUSHRUT HOSPITAL',NULL,NULL,'2023-03-28 13:55:47'),(2,'hospital_logo','logo.jpg',NULL,NULL,'2023-05-12 05:49:54'),(3,'doctor_name','Dr. Jitendra Chandurkar',NULL,NULL,'2023-03-28 13:58:10'),(4,'uhid_prefix','SH/',NULL,NULL,'2023-03-28 13:58:34'),(5,'bill_number','00001',NULL,NULL,'2021-03-20 05:27:20'),(6,'bill_pointer','00719',NULL,NULL,'2023-05-10 00:33:29'),(7,'webcam','0',NULL,NULL,'2023-03-28 13:59:09'),(8,'ipd_prefix','SH_',NULL,NULL,'2023-03-28 13:58:51'),(9,'ipd_bill_prefix','001',NULL,NULL,'2023-03-28 13:59:05'),(10,'twitter_link','twitter.com',NULL,'2021-11-13 08:41:38','2021-11-13 08:41:38'),(11,'appointment_number','98812 04068 / 0251-2690382',NULL,'2021-11-13 08:41:49','2023-03-28 13:59:33'),(12,'openeing_hours','24 Hours',NULL,'2021-11-13 08:42:14','2023-03-28 13:59:39'),(13,'openeing_hours_text','We are Open',NULL,'2021-11-13 08:42:18','2021-11-13 08:42:18'),(14,'insta_link','instagram.com',NULL,'2021-11-13 08:42:30','2021-11-13 08:42:30'),(15,'linkedin_link','linkedin.com',NULL,'2021-11-13 08:42:39','2021-11-13 08:42:39'),(16,'fb_link','https://www.facebook.com/',NULL,'2021-11-13 08:42:46','2021-11-13 08:46:37'),(17,'top_bar','1',NULL,'2021-11-13 08:42:53','2021-11-13 08:42:53'),(18,'ipd_hospital_name','SUSHRUT HOSPITAL',NULL,'2022-03-06 20:33:55','2023-03-28 14:00:12'),(19,'ipd_advance_receipt_number','001',NULL,'2022-03-06 20:34:00','2022-03-06 20:34:00'),(20,'ipd_payment_receipt_number','0001',NULL,'2022-03-06 20:34:03','2022-03-06 20:34:03'),(21,'ipd_ipd_bill_prefix','SH/',NULL,'2022-03-06 20:34:08','2023-03-28 14:00:22'),(22,'ipd_uhid_prefix','SH /',NULL,'2022-03-06 20:34:12','2023-03-28 14:00:44'),(23,'ipd_uhid_number','0001',NULL,'2022-03-06 20:34:16','2022-03-06 20:34:16'),(24,'ipd_ipd_prefix','SH/',NULL,'2022-03-06 20:34:20','2023-03-28 14:00:54'),(25,'ipd_ipd_number','0001',NULL,'2022-03-06 20:34:24','2022-03-06 20:34:24'),(26,'ipd_ipd_bill_number','0001',NULL,'2022-03-11 06:15:05','2022-03-11 06:15:05'),(27,'ipd_summary_bill_prefix','SH/',NULL,'2022-03-11 06:15:11','2023-03-28 14:00:34'),(28,'ipd_summary_bill_number','0030',NULL,'2022-03-11 06:15:15','2023-03-23 06:07:00');
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `skin`
--

DROP TABLE IF EXISTS `skin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `skin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `case_id` bigint(20) DEFAULT NULL,
  `odp` text,
  `PalmSole` text,
  `GenitalArea` text,
  `OralMucosa` text,
  `Nails` text,
  `SpecialComment` text,
  `FollowUpDoctor_id` int(11) NOT NULL,
  `FollowUpDate` text,
  `FollowUpTime` text,
  `BeforeImagePath` text,
  `AfterImagePath` text,
  `casePaperImage` text,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `skin`
--

LOCK TABLES `skin` WRITE;
/*!40000 ALTER TABLE `skin` DISABLE KEYS */;
/*!40000 ALTER TABLE `skin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `skinmultiple`
--

DROP TABLE IF EXISTS `skinmultiple`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `skinmultiple` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `case_id` bigint(20) DEFAULT NULL,
  `formFieldName` text,
  `formfieldCode` text,
  `valueData` text,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=365 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `skinmultiple`
--

LOCK TABLES `skinmultiple` WRITE;
/*!40000 ALTER TABLE `skinmultiple` DISABLE KEYS */;
/*!40000 ALTER TABLE `skinmultiple` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staff_type`
--

DROP TABLE IF EXISTS `staff_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `staff_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type_name` text,
  `type_description` text,
  `is_active` bit(1) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staff_type`
--

LOCK TABLES `staff_type` WRITE;
/*!40000 ALTER TABLE `staff_type` DISABLE KEYS */;
INSERT INTO `staff_type` VALUES (1,'nurse','nurse','','2017-06-26 00:00:00','2017-06-26 00:00:00'),(2,'Hospital boy','Hospital boy','','2017-06-26 00:00:00','2017-06-26 00:00:00'),(3,'Ref. Doctor','Ref. Doctor','','2017-06-26 00:00:00','2017-06-26 00:00:00'),(4,'Medical Store','Medical Store','','2017-06-26 00:00:00','2017-06-26 00:00:00');
/*!40000 ALTER TABLE `staff_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staff_users`
--

DROP TABLE IF EXISTS `staff_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `staff_users` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `staff_type_id` int(11) NOT NULL,
  `name` text,
  `description` text,
  `ed_degree` text,
  `mobile_no` text,
  `email_id` text,
  `address` text,
  `is_active` bit(1) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staff_users`
--

LOCK TABLES `staff_users` WRITE;
/*!40000 ALTER TABLE `staff_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `staff_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `strength_dropdown`
--

DROP TABLE IF EXISTS `strength_dropdown`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `strength_dropdown` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text,
  `is_active` bit(1) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `update_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `strength_dropdown`
--

LOCK TABLES `strength_dropdown` WRITE;
/*!40000 ALTER TABLE `strength_dropdown` DISABLE KEYS */;
/*!40000 ALTER TABLE `strength_dropdown` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_appoinment_slot`
--

DROP TABLE IF EXISTS `tbl_appoinment_slot`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_appoinment_slot` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `doctor_id` text NOT NULL,
  `day` text NOT NULL,
  `starttime` text NOT NULL,
  `endtime` text NOT NULL,
  `time_diff_minute` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  `slotime` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=280 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_appoinment_slot`
--

LOCK TABLES `tbl_appoinment_slot` WRITE;
/*!40000 ALTER TABLE `tbl_appoinment_slot` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_appoinment_slot` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_certificate_main`
--

DROP TABLE IF EXISTS `tbl_certificate_main`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_certificate_main` (
  `main_id` int(11) NOT NULL,
  `filenames1` text NOT NULL,
  `gallery_name` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_certificate_main`
--

LOCK TABLES `tbl_certificate_main` WRITE;
/*!40000 ALTER TABLE `tbl_certificate_main` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_certificate_main` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_consultant_main`
--

DROP TABLE IF EXISTS `tbl_consultant_main`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_consultant_main` (
  `main_id` int(11) NOT NULL,
  `filenames1` text NOT NULL,
  `gallery_name` text NOT NULL,
  `degree` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_consultant_main`
--

LOCK TABLES `tbl_consultant_main` WRITE;
/*!40000 ALTER TABLE `tbl_consultant_main` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_consultant_main` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_customer`
--

DROP TABLE IF EXISTS `tbl_customer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_customer` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `CustomerName` varchar(200) NOT NULL,
  `Address` varchar(200) NOT NULL,
  `City` text NOT NULL,
  `PostalCode` text NOT NULL,
  `Country` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_customer`
--

LOCK TABLES `tbl_customer` WRITE;
/*!40000 ALTER TABLE `tbl_customer` DISABLE KEYS */;
INSERT INTO `tbl_customer` VALUES (1,'Seema','Thane','Thane','400604','India');
/*!40000 ALTER TABLE `tbl_customer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_events1`
--

DROP TABLE IF EXISTS `tbl_events1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_events1` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` text NOT NULL,
  `start_date` text NOT NULL,
  `end_date` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_events1`
--

LOCK TABLES `tbl_events1` WRITE;
/*!40000 ALTER TABLE `tbl_events1` DISABLE KEYS */;
INSERT INTO `tbl_events1` VALUES (1,'Demo Event-1','2019-01-25','2019-01-6','2020-01-18 11:08:30','2020-01-18 16:38:30');
/*!40000 ALTER TABLE `tbl_events1` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_feedback_main`
--

DROP TABLE IF EXISTS `tbl_feedback_main`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_feedback_main` (
  `main_id` int(11) NOT NULL,
  `filenames1` text NOT NULL,
  `name` text NOT NULL,
  `message` longtext
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_feedback_main`
--

LOCK TABLES `tbl_feedback_main` WRITE;
/*!40000 ALTER TABLE `tbl_feedback_main` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_feedback_main` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_gallery`
--

DROP TABLE IF EXISTS `tbl_gallery`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_gallery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `gallery_name` text NOT NULL,
  `filenames` text NOT NULL,
  `main_id` text NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_gallery`
--

LOCK TABLES `tbl_gallery` WRITE;
/*!40000 ALTER TABLE `tbl_gallery` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_gallery` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_gallery_main`
--

DROP TABLE IF EXISTS `tbl_gallery_main`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_gallery_main` (
  `main_id` int(11) NOT NULL AUTO_INCREMENT,
  `filenames1` text NOT NULL,
  `gallery_name` text NOT NULL,
  PRIMARY KEY (`main_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_gallery_main`
--

LOCK TABLES `tbl_gallery_main` WRITE;
/*!40000 ALTER TABLE `tbl_gallery_main` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_gallery_main` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_service_main`
--

DROP TABLE IF EXISTS `tbl_service_main`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_service_main` (
  `main_id` int(11) NOT NULL AUTO_INCREMENT,
  `filenames1` text NOT NULL,
  `gallery_name` text NOT NULL,
  `link` text,
  PRIMARY KEY (`main_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_service_main`
--

LOCK TABLES `tbl_service_main` WRITE;
/*!40000 ALTER TABLE `tbl_service_main` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_service_main` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `timeslots`
--

DROP TABLE IF EXISTS `timeslots`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `timeslots` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(500) NOT NULL,
  `isActive` tinyint(1) NOT NULL DEFAULT '1',
  `created_dt` datetime DEFAULT NULL,
  `update_dt` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `timeslots`
--

LOCK TABLES `timeslots` WRITE;
/*!40000 ALTER TABLE `timeslots` DISABLE KEYS */;
/*!40000 ALTER TABLE `timeslots` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tpr_monitoring_chart`
--

DROP TABLE IF EXISTS `tpr_monitoring_chart`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tpr_monitoring_chart` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `registration_id` int(11) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `timing` varchar(255) DEFAULT NULL,
  `temp` varchar(255) DEFAULT NULL,
  `pulse` varchar(255) DEFAULT NULL,
  `resp` varchar(255) DEFAULT NULL,
  `bp` varchar(255) DEFAULT NULL,
  `spo2` varchar(255) DEFAULT NULL,
  `iv` varchar(255) DEFAULT NULL,
  `rt` varchar(255) DEFAULT NULL,
  `oral` varchar(255) DEFAULT NULL,
  `ag` varchar(255) DEFAULT NULL,
  `urine` varchar(255) DEFAULT NULL,
  `aspiration` varchar(255) DEFAULT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tpr_monitoring_chart`
--

LOCK TABLES `tpr_monitoring_chart` WRITE;
/*!40000 ALTER TABLE `tpr_monitoring_chart` DISABLE KEYS */;
/*!40000 ALTER TABLE `tpr_monitoring_chart` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `treatment_medication_sheet`
--

DROP TABLE IF EXISTS `treatment_medication_sheet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `treatment_medication_sheet` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `registration_id` int(11) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `treatment_medication_sheet`
--

LOCK TABLES `treatment_medication_sheet` WRITE;
/*!40000 ALTER TABLE `treatment_medication_sheet` DISABLE KEYS */;
/*!40000 ALTER TABLE `treatment_medication_sheet` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `treatment_medication_sheet_data`
--

DROP TABLE IF EXISTS `treatment_medication_sheet_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `treatment_medication_sheet_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `medication_id` int(11) DEFAULT NULL,
  `administration_record_1` text,
  `administration_record_2` text,
  `administration_record_3` text,
  `administration_record_4` text,
  `administration_record_5` text,
  `single_val` longtext,
  `type` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `treatment_medication_sheet_data`
--

LOCK TABLES `treatment_medication_sheet_data` WRITE;
/*!40000 ALTER TABLE `treatment_medication_sheet_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `treatment_medication_sheet_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uhid_ipd_used`
--

DROP TABLE IF EXISTS `uhid_ipd_used`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uhid_ipd_used` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uhid` varchar(255) NOT NULL,
  `ipd` varchar(255) NOT NULL,
  `case_id` int(11) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `registration_year` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uhid_ipd_used`
--

LOCK TABLES `uhid_ipd_used` WRITE;
/*!40000 ALTER TABLE `uhid_ipd_used` DISABLE KEYS */;
INSERT INTO `uhid_ipd_used` VALUES (36,'SH/0001/2023','',136,0,'2023'),(37,'SH/0002/2023','',137,0,'2023'),(38,'SH/2023/0003','SH_/0001/2023',0,28,'2023'),(39,'SH/0004/2023','',138,0,'2023'),(40,'SH/0005/2023','',139,0,'2023');
/*!40000 ALTER TABLE `uhid_ipd_used` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_permission`
--

DROP TABLE IF EXISTS `user_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_permission` (
  `user_permission_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `section_id` int(11) DEFAULT NULL,
  `listing_permission` enum('0','1','2') NOT NULL DEFAULT '0',
  `view_permission` enum('0','1','2') NOT NULL DEFAULT '0',
  `add_permission` enum('0','1','2') NOT NULL DEFAULT '0',
  `edit_permission` enum('0','1','2') NOT NULL DEFAULT '0',
  `delete_permission` enum('0','1','2') NOT NULL DEFAULT '0',
  `print_permission` enum('0','1') NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`user_permission_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1675 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_permission`
--

LOCK TABLES `user_permission` WRITE;
/*!40000 ALTER TABLE `user_permission` DISABLE KEYS */;
INSERT INTO `user_permission` VALUES (1,18,1,'1','1','1','0','0','0',NULL,NULL),(2,18,2,'1','1','0','0','0','0',NULL,NULL),(3,18,3,'1','1','0','0','0','0',NULL,NULL),(4,18,4,'1','1','0','0','0','0',NULL,NULL),(5,18,5,'1','1','0','0','0','0',NULL,NULL),(6,18,6,'1','1','0','0','0','0',NULL,NULL),(7,18,7,'1','1','1','1','0','0',NULL,NULL),(8,18,8,'0','0','0','0','0','0',NULL,NULL),(9,18,9,'0','0','0','0','0','0',NULL,NULL),(10,18,10,'0','0','0','0','0','0',NULL,NULL),(11,18,11,'0','0','0','0','0','0',NULL,NULL),(12,18,12,'0','0','0','0','0','0',NULL,NULL),(13,18,13,'0','0','0','0','0','0',NULL,NULL),(14,18,14,'0','0','0','0','0','0',NULL,NULL),(15,18,15,'0','0','0','0','0','0',NULL,NULL),(16,18,16,'0','0','0','0','0','0',NULL,NULL),(17,18,17,'0','0','0','0','0','0',NULL,NULL),(18,18,18,'0','0','0','0','0','0',NULL,NULL),(19,18,19,'0','0','0','0','0','0',NULL,NULL),(20,18,20,'0','0','0','0','0','0',NULL,NULL),(21,18,21,'0','0','0','0','0','0',NULL,NULL),(22,18,22,'0','0','0','0','0','0',NULL,NULL),(23,18,23,'0','0','0','0','0','0',NULL,NULL),(24,18,24,'0','0','0','0','0','0',NULL,NULL),(25,18,25,'0','0','0','0','0','0',NULL,NULL),(26,18,26,'0','0','0','0','0','0',NULL,NULL),(27,18,27,'0','0','0','0','0','0',NULL,NULL),(28,18,28,'0','0','0','0','0','0',NULL,NULL),(29,18,29,'0','0','0','0','0','0',NULL,NULL),(30,18,30,'0','0','0','0','0','0',NULL,NULL),(31,18,31,'0','0','0','0','0','0',NULL,NULL),(32,18,32,'0','0','0','0','0','0',NULL,NULL),(33,18,33,'0','0','0','0','0','0',NULL,NULL),(34,18,34,'0','0','0','0','0','0',NULL,NULL),(35,18,35,'0','0','0','0','0','0',NULL,NULL),(36,18,36,'0','0','0','0','0','0',NULL,NULL),(37,18,37,'0','0','0','0','0','0',NULL,NULL),(38,18,38,'0','0','0','0','0','0',NULL,NULL),(39,18,39,'0','0','0','0','0','0',NULL,NULL),(40,18,40,'0','0','0','0','0','0',NULL,NULL),(41,18,41,'0','0','0','0','0','0',NULL,NULL),(42,18,42,'0','0','0','0','0','0',NULL,NULL),(43,18,43,'0','0','0','0','0','0',NULL,NULL),(44,18,44,'0','0','0','0','0','0',NULL,NULL),(45,18,45,'0','0','0','0','0','0',NULL,NULL),(46,18,46,'0','0','0','0','0','0',NULL,NULL),(47,18,47,'0','0','0','0','0','0',NULL,NULL),(48,18,48,'0','0','0','0','0','0',NULL,NULL),(49,18,49,'0','0','0','0','0','0',NULL,NULL),(50,18,50,'0','0','0','0','0','0',NULL,NULL),(51,18,51,'0','0','0','0','0','0',NULL,NULL),(52,18,52,'0','0','0','0','0','0',NULL,NULL),(53,18,53,'0','0','0','0','0','0',NULL,NULL),(54,19,1,'1','1','1','0','0','0',NULL,NULL),(55,19,2,'1','1','0','0','0','0',NULL,NULL),(56,19,3,'1','1','0','0','0','0',NULL,NULL),(57,19,4,'1','1','0','0','0','0',NULL,NULL),(58,19,5,'1','1','0','0','0','0',NULL,NULL),(59,19,6,'1','1','0','0','0','0',NULL,NULL),(60,19,7,'1','1','1','1','1','0',NULL,NULL),(61,19,8,'0','0','0','0','0','0',NULL,NULL),(62,19,9,'0','0','0','0','0','0',NULL,NULL),(63,19,10,'0','0','0','0','0','0',NULL,NULL),(64,19,11,'0','0','0','0','0','0',NULL,NULL),(65,19,12,'0','0','0','0','0','0',NULL,NULL),(66,19,13,'0','0','0','0','0','0',NULL,NULL),(67,19,14,'0','0','0','0','0','0',NULL,NULL),(68,19,15,'0','0','0','0','0','0',NULL,NULL),(69,19,16,'0','0','0','0','0','0',NULL,NULL),(70,19,17,'0','0','0','0','0','0',NULL,NULL),(71,19,18,'0','0','0','0','0','0',NULL,NULL),(72,19,19,'0','0','0','0','0','0',NULL,NULL),(73,19,20,'0','0','0','0','0','0',NULL,NULL),(74,19,21,'0','0','0','0','0','0',NULL,NULL),(75,19,22,'0','0','0','0','0','0',NULL,NULL),(76,19,23,'0','0','0','0','0','0',NULL,NULL),(77,19,24,'0','0','0','0','0','0',NULL,NULL),(78,19,25,'0','0','0','0','0','0',NULL,NULL),(79,19,26,'0','0','0','0','0','0',NULL,NULL),(80,19,27,'0','0','0','0','0','0',NULL,NULL),(81,19,28,'0','0','0','0','0','0',NULL,NULL),(82,19,29,'0','0','0','0','0','0',NULL,NULL),(83,19,30,'0','0','0','0','0','0',NULL,NULL),(84,19,31,'0','0','0','0','0','0',NULL,NULL),(85,19,32,'0','0','0','0','0','0',NULL,NULL),(86,19,33,'0','0','0','0','0','0',NULL,NULL),(87,19,34,'0','0','0','0','0','0',NULL,NULL),(88,19,35,'0','0','0','0','0','0',NULL,NULL),(89,19,36,'0','0','0','0','0','0',NULL,NULL),(90,19,37,'0','0','0','0','0','0',NULL,NULL),(91,19,38,'0','0','0','0','0','0',NULL,NULL),(92,19,39,'0','0','0','0','0','0',NULL,NULL),(93,19,40,'0','0','0','0','0','0',NULL,NULL),(94,19,41,'0','0','0','0','0','0',NULL,NULL),(95,19,42,'0','0','0','0','0','0',NULL,NULL),(96,19,43,'0','0','0','0','0','0',NULL,NULL),(97,19,44,'0','0','0','0','0','0',NULL,NULL),(98,19,45,'0','0','0','0','0','0',NULL,NULL),(99,19,46,'0','0','0','0','0','0',NULL,NULL),(100,19,47,'0','0','0','0','0','0',NULL,NULL),(101,19,48,'0','0','0','0','0','0',NULL,NULL),(102,19,49,'0','0','0','0','0','0',NULL,NULL),(103,19,50,'0','0','0','0','0','0',NULL,NULL),(104,19,51,'0','0','0','0','0','0',NULL,NULL),(105,19,52,'0','0','0','0','0','0',NULL,NULL),(106,19,53,'0','0','0','0','0','0',NULL,NULL),(107,20,1,'1','1','1','1','1','0',NULL,NULL),(108,20,2,'1','1','1','1','1','0',NULL,NULL),(109,20,3,'1','1','1','1','1','0',NULL,NULL),(110,20,4,'1','1','1','1','1','0',NULL,NULL),(111,20,5,'1','1','1','1','1','0',NULL,NULL),(112,20,6,'1','1','1','1','1','0',NULL,NULL),(113,20,7,'1','1','1','1','1','0',NULL,NULL),(114,20,8,'0','0','0','0','0','0',NULL,NULL),(115,20,9,'1','1','1','1','1','0',NULL,NULL),(116,20,10,'1','1','1','1','1','0',NULL,NULL),(117,20,11,'1','1','1','1','1','0',NULL,NULL),(118,20,12,'1','1','1','1','1','0',NULL,NULL),(119,20,13,'1','1','1','1','1','0',NULL,NULL),(120,20,14,'1','1','1','1','1','0',NULL,NULL),(121,20,15,'1','1','1','1','1','0',NULL,NULL),(122,20,16,'1','1','1','1','1','0',NULL,NULL),(123,20,17,'0','0','0','0','0','0',NULL,NULL),(124,20,18,'1','1','1','1','1','0',NULL,NULL),(125,20,19,'0','0','0','0','0','0',NULL,NULL),(126,20,20,'1','1','1','1','1','0',NULL,NULL),(127,20,21,'1','1','1','1','1','0',NULL,NULL),(128,20,22,'1','1','1','1','1','0',NULL,NULL),(129,20,23,'1','1','1','1','1','0',NULL,NULL),(130,20,24,'0','0','0','0','0','0',NULL,NULL),(131,20,25,'0','0','0','0','0','0',NULL,NULL),(132,20,26,'0','0','0','0','0','0',NULL,NULL),(133,20,27,'0','0','0','0','0','0',NULL,NULL),(134,20,28,'0','0','0','0','0','0',NULL,NULL),(135,20,29,'0','0','0','0','0','0',NULL,NULL),(136,20,30,'0','0','0','0','0','0',NULL,NULL),(137,20,31,'0','0','0','0','0','0',NULL,NULL),(138,20,32,'0','0','0','0','0','0',NULL,NULL),(139,20,33,'0','0','0','0','0','0',NULL,NULL),(140,20,34,'0','0','0','0','0','0',NULL,NULL),(141,20,35,'0','0','0','0','0','0',NULL,NULL),(142,20,36,'0','0','0','0','0','0',NULL,NULL),(143,20,37,'0','0','0','0','0','0',NULL,NULL),(144,20,38,'0','0','0','0','0','0',NULL,NULL),(145,20,39,'0','0','0','0','0','0',NULL,NULL),(146,20,40,'0','0','0','0','0','0',NULL,NULL),(147,20,41,'0','0','0','0','0','0',NULL,NULL),(148,20,42,'0','0','0','0','0','0',NULL,NULL),(149,20,43,'0','0','0','0','0','0',NULL,NULL),(150,20,44,'0','0','0','0','0','0',NULL,NULL),(151,20,45,'0','0','0','0','0','0',NULL,NULL),(152,20,46,'1','1','1','1','1','0',NULL,NULL),(153,20,47,'1','1','1','1','1','0',NULL,NULL),(154,20,48,'0','1','0','0','0','0',NULL,NULL),(155,20,49,'0','0','0','0','0','0',NULL,NULL),(156,20,50,'1','1','1','1','1','0',NULL,NULL),(157,20,51,'1','1','1','1','1','0',NULL,NULL),(158,20,52,'1','1','1','1','1','0',NULL,NULL),(159,20,53,'1','1','1','1','1','0',NULL,NULL),(160,21,1,'1','1','1','1','1','0',NULL,NULL),(161,21,2,'1','1','1','1','1','0',NULL,NULL),(162,21,3,'1','1','1','1','1','0',NULL,NULL),(163,21,4,'1','1','1','1','1','0',NULL,NULL),(164,21,5,'1','1','1','1','1','0',NULL,NULL),(165,21,6,'1','1','1','1','1','0',NULL,NULL),(166,21,7,'1','1','1','1','0','0',NULL,NULL),(167,21,8,'0','0','0','0','0','0',NULL,NULL),(168,21,9,'1','1','1','1','1','0',NULL,NULL),(169,21,10,'0','0','0','0','0','0',NULL,NULL),(170,21,11,'0','0','0','0','0','0',NULL,NULL),(171,21,12,'0','0','0','0','0','0',NULL,NULL),(172,21,13,'0','0','0','0','0','0',NULL,NULL),(173,21,14,'0','0','0','0','0','0',NULL,NULL),(174,21,15,'0','0','0','0','0','0',NULL,NULL),(175,21,16,'0','0','0','0','0','0',NULL,NULL),(176,21,17,'0','0','0','0','0','0',NULL,NULL),(177,21,18,'0','0','0','0','0','0',NULL,NULL),(178,21,19,'0','0','0','0','0','0',NULL,NULL),(179,21,20,'0','0','0','0','0','0',NULL,NULL),(180,21,21,'0','0','0','0','0','0',NULL,NULL),(181,21,22,'0','0','0','0','0','0',NULL,NULL),(182,21,23,'0','0','0','0','0','0',NULL,NULL),(183,21,24,'0','0','0','0','0','0',NULL,NULL),(184,21,25,'0','0','0','0','0','0',NULL,NULL),(185,21,26,'0','0','0','0','0','0',NULL,NULL),(186,21,27,'0','0','0','0','0','0',NULL,NULL),(187,21,28,'0','0','0','0','0','0',NULL,NULL),(188,21,29,'0','0','0','0','0','0',NULL,NULL),(189,21,30,'0','0','0','0','0','0',NULL,NULL),(190,21,31,'0','0','0','0','0','0',NULL,NULL),(191,21,32,'0','0','0','0','0','0',NULL,NULL),(192,21,33,'0','0','0','0','0','0',NULL,NULL),(193,21,34,'0','0','0','0','0','0',NULL,NULL),(194,21,35,'0','0','0','0','0','0',NULL,NULL),(195,21,36,'0','0','0','0','0','0',NULL,NULL),(196,21,37,'0','0','0','0','0','0',NULL,NULL),(197,21,38,'0','0','0','0','0','0',NULL,NULL),(198,21,39,'0','0','0','0','0','0',NULL,NULL),(199,21,40,'0','0','0','0','0','0',NULL,NULL),(200,21,41,'0','0','0','0','0','0',NULL,NULL),(201,21,42,'0','0','0','0','0','0',NULL,NULL),(202,21,43,'0','0','0','0','0','0',NULL,NULL),(203,21,44,'0','0','0','0','0','0',NULL,NULL),(204,21,45,'0','0','0','0','0','0',NULL,NULL),(205,21,46,'0','0','0','0','0','0',NULL,NULL),(206,21,47,'0','0','0','0','0','0',NULL,NULL),(207,21,48,'0','0','0','0','0','0',NULL,NULL),(208,21,49,'0','0','0','0','0','0',NULL,NULL),(209,21,50,'0','0','0','0','0','0',NULL,NULL),(210,21,51,'0','0','0','0','0','0',NULL,NULL),(211,21,52,'0','0','0','0','0','0',NULL,NULL),(212,21,53,'0','0','0','0','0','0',NULL,NULL),(213,20,54,'1','1','1','1','0','0',NULL,NULL),(214,22,1,'1','1','1','1','1','0',NULL,NULL),(215,22,2,'1','1','1','1','1','0',NULL,NULL),(216,22,3,'1','1','1','1','1','0',NULL,NULL),(217,22,4,'1','1','1','1','1','0',NULL,NULL),(218,22,5,'1','1','1','1','1','0',NULL,NULL),(219,22,6,'0','0','0','0','0','0',NULL,NULL),(220,22,7,'1','1','1','0','0','0',NULL,NULL),(221,22,8,'0','0','0','0','0','0',NULL,NULL),(222,22,9,'1','1','1','1','1','0',NULL,NULL),(223,22,10,'0','0','0','0','0','0',NULL,NULL),(224,22,11,'0','0','0','0','0','0',NULL,NULL),(225,22,12,'0','0','0','0','0','0',NULL,NULL),(226,22,13,'0','0','0','0','0','0',NULL,NULL),(227,22,14,'0','0','0','0','0','0',NULL,NULL),(228,22,15,'0','0','0','0','0','0',NULL,NULL),(229,22,16,'0','0','0','0','0','0',NULL,NULL),(230,22,17,'0','0','0','0','0','0',NULL,NULL),(231,22,18,'0','0','0','0','0','0',NULL,NULL),(232,22,19,'0','0','0','0','0','0',NULL,NULL),(233,22,20,'0','0','0','0','0','0',NULL,NULL),(234,22,21,'0','0','0','0','0','0',NULL,NULL),(235,22,22,'0','0','0','0','0','0',NULL,NULL),(236,22,23,'0','0','0','0','0','0',NULL,NULL),(237,22,24,'0','0','0','0','0','0',NULL,NULL),(238,22,25,'0','0','0','0','0','0',NULL,NULL),(239,22,26,'0','0','0','0','0','0',NULL,NULL),(240,22,27,'0','0','0','0','0','0',NULL,NULL),(241,22,28,'0','0','0','0','0','0',NULL,NULL),(242,22,29,'0','0','0','0','0','0',NULL,NULL),(243,22,30,'0','0','0','0','0','0',NULL,NULL),(244,22,31,'0','0','0','0','0','0',NULL,NULL),(245,22,32,'0','0','0','0','0','0',NULL,NULL),(246,22,33,'0','0','0','0','0','0',NULL,NULL),(247,22,34,'0','0','0','0','0','0',NULL,NULL),(248,22,35,'0','0','0','0','0','0',NULL,NULL),(249,22,36,'0','0','0','0','0','0',NULL,NULL),(250,22,37,'0','0','0','0','0','0',NULL,NULL),(251,22,38,'0','0','0','0','0','0',NULL,NULL),(252,22,39,'0','0','0','0','0','0',NULL,NULL),(253,22,40,'0','0','0','0','0','0',NULL,NULL),(254,22,41,'0','0','0','0','0','0',NULL,NULL),(255,22,42,'0','0','0','0','0','0',NULL,NULL),(256,22,43,'0','0','0','0','0','0',NULL,NULL),(257,22,44,'0','0','0','0','0','0',NULL,NULL),(258,22,45,'0','0','0','0','0','0',NULL,NULL),(259,22,46,'0','0','0','0','0','0',NULL,NULL),(260,22,47,'0','0','0','0','0','0',NULL,NULL),(261,22,48,'0','0','0','0','0','0',NULL,NULL),(262,22,49,'0','0','0','0','0','0',NULL,NULL),(263,22,50,'0','0','0','0','0','0',NULL,NULL),(264,22,51,'0','0','0','0','0','0',NULL,NULL),(265,22,52,'0','0','0','0','0','0',NULL,NULL),(266,22,53,'0','0','0','0','0','0',NULL,NULL),(267,22,54,'0','0','0','0','0','0',NULL,NULL),(268,21,54,'0','0','0','0','0','0',NULL,NULL),(269,23,1,'1','1','1','1','1','0',NULL,NULL),(270,23,2,'1','1','1','0','0','0',NULL,NULL),(271,23,3,'1','1','1','1','0','0',NULL,NULL),(272,23,4,'1','1','1','1','0','0',NULL,NULL),(273,23,5,'1','1','1','1','0','0',NULL,NULL),(274,23,6,'0','0','0','0','0','0',NULL,NULL),(275,23,7,'0','0','0','0','0','0',NULL,NULL),(276,23,8,'0','0','0','0','0','0',NULL,NULL),(277,23,9,'1','1','1','1','1','0',NULL,NULL),(278,23,10,'1','1','1','1','1','0',NULL,NULL),(279,23,11,'1','1','1','1','1','0',NULL,NULL),(280,23,12,'1','1','1','1','1','0',NULL,NULL),(281,23,13,'1','1','1','1','1','0',NULL,NULL),(282,23,14,'1','1','1','1','0','0',NULL,NULL),(283,23,15,'1','1','1','1','0','0',NULL,NULL),(284,23,16,'0','0','0','0','0','0',NULL,NULL),(285,23,17,'0','0','0','0','0','0',NULL,NULL),(286,23,18,'0','0','0','0','0','0',NULL,NULL),(287,23,19,'1','1','1','1','1','0',NULL,NULL),(288,23,20,'1','1','1','1','1','0',NULL,NULL),(289,23,21,'1','1','1','1','1','0',NULL,NULL),(290,23,22,'0','0','1','0','0','0',NULL,NULL),(291,23,23,'1','1','1','1','1','0',NULL,NULL),(292,23,24,'1','1','1','1','1','0',NULL,NULL),(293,23,25,'1','1','1','1','1','0',NULL,NULL),(294,23,26,'1','1','1','1','1','0',NULL,NULL),(295,23,27,'0','0','0','0','0','0',NULL,NULL),(296,23,28,'0','0','0','0','0','0',NULL,NULL),(297,23,29,'0','0','0','0','0','0',NULL,NULL),(298,23,30,'0','0','0','0','0','0',NULL,NULL),(299,23,31,'0','0','0','0','0','0',NULL,NULL),(300,23,32,'0','0','0','0','0','0',NULL,NULL),(301,23,33,'0','0','0','0','0','0',NULL,NULL),(302,23,34,'0','0','0','0','0','0',NULL,NULL),(303,23,35,'0','0','0','0','0','0',NULL,NULL),(304,23,36,'0','0','0','0','0','0',NULL,NULL),(305,23,37,'0','0','0','0','0','0',NULL,NULL),(306,23,38,'0','0','0','0','0','0',NULL,NULL),(307,23,39,'0','0','0','0','0','0',NULL,NULL),(308,23,40,'0','0','0','0','0','0',NULL,NULL),(309,23,41,'0','0','0','0','0','0',NULL,NULL),(310,23,42,'0','0','0','0','0','0',NULL,NULL),(311,23,43,'0','0','0','0','0','0',NULL,NULL),(312,23,44,'0','0','0','0','0','0',NULL,NULL),(313,23,45,'0','0','0','0','0','0',NULL,NULL),(314,23,46,'0','0','0','0','0','0',NULL,NULL),(315,23,47,'1','1','1','1','0','0',NULL,NULL),(316,23,48,'0','0','0','0','0','0',NULL,NULL),(317,23,49,'0','0','0','0','0','0',NULL,NULL),(318,23,50,'0','0','0','0','0','0',NULL,NULL),(319,23,51,'0','0','0','0','0','0',NULL,NULL),(320,23,52,'0','0','0','0','0','0',NULL,NULL),(321,23,53,'0','0','0','0','0','0',NULL,NULL),(322,23,54,'0','0','0','0','0','0',NULL,NULL),(323,24,1,'1','1','1','1','1','0',NULL,NULL),(324,24,2,'1','1','1','1','1','0',NULL,NULL),(325,24,3,'1','1','1','1','1','0',NULL,NULL),(326,24,4,'1','1','1','1','1','0',NULL,NULL),(327,24,5,'1','1','1','1','1','0',NULL,NULL),(328,24,6,'1','1','1','1','1','0',NULL,NULL),(329,24,7,'1','1','1','1','1','0',NULL,NULL),(330,24,8,'1','1','1','1','1','0',NULL,NULL),(331,24,9,'1','1','1','1','1','0',NULL,NULL),(332,24,10,'1','1','1','1','0','0',NULL,NULL),(333,24,11,'1','1','1','1','0','0',NULL,NULL),(334,24,12,'1','1','1','1','0','0',NULL,NULL),(335,24,13,'1','1','1','1','0','0',NULL,NULL),(336,24,14,'1','1','1','1','0','0',NULL,NULL),(337,24,15,'1','1','1','1','0','0',NULL,NULL),(338,24,16,'0','0','0','0','0','0',NULL,NULL),(339,24,17,'1','1','1','1','0','0',NULL,NULL),(340,24,18,'0','0','0','0','0','0',NULL,NULL),(341,24,19,'1','1','1','1','0','0',NULL,NULL),(342,24,20,'1','1','1','1','0','0',NULL,NULL),(343,24,21,'1','1','1','1','0','0',NULL,NULL),(344,24,22,'0','0','0','0','0','0',NULL,NULL),(345,24,23,'1','1','1','1','0','0',NULL,NULL),(346,24,24,'1','1','1','1','0','0',NULL,NULL),(347,24,25,'1','1','1','1','0','0',NULL,NULL),(348,24,26,'1','1','1','1','0','0',NULL,NULL),(349,24,27,'0','0','0','0','0','0',NULL,NULL),(350,24,28,'0','0','0','0','0','0',NULL,NULL),(351,24,29,'0','0','0','0','0','0',NULL,NULL),(352,24,30,'0','0','0','0','0','0',NULL,NULL),(353,24,31,'0','0','0','0','0','0',NULL,NULL),(354,24,32,'0','0','0','0','0','0',NULL,NULL),(355,24,33,'0','0','0','0','0','0',NULL,NULL),(356,24,34,'0','0','0','0','0','0',NULL,NULL),(357,24,35,'0','0','0','0','0','0',NULL,NULL),(358,24,36,'0','0','0','0','0','0',NULL,NULL),(359,24,37,'0','0','0','0','0','0',NULL,NULL),(360,24,38,'0','0','0','0','0','0',NULL,NULL),(361,24,39,'0','0','0','0','0','0',NULL,NULL),(362,24,40,'0','0','0','0','0','0',NULL,NULL),(363,24,41,'0','0','0','0','0','0',NULL,NULL),(364,24,42,'0','0','0','0','0','0',NULL,NULL),(365,24,43,'0','0','0','0','0','0',NULL,NULL),(366,24,44,'0','0','0','0','0','0',NULL,NULL),(367,24,45,'0','0','0','0','0','0',NULL,NULL),(368,24,46,'1','1','1','1','1','0',NULL,NULL),(369,24,47,'1','1','1','1','1','0',NULL,NULL),(370,24,48,'1','1','1','1','1','0',NULL,NULL),(371,24,49,'1','1','1','1','1','0',NULL,NULL),(372,24,50,'1','1','1','1','1','0',NULL,NULL),(373,24,51,'0','0','0','0','0','0',NULL,NULL),(374,24,52,'0','0','0','0','0','0',NULL,NULL),(375,24,53,'1','1','1','1','0','0',NULL,NULL),(376,24,54,'0','0','0','0','0','0',NULL,NULL),(377,25,1,'1','1','1','1','0','0',NULL,NULL),(378,25,2,'1','1','1','1','0','0',NULL,NULL),(379,25,3,'1','1','1','1','0','0',NULL,NULL),(380,25,4,'1','1','1','1','0','0',NULL,NULL),(381,25,5,'1','1','1','1','0','0',NULL,NULL),(382,25,6,'0','0','0','0','0','0',NULL,NULL),(383,25,7,'0','0','0','0','0','0',NULL,NULL),(384,25,8,'0','0','0','0','0','0',NULL,NULL),(385,25,9,'1','1','1','1','0','0',NULL,NULL),(386,25,10,'1','1','1','1','0','0',NULL,NULL),(387,25,11,'1','1','1','1','0','0',NULL,NULL),(388,25,12,'1','1','1','1','0','0',NULL,NULL),(389,25,13,'1','1','1','1','0','0',NULL,NULL),(390,25,14,'1','1','1','1','0','0',NULL,NULL),(391,25,15,'1','1','1','1','0','0',NULL,NULL),(392,25,16,'0','0','0','0','0','0',NULL,NULL),(393,25,17,'0','0','0','0','0','0',NULL,NULL),(394,25,18,'0','0','0','0','0','0',NULL,NULL),(395,25,19,'1','1','1','1','0','0',NULL,NULL),(396,25,20,'1','1','1','1','0','0',NULL,NULL),(397,25,21,'1','1','1','1','0','0',NULL,NULL),(398,25,22,'0','0','0','0','0','0',NULL,NULL),(399,25,23,'1','1','1','1','0','0',NULL,NULL),(400,25,24,'1','1','1','1','0','0',NULL,NULL),(401,25,25,'1','1','1','1','0','0',NULL,NULL),(402,25,26,'1','1','1','1','0','0',NULL,NULL),(403,25,27,'0','0','0','0','0','0',NULL,NULL),(404,25,28,'0','0','0','0','0','0',NULL,NULL),(405,25,29,'0','0','0','0','0','0',NULL,NULL),(406,25,30,'0','0','0','0','0','0',NULL,NULL),(407,25,31,'0','0','0','0','0','0',NULL,NULL),(408,25,32,'0','0','0','0','0','0',NULL,NULL),(409,25,33,'0','0','0','0','0','0',NULL,NULL),(410,25,34,'0','0','0','0','0','0',NULL,NULL),(411,25,35,'0','0','0','0','0','0',NULL,NULL),(412,25,36,'0','0','0','0','0','0',NULL,NULL),(413,25,37,'0','0','0','0','0','0',NULL,NULL),(414,25,38,'0','0','0','0','0','0',NULL,NULL),(415,25,39,'0','0','0','0','0','0',NULL,NULL),(416,25,40,'0','0','0','0','0','0',NULL,NULL),(417,25,41,'0','0','0','0','0','0',NULL,NULL),(418,25,42,'0','0','0','0','0','0',NULL,NULL),(419,25,43,'0','0','0','0','0','0',NULL,NULL),(420,25,44,'0','0','0','0','0','0',NULL,NULL),(421,25,45,'0','0','0','0','0','0',NULL,NULL),(422,25,46,'1','1','1','1','0','0',NULL,NULL),(423,25,47,'1','1','1','1','0','0',NULL,NULL),(424,25,48,'1','1','1','1','0','0',NULL,NULL),(425,25,49,'1','1','1','1','0','0',NULL,NULL),(426,25,50,'1','1','1','1','0','0',NULL,NULL),(427,25,51,'0','0','0','0','0','0',NULL,NULL),(428,25,52,'0','0','0','0','0','0',NULL,NULL),(429,25,53,'1','1','1','1','0','0',NULL,NULL),(430,25,54,'0','0','0','0','0','0',NULL,NULL),(431,26,1,'1','1','1','1','1','0',NULL,NULL),(432,26,2,'1','1','1','1','1','0',NULL,NULL),(433,26,3,'1','1','1','1','1','0',NULL,NULL),(434,26,4,'0','0','0','0','0','0',NULL,NULL),(435,26,5,'1','1','1','1','1','0',NULL,NULL),(436,26,6,'0','0','0','0','0','0',NULL,NULL),(437,26,7,'1','1','1','1','1','0',NULL,NULL),(438,26,8,'0','0','0','0','0','0',NULL,NULL),(439,26,9,'1','1','1','1','1','0',NULL,NULL),(440,26,10,'0','0','0','0','0','0',NULL,NULL),(441,26,11,'0','0','0','0','0','0',NULL,NULL),(442,26,12,'0','0','0','0','0','0',NULL,NULL),(443,26,13,'0','0','0','0','0','0',NULL,NULL),(444,26,14,'0','0','0','0','0','0',NULL,NULL),(445,26,15,'0','0','0','0','0','0',NULL,NULL),(446,26,16,'0','0','0','0','0','0',NULL,NULL),(447,26,17,'0','0','0','0','0','0',NULL,NULL),(448,26,18,'0','0','0','0','0','0',NULL,NULL),(449,26,19,'0','0','0','0','0','0',NULL,NULL),(450,26,20,'0','0','0','0','0','0',NULL,NULL),(451,26,21,'0','0','0','0','0','0',NULL,NULL),(452,26,22,'0','0','0','0','0','0',NULL,NULL),(453,26,23,'0','0','0','0','0','0',NULL,NULL),(454,26,24,'0','0','0','0','0','0',NULL,NULL),(455,26,25,'0','0','0','0','0','0',NULL,NULL),(456,26,26,'0','0','0','0','0','0',NULL,NULL),(457,26,27,'0','0','0','0','0','0',NULL,NULL),(458,26,28,'0','0','0','0','0','0',NULL,NULL),(459,26,29,'0','0','0','0','0','0',NULL,NULL),(460,26,30,'0','0','0','0','0','0',NULL,NULL),(461,26,31,'0','0','0','0','0','0',NULL,NULL),(462,26,32,'0','0','0','0','0','0',NULL,NULL),(463,26,33,'0','0','0','0','0','0',NULL,NULL),(464,26,34,'0','0','0','0','0','0',NULL,NULL),(465,26,35,'0','0','0','0','0','0',NULL,NULL),(466,26,36,'0','0','0','0','0','0',NULL,NULL),(467,26,37,'0','0','0','0','0','0',NULL,NULL),(468,26,38,'0','0','0','0','0','0',NULL,NULL),(469,26,39,'0','0','0','0','0','0',NULL,NULL),(470,26,40,'0','0','0','0','0','0',NULL,NULL),(471,26,41,'0','0','0','0','0','0',NULL,NULL),(472,26,42,'0','0','0','0','0','0',NULL,NULL),(473,26,43,'0','0','0','0','0','0',NULL,NULL),(474,26,44,'0','0','0','0','0','0',NULL,NULL),(475,26,45,'0','0','0','0','0','0',NULL,NULL),(476,26,46,'0','0','0','0','0','0',NULL,NULL),(477,26,47,'0','0','0','0','0','0',NULL,NULL),(478,26,48,'0','0','0','0','0','0',NULL,NULL),(479,26,49,'0','0','0','0','0','0',NULL,NULL),(480,26,50,'0','0','0','0','0','0',NULL,NULL),(481,26,51,'0','0','0','0','0','0',NULL,NULL),(482,26,52,'0','0','0','0','0','0',NULL,NULL),(483,26,53,'0','0','0','0','0','0',NULL,NULL),(484,26,54,'0','0','0','0','0','0',NULL,NULL),(485,27,1,'1','1','1','1','1','0',NULL,NULL),(486,27,2,'0','0','0','0','0','0',NULL,NULL),(487,27,3,'0','0','0','0','0','0',NULL,NULL),(488,27,4,'0','0','0','0','0','0',NULL,NULL),(489,27,5,'0','0','0','0','0','0',NULL,NULL),(490,27,6,'0','0','0','0','0','0',NULL,NULL),(491,27,7,'0','0','0','0','0','0',NULL,NULL),(492,27,8,'0','0','0','0','0','0',NULL,NULL),(493,27,9,'1','1','1','1','1','0',NULL,NULL),(494,27,10,'1','1','1','1','1','0',NULL,NULL),(495,27,11,'1','1','1','1','1','0',NULL,NULL),(496,27,12,'1','1','1','1','1','0',NULL,NULL),(497,27,13,'0','0','0','0','0','0',NULL,NULL),(498,27,14,'0','0','0','0','0','0',NULL,NULL),(499,27,15,'0','0','0','0','0','0',NULL,NULL),(500,27,16,'0','0','0','0','0','0',NULL,NULL),(501,27,17,'0','0','0','0','0','0',NULL,NULL),(502,27,18,'0','0','0','0','0','0',NULL,NULL),(503,27,19,'0','0','0','0','0','0',NULL,NULL),(504,27,20,'0','0','0','0','0','0',NULL,NULL),(505,27,21,'0','0','0','0','0','0',NULL,NULL),(506,27,22,'0','0','0','0','0','0',NULL,NULL),(507,27,23,'0','0','0','0','0','0',NULL,NULL),(508,27,24,'0','0','0','0','0','0',NULL,NULL),(509,27,25,'0','0','0','0','0','0',NULL,NULL),(510,27,26,'0','0','0','0','0','0',NULL,NULL),(511,27,27,'0','0','0','0','0','0',NULL,NULL),(512,27,28,'0','0','0','0','0','0',NULL,NULL),(513,27,29,'0','0','0','0','0','0',NULL,NULL),(514,27,30,'0','0','0','0','0','0',NULL,NULL),(515,27,31,'0','0','0','0','0','0',NULL,NULL),(516,27,32,'0','0','0','0','0','0',NULL,NULL),(517,27,33,'0','0','0','0','0','0',NULL,NULL),(518,27,34,'0','0','0','0','0','0',NULL,NULL),(519,27,35,'0','0','0','0','0','0',NULL,NULL),(520,27,36,'0','0','0','0','0','0',NULL,NULL),(521,27,37,'0','0','0','0','0','0',NULL,NULL),(522,27,38,'0','0','0','0','0','0',NULL,NULL),(523,27,39,'0','0','0','0','0','0',NULL,NULL),(524,27,40,'0','0','0','0','0','0',NULL,NULL),(525,27,41,'0','0','0','0','0','0',NULL,NULL),(526,27,42,'0','0','0','0','0','0',NULL,NULL),(527,27,43,'0','0','0','0','0','0',NULL,NULL),(528,27,44,'0','0','0','0','0','0',NULL,NULL),(529,27,45,'0','0','0','0','0','0',NULL,NULL),(530,27,46,'0','0','0','0','0','0',NULL,NULL),(531,27,47,'0','0','0','0','0','0',NULL,NULL),(532,27,48,'0','0','0','0','0','0',NULL,NULL),(533,27,49,'0','0','0','0','0','0',NULL,NULL),(534,27,50,'0','0','0','0','0','0',NULL,NULL),(535,27,51,'0','0','0','0','0','0',NULL,NULL),(536,27,52,'0','0','0','0','0','0',NULL,NULL),(537,27,53,'0','0','0','0','0','0',NULL,NULL),(538,27,54,'0','0','0','0','0','0',NULL,NULL),(539,28,1,'1','1','1','1','1','0',NULL,NULL),(540,28,2,'1','0','0','0','0','0',NULL,NULL),(541,28,3,'1','1','1','1','1','0',NULL,NULL),(542,28,4,'1','1','1','1','1','0',NULL,NULL),(543,28,5,'1','1','1','1','1','0',NULL,NULL),(544,28,6,'0','0','0','0','0','0',NULL,NULL),(545,28,7,'0','0','0','0','0','0',NULL,NULL),(546,28,8,'0','0','0','0','0','0',NULL,NULL),(547,28,9,'0','0','0','0','0','0',NULL,NULL),(548,28,10,'0','0','0','0','0','0',NULL,NULL),(549,28,11,'0','0','0','0','0','0',NULL,NULL),(550,28,12,'0','0','0','0','0','0',NULL,NULL),(551,28,13,'0','0','0','0','0','0',NULL,NULL),(552,28,14,'0','0','0','0','0','0',NULL,NULL),(553,28,15,'0','0','0','0','0','0',NULL,NULL),(554,28,16,'0','0','0','0','0','0',NULL,NULL),(555,28,17,'0','0','0','0','0','0',NULL,NULL),(556,28,18,'0','0','0','0','0','0',NULL,NULL),(557,28,19,'0','0','0','0','0','0',NULL,NULL),(558,28,20,'0','0','0','0','0','0',NULL,NULL),(559,28,21,'0','0','0','0','0','0',NULL,NULL),(560,28,22,'0','0','0','0','0','0',NULL,NULL),(561,28,23,'0','0','0','0','0','0',NULL,NULL),(562,28,24,'0','0','0','0','0','0',NULL,NULL),(563,28,25,'0','0','0','0','0','0',NULL,NULL),(564,28,26,'0','0','0','0','0','0',NULL,NULL),(565,28,27,'0','0','0','0','0','0',NULL,NULL),(566,28,28,'0','0','0','0','0','0',NULL,NULL),(567,28,29,'0','0','0','0','0','0',NULL,NULL),(568,28,30,'0','0','0','0','0','0',NULL,NULL),(569,28,31,'0','0','0','0','0','0',NULL,NULL),(570,28,32,'0','0','0','0','0','0',NULL,NULL),(571,28,33,'0','0','0','0','0','0',NULL,NULL),(572,28,34,'0','0','0','0','0','0',NULL,NULL),(573,28,35,'0','0','0','0','0','0',NULL,NULL),(574,28,36,'0','0','0','0','0','0',NULL,NULL),(575,28,37,'0','0','0','0','0','0',NULL,NULL),(576,28,38,'0','0','0','0','0','0',NULL,NULL),(577,28,39,'0','0','0','0','0','0',NULL,NULL),(578,28,40,'0','0','0','0','0','0',NULL,NULL),(579,28,41,'0','0','0','0','0','0',NULL,NULL),(580,28,42,'0','0','0','0','0','0',NULL,NULL),(581,28,43,'0','0','0','0','0','0',NULL,NULL),(582,28,44,'0','0','0','0','0','0',NULL,NULL),(583,28,45,'0','0','0','0','0','0',NULL,NULL),(584,28,46,'0','0','0','0','0','0',NULL,NULL),(585,28,47,'0','0','0','0','0','0',NULL,NULL),(586,28,48,'0','0','0','0','0','0',NULL,NULL),(587,28,49,'0','0','0','0','0','0',NULL,NULL),(588,28,50,'0','0','0','0','0','0',NULL,NULL),(589,28,51,'0','0','0','0','0','0',NULL,NULL),(590,28,52,'0','0','0','0','0','0',NULL,NULL),(591,28,53,'0','0','0','0','0','0',NULL,NULL),(592,28,54,'0','0','0','0','0','0',NULL,NULL),(593,3,1,'1','0','0','0','0','0',NULL,NULL),(594,3,2,'1','1','1','1','1','0',NULL,NULL),(595,3,3,'1','1','1','1','1','0',NULL,NULL),(596,3,4,'1','1','1','1','1','0',NULL,NULL),(597,3,5,'1','1','1','1','1','0',NULL,NULL),(598,3,6,'1','1','1','1','1','0',NULL,NULL),(599,3,7,'1','1','1','1','1','0',NULL,NULL),(600,3,8,'1','1','1','1','1','0',NULL,NULL),(601,3,9,'1','1','1','1','1','0',NULL,NULL),(602,3,10,'1','1','0','0','0','0',NULL,NULL),(603,3,11,'0','0','0','0','0','0',NULL,NULL),(604,3,12,'0','0','0','0','0','0',NULL,NULL),(605,3,13,'0','0','0','0','0','0',NULL,NULL),(606,3,14,'0','0','0','0','0','0',NULL,NULL),(607,3,15,'0','0','0','0','0','0',NULL,NULL),(608,3,16,'0','0','0','0','0','0',NULL,NULL),(609,3,17,'0','0','0','0','0','0',NULL,NULL),(610,3,18,'0','0','0','0','0','0',NULL,NULL),(611,3,19,'0','0','0','0','0','0',NULL,NULL),(612,3,20,'0','0','0','0','0','0',NULL,NULL),(613,3,21,'0','0','0','0','0','0',NULL,NULL),(614,3,22,'0','0','0','0','0','0',NULL,NULL),(615,3,23,'0','0','0','0','0','0',NULL,NULL),(616,3,24,'0','0','0','0','0','0',NULL,NULL),(617,3,25,'0','0','0','0','0','0',NULL,NULL),(618,3,26,'0','0','0','0','0','0',NULL,NULL),(619,3,27,'0','0','0','0','0','0',NULL,NULL),(620,3,28,'0','0','0','0','0','0',NULL,NULL),(621,3,29,'0','0','0','0','0','0',NULL,NULL),(622,3,30,'0','0','0','0','0','0',NULL,NULL),(623,3,31,'0','0','0','0','0','0',NULL,NULL),(624,3,32,'0','0','0','0','0','0',NULL,NULL),(625,3,33,'0','0','0','0','0','0',NULL,NULL),(626,3,34,'0','0','0','0','0','0',NULL,NULL),(627,3,35,'0','0','0','0','0','0',NULL,NULL),(628,3,36,'0','0','0','0','0','0',NULL,NULL),(629,3,37,'0','0','0','0','0','0',NULL,NULL),(630,3,38,'0','0','0','0','0','0',NULL,NULL),(631,3,39,'0','0','0','0','0','0',NULL,NULL),(632,3,40,'0','0','0','0','0','0',NULL,NULL),(633,3,41,'0','0','0','0','0','0',NULL,NULL),(634,3,42,'0','0','0','0','0','0',NULL,NULL),(635,3,43,'0','0','0','0','0','0',NULL,NULL),(636,3,44,'0','0','0','0','0','0',NULL,NULL),(637,3,45,'0','0','0','0','0','0',NULL,NULL),(638,3,46,'0','0','0','0','0','0',NULL,NULL),(639,3,47,'0','0','0','0','0','0',NULL,NULL),(640,3,48,'0','0','0','0','0','0',NULL,NULL),(641,3,49,'0','0','0','0','0','0',NULL,NULL),(642,3,50,'0','0','0','0','0','0',NULL,NULL),(643,3,51,'0','0','0','0','0','0',NULL,NULL),(644,3,52,'0','0','0','0','0','0',NULL,NULL),(645,3,53,'0','0','0','0','0','0',NULL,NULL),(646,3,54,'0','0','0','0','0','0',NULL,NULL),(647,4,1,'1','1','1','1','1','0',NULL,NULL),(648,4,2,'1','1','1','1','1','0',NULL,NULL),(649,4,3,'1','1','1','1','1','0',NULL,NULL),(650,4,4,'1','1','1','1','1','0',NULL,NULL),(651,4,5,'1','1','1','1','1','0',NULL,NULL),(652,4,6,'1','1','1','1','1','0',NULL,NULL),(653,4,7,'1','1','1','1','1','0',NULL,NULL),(654,4,8,'1','1','1','1','1','0',NULL,NULL),(655,4,9,'1','1','1','1','1','0',NULL,NULL),(656,4,10,'0','0','0','0','0','0',NULL,NULL),(657,4,11,'0','0','0','0','0','0',NULL,NULL),(658,4,12,'0','0','0','0','0','0',NULL,NULL),(659,4,13,'0','0','0','0','0','0',NULL,NULL),(660,4,14,'0','0','0','0','0','0',NULL,NULL),(661,4,15,'0','0','0','0','0','0',NULL,NULL),(662,4,16,'0','0','0','0','0','0',NULL,NULL),(663,4,17,'0','0','0','0','0','0',NULL,NULL),(664,4,18,'0','0','0','0','0','0',NULL,NULL),(665,4,19,'0','0','0','0','0','0',NULL,NULL),(666,4,20,'0','0','0','0','0','0',NULL,NULL),(667,4,21,'0','0','0','0','0','0',NULL,NULL),(668,4,22,'0','0','0','0','0','0',NULL,NULL),(669,4,23,'0','0','0','0','0','0',NULL,NULL),(670,4,24,'0','0','0','0','0','0',NULL,NULL),(671,4,25,'0','0','0','0','0','0',NULL,NULL),(672,4,26,'0','0','0','0','0','0',NULL,NULL),(673,4,27,'0','0','0','0','0','0',NULL,NULL),(674,4,28,'0','0','0','0','0','0',NULL,NULL),(675,4,29,'0','0','0','0','0','0',NULL,NULL),(676,4,30,'0','0','0','0','0','0',NULL,NULL),(677,4,31,'0','0','0','0','0','0',NULL,NULL),(678,4,32,'0','0','0','0','0','0',NULL,NULL),(679,4,33,'0','0','0','0','0','0',NULL,NULL),(680,4,34,'0','0','0','0','0','0',NULL,NULL),(681,4,35,'0','0','0','0','0','0',NULL,NULL),(682,4,36,'0','0','0','0','0','0',NULL,NULL),(683,4,37,'0','0','0','0','0','0',NULL,NULL),(684,4,38,'0','0','0','0','0','0',NULL,NULL),(685,4,39,'0','0','0','0','0','0',NULL,NULL),(686,4,40,'0','0','0','0','0','0',NULL,NULL),(687,4,41,'0','0','0','0','0','0',NULL,NULL),(688,4,42,'0','0','0','0','0','0',NULL,NULL),(689,4,43,'0','0','0','0','0','0',NULL,NULL),(690,4,44,'0','0','0','0','0','0',NULL,NULL),(691,4,45,'0','0','0','0','0','0',NULL,NULL),(692,4,46,'0','0','0','0','0','0',NULL,NULL),(693,4,47,'0','0','0','0','0','0',NULL,NULL),(694,4,48,'0','0','0','0','0','0',NULL,NULL),(695,4,49,'0','0','0','0','0','0',NULL,NULL),(696,4,50,'0','0','0','0','0','0',NULL,NULL),(697,4,51,'0','0','0','0','0','0',NULL,NULL),(698,4,52,'0','0','0','0','0','0',NULL,NULL),(699,4,53,'0','0','0','0','0','0',NULL,NULL),(700,4,54,'0','0','0','0','0','0',NULL,NULL),(701,5,1,'1','1','1','1','1','0',NULL,NULL),(702,5,2,'0','0','0','0','0','0',NULL,NULL),(703,5,3,'0','0','0','0','0','0',NULL,NULL),(704,5,4,'0','0','0','0','0','0',NULL,NULL),(705,5,5,'0','0','0','0','0','0',NULL,NULL),(706,5,6,'0','0','0','0','0','0',NULL,NULL),(707,5,7,'0','0','0','0','0','0',NULL,NULL),(708,5,8,'0','0','0','0','0','0',NULL,NULL),(709,5,9,'0','0','0','0','0','0',NULL,NULL),(710,5,10,'0','0','0','0','0','0',NULL,NULL),(711,5,11,'0','0','0','0','0','0',NULL,NULL),(712,5,12,'0','0','0','0','0','0',NULL,NULL),(713,5,13,'0','0','0','0','0','0',NULL,NULL),(714,5,14,'0','0','0','0','0','0',NULL,NULL),(715,5,15,'0','0','0','0','0','0',NULL,NULL),(716,5,16,'0','0','0','0','0','0',NULL,NULL),(717,5,17,'0','0','0','0','0','0',NULL,NULL),(718,5,18,'0','0','0','0','0','0',NULL,NULL),(719,5,19,'0','0','0','0','0','0',NULL,NULL),(720,5,20,'0','0','0','0','0','0',NULL,NULL),(721,5,21,'0','0','0','0','0','0',NULL,NULL),(722,5,22,'0','0','0','0','0','0',NULL,NULL),(723,5,23,'0','0','0','0','0','0',NULL,NULL),(724,5,24,'0','0','0','0','0','0',NULL,NULL),(725,5,25,'0','0','0','0','0','0',NULL,NULL),(726,5,26,'0','0','0','0','0','0',NULL,NULL),(727,5,27,'0','0','0','0','0','0',NULL,NULL),(728,5,28,'0','0','0','0','0','0',NULL,NULL),(729,5,29,'0','0','0','0','0','0',NULL,NULL),(730,5,30,'0','0','0','0','0','0',NULL,NULL),(731,5,31,'0','0','0','0','0','0',NULL,NULL),(732,5,32,'0','0','0','0','0','0',NULL,NULL),(733,5,33,'0','0','0','0','0','0',NULL,NULL),(734,5,34,'0','0','0','0','0','0',NULL,NULL),(735,5,35,'0','0','0','0','0','0',NULL,NULL),(736,5,36,'0','0','0','0','0','0',NULL,NULL),(737,5,37,'0','0','0','0','0','0',NULL,NULL),(738,5,38,'0','0','0','0','0','0',NULL,NULL),(739,5,39,'0','0','0','0','0','0',NULL,NULL),(740,5,40,'0','0','0','0','0','0',NULL,NULL),(741,5,41,'0','0','0','0','0','0',NULL,NULL),(742,5,42,'0','0','0','0','0','0',NULL,NULL),(743,5,43,'0','0','0','0','0','0',NULL,NULL),(744,5,44,'0','0','0','0','0','0',NULL,NULL),(745,5,45,'0','0','0','0','0','0',NULL,NULL),(746,5,46,'0','0','0','0','0','0',NULL,NULL),(747,5,47,'0','0','0','0','0','0',NULL,NULL),(748,5,48,'0','0','0','0','0','0',NULL,NULL),(749,5,49,'0','0','0','0','0','0',NULL,NULL),(750,5,50,'0','0','0','0','0','0',NULL,NULL),(751,5,51,'0','0','0','0','0','0',NULL,NULL),(752,5,52,'0','0','0','0','0','0',NULL,NULL),(753,5,53,'0','0','0','0','0','0',NULL,NULL),(754,5,54,'0','0','0','0','0','0',NULL,NULL),(755,5,55,'0','0','0','0','0','0',NULL,NULL),(756,5,56,'0','0','0','0','0','0',NULL,NULL),(757,5,57,'0','0','0','0','0','0',NULL,NULL),(758,5,58,'1','1','1','1','1','0',NULL,NULL),(759,5,59,'1','1','1','1','1','0',NULL,NULL),(760,5,60,'1','1','1','1','1','0',NULL,NULL),(761,5,61,'0','0','0','0','0','0',NULL,NULL),(762,5,62,'0','0','0','0','0','0',NULL,NULL),(763,5,63,'0','0','0','0','0','0',NULL,NULL),(764,5,64,'0','0','0','0','0','0',NULL,NULL),(765,5,65,'0','0','0','0','0','0',NULL,NULL),(766,5,66,'0','0','0','0','0','0',NULL,NULL),(767,5,67,'0','0','0','0','0','0',NULL,NULL),(768,5,68,'0','0','0','0','0','0',NULL,NULL),(769,5,69,'0','0','0','0','0','0',NULL,NULL),(770,5,70,'0','0','0','0','0','0',NULL,NULL),(771,5,71,'0','0','0','0','0','0',NULL,NULL),(772,5,72,'0','0','0','0','0','0',NULL,NULL),(773,5,73,'0','0','0','0','0','0',NULL,NULL),(774,5,74,'0','0','0','0','0','0',NULL,NULL),(775,5,75,'0','0','0','0','0','0',NULL,NULL),(776,5,76,'0','0','0','0','0','0',NULL,NULL),(777,5,77,'0','0','0','0','0','0',NULL,NULL),(778,5,78,'0','0','0','0','0','0',NULL,NULL),(779,5,79,'0','0','0','0','0','0',NULL,NULL),(780,5,80,'0','0','0','0','0','0',NULL,NULL),(781,6,1,'0','0','0','0','0','0',NULL,NULL),(782,6,2,'0','0','0','0','0','0',NULL,NULL),(783,6,3,'0','0','0','0','0','0',NULL,NULL),(784,6,4,'0','0','0','0','0','0',NULL,NULL),(785,6,5,'0','0','0','0','0','0',NULL,NULL),(786,6,6,'0','0','0','0','0','0',NULL,NULL),(787,6,7,'0','0','0','0','0','0',NULL,NULL),(788,6,8,'0','0','0','0','0','0',NULL,NULL),(789,6,9,'0','0','0','0','0','0',NULL,NULL),(790,6,10,'0','0','0','0','0','0',NULL,NULL),(791,6,11,'0','0','0','0','0','0',NULL,NULL),(792,6,12,'0','0','0','0','0','0',NULL,NULL),(793,6,13,'0','0','0','0','0','0',NULL,NULL),(794,6,14,'0','0','0','0','0','0',NULL,NULL),(795,6,15,'0','0','0','0','0','0',NULL,NULL),(796,6,16,'0','0','0','0','0','0',NULL,NULL),(797,6,17,'0','0','0','0','0','0',NULL,NULL),(798,6,18,'0','0','0','0','0','0',NULL,NULL),(799,6,19,'0','0','0','0','0','0',NULL,NULL),(800,6,20,'0','0','0','0','0','0',NULL,NULL),(801,6,21,'0','0','0','0','0','0',NULL,NULL),(802,6,22,'0','0','0','0','0','0',NULL,NULL),(803,6,23,'0','0','0','0','0','0',NULL,NULL),(804,6,24,'0','0','0','0','0','0',NULL,NULL),(805,6,25,'0','0','0','0','0','0',NULL,NULL),(806,6,26,'0','0','0','0','0','0',NULL,NULL),(807,6,27,'0','0','0','0','0','0',NULL,NULL),(808,6,28,'0','0','0','0','0','0',NULL,NULL),(809,6,29,'0','0','0','0','0','0',NULL,NULL),(810,6,30,'0','0','0','0','0','0',NULL,NULL),(811,6,31,'0','0','0','0','0','0',NULL,NULL),(812,6,32,'0','0','0','0','0','0',NULL,NULL),(813,6,33,'0','0','0','0','0','0',NULL,NULL),(814,6,34,'0','0','0','0','0','0',NULL,NULL),(815,6,35,'0','0','0','0','0','0',NULL,NULL),(816,6,36,'0','0','0','0','0','0',NULL,NULL),(817,6,37,'0','0','0','0','0','0',NULL,NULL),(818,6,38,'0','0','0','0','0','0',NULL,NULL),(819,6,39,'0','0','0','0','0','0',NULL,NULL),(820,6,40,'0','0','0','0','0','0',NULL,NULL),(821,6,41,'0','0','0','0','0','0',NULL,NULL),(822,6,42,'0','0','0','0','0','0',NULL,NULL),(823,6,43,'0','0','0','0','0','0',NULL,NULL),(824,6,44,'0','0','0','0','0','0',NULL,NULL),(825,6,45,'0','0','0','0','0','0',NULL,NULL),(826,6,46,'0','0','0','0','0','0',NULL,NULL),(827,6,47,'0','0','0','0','0','0',NULL,NULL),(828,6,48,'0','0','0','0','0','0',NULL,NULL),(829,6,49,'0','0','0','0','0','0',NULL,NULL),(830,6,50,'0','0','0','0','0','0',NULL,NULL),(831,6,51,'0','0','0','0','0','0',NULL,NULL),(832,6,52,'0','0','0','0','0','0',NULL,NULL),(833,6,53,'0','0','0','0','0','0',NULL,NULL),(834,6,54,'0','0','0','0','0','0',NULL,NULL),(835,6,55,'0','0','0','0','0','0',NULL,NULL),(836,6,56,'0','0','0','0','0','0',NULL,NULL),(837,6,57,'0','0','0','0','0','0',NULL,NULL),(838,6,58,'1','0','0','0','0','0',NULL,NULL),(839,6,59,'1','0','0','0','0','0',NULL,NULL),(840,6,60,'1','0','0','0','0','0',NULL,NULL),(841,6,61,'0','0','0','0','0','0',NULL,NULL),(842,6,62,'0','0','0','0','0','0',NULL,NULL),(843,6,63,'0','0','0','0','0','0',NULL,NULL),(844,6,64,'0','0','0','0','0','0',NULL,NULL),(845,6,65,'0','0','0','0','0','0',NULL,NULL),(846,6,66,'0','0','0','0','0','0',NULL,NULL),(847,6,67,'0','0','0','0','0','0',NULL,NULL),(848,6,68,'0','0','0','0','0','0',NULL,NULL),(849,6,69,'0','0','0','0','0','0',NULL,NULL),(850,6,70,'0','0','0','0','0','0',NULL,NULL),(851,6,71,'0','0','0','0','0','0',NULL,NULL),(852,6,72,'0','0','0','0','0','0',NULL,NULL),(853,6,73,'0','0','0','0','0','0',NULL,NULL),(854,6,74,'0','0','0','0','0','0',NULL,NULL),(855,6,75,'0','0','0','0','0','0',NULL,NULL),(856,6,76,'0','0','0','0','0','0',NULL,NULL),(857,6,77,'0','0','0','0','0','0',NULL,NULL),(858,6,78,'0','0','0','0','0','0',NULL,NULL),(859,6,79,'0','0','0','0','0','0',NULL,NULL),(860,6,80,'0','0','0','0','0','0',NULL,NULL),(861,7,1,'1','1','1','1','1','0',NULL,NULL),(862,7,2,'1','1','1','1','1','0',NULL,NULL),(863,7,3,'1','1','1','1','1','0',NULL,NULL),(864,7,4,'0','0','0','0','0','0',NULL,NULL),(865,7,5,'0','0','0','0','0','0',NULL,NULL),(866,7,6,'0','0','0','0','0','0',NULL,NULL),(867,7,7,'1','1','1','1','1','0',NULL,NULL),(868,7,8,'0','0','0','0','0','0',NULL,NULL),(869,7,9,'1','1','1','0','0','0',NULL,NULL),(870,7,10,'0','0','0','0','0','0',NULL,NULL),(871,7,11,'0','0','0','0','0','0',NULL,NULL),(872,7,12,'0','0','0','0','0','0',NULL,NULL),(873,7,13,'0','0','0','0','0','0',NULL,NULL),(874,7,14,'0','0','0','0','0','0',NULL,NULL),(875,7,15,'0','0','0','0','0','0',NULL,NULL),(876,7,16,'0','0','0','0','0','0',NULL,NULL),(877,7,17,'0','0','0','0','0','0',NULL,NULL),(878,7,18,'0','0','0','0','0','0',NULL,NULL),(879,7,19,'0','0','0','0','0','0',NULL,NULL),(880,7,20,'0','0','0','0','0','0',NULL,NULL),(881,7,21,'0','0','0','0','0','0',NULL,NULL),(882,7,22,'0','0','0','0','0','0',NULL,NULL),(883,7,23,'0','0','0','0','0','0',NULL,NULL),(884,7,24,'0','0','0','0','0','0',NULL,NULL),(885,7,25,'0','0','0','0','0','0',NULL,NULL),(886,7,26,'0','0','0','0','0','0',NULL,NULL),(887,7,27,'0','0','0','0','0','0',NULL,NULL),(888,7,28,'1','1','1','1','1','0',NULL,NULL),(889,7,29,'0','0','0','0','0','0',NULL,NULL),(890,7,30,'0','0','0','0','0','0',NULL,NULL),(891,7,31,'0','0','0','0','0','0',NULL,NULL),(892,7,32,'0','0','0','0','0','0',NULL,NULL),(893,7,33,'0','0','0','0','0','0',NULL,NULL),(894,7,34,'0','0','0','0','0','0',NULL,NULL),(895,7,35,'0','0','0','0','0','0',NULL,NULL),(896,7,36,'0','0','0','0','0','0',NULL,NULL),(897,7,37,'0','0','0','0','0','0',NULL,NULL),(898,7,38,'0','0','0','0','0','0',NULL,NULL),(899,7,39,'0','0','0','0','0','0',NULL,NULL),(900,7,40,'0','0','0','0','0','0',NULL,NULL),(901,7,41,'0','0','0','0','0','0',NULL,NULL),(902,7,42,'0','0','0','0','0','0',NULL,NULL),(903,7,43,'0','0','0','0','0','0',NULL,NULL),(904,7,44,'0','0','0','0','0','0',NULL,NULL),(905,7,45,'0','0','0','0','0','0',NULL,NULL),(906,7,46,'0','0','0','0','0','0',NULL,NULL),(907,7,47,'0','0','0','0','0','0',NULL,NULL),(908,7,48,'0','0','0','0','0','0',NULL,NULL),(909,7,49,'0','0','0','0','0','0',NULL,NULL),(910,7,50,'0','0','0','0','0','0',NULL,NULL),(911,7,51,'0','0','0','0','0','0',NULL,NULL),(912,7,52,'0','0','0','0','0','0',NULL,NULL),(913,7,53,'0','0','0','0','0','0',NULL,NULL),(914,7,54,'0','0','0','0','0','0',NULL,NULL),(915,7,55,'0','0','0','0','0','0',NULL,NULL),(916,7,56,'0','0','0','0','0','0',NULL,NULL),(917,7,57,'0','0','0','0','0','0',NULL,NULL),(918,7,58,'1','1','0','0','0','0',NULL,NULL),(919,7,59,'0','0','0','0','0','0',NULL,NULL),(920,7,60,'0','0','0','0','0','0',NULL,NULL),(921,7,61,'0','0','0','0','0','0',NULL,NULL),(922,7,62,'0','0','0','0','0','0',NULL,NULL),(923,7,63,'0','0','0','0','0','0',NULL,NULL),(924,7,64,'0','0','0','0','0','0',NULL,NULL),(925,7,65,'0','0','0','0','0','0',NULL,NULL),(926,7,66,'0','0','0','0','0','0',NULL,NULL),(927,7,67,'0','0','0','0','0','0',NULL,NULL),(928,7,68,'0','0','0','0','0','0',NULL,NULL),(929,2,58,'1','1','1','1','1','0',NULL,NULL),(930,2,55,'1','1','1','1','1','0',NULL,NULL),(931,2,56,'1','1','1','1','1','0',NULL,NULL),(932,2,57,'1','1','1','1','1','0',NULL,NULL),(933,2,59,'1','1','1','1','1','0',NULL,NULL),(934,2,60,'1','1','1','1','1','0',NULL,NULL),(935,2,68,'1','1','1','1','1','0',NULL,NULL),(936,2,61,'1','1','1','1','1','0',NULL,NULL),(937,8,1,'1','1','1','1','1','0',NULL,NULL),(938,8,2,'1','1','1','1','1','0',NULL,NULL),(939,8,3,'1','1','1','1','1','0',NULL,NULL),(940,8,4,'1','1','1','1','1','0',NULL,NULL),(941,8,5,'0','0','0','0','0','0',NULL,NULL),(942,8,6,'0','0','0','0','0','0',NULL,NULL),(943,8,7,'1','1','1','1','1','0',NULL,NULL),(944,8,8,'0','0','0','0','0','0',NULL,NULL),(945,8,9,'1','1','1','1','0','0',NULL,NULL),(946,8,10,'0','0','0','0','0','0',NULL,NULL),(947,8,11,'0','0','0','0','0','0',NULL,NULL),(948,8,12,'0','0','0','0','0','0',NULL,NULL),(949,8,13,'0','0','0','0','0','0',NULL,NULL),(950,8,14,'1','1','1','1','0','0',NULL,NULL),(951,8,15,'0','0','0','0','0','0',NULL,NULL),(952,8,16,'0','0','0','0','0','0',NULL,NULL),(953,8,17,'0','0','0','0','0','0',NULL,NULL),(954,8,18,'1','1','1','1','0','0',NULL,NULL),(955,8,19,'0','0','0','0','0','0',NULL,NULL),(956,8,20,'0','0','0','0','0','0',NULL,NULL),(957,8,21,'0','0','0','0','0','0',NULL,NULL),(958,8,22,'0','0','0','0','0','0',NULL,NULL),(959,8,23,'0','0','0','0','0','0',NULL,NULL),(960,8,24,'0','0','0','0','0','0',NULL,NULL),(961,8,25,'0','0','0','0','0','0',NULL,NULL),(962,8,26,'0','0','0','0','0','0',NULL,NULL),(963,8,27,'0','0','0','0','0','0',NULL,NULL),(964,8,28,'1','1','1','1','0','0',NULL,NULL),(965,8,29,'0','0','0','0','0','0',NULL,NULL),(966,8,30,'0','0','0','0','0','0',NULL,NULL),(967,8,31,'0','0','0','0','0','0',NULL,NULL),(968,8,32,'0','0','0','0','0','0',NULL,NULL),(969,8,33,'0','0','0','0','0','0',NULL,NULL),(970,8,34,'0','0','0','0','0','0',NULL,NULL),(971,8,35,'0','0','0','0','0','0',NULL,NULL),(972,8,36,'0','0','0','0','0','0',NULL,NULL),(973,8,37,'0','0','0','0','0','0',NULL,NULL),(974,8,38,'0','0','0','0','0','0',NULL,NULL),(975,8,39,'0','0','0','0','0','0',NULL,NULL),(976,8,40,'0','0','0','0','0','0',NULL,NULL),(977,8,41,'0','0','0','0','0','0',NULL,NULL),(978,8,42,'0','0','0','0','0','0',NULL,NULL),(979,8,43,'0','0','0','0','0','0',NULL,NULL),(980,8,44,'0','0','0','0','0','0',NULL,NULL),(981,8,45,'0','0','0','0','0','0',NULL,NULL),(982,8,46,'0','0','0','0','0','0',NULL,NULL),(983,8,47,'0','0','0','0','0','0',NULL,NULL),(984,8,48,'0','0','0','0','0','0',NULL,NULL),(985,8,49,'0','0','0','0','0','0',NULL,NULL),(986,8,50,'0','0','0','0','0','0',NULL,NULL),(987,8,51,'0','0','0','0','0','0',NULL,NULL),(988,8,52,'0','0','0','0','0','0',NULL,NULL),(989,8,53,'0','0','0','0','0','0',NULL,NULL),(990,8,54,'0','0','0','0','0','0',NULL,NULL),(991,8,55,'0','0','0','0','0','0',NULL,NULL),(992,8,56,'0','0','0','0','0','0',NULL,NULL),(993,8,57,'0','0','0','0','0','0',NULL,NULL),(994,8,58,'1','1','1','1','1','0',NULL,NULL),(995,8,59,'1','1','1','1','1','0',NULL,NULL),(996,8,60,'0','0','0','0','0','0',NULL,NULL),(997,8,61,'1','1','1','1','0','0',NULL,NULL),(998,8,62,'0','0','0','0','0','0',NULL,NULL),(999,8,63,'0','0','0','0','0','0',NULL,NULL),(1000,8,64,'0','0','0','0','0','0',NULL,NULL),(1001,8,65,'0','0','0','0','0','0',NULL,NULL),(1002,8,66,'0','0','0','0','0','0',NULL,NULL),(1003,8,67,'0','0','0','0','0','0',NULL,NULL),(1004,8,68,'0','0','0','0','0','0',NULL,NULL),(1005,8,69,'0','0','0','0','0','0',NULL,NULL),(1006,8,70,'0','0','0','0','0','0',NULL,NULL),(1007,8,71,'0','0','0','0','0','0',NULL,NULL),(1008,8,72,'1','1','1','1','1','0',NULL,NULL),(1009,8,73,'1','1','1','1','1','0',NULL,NULL),(1010,8,74,'1','1','1','1','1','0',NULL,NULL),(1011,8,75,'1','1','1','1','1','0',NULL,NULL),(1012,8,76,'1','1','1','1','0','0',NULL,NULL),(1013,8,77,'0','0','0','0','0','0',NULL,NULL),(1014,8,78,'0','0','0','0','0','0',NULL,NULL),(1015,8,79,'0','0','0','0','0','0',NULL,NULL),(1016,8,80,'0','0','0','0','0','0',NULL,NULL),(1017,8,81,'0','0','0','0','0','0',NULL,NULL),(1018,8,82,'0','0','0','0','0','0',NULL,NULL),(1019,9,1,'1','1','1','1','0','0',NULL,NULL),(1020,9,2,'1','1','1','1','0','0',NULL,NULL),(1021,9,3,'1','1','1','1','0','0',NULL,NULL),(1022,9,4,'0','0','0','0','0','0',NULL,NULL),(1023,9,5,'1','1','1','1','0','0',NULL,NULL),(1024,9,6,'0','0','0','0','0','0',NULL,NULL),(1025,9,7,'1','1','1','1','0','0',NULL,NULL),(1026,9,8,'0','0','0','0','0','0',NULL,NULL),(1027,9,9,'1','1','1','1','0','0',NULL,NULL),(1028,9,10,'0','0','0','0','0','0',NULL,NULL),(1029,9,11,'0','0','0','0','0','0',NULL,NULL),(1030,9,12,'0','0','0','0','0','0',NULL,NULL),(1031,9,13,'0','0','0','0','0','0',NULL,NULL),(1032,9,14,'0','0','0','0','0','0',NULL,NULL),(1033,9,15,'0','0','0','0','0','0',NULL,NULL),(1034,9,16,'0','0','0','0','0','0',NULL,NULL),(1035,9,17,'0','0','0','0','0','0',NULL,NULL),(1036,9,18,'0','0','0','0','0','0',NULL,NULL),(1037,9,19,'0','0','0','0','0','0',NULL,NULL),(1038,9,20,'0','0','0','0','0','0',NULL,NULL),(1039,9,21,'0','0','0','0','0','0',NULL,NULL),(1040,9,22,'0','0','0','0','0','0',NULL,NULL),(1041,9,23,'0','0','0','0','0','0',NULL,NULL),(1042,9,24,'0','0','0','0','0','0',NULL,NULL),(1043,9,25,'0','0','0','0','0','0',NULL,NULL),(1044,9,26,'0','0','0','0','0','0',NULL,NULL),(1045,9,27,'0','0','0','0','0','0',NULL,NULL),(1046,9,28,'0','0','0','0','0','0',NULL,NULL),(1047,9,29,'0','0','0','0','0','0',NULL,NULL),(1048,9,30,'0','0','0','0','0','0',NULL,NULL),(1049,9,31,'0','0','0','0','0','0',NULL,NULL),(1050,9,32,'0','0','0','0','0','0',NULL,NULL),(1051,9,33,'0','0','0','0','0','0',NULL,NULL),(1052,9,34,'0','0','0','0','0','0',NULL,NULL),(1053,9,35,'0','0','0','0','0','0',NULL,NULL),(1054,9,36,'0','0','0','0','0','0',NULL,NULL),(1055,9,37,'0','0','0','0','0','0',NULL,NULL),(1056,9,38,'0','0','0','0','0','0',NULL,NULL),(1057,9,39,'0','0','0','0','0','0',NULL,NULL),(1058,9,40,'0','0','0','0','0','0',NULL,NULL),(1059,9,41,'0','0','0','0','0','0',NULL,NULL),(1060,9,42,'0','0','0','0','0','0',NULL,NULL),(1061,9,43,'0','0','0','0','0','0',NULL,NULL),(1062,9,44,'0','0','0','0','0','0',NULL,NULL),(1063,9,45,'0','0','0','0','0','0',NULL,NULL),(1064,9,46,'0','0','0','0','0','0',NULL,NULL),(1065,9,47,'0','0','0','0','0','0',NULL,NULL),(1066,9,48,'0','0','0','0','0','0',NULL,NULL),(1067,9,49,'0','0','0','0','0','0',NULL,NULL),(1068,9,50,'0','0','0','0','0','0',NULL,NULL),(1069,9,51,'0','0','0','0','0','0',NULL,NULL),(1070,9,52,'0','0','0','0','0','0',NULL,NULL),(1071,9,53,'0','0','0','0','0','0',NULL,NULL),(1072,9,54,'0','0','0','0','0','0',NULL,NULL),(1073,9,55,'0','0','0','0','0','0',NULL,NULL),(1074,9,56,'0','0','0','0','0','0',NULL,NULL),(1075,9,57,'0','0','0','0','0','0',NULL,NULL),(1076,9,58,'1','1','1','1','0','0',NULL,NULL),(1077,9,59,'1','1','1','1','0','0',NULL,NULL),(1078,9,60,'1','1','1','1','0','0',NULL,NULL),(1079,9,61,'0','0','0','0','0','0',NULL,NULL),(1080,9,62,'0','0','0','0','0','0',NULL,NULL),(1081,9,63,'0','0','0','0','0','0',NULL,NULL),(1082,9,64,'0','0','0','0','0','0',NULL,NULL),(1083,9,65,'0','0','0','0','0','0',NULL,NULL),(1084,9,66,'0','0','0','0','0','0',NULL,NULL),(1085,9,67,'0','0','0','0','0','0',NULL,NULL),(1086,9,68,'1','1','1','1','0','0',NULL,NULL),(1087,9,69,'0','0','0','0','0','0',NULL,NULL),(1088,9,70,'0','0','0','0','0','0',NULL,NULL),(1089,9,71,'0','0','0','0','0','0',NULL,NULL),(1090,9,72,'1','1','1','1','0','0',NULL,NULL),(1091,9,73,'1','1','1','1','0','0',NULL,NULL),(1092,9,74,'1','1','1','1','0','0',NULL,NULL),(1093,9,75,'1','1','1','1','0','0',NULL,NULL),(1094,9,76,'1','1','1','1','0','0',NULL,NULL),(1095,9,77,'1','1','1','1','0','0',NULL,NULL),(1096,9,78,'0','0','0','0','0','0',NULL,NULL),(1097,9,79,'0','0','0','0','0','0',NULL,NULL),(1098,9,80,'0','0','0','0','0','0',NULL,NULL),(1099,9,81,'0','0','0','0','0','0',NULL,NULL),(1100,9,82,'0','0','0','0','0','0',NULL,NULL),(1101,10,1,'1','1','1','1','0','0',NULL,NULL),(1102,10,2,'1','1','1','1','0','0',NULL,NULL),(1103,10,3,'1','1','1','1','0','0',NULL,NULL),(1104,10,4,'0','0','0','0','0','0',NULL,NULL),(1105,10,5,'1','1','1','1','0','0',NULL,NULL),(1106,10,6,'0','0','0','0','0','0',NULL,NULL),(1107,10,7,'1','1','1','1','0','0',NULL,NULL),(1108,10,8,'0','0','0','0','0','0',NULL,NULL),(1109,10,9,'1','1','1','1','0','0',NULL,NULL),(1110,10,10,'0','0','0','0','0','0',NULL,NULL),(1111,10,11,'0','0','0','0','0','0',NULL,NULL),(1112,10,12,'0','0','0','0','0','0',NULL,NULL),(1113,10,13,'0','0','0','0','0','0',NULL,NULL),(1114,10,14,'0','0','0','0','0','0',NULL,NULL),(1115,10,15,'0','0','0','0','0','0',NULL,NULL),(1116,10,16,'0','0','0','0','0','0',NULL,NULL),(1117,10,17,'0','0','0','0','0','0',NULL,NULL),(1118,10,18,'0','0','0','0','0','0',NULL,NULL),(1119,10,19,'0','0','0','0','0','0',NULL,NULL),(1120,10,20,'0','0','0','0','0','0',NULL,NULL),(1121,10,21,'0','0','0','0','0','0',NULL,NULL),(1122,10,22,'0','0','0','0','0','0',NULL,NULL),(1123,10,23,'0','0','0','0','0','0',NULL,NULL),(1124,10,24,'0','0','0','0','0','0',NULL,NULL),(1125,10,25,'0','0','0','0','0','0',NULL,NULL),(1126,10,26,'0','0','0','0','0','0',NULL,NULL),(1127,10,27,'0','0','0','0','0','0',NULL,NULL),(1128,10,28,'0','0','0','0','0','0',NULL,NULL),(1129,10,29,'0','0','0','0','0','0',NULL,NULL),(1130,10,30,'0','0','0','0','0','0',NULL,NULL),(1131,10,31,'0','0','0','0','0','0',NULL,NULL),(1132,10,32,'0','0','0','0','0','0',NULL,NULL),(1133,10,33,'0','0','0','0','0','0',NULL,NULL),(1134,10,34,'0','0','0','0','0','0',NULL,NULL),(1135,10,35,'0','0','0','0','0','0',NULL,NULL),(1136,10,36,'0','0','0','0','0','0',NULL,NULL),(1137,10,37,'0','0','0','0','0','0',NULL,NULL),(1138,10,38,'0','0','0','0','0','0',NULL,NULL),(1139,10,39,'0','0','0','0','0','0',NULL,NULL),(1140,10,40,'0','0','0','0','0','0',NULL,NULL),(1141,10,41,'0','0','0','0','0','0',NULL,NULL),(1142,10,42,'0','0','0','0','0','0',NULL,NULL),(1143,10,43,'0','0','0','0','0','0',NULL,NULL),(1144,10,44,'0','0','0','0','0','0',NULL,NULL),(1145,10,45,'0','0','0','0','0','0',NULL,NULL),(1146,10,46,'0','0','0','0','0','0',NULL,NULL),(1147,10,47,'0','0','0','0','0','0',NULL,NULL),(1148,10,48,'0','0','0','0','0','0',NULL,NULL),(1149,10,49,'0','0','0','0','0','0',NULL,NULL),(1150,10,50,'0','0','0','0','0','0',NULL,NULL),(1151,10,51,'0','0','0','0','0','0',NULL,NULL),(1152,10,52,'0','0','0','0','0','0',NULL,NULL),(1153,10,53,'0','0','0','0','0','0',NULL,NULL),(1154,10,54,'0','0','0','0','0','0',NULL,NULL),(1155,10,55,'0','0','0','0','0','0',NULL,NULL),(1156,10,56,'0','0','0','0','0','0',NULL,NULL),(1157,10,57,'0','0','0','0','0','0',NULL,NULL),(1158,10,58,'1','1','1','1','0','0',NULL,NULL),(1159,10,59,'1','1','1','1','0','0',NULL,NULL),(1160,10,60,'1','1','1','1','0','0',NULL,NULL),(1161,10,61,'0','0','0','0','0','0',NULL,NULL),(1162,10,62,'0','0','0','0','0','0',NULL,NULL),(1163,10,63,'0','0','0','0','0','0',NULL,NULL),(1164,10,64,'0','0','0','0','0','0',NULL,NULL),(1165,10,65,'0','0','0','0','0','0',NULL,NULL),(1166,10,66,'0','0','0','0','0','0',NULL,NULL),(1167,10,67,'0','0','0','0','0','0',NULL,NULL),(1168,10,68,'1','1','1','1','0','0',NULL,NULL),(1169,10,69,'0','0','0','0','0','0',NULL,NULL),(1170,10,70,'0','0','0','0','0','0',NULL,NULL),(1171,10,71,'0','0','0','0','0','0',NULL,NULL),(1172,10,72,'1','1','1','1','0','0',NULL,NULL),(1173,10,73,'1','1','1','1','0','0',NULL,NULL),(1174,10,74,'1','1','1','1','0','0',NULL,NULL),(1175,10,75,'1','1','1','1','0','0',NULL,NULL),(1176,10,76,'1','1','1','1','0','0',NULL,NULL),(1177,10,77,'1','1','1','1','0','0',NULL,NULL),(1178,10,78,'0','0','0','0','0','0',NULL,NULL),(1179,10,79,'0','0','0','0','0','0',NULL,NULL),(1180,10,80,'0','0','0','0','0','0',NULL,NULL),(1181,10,81,'0','0','0','0','0','0',NULL,NULL),(1182,10,82,'0','0','0','0','0','0',NULL,NULL),(1183,11,1,'1','1','1','1','0','0',NULL,NULL),(1184,11,2,'1','1','1','1','0','0',NULL,NULL),(1185,11,3,'1','1','1','1','0','0',NULL,NULL),(1186,11,4,'0','0','0','0','0','0',NULL,NULL),(1187,11,5,'1','1','1','1','0','0',NULL,NULL),(1188,11,6,'0','0','0','0','0','0',NULL,NULL),(1189,11,7,'1','1','1','1','0','0',NULL,NULL),(1190,11,8,'0','0','0','0','0','0',NULL,NULL),(1191,11,9,'1','1','1','1','0','0',NULL,NULL),(1192,11,10,'0','0','0','0','0','0',NULL,NULL),(1193,11,11,'0','0','0','0','0','0',NULL,NULL),(1194,11,12,'0','0','0','0','0','0',NULL,NULL),(1195,11,13,'0','0','0','0','0','0',NULL,NULL),(1196,11,14,'0','0','0','0','0','0',NULL,NULL),(1197,11,15,'0','0','0','0','0','0',NULL,NULL),(1198,11,16,'0','0','0','0','0','0',NULL,NULL),(1199,11,17,'0','0','0','0','0','0',NULL,NULL),(1200,11,18,'0','0','0','0','0','0',NULL,NULL),(1201,11,19,'0','0','0','0','0','0',NULL,NULL),(1202,11,20,'0','0','0','0','0','0',NULL,NULL),(1203,11,21,'0','0','0','0','0','0',NULL,NULL),(1204,11,22,'0','0','0','0','0','0',NULL,NULL),(1205,11,23,'0','0','0','0','0','0',NULL,NULL),(1206,11,24,'0','0','0','0','0','0',NULL,NULL),(1207,11,25,'0','0','0','0','0','0',NULL,NULL),(1208,11,26,'0','0','0','0','0','0',NULL,NULL),(1209,11,27,'0','0','0','0','0','0',NULL,NULL),(1210,11,28,'0','0','0','0','0','0',NULL,NULL),(1211,11,29,'0','0','0','0','0','0',NULL,NULL),(1212,11,30,'0','0','0','0','0','0',NULL,NULL),(1213,11,31,'0','0','0','0','0','0',NULL,NULL),(1214,11,32,'0','0','0','0','0','0',NULL,NULL),(1215,11,33,'0','0','0','0','0','0',NULL,NULL),(1216,11,34,'0','0','0','0','0','0',NULL,NULL),(1217,11,35,'0','0','0','0','0','0',NULL,NULL),(1218,11,36,'0','0','0','0','0','0',NULL,NULL),(1219,11,37,'0','0','0','0','0','0',NULL,NULL),(1220,11,38,'0','0','0','0','0','0',NULL,NULL),(1221,11,39,'0','0','0','0','0','0',NULL,NULL),(1222,11,40,'0','0','0','0','0','0',NULL,NULL),(1223,11,41,'0','0','0','0','0','0',NULL,NULL),(1224,11,42,'0','0','0','0','0','0',NULL,NULL),(1225,11,43,'0','0','0','0','0','0',NULL,NULL),(1226,11,44,'0','0','0','0','0','0',NULL,NULL),(1227,11,45,'0','0','0','0','0','0',NULL,NULL),(1228,11,46,'0','0','0','0','0','0',NULL,NULL),(1229,11,47,'0','0','0','0','0','0',NULL,NULL),(1230,11,48,'0','0','0','0','0','0',NULL,NULL),(1231,11,49,'0','0','0','0','0','0',NULL,NULL),(1232,11,50,'0','0','0','0','0','0',NULL,NULL),(1233,11,51,'0','0','0','0','0','0',NULL,NULL),(1234,11,52,'0','0','0','0','0','0',NULL,NULL),(1235,11,53,'0','0','0','0','0','0',NULL,NULL),(1236,11,54,'0','0','0','0','0','0',NULL,NULL),(1237,11,55,'0','0','0','0','0','0',NULL,NULL),(1238,11,56,'0','0','0','0','0','0',NULL,NULL),(1239,11,57,'0','0','0','0','0','0',NULL,NULL),(1240,11,58,'0','0','0','0','0','0',NULL,NULL),(1241,11,59,'0','0','0','0','0','0',NULL,NULL),(1242,11,60,'0','0','0','0','0','0',NULL,NULL),(1243,11,61,'0','0','0','0','0','0',NULL,NULL),(1244,11,62,'0','0','0','0','0','0',NULL,NULL),(1245,11,63,'0','0','0','0','0','0',NULL,NULL),(1246,11,64,'0','0','0','0','0','0',NULL,NULL),(1247,11,65,'0','0','0','0','0','0',NULL,NULL),(1248,11,66,'0','0','0','0','0','0',NULL,NULL),(1249,11,67,'0','0','0','0','0','0',NULL,NULL),(1250,11,68,'0','0','0','0','0','0',NULL,NULL),(1251,11,69,'0','0','0','0','0','0',NULL,NULL),(1252,11,70,'0','0','0','0','0','0',NULL,NULL),(1253,11,71,'0','0','0','0','0','0',NULL,NULL),(1254,11,72,'0','0','0','0','0','0',NULL,NULL),(1255,11,73,'0','0','0','0','0','0',NULL,NULL),(1256,11,74,'0','0','0','0','0','0',NULL,NULL),(1257,11,75,'0','0','0','0','0','0',NULL,NULL),(1258,11,76,'0','0','0','0','0','0',NULL,NULL),(1259,11,77,'0','0','0','0','0','0',NULL,NULL),(1260,11,78,'0','0','0','0','0','0',NULL,NULL),(1261,11,79,'0','0','0','0','0','0',NULL,NULL),(1262,11,80,'0','0','0','0','0','0',NULL,NULL),(1263,11,81,'0','0','0','0','0','0',NULL,NULL),(1264,11,82,'0','0','0','0','0','0',NULL,NULL),(1265,12,1,'1','1','1','1','0','0',NULL,NULL),(1266,12,2,'1','1','1','1','0','0',NULL,NULL),(1267,12,3,'1','1','1','1','0','0',NULL,NULL),(1268,12,4,'0','0','0','0','0','0',NULL,NULL),(1269,12,5,'1','1','1','1','0','0',NULL,NULL),(1270,12,6,'0','0','0','0','0','0',NULL,NULL),(1271,12,7,'1','1','1','1','0','0',NULL,NULL),(1272,12,8,'0','0','0','0','0','0',NULL,NULL),(1273,12,9,'1','1','1','1','0','0',NULL,NULL),(1274,12,10,'0','0','0','0','0','0',NULL,NULL),(1275,12,11,'0','0','0','0','0','0',NULL,NULL),(1276,12,12,'0','0','0','0','0','0',NULL,NULL),(1277,12,13,'0','0','0','0','0','0',NULL,NULL),(1278,12,14,'0','0','0','0','0','0',NULL,NULL),(1279,12,15,'0','0','0','0','0','0',NULL,NULL),(1280,12,16,'0','0','0','0','0','0',NULL,NULL),(1281,12,17,'0','0','0','0','0','0',NULL,NULL),(1282,12,18,'0','0','0','0','0','0',NULL,NULL),(1283,12,19,'0','0','0','0','0','0',NULL,NULL),(1284,12,20,'0','0','0','0','0','0',NULL,NULL),(1285,12,21,'0','0','0','0','0','0',NULL,NULL),(1286,12,22,'0','0','0','0','0','0',NULL,NULL),(1287,12,23,'0','0','0','0','0','0',NULL,NULL),(1288,12,24,'0','0','0','0','0','0',NULL,NULL),(1289,12,25,'0','0','0','0','0','0',NULL,NULL),(1290,12,26,'0','0','0','0','0','0',NULL,NULL),(1291,12,27,'0','0','0','0','0','0',NULL,NULL),(1292,12,28,'0','0','0','0','0','0',NULL,NULL),(1293,12,29,'0','0','0','0','0','0',NULL,NULL),(1294,12,30,'0','0','0','0','0','0',NULL,NULL),(1295,12,31,'0','0','0','0','0','0',NULL,NULL),(1296,12,32,'0','0','0','0','0','0',NULL,NULL),(1297,12,33,'0','0','0','0','0','0',NULL,NULL),(1298,12,34,'0','0','0','0','0','0',NULL,NULL),(1299,12,35,'0','0','0','0','0','0',NULL,NULL),(1300,12,36,'0','0','0','0','0','0',NULL,NULL),(1301,12,37,'0','0','0','0','0','0',NULL,NULL),(1302,12,38,'0','0','0','0','0','0',NULL,NULL),(1303,12,39,'0','0','0','0','0','0',NULL,NULL),(1304,12,40,'0','0','0','0','0','0',NULL,NULL),(1305,12,41,'0','0','0','0','0','0',NULL,NULL),(1306,12,42,'0','0','0','0','0','0',NULL,NULL),(1307,12,43,'0','0','0','0','0','0',NULL,NULL),(1308,12,44,'0','0','0','0','0','0',NULL,NULL),(1309,12,45,'0','0','0','0','0','0',NULL,NULL),(1310,12,46,'0','0','0','0','0','0',NULL,NULL),(1311,12,47,'0','0','0','0','0','0',NULL,NULL),(1312,12,48,'0','0','0','0','0','0',NULL,NULL),(1313,12,49,'0','0','0','0','0','0',NULL,NULL),(1314,12,50,'0','0','0','0','0','0',NULL,NULL),(1315,12,51,'0','0','0','0','0','0',NULL,NULL),(1316,12,52,'0','0','0','0','0','0',NULL,NULL),(1317,12,53,'0','0','0','0','0','0',NULL,NULL),(1318,12,54,'0','0','0','0','0','0',NULL,NULL),(1319,12,55,'0','0','0','0','0','0',NULL,NULL),(1320,12,56,'0','0','0','0','0','0',NULL,NULL),(1321,12,57,'0','0','0','0','0','0',NULL,NULL),(1322,12,58,'0','0','0','0','0','0',NULL,NULL),(1323,12,59,'0','0','0','0','0','0',NULL,NULL),(1324,12,60,'0','0','0','0','0','0',NULL,NULL),(1325,12,61,'0','0','0','0','0','0',NULL,NULL),(1326,12,62,'0','0','0','0','0','0',NULL,NULL),(1327,12,63,'0','0','0','0','0','0',NULL,NULL),(1328,12,64,'0','0','0','0','0','0',NULL,NULL),(1329,12,65,'0','0','0','0','0','0',NULL,NULL),(1330,12,66,'0','0','0','0','0','0',NULL,NULL),(1331,12,67,'0','0','0','0','0','0',NULL,NULL),(1332,12,68,'0','0','0','0','0','0',NULL,NULL),(1333,12,69,'0','0','0','0','0','0',NULL,NULL),(1334,12,70,'0','0','0','0','0','0',NULL,NULL),(1335,12,71,'0','0','0','0','0','0',NULL,NULL),(1336,12,72,'0','0','0','0','0','0',NULL,NULL),(1337,12,73,'0','0','0','0','0','0',NULL,NULL),(1338,12,74,'0','0','0','0','0','0',NULL,NULL),(1339,12,75,'0','0','0','0','0','0',NULL,NULL),(1340,12,76,'0','0','0','0','0','0',NULL,NULL),(1341,12,77,'0','0','0','0','0','0',NULL,NULL),(1342,12,78,'0','0','0','0','0','0',NULL,NULL),(1343,12,79,'0','0','0','0','0','0',NULL,NULL),(1344,12,80,'0','0','0','0','0','0',NULL,NULL),(1345,12,81,'0','0','0','0','0','0',NULL,NULL),(1346,12,82,'0','0','0','0','0','0',NULL,NULL),(1347,13,1,'1','1','1','1','0','0',NULL,NULL),(1348,13,2,'1','1','1','1','0','0',NULL,NULL),(1349,13,3,'1','1','1','1','0','0',NULL,NULL),(1350,13,4,'0','0','0','0','0','0',NULL,NULL),(1351,13,5,'1','1','1','1','0','0',NULL,NULL),(1352,13,6,'0','0','0','0','0','0',NULL,NULL),(1353,13,7,'1','1','1','1','0','0',NULL,NULL),(1354,13,8,'0','0','0','0','0','0',NULL,NULL),(1355,13,9,'1','1','1','1','0','0',NULL,NULL),(1356,13,10,'0','0','0','0','0','0',NULL,NULL),(1357,13,11,'0','0','0','0','0','0',NULL,NULL),(1358,13,12,'0','0','0','0','0','0',NULL,NULL),(1359,13,13,'0','0','0','0','0','0',NULL,NULL),(1360,13,14,'0','0','0','0','0','0',NULL,NULL),(1361,13,15,'0','0','0','0','0','0',NULL,NULL),(1362,13,16,'0','0','0','0','0','0',NULL,NULL),(1363,13,17,'0','0','0','0','0','0',NULL,NULL),(1364,13,18,'0','0','0','0','0','0',NULL,NULL),(1365,13,19,'0','0','0','0','0','0',NULL,NULL),(1366,13,20,'0','0','0','0','0','0',NULL,NULL),(1367,13,21,'0','0','0','0','0','0',NULL,NULL),(1368,13,22,'0','0','0','0','0','0',NULL,NULL),(1369,13,23,'0','0','0','0','0','0',NULL,NULL),(1370,13,24,'0','0','0','0','0','0',NULL,NULL),(1371,13,25,'0','0','0','0','0','0',NULL,NULL),(1372,13,26,'0','0','0','0','0','0',NULL,NULL),(1373,13,27,'0','0','0','0','0','0',NULL,NULL),(1374,13,28,'0','0','0','0','0','0',NULL,NULL),(1375,13,29,'0','0','0','0','0','0',NULL,NULL),(1376,13,30,'0','0','0','0','0','0',NULL,NULL),(1377,13,31,'0','0','0','0','0','0',NULL,NULL),(1378,13,32,'0','0','0','0','0','0',NULL,NULL),(1379,13,33,'0','0','0','0','0','0',NULL,NULL),(1380,13,34,'0','0','0','0','0','0',NULL,NULL),(1381,13,35,'0','0','0','0','0','0',NULL,NULL),(1382,13,36,'0','0','0','0','0','0',NULL,NULL),(1383,13,37,'0','0','0','0','0','0',NULL,NULL),(1384,13,38,'0','0','0','0','0','0',NULL,NULL),(1385,13,39,'0','0','0','0','0','0',NULL,NULL),(1386,13,40,'0','0','0','0','0','0',NULL,NULL),(1387,13,41,'0','0','0','0','0','0',NULL,NULL),(1388,13,42,'0','0','0','0','0','0',NULL,NULL),(1389,13,43,'0','0','0','0','0','0',NULL,NULL),(1390,13,44,'0','0','0','0','0','0',NULL,NULL),(1391,13,45,'0','0','0','0','0','0',NULL,NULL),(1392,13,46,'0','0','0','0','0','0',NULL,NULL),(1393,13,47,'0','0','0','0','0','0',NULL,NULL),(1394,13,48,'0','0','0','0','0','0',NULL,NULL),(1395,13,49,'0','0','0','0','0','0',NULL,NULL),(1396,13,50,'0','0','0','0','0','0',NULL,NULL),(1397,13,51,'0','0','0','0','0','0',NULL,NULL),(1398,13,52,'0','0','0','0','0','0',NULL,NULL),(1399,13,53,'0','0','0','0','0','0',NULL,NULL),(1400,13,54,'0','0','0','0','0','0',NULL,NULL),(1401,13,55,'0','0','0','0','0','0',NULL,NULL),(1402,13,56,'0','0','0','0','0','0',NULL,NULL),(1403,13,57,'0','0','0','0','0','0',NULL,NULL),(1404,13,58,'0','0','0','0','0','0',NULL,NULL),(1405,13,59,'0','0','0','0','0','0',NULL,NULL),(1406,13,60,'0','0','0','0','0','0',NULL,NULL),(1407,13,61,'0','0','0','0','0','0',NULL,NULL),(1408,13,62,'0','0','0','0','0','0',NULL,NULL),(1409,13,63,'0','0','0','0','0','0',NULL,NULL),(1410,13,64,'0','0','0','0','0','0',NULL,NULL),(1411,13,65,'0','0','0','0','0','0',NULL,NULL),(1412,13,66,'0','0','0','0','0','0',NULL,NULL),(1413,13,67,'0','0','0','0','0','0',NULL,NULL),(1414,13,68,'0','0','0','0','0','0',NULL,NULL),(1415,13,69,'0','0','0','0','0','0',NULL,NULL),(1416,13,70,'0','0','0','0','0','0',NULL,NULL),(1417,13,71,'0','0','0','0','0','0',NULL,NULL),(1418,13,72,'0','0','0','0','0','0',NULL,NULL),(1419,13,73,'0','0','0','0','0','0',NULL,NULL),(1420,13,74,'0','0','0','0','0','0',NULL,NULL),(1421,13,75,'0','0','0','0','0','0',NULL,NULL),(1422,13,76,'0','0','0','0','0','0',NULL,NULL),(1423,13,77,'0','0','0','0','0','0',NULL,NULL),(1424,13,78,'0','0','0','0','0','0',NULL,NULL),(1425,13,79,'0','0','0','0','0','0',NULL,NULL),(1426,13,80,'0','0','0','0','0','0',NULL,NULL),(1427,13,81,'0','0','0','0','0','0',NULL,NULL),(1428,13,82,'0','0','0','0','0','0',NULL,NULL),(1429,14,1,'1','1','1','1','0','0',NULL,NULL),(1430,14,2,'1','1','1','1','0','0',NULL,NULL),(1431,14,3,'1','1','1','1','0','0',NULL,NULL),(1432,14,4,'1','1','1','1','0','0',NULL,NULL),(1433,14,5,'1','1','1','1','0','0',NULL,NULL),(1434,14,6,'1','1','1','1','0','0',NULL,NULL),(1435,14,7,'1','1','1','1','0','0',NULL,NULL),(1436,14,8,'0','0','0','0','0','0',NULL,NULL),(1437,14,9,'1','1','1','1','0','0',NULL,NULL),(1438,14,10,'0','0','0','0','0','0',NULL,NULL),(1439,14,11,'0','0','0','0','0','0',NULL,NULL),(1440,14,12,'0','0','0','0','0','0',NULL,NULL),(1441,14,13,'0','0','0','0','0','0',NULL,NULL),(1442,14,14,'0','0','0','0','0','0',NULL,NULL),(1443,14,15,'0','0','0','0','0','0',NULL,NULL),(1444,14,16,'0','0','0','0','0','0',NULL,NULL),(1445,14,17,'0','0','0','0','0','0',NULL,NULL),(1446,14,18,'1','1','1','1','0','0',NULL,NULL),(1447,14,19,'0','0','0','0','0','0',NULL,NULL),(1448,14,20,'0','0','0','0','0','0',NULL,NULL),(1449,14,21,'0','0','0','0','0','0',NULL,NULL),(1450,14,22,'0','0','0','0','0','0',NULL,NULL),(1451,14,23,'0','0','0','0','0','0',NULL,NULL),(1452,14,24,'0','0','0','0','0','0',NULL,NULL),(1453,14,25,'0','0','0','0','0','0',NULL,NULL),(1454,14,26,'0','0','0','0','0','0',NULL,NULL),(1455,14,27,'0','0','0','0','0','0',NULL,NULL),(1456,14,28,'0','0','0','0','0','0',NULL,NULL),(1457,14,29,'0','0','0','0','0','0',NULL,NULL),(1458,14,30,'0','0','0','0','0','0',NULL,NULL),(1459,14,31,'0','0','0','0','0','0',NULL,NULL),(1460,14,32,'0','0','0','0','0','0',NULL,NULL),(1461,14,33,'0','0','0','0','0','0',NULL,NULL),(1462,14,34,'0','0','0','0','0','0',NULL,NULL),(1463,14,35,'0','0','0','0','0','0',NULL,NULL),(1464,14,36,'0','0','0','0','0','0',NULL,NULL),(1465,14,37,'0','0','0','0','0','0',NULL,NULL),(1466,14,38,'0','0','0','0','0','0',NULL,NULL),(1467,14,39,'0','0','0','0','0','0',NULL,NULL),(1468,14,40,'0','0','0','0','0','0',NULL,NULL),(1469,14,41,'0','0','0','0','0','0',NULL,NULL),(1470,14,42,'0','0','0','0','0','0',NULL,NULL),(1471,14,43,'0','0','0','0','0','0',NULL,NULL),(1472,14,44,'0','0','0','0','0','0',NULL,NULL),(1473,14,45,'0','0','0','0','0','0',NULL,NULL),(1474,14,46,'0','0','0','0','0','0',NULL,NULL),(1475,14,47,'0','0','0','0','0','0',NULL,NULL),(1476,14,48,'0','0','0','0','0','0',NULL,NULL),(1477,14,49,'0','0','0','0','0','0',NULL,NULL),(1478,14,50,'0','0','0','0','0','0',NULL,NULL),(1479,14,51,'0','0','0','0','0','0',NULL,NULL),(1480,14,52,'0','0','0','0','0','0',NULL,NULL),(1481,14,53,'0','0','0','0','0','0',NULL,NULL),(1482,14,54,'0','0','0','0','0','0',NULL,NULL),(1483,14,55,'1','1','1','1','0','0',NULL,NULL),(1484,14,56,'1','1','1','1','0','0',NULL,NULL),(1485,14,57,'1','1','1','1','0','0',NULL,NULL),(1486,14,58,'0','0','0','0','0','0',NULL,NULL),(1487,14,59,'0','0','0','0','0','0',NULL,NULL),(1488,14,60,'0','0','0','0','0','0',NULL,NULL),(1489,14,61,'0','0','0','0','0','0',NULL,NULL),(1490,14,62,'0','0','0','0','0','0',NULL,NULL),(1491,14,63,'0','0','0','0','0','0',NULL,NULL),(1492,14,64,'0','0','0','0','0','0',NULL,NULL),(1493,14,65,'0','0','0','0','0','0',NULL,NULL),(1494,14,66,'0','0','0','0','0','0',NULL,NULL),(1495,14,67,'0','0','0','0','0','0',NULL,NULL),(1496,14,68,'0','0','0','0','0','0',NULL,NULL),(1497,14,69,'0','0','0','0','0','0',NULL,NULL),(1498,14,70,'0','0','0','0','0','0',NULL,NULL),(1499,14,71,'1','1','1','1','0','0',NULL,NULL),(1500,14,72,'0','0','0','0','0','0',NULL,NULL),(1501,14,73,'0','0','0','0','0','0',NULL,NULL),(1502,14,74,'0','0','0','0','0','0',NULL,NULL),(1503,14,75,'0','0','0','0','0','0',NULL,NULL),(1504,14,76,'0','0','0','0','0','0',NULL,NULL),(1505,14,77,'0','0','0','0','0','0',NULL,NULL),(1506,14,78,'0','0','0','0','0','0',NULL,NULL),(1507,14,79,'0','0','0','0','0','0',NULL,NULL),(1508,14,80,'0','0','0','0','0','0',NULL,NULL),(1509,14,81,'0','0','0','0','0','0',NULL,NULL),(1510,14,82,'0','0','0','0','0','0',NULL,NULL),(1511,15,1,'1','1','1','1','0','0',NULL,NULL),(1512,15,2,'1','1','1','1','0','0',NULL,NULL),(1513,15,3,'1','1','1','1','0','0',NULL,NULL),(1514,15,4,'0','0','0','0','0','0',NULL,NULL),(1515,15,5,'1','1','1','1','0','0',NULL,NULL),(1516,15,6,'0','0','0','0','0','0',NULL,NULL),(1517,15,7,'1','1','1','1','0','0',NULL,NULL),(1518,15,8,'0','0','0','0','0','0',NULL,NULL),(1519,15,9,'1','1','1','1','0','0',NULL,NULL),(1520,15,10,'0','0','0','0','0','0',NULL,NULL),(1521,15,11,'0','0','0','0','0','0',NULL,NULL),(1522,15,12,'0','0','0','0','0','0',NULL,NULL),(1523,15,13,'0','0','0','0','0','0',NULL,NULL),(1524,15,14,'0','0','0','0','0','0',NULL,NULL),(1525,15,15,'0','0','0','0','0','0',NULL,NULL),(1526,15,16,'0','0','0','0','0','0',NULL,NULL),(1527,15,17,'0','0','0','0','0','0',NULL,NULL),(1528,15,18,'0','0','0','0','0','0',NULL,NULL),(1529,15,19,'0','0','0','0','0','0',NULL,NULL),(1530,15,20,'0','0','0','0','0','0',NULL,NULL),(1531,15,21,'0','0','0','0','0','0',NULL,NULL),(1532,15,22,'0','0','0','0','0','0',NULL,NULL),(1533,15,23,'0','0','0','0','0','0',NULL,NULL),(1534,15,24,'0','0','0','0','0','0',NULL,NULL),(1535,15,25,'0','0','0','0','0','0',NULL,NULL),(1536,15,26,'0','0','0','0','0','0',NULL,NULL),(1537,15,27,'0','0','0','0','0','0',NULL,NULL),(1538,15,28,'0','0','0','0','0','0',NULL,NULL),(1539,15,29,'0','0','0','0','0','0',NULL,NULL),(1540,15,30,'0','0','0','0','0','0',NULL,NULL),(1541,15,31,'0','0','0','0','0','0',NULL,NULL),(1542,15,32,'0','0','0','0','0','0',NULL,NULL),(1543,15,33,'0','0','0','0','0','0',NULL,NULL),(1544,15,34,'0','0','0','0','0','0',NULL,NULL),(1545,15,35,'0','0','0','0','0','0',NULL,NULL),(1546,15,36,'0','0','0','0','0','0',NULL,NULL),(1547,15,37,'0','0','0','0','0','0',NULL,NULL),(1548,15,38,'0','0','0','0','0','0',NULL,NULL),(1549,15,39,'0','0','0','0','0','0',NULL,NULL),(1550,15,40,'0','0','0','0','0','0',NULL,NULL),(1551,15,41,'0','0','0','0','0','0',NULL,NULL),(1552,15,42,'0','0','0','0','0','0',NULL,NULL),(1553,15,43,'0','0','0','0','0','0',NULL,NULL),(1554,15,44,'0','0','0','0','0','0',NULL,NULL),(1555,15,45,'0','0','0','0','0','0',NULL,NULL),(1556,15,46,'0','0','0','0','0','0',NULL,NULL),(1557,15,47,'0','0','0','0','0','0',NULL,NULL),(1558,15,48,'0','0','0','0','0','0',NULL,NULL),(1559,15,49,'0','0','0','0','0','0',NULL,NULL),(1560,15,50,'0','0','0','0','0','0',NULL,NULL),(1561,15,51,'0','0','0','0','0','0',NULL,NULL),(1562,15,52,'0','0','0','0','0','0',NULL,NULL),(1563,15,53,'0','0','0','0','0','0',NULL,NULL),(1564,15,54,'0','0','0','0','0','0',NULL,NULL),(1565,15,55,'0','0','0','0','0','0',NULL,NULL),(1566,15,56,'0','0','0','0','0','0',NULL,NULL),(1567,15,57,'0','0','0','0','0','0',NULL,NULL),(1568,15,58,'0','0','0','0','0','0',NULL,NULL),(1569,15,59,'0','0','0','0','0','0',NULL,NULL),(1570,15,60,'0','0','0','0','0','0',NULL,NULL),(1571,15,61,'0','0','0','0','0','0',NULL,NULL),(1572,15,62,'0','0','0','0','0','0',NULL,NULL),(1573,15,63,'0','0','0','0','0','0',NULL,NULL),(1574,15,64,'0','0','0','0','0','0',NULL,NULL),(1575,15,65,'0','0','0','0','0','0',NULL,NULL),(1576,15,66,'0','0','0','0','0','0',NULL,NULL),(1577,15,67,'0','0','0','0','0','0',NULL,NULL),(1578,15,68,'0','0','0','0','0','0',NULL,NULL),(1579,15,69,'0','0','0','0','0','0',NULL,NULL),(1580,15,70,'0','0','0','0','0','0',NULL,NULL),(1581,15,71,'0','0','0','0','0','0',NULL,NULL),(1582,15,72,'0','0','0','0','0','0',NULL,NULL),(1583,15,73,'0','0','0','0','0','0',NULL,NULL),(1584,15,74,'0','0','0','0','0','0',NULL,NULL),(1585,15,75,'0','0','0','0','0','0',NULL,NULL),(1586,15,76,'0','0','0','0','0','0',NULL,NULL),(1587,15,77,'0','0','0','0','0','0',NULL,NULL),(1588,15,78,'0','0','0','0','0','0',NULL,NULL),(1589,15,79,'0','0','0','0','0','0',NULL,NULL),(1590,15,80,'0','0','0','0','0','0',NULL,NULL),(1591,15,81,'0','0','0','0','0','0',NULL,NULL),(1592,15,82,'0','0','0','0','0','0',NULL,NULL),(1593,16,1,'1','1','1','1','0','0',NULL,NULL),(1594,16,2,'1','1','1','1','0','0',NULL,NULL),(1595,16,3,'1','1','1','1','0','0',NULL,NULL),(1596,16,4,'0','0','0','0','0','0',NULL,NULL),(1597,16,5,'1','1','1','1','0','0',NULL,NULL),(1598,16,6,'0','0','0','0','0','0',NULL,NULL),(1599,16,7,'1','1','1','1','0','0',NULL,NULL),(1600,16,8,'0','0','0','0','0','0',NULL,NULL),(1601,16,9,'1','1','1','1','0','0',NULL,NULL),(1602,16,10,'0','0','0','0','0','0',NULL,NULL),(1603,16,11,'0','0','0','0','0','0',NULL,NULL),(1604,16,12,'0','0','0','0','0','0',NULL,NULL),(1605,16,13,'0','0','0','0','0','0',NULL,NULL),(1606,16,14,'0','0','0','0','0','0',NULL,NULL),(1607,16,15,'0','0','0','0','0','0',NULL,NULL),(1608,16,16,'0','0','0','0','0','0',NULL,NULL),(1609,16,17,'0','0','0','0','0','0',NULL,NULL),(1610,16,18,'0','0','0','0','0','0',NULL,NULL),(1611,16,19,'0','0','0','0','0','0',NULL,NULL),(1612,16,20,'0','0','0','0','0','0',NULL,NULL),(1613,16,21,'0','0','0','0','0','0',NULL,NULL),(1614,16,22,'0','0','0','0','0','0',NULL,NULL),(1615,16,23,'0','0','0','0','0','0',NULL,NULL),(1616,16,24,'0','0','0','0','0','0',NULL,NULL),(1617,16,25,'0','0','0','0','0','0',NULL,NULL),(1618,16,26,'0','0','0','0','0','0',NULL,NULL),(1619,16,27,'0','0','0','0','0','0',NULL,NULL),(1620,16,28,'0','0','0','0','0','0',NULL,NULL),(1621,16,29,'0','0','0','0','0','0',NULL,NULL),(1622,16,30,'0','0','0','0','0','0',NULL,NULL),(1623,16,31,'0','0','0','0','0','0',NULL,NULL),(1624,16,32,'0','0','0','0','0','0',NULL,NULL),(1625,16,33,'0','0','0','0','0','0',NULL,NULL),(1626,16,34,'0','0','0','0','0','0',NULL,NULL),(1627,16,35,'0','0','0','0','0','0',NULL,NULL),(1628,16,36,'0','0','0','0','0','0',NULL,NULL),(1629,16,37,'0','0','0','0','0','0',NULL,NULL),(1630,16,38,'0','0','0','0','0','0',NULL,NULL),(1631,16,39,'0','0','0','0','0','0',NULL,NULL),(1632,16,40,'0','0','0','0','0','0',NULL,NULL),(1633,16,41,'0','0','0','0','0','0',NULL,NULL),(1634,16,42,'0','0','0','0','0','0',NULL,NULL),(1635,16,43,'0','0','0','0','0','0',NULL,NULL),(1636,16,44,'0','0','0','0','0','0',NULL,NULL),(1637,16,45,'0','0','0','0','0','0',NULL,NULL),(1638,16,46,'0','0','0','0','0','0',NULL,NULL),(1639,16,47,'0','0','0','0','0','0',NULL,NULL),(1640,16,48,'0','0','0','0','0','0',NULL,NULL),(1641,16,49,'0','0','0','0','0','0',NULL,NULL),(1642,16,50,'0','0','0','0','0','0',NULL,NULL),(1643,16,51,'0','0','0','0','0','0',NULL,NULL),(1644,16,52,'0','0','0','0','0','0',NULL,NULL),(1645,16,53,'0','0','0','0','0','0',NULL,NULL),(1646,16,54,'0','0','0','0','0','0',NULL,NULL),(1647,16,55,'0','0','0','0','0','0',NULL,NULL),(1648,16,56,'0','0','0','0','0','0',NULL,NULL),(1649,16,57,'0','0','0','0','0','0',NULL,NULL),(1650,16,58,'0','0','0','0','0','0',NULL,NULL),(1651,16,59,'0','0','0','0','0','0',NULL,NULL),(1652,16,60,'0','0','0','0','0','0',NULL,NULL),(1653,16,61,'0','0','0','0','0','0',NULL,NULL),(1654,16,62,'0','0','0','0','0','0',NULL,NULL),(1655,16,63,'0','0','0','0','0','0',NULL,NULL),(1656,16,64,'0','0','0','0','0','0',NULL,NULL),(1657,16,65,'0','0','0','0','0','0',NULL,NULL),(1658,16,66,'0','0','0','0','0','0',NULL,NULL),(1659,16,67,'0','0','0','0','0','0',NULL,NULL),(1660,16,68,'0','0','0','0','0','0',NULL,NULL),(1661,16,69,'0','0','0','0','0','0',NULL,NULL),(1662,16,70,'0','0','0','0','0','0',NULL,NULL),(1663,16,71,'0','0','0','0','0','0',NULL,NULL),(1664,16,72,'0','0','0','0','0','0',NULL,NULL),(1665,16,73,'0','0','0','0','0','0',NULL,NULL),(1666,16,74,'0','0','0','0','0','0',NULL,NULL),(1667,16,75,'0','0','0','0','0','0',NULL,NULL),(1668,16,76,'0','0','0','0','0','0',NULL,NULL),(1669,16,77,'0','0','0','0','0','0',NULL,NULL),(1670,16,78,'0','0','0','0','0','0',NULL,NULL),(1671,16,79,'0','0','0','0','0','0',NULL,NULL),(1672,16,80,'0','0','0','0','0','0',NULL,NULL),(1673,16,81,'0','0','0','0','0','0',NULL,NULL),(1674,16,82,'0','0','0','0','0','0',NULL,NULL);
/*!40000 ALTER TABLE `user_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `useraccess`
--

DROP TABLE IF EXISTS `useraccess`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `useraccess` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `userid` int(200) NOT NULL,
  `sectionid` int(200) NOT NULL,
  `accesslevel` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1420 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `useraccess`
--

LOCK TABLES `useraccess` WRITE;
/*!40000 ALTER TABLE `useraccess` DISABLE KEYS */;
INSERT INTO `useraccess` VALUES (1,2,1,'1','2020-02-11 09:42:48','2020-02-11 09:42:48'),(3,1,1,'1','2020-02-11 09:44:59','2020-02-11 09:44:59'),(4,2,3,'1','2020-02-11 09:48:36','2020-02-11 09:48:36'),(5,2,4,'1','2020-02-11 09:50:34','2020-02-11 09:50:34'),(6,2,5,'1','2020-02-11 09:50:51','2020-02-11 09:50:51'),(7,2,6,'1','2020-02-11 10:10:40','2020-02-11 10:10:40'),(8,2,7,'1','2020-02-11 10:17:13','2020-02-11 10:17:13'),(10,2,8,'1','2020-02-11 10:23:58','2020-02-11 10:23:58'),(11,2,9,'1','2020-02-11 10:30:19','2020-02-11 10:30:19'),(14,2,11,'1','2020-02-11 11:04:09','2020-02-11 11:04:09'),(15,2,12,'1','2020-02-11 11:58:18','2020-02-11 11:58:18'),(16,1,12,'1','2020-02-11 11:58:30','2020-02-11 11:58:30'),(17,1,6,'1','2020-02-11 12:02:00','2020-02-11 12:02:00'),(18,1,2,'1','2020-02-11 12:03:00','2020-02-11 12:03:00'),(38,7,1,'0','2020-02-12 12:12:30','2020-02-12 12:12:30'),(39,7,2,'0','2020-02-12 12:12:31','2020-02-12 12:12:31'),(40,7,3,'0','2020-02-12 12:12:31','2020-02-12 12:12:31'),(41,7,4,'0','2020-02-12 12:12:31','2020-02-12 12:12:31'),(42,7,5,'0','2020-02-12 12:12:31','2020-02-12 12:12:31'),(43,7,6,'0','2020-02-12 12:12:31','2020-02-12 12:12:31'),(44,7,7,'0','2020-02-12 12:12:31','2020-02-12 12:12:31'),(45,7,8,'0','2020-02-12 12:12:31','2020-02-12 12:12:31'),(46,7,9,'0','2020-02-12 12:12:31','2020-02-12 12:12:31'),(47,7,10,'0','2020-02-12 12:12:31','2020-02-12 12:12:31'),(48,7,11,'0','2020-02-12 12:12:31','2020-02-12 12:12:31'),(49,7,12,'0','2020-02-12 12:12:31','2020-02-12 12:12:31'),(50,7,13,'0','2020-02-12 12:12:31','2020-02-12 12:12:31'),(51,7,14,'0','2020-02-12 12:12:31','2020-02-12 12:12:31'),(52,7,15,'0','2020-02-12 12:12:31','2020-02-12 12:12:31'),(53,7,16,'0','2020-02-12 12:12:31','2020-02-12 12:12:31'),(54,7,17,'0','2020-02-12 12:12:31','2020-02-12 12:12:31'),(55,7,18,'0','2020-02-12 12:12:31','2020-02-12 12:12:31'),(56,7,19,'0','2020-02-12 12:12:31','2020-02-12 12:12:31'),(57,7,20,'0','2020-02-12 12:12:31','2020-02-12 12:12:31'),(58,7,21,'0','2020-02-12 12:12:31','2020-02-12 12:12:31'),(59,7,22,'0','2020-02-12 12:12:31','2020-02-12 12:12:31'),(60,7,23,'0','2020-02-12 12:12:31','2020-02-12 12:12:31'),(61,7,24,'0','2020-02-12 12:12:31','2020-02-12 12:12:31'),(62,7,25,'0','2020-02-12 12:12:31','2020-02-12 12:12:31'),(63,2,2,'1','2020-02-13 07:38:24','2020-02-13 07:38:24'),(64,2,10,'1','2020-02-13 07:38:24','2020-02-13 07:38:24'),(65,2,13,'1','2020-02-13 07:38:24','2020-02-13 07:38:24'),(66,2,14,'1','2020-02-13 07:38:24','2020-02-13 07:38:24'),(67,2,15,'1','2020-02-13 07:38:24','2020-02-13 07:38:24'),(68,2,16,'1','2020-02-13 07:38:24','2020-02-13 07:38:24'),(69,2,17,'1','2020-02-13 07:38:25','2020-02-13 07:38:25'),(70,2,18,'1','2020-02-13 07:38:25','2020-02-13 07:38:25'),(71,2,19,'1','2020-02-13 07:38:25','2020-02-13 07:38:25'),(72,2,20,'1','2020-02-13 07:38:25','2020-02-13 07:38:25'),(73,2,21,'1','2020-02-13 07:38:25','2020-02-13 07:38:25'),(74,2,22,'1','2020-02-13 07:38:25','2020-02-13 07:38:25'),(75,2,23,'1','2020-02-13 07:38:25','2020-02-13 07:38:25'),(76,2,24,'1','2020-02-13 07:38:25','2020-02-13 07:38:25'),(77,2,25,'1','2020-02-13 07:38:25','2020-02-13 07:38:25'),(78,1,3,'0','2020-02-13 07:39:08','2020-02-13 07:39:08'),(79,1,4,'0','2020-02-13 07:39:08','2020-02-13 07:39:08'),(80,1,5,'0','2020-02-13 07:39:08','2020-02-13 07:39:08'),(81,1,7,'0','2020-02-13 07:39:08','2020-02-13 07:39:08'),(82,1,8,'0','2020-02-13 07:39:08','2020-02-13 07:39:08'),(83,1,9,'0','2020-02-13 07:39:08','2020-02-13 07:39:08'),(84,1,10,'0','2020-02-13 07:39:08','2020-02-13 07:39:08'),(85,1,11,'0','2020-02-13 07:39:08','2020-02-13 07:39:08'),(86,1,13,'0','2020-02-13 07:39:08','2020-02-13 07:39:08'),(87,1,14,'0','2020-02-13 07:39:08','2020-02-13 07:39:08'),(88,1,15,'0','2020-02-13 07:39:08','2020-02-13 07:39:08'),(89,1,16,'0','2020-02-13 07:39:08','2020-02-13 07:39:08'),(90,1,17,'0','2020-02-13 07:39:08','2020-02-13 07:39:08'),(91,1,18,'0','2020-02-13 07:39:08','2020-02-13 07:39:08'),(92,1,19,'0','2020-02-13 07:39:08','2020-02-13 07:39:08'),(93,1,20,'0','2020-02-13 07:39:08','2020-02-13 07:39:08'),(94,1,21,'0','2020-02-13 07:39:08','2020-02-13 07:39:08'),(95,1,22,'0','2020-02-13 07:39:08','2020-02-13 07:39:08'),(96,1,23,'0','2020-02-13 07:39:08','2020-02-13 07:39:08'),(97,1,24,'0','2020-02-13 07:39:08','2020-02-13 07:39:08'),(98,1,25,'0','2020-02-13 07:39:09','2020-02-13 07:39:09'),(99,0,1,'0','2020-02-13 08:19:22','2020-02-13 08:19:22'),(100,0,2,'0','2020-02-13 08:19:22','2020-02-13 08:19:22'),(101,0,3,'0','2020-02-13 08:19:23','2020-02-13 08:19:23'),(102,0,4,'0','2020-02-13 08:19:23','2020-02-13 08:19:23'),(103,0,5,'0','2020-02-13 08:19:23','2020-02-13 08:19:23'),(104,0,6,'0','2020-02-13 08:19:23','2020-02-13 08:19:23'),(105,0,7,'0','2020-02-13 08:19:23','2020-02-13 08:19:23'),(106,0,8,'0','2020-02-13 08:19:23','2020-02-13 08:19:23'),(107,0,9,'0','2020-02-13 08:19:23','2020-02-13 08:19:23'),(108,0,10,'0','2020-02-13 08:19:23','2020-02-13 08:19:23'),(109,0,11,'0','2020-02-13 08:19:23','2020-02-13 08:19:23'),(110,0,12,'0','2020-02-13 08:19:23','2020-02-13 08:19:23'),(111,0,13,'0','2020-02-13 08:19:23','2020-02-13 08:19:23'),(112,0,14,'0','2020-02-13 08:19:23','2020-02-13 08:19:23'),(113,0,15,'0','2020-02-13 08:19:23','2020-02-13 08:19:23'),(114,0,16,'0','2020-02-13 08:19:23','2020-02-13 08:19:23'),(115,0,17,'0','2020-02-13 08:19:23','2020-02-13 08:19:23'),(116,0,18,'0','2020-02-13 08:19:23','2020-02-13 08:19:23'),(117,0,19,'0','2020-02-13 08:19:23','2020-02-13 08:19:23'),(118,0,20,'0','2020-02-13 08:19:23','2020-02-13 08:19:23'),(119,0,21,'0','2020-02-13 08:19:23','2020-02-13 08:19:23'),(120,0,22,'0','2020-02-13 08:19:23','2020-02-13 08:19:23'),(121,0,23,'0','2020-02-13 08:19:23','2020-02-13 08:19:23'),(122,0,24,'0','2020-02-13 08:19:23','2020-02-13 08:19:23'),(123,0,25,'0','2020-02-13 08:19:23','2020-02-13 08:19:23'),(124,0,26,'0','2020-02-13 11:18:54','2020-02-13 11:18:54'),(125,0,27,'0','2020-02-13 11:18:54','2020-02-13 11:18:54'),(126,0,28,'0','2020-02-13 11:18:54','2020-02-13 11:18:54'),(127,0,29,'0','2020-02-13 11:18:54','2020-02-13 11:18:54'),(128,0,30,'0','2020-02-13 11:18:54','2020-02-13 11:18:54'),(129,0,31,'0','2020-02-13 11:18:54','2020-02-13 11:18:54'),(130,0,32,'0','2020-02-13 11:18:54','2020-02-13 11:18:54'),(131,2,26,'1','2020-02-13 11:19:11','2020-02-13 11:19:11'),(132,2,27,'1','2020-02-13 11:19:11','2020-02-13 11:19:11'),(133,2,28,'1','2020-02-13 11:19:11','2020-02-13 11:19:11'),(134,2,29,'1','2020-02-13 11:19:11','2020-02-13 11:19:11'),(135,2,30,'1','2020-02-13 11:19:11','2020-02-13 11:19:11'),(136,2,31,'1','2020-02-13 11:19:11','2020-02-13 11:19:11'),(137,2,32,'1','2020-02-13 11:19:11','2020-02-13 11:19:11'),(138,0,33,'0','2020-02-13 12:23:27','2020-02-13 12:23:27'),(139,7,26,'0','2020-02-13 12:23:29','2020-02-13 12:23:29'),(140,7,27,'0','2020-02-13 12:23:29','2020-02-13 12:23:29'),(141,7,28,'0','2020-02-13 12:23:29','2020-02-13 12:23:29'),(142,7,29,'0','2020-02-13 12:23:29','2020-02-13 12:23:29'),(143,7,30,'0','2020-02-13 12:23:29','2020-02-13 12:23:29'),(144,7,31,'0','2020-02-13 12:23:29','2020-02-13 12:23:29'),(145,7,32,'0','2020-02-13 12:23:29','2020-02-13 12:23:29'),(146,7,33,'0','2020-02-13 12:23:29','2020-02-13 12:23:29'),(147,2,33,'1','2020-02-13 12:23:32','2020-02-13 12:23:32'),(148,0,34,'0','2020-02-13 12:28:17','2020-02-13 12:28:17'),(149,2,34,'1','2020-02-13 12:28:20','2020-02-13 12:28:20'),(150,2,35,'1','2020-02-13 12:34:44','2020-02-13 12:34:44'),(151,0,35,'0','2020-02-13 12:35:59','2020-02-13 12:35:59'),(152,0,36,'0','2020-02-13 12:49:17','2020-02-13 12:49:17'),(153,2,36,'1','2020-02-13 12:49:20','2020-02-13 12:49:20'),(154,0,37,'0','2020-02-13 13:22:20','2020-02-13 13:22:20'),(155,2,37,'1','2020-02-13 13:22:23','2020-02-13 13:22:23'),(156,0,38,'0','2020-02-13 14:31:36','2020-02-13 14:31:36'),(157,0,39,'0','2020-02-13 14:31:36','2020-02-13 14:31:36'),(158,0,40,'0','2020-02-13 14:31:36','2020-02-13 14:31:36'),(159,0,41,'0','2020-02-13 14:31:36','2020-02-13 14:31:36'),(160,0,42,'0','2020-02-13 14:31:36','2020-02-13 14:31:36'),(161,0,43,'0','2020-02-13 14:31:36','2020-02-13 14:31:36'),(162,0,44,'0','2020-02-13 14:31:36','2020-02-13 14:31:36'),(163,0,45,'0','2020-02-13 14:31:36','2020-02-13 14:31:36'),(164,0,46,'0','2020-02-13 14:31:36','2020-02-13 14:31:36'),(165,0,47,'0','2020-02-13 14:31:36','2020-02-13 14:31:36'),(166,0,48,'0','2020-02-13 14:31:36','2020-02-13 14:31:36'),(167,0,49,'0','2020-02-13 14:31:36','2020-02-13 14:31:36'),(168,0,50,'0','2020-02-13 14:31:36','2020-02-13 14:31:36'),(169,0,51,'0','2020-02-13 14:31:36','2020-02-13 14:31:36'),(170,0,52,'0','2020-02-13 14:31:36','2020-02-13 14:31:36'),(171,0,53,'0','2020-02-13 14:31:36','2020-02-13 14:31:36'),(172,0,54,'0','2020-02-13 14:31:36','2020-02-13 14:31:36'),(173,0,55,'0','2020-02-13 14:31:37','2020-02-13 14:31:37'),(174,0,56,'0','2020-02-13 14:31:37','2020-02-13 14:31:37'),(175,0,57,'0','2020-02-13 14:31:37','2020-02-13 14:31:37'),(176,0,58,'0','2020-02-13 14:31:37','2020-02-13 14:31:37'),(177,0,59,'0','2020-02-13 14:31:37','2020-02-13 14:31:37'),(178,0,60,'0','2020-02-13 14:31:37','2020-02-13 14:31:37'),(179,0,61,'0','2020-02-13 14:31:37','2020-02-13 14:31:37'),(180,0,62,'0','2020-02-13 14:31:37','2020-02-13 14:31:37'),(181,0,63,'0','2020-02-13 14:31:37','2020-02-13 14:31:37'),(182,0,64,'0','2020-02-13 14:31:37','2020-02-13 14:31:37'),(183,0,65,'0','2020-02-13 14:31:37','2020-02-13 14:31:37'),(184,0,66,'0','2020-02-13 14:31:37','2020-02-13 14:31:37'),(185,2,38,'1','2020-02-13 14:31:42','2020-02-13 14:31:42'),(186,2,39,'1','2020-02-13 14:31:42','2020-02-13 14:31:42'),(187,2,40,'1','2020-02-13 14:31:42','2020-02-13 14:31:42'),(188,2,41,'1','2020-02-13 14:31:42','2020-02-13 14:31:42'),(189,2,42,'1','2020-02-13 14:31:42','2020-02-13 14:31:42'),(190,2,43,'1','2020-02-13 14:31:42','2020-02-13 14:31:42'),(191,2,44,'1','2020-02-13 14:31:42','2020-02-13 14:31:42'),(192,2,45,'1','2020-02-13 14:31:42','2020-02-13 14:31:42'),(193,2,46,'1','2020-02-13 14:31:42','2020-02-13 14:31:42'),(194,2,47,'1','2020-02-13 14:31:42','2020-02-13 14:31:42'),(195,2,48,'1','2020-02-13 14:31:42','2020-02-13 14:31:42'),(196,2,49,'1','2020-02-13 14:31:42','2020-02-13 14:31:42'),(197,2,50,'1','2020-02-13 14:31:42','2020-02-13 14:31:42'),(198,2,51,'1','2020-02-13 14:31:42','2020-02-13 14:31:42'),(199,2,52,'1','2020-02-13 14:31:42','2020-02-13 14:31:42'),(200,2,53,'1','2020-02-13 14:31:42','2020-02-13 14:31:42'),(201,2,54,'1','2020-02-13 14:31:42','2020-02-13 14:31:42'),(202,2,55,'1','2020-02-13 14:31:42','2020-02-13 14:31:42'),(203,2,56,'1','2020-02-13 14:31:42','2020-02-13 14:31:42'),(204,2,57,'1','2020-02-13 14:31:43','2020-02-13 14:31:43'),(205,2,58,'1','2020-02-13 14:31:43','2020-02-13 14:31:43'),(206,2,59,'1','2020-02-13 14:31:43','2020-02-13 14:31:43'),(207,2,60,'1','2020-02-13 14:31:43','2020-02-13 14:31:43'),(208,2,61,'1','2020-02-13 14:31:43','2020-02-13 14:31:43'),(209,2,62,'1','2020-02-13 14:31:43','2020-02-13 14:31:43'),(210,2,63,'1','2020-02-13 14:31:43','2020-02-13 14:31:43'),(211,2,64,'1','2020-02-13 14:31:43','2020-02-13 14:31:43'),(212,2,65,'1','2020-02-13 14:31:43','2020-02-13 14:31:43'),(213,2,66,'1','2020-02-13 14:31:43','2020-02-13 14:31:43'),(214,1,26,'0','2020-02-14 05:35:55','2020-02-14 05:35:55'),(215,1,27,'0','2020-02-14 05:35:56','2020-02-14 05:35:56'),(216,1,28,'0','2020-02-14 05:35:56','2020-02-14 05:35:56'),(217,1,29,'0','2020-02-14 05:35:56','2020-02-14 05:35:56'),(218,1,30,'0','2020-02-14 05:35:56','2020-02-14 05:35:56'),(219,1,31,'0','2020-02-14 05:35:56','2020-02-14 05:35:56'),(220,1,32,'0','2020-02-14 05:35:56','2020-02-14 05:35:56'),(221,1,33,'0','2020-02-14 05:35:56','2020-02-14 05:35:56'),(222,1,34,'0','2020-02-14 05:35:56','2020-02-14 05:35:56'),(223,1,35,'0','2020-02-14 05:35:56','2020-02-14 05:35:56'),(224,1,36,'0','2020-02-14 05:35:56','2020-02-14 05:35:56'),(225,1,37,'0','2020-02-14 05:35:56','2020-02-14 05:35:56'),(226,1,38,'0','2020-02-14 05:35:56','2020-02-14 05:35:56'),(227,1,39,'0','2020-02-14 05:35:56','2020-02-14 05:35:56'),(228,1,40,'0','2020-02-14 05:35:56','2020-02-14 05:35:56'),(229,1,41,'0','2020-02-14 05:35:56','2020-02-14 05:35:56'),(230,1,42,'0','2020-02-14 05:35:56','2020-02-14 05:35:56'),(231,1,43,'0','2020-02-14 05:35:56','2020-02-14 05:35:56'),(232,1,44,'0','2020-02-14 05:35:56','2020-02-14 05:35:56'),(233,1,45,'0','2020-02-14 05:35:56','2020-02-14 05:35:56'),(234,1,46,'0','2020-02-14 05:35:56','2020-02-14 05:35:56'),(235,1,47,'0','2020-02-14 05:35:56','2020-02-14 05:35:56'),(236,1,48,'0','2020-02-14 05:35:56','2020-02-14 05:35:56'),(237,1,49,'0','2020-02-14 05:35:56','2020-02-14 05:35:56'),(238,1,50,'0','2020-02-14 05:35:56','2020-02-14 05:35:56'),(239,1,51,'0','2020-02-14 05:35:56','2020-02-14 05:35:56'),(240,1,52,'0','2020-02-14 05:35:57','2020-02-14 05:35:57'),(241,1,53,'0','2020-02-14 05:35:57','2020-02-14 05:35:57'),(242,1,54,'0','2020-02-14 05:35:57','2020-02-14 05:35:57'),(243,1,55,'0','2020-02-14 05:35:57','2020-02-14 05:35:57'),(244,1,56,'0','2020-02-14 05:35:57','2020-02-14 05:35:57'),(245,1,57,'0','2020-02-14 05:35:57','2020-02-14 05:35:57'),(246,1,58,'0','2020-02-14 05:35:57','2020-02-14 05:35:57'),(247,1,59,'0','2020-02-14 05:35:57','2020-02-14 05:35:57'),(248,1,60,'0','2020-02-14 05:35:57','2020-02-14 05:35:57'),(249,1,61,'0','2020-02-14 05:35:57','2020-02-14 05:35:57'),(250,1,62,'0','2020-02-14 05:35:57','2020-02-14 05:35:57'),(251,1,63,'0','2020-02-14 05:35:57','2020-02-14 05:35:57'),(252,1,64,'0','2020-02-14 05:35:57','2020-02-14 05:35:57'),(253,1,65,'0','2020-02-14 05:35:57','2020-02-14 05:35:57'),(254,1,66,'0','2020-02-14 05:35:57','2020-02-14 05:35:57'),(255,0,67,'0','2020-02-14 06:12:19','2020-02-14 06:12:19'),(256,0,68,'0','2020-02-14 06:12:19','2020-02-14 06:12:19'),(257,2,67,'1','2020-02-14 06:12:22','2020-02-14 06:12:22'),(258,2,68,'1','2020-02-14 06:12:22','2020-02-14 06:12:22'),(259,2,69,'1','2020-02-14 07:17:09','2020-02-14 07:17:09'),(260,0,69,'0','2020-02-14 07:38:42','2020-02-14 07:38:42'),(261,0,70,'0','2020-02-14 07:38:42','2020-02-14 07:38:42'),(262,2,70,'1','2020-02-14 07:38:44','2020-02-14 07:38:44'),(263,0,71,'0','2020-02-14 08:05:10','2020-02-14 08:05:10'),(264,2,71,'1','2020-02-14 08:05:11','2020-02-14 08:05:11'),(265,0,72,'0','2020-02-14 13:50:22','2020-02-14 13:50:22'),(266,2,72,'1','2020-02-14 13:50:25','2020-02-14 13:50:25'),(267,0,73,'0','2020-02-15 10:13:02','2020-02-15 10:13:02'),(268,2,73,'1','2020-02-15 10:13:05','2020-02-15 10:13:05'),(269,0,74,'0','2020-02-15 12:07:05','2020-02-15 12:07:05'),(270,0,75,'0','2020-02-15 12:07:05','2020-02-15 12:07:05'),(271,0,76,'0','2020-02-15 12:07:05','2020-02-15 12:07:05'),(272,0,77,'0','2020-02-15 12:07:05','2020-02-15 12:07:05'),(273,0,78,'0','2020-02-15 12:07:05','2020-02-15 12:07:05'),(274,0,79,'0','2020-02-15 12:07:05','2020-02-15 12:07:05'),(275,0,80,'0','2020-02-15 12:07:05','2020-02-15 12:07:05'),(276,0,81,'0','2020-02-15 12:07:05','2020-02-15 12:07:05'),(277,0,82,'0','2020-02-15 12:07:05','2020-02-15 12:07:05'),(278,0,83,'0','2020-02-15 12:07:05','2020-02-15 12:07:05'),(279,0,84,'0','2020-02-15 12:07:05','2020-02-15 12:07:05'),(280,0,85,'0','2020-02-15 12:07:05','2020-02-15 12:07:05'),(281,0,86,'0','2020-02-15 12:07:05','2020-02-15 12:07:05'),(282,2,74,'1','2020-02-15 12:07:07','2020-02-15 12:07:07'),(283,2,75,'1','2020-02-15 12:07:07','2020-02-15 12:07:07'),(284,2,76,'1','2020-02-15 12:07:07','2020-02-15 12:07:07'),(285,2,77,'1','2020-02-15 12:07:07','2020-02-15 12:07:07'),(286,2,78,'1','2020-02-15 12:07:07','2020-02-15 12:07:07'),(287,2,79,'1','2020-02-15 12:07:07','2020-02-15 12:07:07'),(288,2,80,'1','2020-02-15 12:07:07','2020-02-15 12:07:07'),(289,2,81,'1','2020-02-15 12:07:07','2020-02-15 12:07:07'),(290,2,82,'1','2020-02-15 12:07:07','2020-02-15 12:07:07'),(291,2,83,'1','2020-02-15 12:07:07','2020-02-15 12:07:07'),(292,2,84,'1','2020-02-15 12:07:07','2020-02-15 12:07:07'),(293,2,85,'1','2020-02-15 12:07:08','2020-02-15 12:07:08'),(294,2,86,'1','2020-02-15 12:07:08','2020-02-15 12:07:08'),(295,0,87,'0','2020-02-15 13:08:00','2020-02-15 13:08:00'),(296,2,87,'1','2020-02-15 13:08:01','2020-02-15 13:08:01'),(297,8,1,'0','2020-02-19 07:46:26','2020-02-19 07:46:26'),(298,8,2,'0','2020-02-19 07:46:26','2020-02-19 07:46:26'),(299,8,3,'0','2020-02-19 07:46:26','2020-02-19 07:46:26'),(300,8,4,'0','2020-02-19 07:46:26','2020-02-19 07:46:26'),(301,8,5,'0','2020-02-19 07:46:26','2020-02-19 07:46:26'),(302,8,6,'0','2020-02-19 07:46:26','2020-02-19 07:46:26'),(303,8,7,'0','2020-02-19 07:46:26','2020-02-19 07:46:26'),(304,8,8,'0','2020-02-19 07:46:26','2020-02-19 07:46:26'),(305,8,9,'0','2020-02-19 07:46:26','2020-02-19 07:46:26'),(306,8,10,'0','2020-02-19 07:46:26','2020-02-19 07:46:26'),(307,8,11,'0','2020-02-19 07:46:26','2020-02-19 07:46:26'),(308,8,12,'0','2020-02-19 07:46:26','2020-02-19 07:46:26'),(309,8,13,'0','2020-02-19 07:46:26','2020-02-19 07:46:26'),(310,8,14,'0','2020-02-19 07:46:26','2020-02-19 07:46:26'),(311,8,15,'0','2020-02-19 07:46:26','2020-02-19 07:46:26'),(312,8,16,'0','2020-02-19 07:46:26','2020-02-19 07:46:26'),(313,8,17,'0','2020-02-19 07:46:27','2020-02-19 07:46:27'),(314,8,18,'0','2020-02-19 07:46:27','2020-02-19 07:46:27'),(315,8,19,'0','2020-02-19 07:46:27','2020-02-19 07:46:27'),(316,8,20,'0','2020-02-19 07:46:27','2020-02-19 07:46:27'),(317,8,21,'0','2020-02-19 07:46:27','2020-02-19 07:46:27'),(318,8,22,'0','2020-02-19 07:46:27','2020-02-19 07:46:27'),(319,8,23,'0','2020-02-19 07:46:27','2020-02-19 07:46:27'),(320,8,24,'0','2020-02-19 07:46:27','2020-02-19 07:46:27'),(321,8,25,'0','2020-02-19 07:46:27','2020-02-19 07:46:27'),(322,8,26,'0','2020-02-19 07:46:27','2020-02-19 07:46:27'),(323,8,27,'0','2020-02-19 07:46:27','2020-02-19 07:46:27'),(324,8,28,'0','2020-02-19 07:46:27','2020-02-19 07:46:27'),(325,8,29,'0','2020-02-19 07:46:27','2020-02-19 07:46:27'),(326,8,30,'0','2020-02-19 07:46:27','2020-02-19 07:46:27'),(327,8,31,'0','2020-02-19 07:46:27','2020-02-19 07:46:27'),(328,8,32,'0','2020-02-19 07:46:27','2020-02-19 07:46:27'),(329,8,33,'0','2020-02-19 07:46:27','2020-02-19 07:46:27'),(330,8,34,'0','2020-02-19 07:46:27','2020-02-19 07:46:27'),(331,8,35,'0','2020-02-19 07:46:27','2020-02-19 07:46:27'),(332,8,36,'0','2020-02-19 07:46:27','2020-02-19 07:46:27'),(333,8,37,'0','2020-02-19 07:46:27','2020-02-19 07:46:27'),(334,8,38,'0','2020-02-19 07:46:27','2020-02-19 07:46:27'),(335,8,39,'0','2020-02-19 07:46:27','2020-02-19 07:46:27'),(336,8,40,'0','2020-02-19 07:46:27','2020-02-19 07:46:27'),(337,8,41,'0','2020-02-19 07:46:27','2020-02-19 07:46:27'),(338,8,42,'0','2020-02-19 07:46:27','2020-02-19 07:46:27'),(339,8,43,'0','2020-02-19 07:46:27','2020-02-19 07:46:27'),(340,8,44,'0','2020-02-19 07:46:27','2020-02-19 07:46:27'),(341,8,45,'0','2020-02-19 07:46:27','2020-02-19 07:46:27'),(342,8,46,'0','2020-02-19 07:46:27','2020-02-19 07:46:27'),(343,8,47,'0','2020-02-19 07:46:27','2020-02-19 07:46:27'),(344,8,48,'0','2020-02-19 07:46:27','2020-02-19 07:46:27'),(345,8,49,'0','2020-02-19 07:46:28','2020-02-19 07:46:28'),(346,8,50,'0','2020-02-19 07:46:28','2020-02-19 07:46:28'),(347,8,51,'0','2020-02-19 07:46:28','2020-02-19 07:46:28'),(348,8,52,'0','2020-02-19 07:46:28','2020-02-19 07:46:28'),(349,8,53,'0','2020-02-19 07:46:28','2020-02-19 07:46:28'),(350,8,54,'0','2020-02-19 07:46:28','2020-02-19 07:46:28'),(351,8,55,'0','2020-02-19 07:46:28','2020-02-19 07:46:28'),(352,8,56,'0','2020-02-19 07:46:28','2020-02-19 07:46:28'),(353,8,57,'0','2020-02-19 07:46:28','2020-02-19 07:46:28'),(354,8,58,'0','2020-02-19 07:46:28','2020-02-19 07:46:28'),(355,8,59,'0','2020-02-19 07:46:28','2020-02-19 07:46:28'),(356,8,60,'0','2020-02-19 07:46:28','2020-02-19 07:46:28'),(357,8,61,'0','2020-02-19 07:46:28','2020-02-19 07:46:28'),(358,8,62,'0','2020-02-19 07:46:28','2020-02-19 07:46:28'),(359,8,63,'0','2020-02-19 07:46:28','2020-02-19 07:46:28'),(360,8,64,'0','2020-02-19 07:46:28','2020-02-19 07:46:28'),(361,8,65,'0','2020-02-19 07:46:28','2020-02-19 07:46:28'),(362,8,66,'0','2020-02-19 07:46:28','2020-02-19 07:46:28'),(363,8,67,'0','2020-02-19 07:46:28','2020-02-19 07:46:28'),(364,8,68,'0','2020-02-19 07:46:28','2020-02-19 07:46:28'),(365,8,69,'0','2020-02-19 07:46:28','2020-02-19 07:46:28'),(366,8,70,'0','2020-02-19 07:46:28','2020-02-19 07:46:28'),(367,8,71,'0','2020-02-19 07:46:28','2020-02-19 07:46:28'),(368,8,73,'0','2020-02-19 07:46:28','2020-02-19 07:46:28'),(369,8,74,'0','2020-02-19 07:46:28','2020-02-19 07:46:28'),(370,8,75,'0','2020-02-19 07:46:28','2020-02-19 07:46:28'),(371,8,76,'0','2020-02-19 07:46:28','2020-02-19 07:46:28'),(372,8,77,'0','2020-02-19 07:46:28','2020-02-19 07:46:28'),(373,8,78,'0','2020-02-19 07:46:28','2020-02-19 07:46:28'),(374,8,79,'0','2020-02-19 07:46:28','2020-02-19 07:46:28'),(375,8,80,'0','2020-02-19 07:46:28','2020-02-19 07:46:28'),(376,8,81,'0','2020-02-19 07:46:28','2020-02-19 07:46:28'),(377,8,82,'0','2020-02-19 07:46:28','2020-02-19 07:46:28'),(378,8,83,'0','2020-02-19 07:46:29','2020-02-19 07:46:29'),(379,8,84,'0','2020-02-19 07:46:29','2020-02-19 07:46:29'),(380,8,85,'0','2020-02-19 07:46:29','2020-02-19 07:46:29'),(381,8,86,'0','2020-02-19 07:46:29','2020-02-19 07:46:29'),(382,9,1,'0','2020-02-19 07:50:50','2020-02-19 07:50:50'),(383,9,2,'0','2020-02-19 07:50:50','2020-02-19 07:50:50'),(384,9,3,'0','2020-02-19 07:50:50','2020-02-19 07:50:50'),(385,9,4,'0','2020-02-19 07:50:50','2020-02-19 07:50:50'),(386,9,5,'0','2020-02-19 07:50:50','2020-02-19 07:50:50'),(387,9,6,'0','2020-02-19 07:50:50','2020-02-19 07:50:50'),(388,9,7,'0','2020-02-19 07:50:50','2020-02-19 07:50:50'),(389,9,8,'0','2020-02-19 07:50:50','2020-02-19 07:50:50'),(390,9,9,'0','2020-02-19 07:50:50','2020-02-19 07:50:50'),(391,9,10,'0','2020-02-19 07:50:50','2020-02-19 07:50:50'),(392,9,11,'0','2020-02-19 07:50:50','2020-02-19 07:50:50'),(393,9,12,'0','2020-02-19 07:50:50','2020-02-19 07:50:50'),(394,9,13,'0','2020-02-19 07:50:50','2020-02-19 07:50:50'),(395,9,14,'0','2020-02-19 07:50:50','2020-02-19 07:50:50'),(396,9,15,'0','2020-02-19 07:50:50','2020-02-19 07:50:50'),(397,9,16,'0','2020-02-19 07:50:50','2020-02-19 07:50:50'),(398,9,17,'0','2020-02-19 07:50:50','2020-02-19 07:50:50'),(399,9,18,'0','2020-02-19 07:50:50','2020-02-19 07:50:50'),(400,9,19,'0','2020-02-19 07:50:51','2020-02-19 07:50:51'),(401,9,20,'0','2020-02-19 07:50:51','2020-02-19 07:50:51'),(402,9,21,'0','2020-02-19 07:50:51','2020-02-19 07:50:51'),(403,9,22,'0','2020-02-19 07:50:51','2020-02-19 07:50:51'),(404,9,23,'0','2020-02-19 07:50:51','2020-02-19 07:50:51'),(405,9,24,'0','2020-02-19 07:50:51','2020-02-19 07:50:51'),(406,9,25,'0','2020-02-19 07:50:51','2020-02-19 07:50:51'),(407,9,26,'0','2020-02-19 07:50:51','2020-02-19 07:50:51'),(408,9,27,'0','2020-02-19 07:50:51','2020-02-19 07:50:51'),(409,9,28,'0','2020-02-19 07:50:51','2020-02-19 07:50:51'),(410,9,29,'0','2020-02-19 07:50:51','2020-02-19 07:50:51'),(411,9,30,'0','2020-02-19 07:50:51','2020-02-19 07:50:51'),(412,9,31,'0','2020-02-19 07:50:51','2020-02-19 07:50:51'),(413,9,32,'0','2020-02-19 07:50:51','2020-02-19 07:50:51'),(414,9,33,'0','2020-02-19 07:50:51','2020-02-19 07:50:51'),(415,9,34,'0','2020-02-19 07:50:51','2020-02-19 07:50:51'),(416,9,35,'0','2020-02-19 07:50:51','2020-02-19 07:50:51'),(417,9,36,'0','2020-02-19 07:50:51','2020-02-19 07:50:51'),(418,9,37,'0','2020-02-19 07:50:51','2020-02-19 07:50:51'),(419,9,38,'0','2020-02-19 07:50:51','2020-02-19 07:50:51'),(420,9,39,'0','2020-02-19 07:50:51','2020-02-19 07:50:51'),(421,9,40,'0','2020-02-19 07:50:51','2020-02-19 07:50:51'),(422,9,41,'0','2020-02-19 07:50:51','2020-02-19 07:50:51'),(423,9,42,'0','2020-02-19 07:50:51','2020-02-19 07:50:51'),(424,9,43,'0','2020-02-19 07:50:51','2020-02-19 07:50:51'),(425,9,44,'0','2020-02-19 07:50:52','2020-02-19 07:50:52'),(426,9,45,'0','2020-02-19 07:50:52','2020-02-19 07:50:52'),(427,9,46,'0','2020-02-19 07:50:52','2020-02-19 07:50:52'),(428,9,47,'0','2020-02-19 07:50:52','2020-02-19 07:50:52'),(429,9,48,'0','2020-02-19 07:50:52','2020-02-19 07:50:52'),(430,9,49,'0','2020-02-19 07:50:52','2020-02-19 07:50:52'),(431,9,50,'0','2020-02-19 07:50:52','2020-02-19 07:50:52'),(432,9,51,'0','2020-02-19 07:50:52','2020-02-19 07:50:52'),(433,9,52,'0','2020-02-19 07:50:52','2020-02-19 07:50:52'),(434,9,53,'0','2020-02-19 07:50:52','2020-02-19 07:50:52'),(435,9,54,'0','2020-02-19 07:50:52','2020-02-19 07:50:52'),(436,9,55,'0','2020-02-19 07:50:52','2020-02-19 07:50:52'),(437,9,56,'0','2020-02-19 07:50:52','2020-02-19 07:50:52'),(438,9,57,'0','2020-02-19 07:50:52','2020-02-19 07:50:52'),(439,9,58,'0','2020-02-19 07:50:52','2020-02-19 07:50:52'),(440,9,59,'0','2020-02-19 07:50:52','2020-02-19 07:50:52'),(441,9,60,'0','2020-02-19 07:50:52','2020-02-19 07:50:52'),(442,9,61,'0','2020-02-19 07:50:52','2020-02-19 07:50:52'),(443,9,62,'0','2020-02-19 07:50:52','2020-02-19 07:50:52'),(444,9,63,'0','2020-02-19 07:50:52','2020-02-19 07:50:52'),(445,9,64,'0','2020-02-19 07:50:52','2020-02-19 07:50:52'),(446,9,65,'0','2020-02-19 07:50:52','2020-02-19 07:50:52'),(447,9,66,'0','2020-02-19 07:50:52','2020-02-19 07:50:52'),(448,9,67,'0','2020-02-19 07:50:52','2020-02-19 07:50:52'),(449,9,68,'0','2020-02-19 07:50:52','2020-02-19 07:50:52'),(450,9,69,'0','2020-02-19 07:50:52','2020-02-19 07:50:52'),(451,9,70,'0','2020-02-19 07:50:52','2020-02-19 07:50:52'),(452,9,71,'0','2020-02-19 07:50:52','2020-02-19 07:50:52'),(453,9,73,'0','2020-02-19 07:50:52','2020-02-19 07:50:52'),(454,9,74,'0','2020-02-19 07:50:53','2020-02-19 07:50:53'),(455,9,75,'0','2020-02-19 07:50:53','2020-02-19 07:50:53'),(456,9,76,'0','2020-02-19 07:50:53','2020-02-19 07:50:53'),(457,9,77,'0','2020-02-19 07:50:53','2020-02-19 07:50:53'),(458,9,78,'0','2020-02-19 07:50:53','2020-02-19 07:50:53'),(459,9,79,'0','2020-02-19 07:50:53','2020-02-19 07:50:53'),(460,9,80,'0','2020-02-19 07:50:53','2020-02-19 07:50:53'),(461,9,81,'0','2020-02-19 07:50:53','2020-02-19 07:50:53'),(462,9,82,'0','2020-02-19 07:50:53','2020-02-19 07:50:53'),(463,9,83,'0','2020-02-19 07:50:53','2020-02-19 07:50:53'),(464,9,84,'0','2020-02-19 07:50:53','2020-02-19 07:50:53'),(465,9,85,'0','2020-02-19 07:50:53','2020-02-19 07:50:53'),(466,9,86,'0','2020-02-19 07:50:53','2020-02-19 07:50:53'),(467,10,1,'0','2020-02-19 07:51:58','2020-02-19 07:51:58'),(468,10,2,'0','2020-02-19 07:51:58','2020-02-19 07:51:58'),(469,10,3,'0','2020-02-19 07:51:58','2020-02-19 07:51:58'),(470,10,4,'0','2020-02-19 07:51:58','2020-02-19 07:51:58'),(471,10,5,'0','2020-02-19 07:51:58','2020-02-19 07:51:58'),(472,10,6,'0','2020-02-19 07:51:58','2020-02-19 07:51:58'),(473,10,7,'0','2020-02-19 07:51:58','2020-02-19 07:51:58'),(474,10,8,'0','2020-02-19 07:51:58','2020-02-19 07:51:58'),(475,10,9,'0','2020-02-19 07:51:58','2020-02-19 07:51:58'),(476,10,10,'0','2020-02-19 07:51:58','2020-02-19 07:51:58'),(477,10,11,'0','2020-02-19 07:51:58','2020-02-19 07:51:58'),(478,10,12,'0','2020-02-19 07:51:58','2020-02-19 07:51:58'),(479,10,13,'0','2020-02-19 07:51:58','2020-02-19 07:51:58'),(480,10,14,'0','2020-02-19 07:51:58','2020-02-19 07:51:58'),(481,10,15,'0','2020-02-19 07:51:58','2020-02-19 07:51:58'),(482,10,16,'0','2020-02-19 07:51:58','2020-02-19 07:51:58'),(483,10,17,'0','2020-02-19 07:51:59','2020-02-19 07:51:59'),(484,10,18,'0','2020-02-19 07:51:59','2020-02-19 07:51:59'),(485,10,19,'0','2020-02-19 07:51:59','2020-02-19 07:51:59'),(486,10,20,'0','2020-02-19 07:51:59','2020-02-19 07:51:59'),(487,10,21,'0','2020-02-19 07:51:59','2020-02-19 07:51:59'),(488,10,22,'0','2020-02-19 07:51:59','2020-02-19 07:51:59'),(489,10,23,'0','2020-02-19 07:51:59','2020-02-19 07:51:59'),(490,10,24,'0','2020-02-19 07:51:59','2020-02-19 07:51:59'),(491,10,25,'0','2020-02-19 07:51:59','2020-02-19 07:51:59'),(492,10,26,'0','2020-02-19 07:51:59','2020-02-19 07:51:59'),(493,10,27,'0','2020-02-19 07:51:59','2020-02-19 07:51:59'),(494,10,28,'0','2020-02-19 07:51:59','2020-02-19 07:51:59'),(495,10,29,'0','2020-02-19 07:51:59','2020-02-19 07:51:59'),(496,10,30,'0','2020-02-19 07:51:59','2020-02-19 07:51:59'),(497,10,31,'0','2020-02-19 07:51:59','2020-02-19 07:51:59'),(498,10,32,'0','2020-02-19 07:51:59','2020-02-19 07:51:59'),(499,10,33,'0','2020-02-19 07:51:59','2020-02-19 07:51:59'),(500,10,34,'0','2020-02-19 07:51:59','2020-02-19 07:51:59'),(501,10,35,'0','2020-02-19 07:51:59','2020-02-19 07:51:59'),(502,10,36,'0','2020-02-19 07:51:59','2020-02-19 07:51:59'),(503,10,37,'0','2020-02-19 07:51:59','2020-02-19 07:51:59'),(504,10,38,'0','2020-02-19 07:51:59','2020-02-19 07:51:59'),(505,10,39,'0','2020-02-19 07:51:59','2020-02-19 07:51:59'),(506,10,40,'0','2020-02-19 07:51:59','2020-02-19 07:51:59'),(507,10,41,'0','2020-02-19 07:51:59','2020-02-19 07:51:59'),(508,10,42,'0','2020-02-19 07:51:59','2020-02-19 07:51:59'),(509,10,43,'0','2020-02-19 07:51:59','2020-02-19 07:51:59'),(510,10,44,'0','2020-02-19 07:51:59','2020-02-19 07:51:59'),(511,10,45,'0','2020-02-19 07:51:59','2020-02-19 07:51:59'),(512,10,46,'0','2020-02-19 07:51:59','2020-02-19 07:51:59'),(513,10,47,'0','2020-02-19 07:51:59','2020-02-19 07:51:59'),(514,10,48,'0','2020-02-19 07:52:00','2020-02-19 07:52:00'),(515,10,49,'0','2020-02-19 07:52:00','2020-02-19 07:52:00'),(516,10,50,'0','2020-02-19 07:52:00','2020-02-19 07:52:00'),(517,10,51,'0','2020-02-19 07:52:00','2020-02-19 07:52:00'),(518,10,52,'0','2020-02-19 07:52:00','2020-02-19 07:52:00'),(519,10,53,'0','2020-02-19 07:52:00','2020-02-19 07:52:00'),(520,10,54,'0','2020-02-19 07:52:00','2020-02-19 07:52:00'),(521,10,55,'0','2020-02-19 07:52:00','2020-02-19 07:52:00'),(522,10,56,'0','2020-02-19 07:52:00','2020-02-19 07:52:00'),(523,10,57,'0','2020-02-19 07:52:00','2020-02-19 07:52:00'),(524,10,58,'0','2020-02-19 07:52:00','2020-02-19 07:52:00'),(525,10,59,'0','2020-02-19 07:52:00','2020-02-19 07:52:00'),(526,10,60,'0','2020-02-19 07:52:00','2020-02-19 07:52:00'),(527,10,61,'0','2020-02-19 07:52:00','2020-02-19 07:52:00'),(528,10,62,'0','2020-02-19 07:52:00','2020-02-19 07:52:00'),(529,10,63,'0','2020-02-19 07:52:00','2020-02-19 07:52:00'),(530,10,64,'0','2020-02-19 07:52:00','2020-02-19 07:52:00'),(531,10,65,'0','2020-02-19 07:52:00','2020-02-19 07:52:00'),(532,10,66,'0','2020-02-19 07:52:00','2020-02-19 07:52:00'),(533,10,67,'0','2020-02-19 07:52:00','2020-02-19 07:52:00'),(534,10,68,'0','2020-02-19 07:52:00','2020-02-19 07:52:00'),(535,10,69,'0','2020-02-19 07:52:00','2020-02-19 07:52:00'),(536,10,70,'0','2020-02-19 07:52:00','2020-02-19 07:52:00'),(537,10,71,'0','2020-02-19 07:52:00','2020-02-19 07:52:00'),(538,10,73,'0','2020-02-19 07:52:00','2020-02-19 07:52:00'),(539,10,74,'0','2020-02-19 07:52:00','2020-02-19 07:52:00'),(540,10,75,'0','2020-02-19 07:52:00','2020-02-19 07:52:00'),(541,10,76,'0','2020-02-19 07:52:01','2020-02-19 07:52:01'),(542,10,77,'0','2020-02-19 07:52:01','2020-02-19 07:52:01'),(543,10,78,'0','2020-02-19 07:52:01','2020-02-19 07:52:01'),(544,10,79,'0','2020-02-19 07:52:01','2020-02-19 07:52:01'),(545,10,80,'0','2020-02-19 07:52:01','2020-02-19 07:52:01'),(546,10,81,'0','2020-02-19 07:52:01','2020-02-19 07:52:01'),(547,10,82,'0','2020-02-19 07:52:01','2020-02-19 07:52:01'),(548,10,83,'0','2020-02-19 07:52:01','2020-02-19 07:52:01'),(549,10,84,'0','2020-02-19 07:52:01','2020-02-19 07:52:01'),(550,10,85,'0','2020-02-19 07:52:01','2020-02-19 07:52:01'),(551,10,86,'0','2020-02-19 07:52:01','2020-02-19 07:52:01'),(552,11,1,'0','2020-02-19 07:53:14','2020-02-19 07:53:14'),(553,11,2,'0','2020-02-19 07:53:14','2020-02-19 07:53:14'),(554,11,3,'0','2020-02-19 07:53:14','2020-02-19 07:53:14'),(555,11,4,'0','2020-02-19 07:53:14','2020-02-19 07:53:14'),(556,11,5,'0','2020-02-19 07:53:14','2020-02-19 07:53:14'),(557,11,6,'0','2020-02-19 07:53:14','2020-02-19 07:53:14'),(558,11,7,'0','2020-02-19 07:53:14','2020-02-19 07:53:14'),(559,11,8,'0','2020-02-19 07:53:14','2020-02-19 07:53:14'),(560,11,9,'0','2020-02-19 07:53:14','2020-02-19 07:53:14'),(561,11,10,'0','2020-02-19 07:53:14','2020-02-19 07:53:14'),(562,11,11,'0','2020-02-19 07:53:14','2020-02-19 07:53:14'),(563,11,12,'0','2020-02-19 07:53:15','2020-02-19 07:53:15'),(564,11,13,'0','2020-02-19 07:53:15','2020-02-19 07:53:15'),(565,11,14,'0','2020-02-19 07:53:15','2020-02-19 07:53:15'),(566,11,15,'0','2020-02-19 07:53:15','2020-02-19 07:53:15'),(567,11,16,'0','2020-02-19 07:53:15','2020-02-19 07:53:15'),(568,11,17,'0','2020-02-19 07:53:15','2020-02-19 07:53:15'),(569,11,18,'0','2020-02-19 07:53:15','2020-02-19 07:53:15'),(570,11,19,'0','2020-02-19 07:53:15','2020-02-19 07:53:15'),(571,11,20,'0','2020-02-19 07:53:15','2020-02-19 07:53:15'),(572,11,21,'0','2020-02-19 07:53:15','2020-02-19 07:53:15'),(573,11,22,'0','2020-02-19 07:53:15','2020-02-19 07:53:15'),(574,11,23,'0','2020-02-19 07:53:15','2020-02-19 07:53:15'),(575,11,24,'0','2020-02-19 07:53:15','2020-02-19 07:53:15'),(576,11,25,'0','2020-02-19 07:53:15','2020-02-19 07:53:15'),(577,11,26,'0','2020-02-19 07:53:15','2020-02-19 07:53:15'),(578,11,27,'0','2020-02-19 07:53:15','2020-02-19 07:53:15'),(579,11,28,'0','2020-02-19 07:53:15','2020-02-19 07:53:15'),(580,11,29,'0','2020-02-19 07:53:15','2020-02-19 07:53:15'),(581,11,30,'0','2020-02-19 07:53:15','2020-02-19 07:53:15'),(582,11,31,'0','2020-02-19 07:53:15','2020-02-19 07:53:15'),(583,11,32,'0','2020-02-19 07:53:15','2020-02-19 07:53:15'),(584,11,33,'0','2020-02-19 07:53:15','2020-02-19 07:53:15'),(585,11,34,'0','2020-02-19 07:53:15','2020-02-19 07:53:15'),(586,11,35,'0','2020-02-19 07:53:15','2020-02-19 07:53:15'),(587,11,36,'0','2020-02-19 07:53:15','2020-02-19 07:53:15'),(588,11,37,'0','2020-02-19 07:53:15','2020-02-19 07:53:15'),(589,11,38,'0','2020-02-19 07:53:15','2020-02-19 07:53:15'),(590,11,39,'0','2020-02-19 07:53:16','2020-02-19 07:53:16'),(591,11,40,'0','2020-02-19 07:53:16','2020-02-19 07:53:16'),(592,11,41,'0','2020-02-19 07:53:16','2020-02-19 07:53:16'),(593,11,42,'0','2020-02-19 07:53:16','2020-02-19 07:53:16'),(594,11,43,'0','2020-02-19 07:53:16','2020-02-19 07:53:16'),(595,11,44,'0','2020-02-19 07:53:16','2020-02-19 07:53:16'),(596,11,45,'0','2020-02-19 07:53:16','2020-02-19 07:53:16'),(597,11,46,'0','2020-02-19 07:53:16','2020-02-19 07:53:16'),(598,11,47,'0','2020-02-19 07:53:16','2020-02-19 07:53:16'),(599,11,48,'0','2020-02-19 07:53:16','2020-02-19 07:53:16'),(600,11,49,'0','2020-02-19 07:53:16','2020-02-19 07:53:16'),(601,11,50,'0','2020-02-19 07:53:16','2020-02-19 07:53:16'),(602,11,51,'0','2020-02-19 07:53:16','2020-02-19 07:53:16'),(603,11,52,'0','2020-02-19 07:53:16','2020-02-19 07:53:16'),(604,11,53,'0','2020-02-19 07:53:16','2020-02-19 07:53:16'),(605,11,54,'0','2020-02-19 07:53:16','2020-02-19 07:53:16'),(606,11,55,'0','2020-02-19 07:53:16','2020-02-19 07:53:16'),(607,11,56,'0','2020-02-19 07:53:16','2020-02-19 07:53:16'),(608,11,57,'0','2020-02-19 07:53:16','2020-02-19 07:53:16'),(609,11,58,'0','2020-02-19 07:53:16','2020-02-19 07:53:16'),(610,11,59,'0','2020-02-19 07:53:16','2020-02-19 07:53:16'),(611,11,60,'0','2020-02-19 07:53:16','2020-02-19 07:53:16'),(612,11,61,'0','2020-02-19 07:53:16','2020-02-19 07:53:16'),(613,11,62,'0','2020-02-19 07:53:16','2020-02-19 07:53:16'),(614,11,63,'0','2020-02-19 07:53:17','2020-02-19 07:53:17'),(615,11,64,'0','2020-02-19 07:53:17','2020-02-19 07:53:17'),(616,11,65,'0','2020-02-19 07:53:17','2020-02-19 07:53:17'),(617,11,66,'0','2020-02-19 07:53:17','2020-02-19 07:53:17'),(618,11,67,'0','2020-02-19 07:53:17','2020-02-19 07:53:17'),(619,11,68,'0','2020-02-19 07:53:17','2020-02-19 07:53:17'),(620,11,69,'0','2020-02-19 07:53:17','2020-02-19 07:53:17'),(621,11,70,'0','2020-02-19 07:53:17','2020-02-19 07:53:17'),(622,11,71,'0','2020-02-19 07:53:17','2020-02-19 07:53:17'),(623,11,73,'0','2020-02-19 07:53:17','2020-02-19 07:53:17'),(624,11,74,'0','2020-02-19 07:53:17','2020-02-19 07:53:17'),(625,11,75,'0','2020-02-19 07:53:17','2020-02-19 07:53:17'),(626,11,76,'0','2020-02-19 07:53:17','2020-02-19 07:53:17'),(627,11,77,'0','2020-02-19 07:53:17','2020-02-19 07:53:17'),(628,11,78,'0','2020-02-19 07:53:17','2020-02-19 07:53:17'),(629,11,79,'0','2020-02-19 07:53:17','2020-02-19 07:53:17'),(630,11,80,'0','2020-02-19 07:53:17','2020-02-19 07:53:17'),(631,11,81,'0','2020-02-19 07:53:17','2020-02-19 07:53:17'),(632,11,82,'0','2020-02-19 07:53:17','2020-02-19 07:53:17'),(633,11,83,'0','2020-02-19 07:53:17','2020-02-19 07:53:17'),(634,11,84,'0','2020-02-19 07:53:17','2020-02-19 07:53:17'),(635,11,85,'0','2020-02-19 07:53:17','2020-02-19 07:53:17'),(636,11,86,'0','2020-02-19 07:53:17','2020-02-19 07:53:17'),(637,0,88,'0','2020-02-19 08:29:22','2020-02-19 08:29:22'),(638,0,89,'0','2020-02-19 08:29:22','2020-02-19 08:29:22'),(639,2,88,'1','2020-02-19 08:29:34','2020-02-19 08:29:34'),(640,2,89,'1','2020-02-19 08:29:35','2020-02-19 08:29:35'),(641,0,90,'0','2020-02-19 10:22:17','2020-02-19 10:22:17'),(642,0,91,'0','2020-02-19 10:22:17','2020-02-19 10:22:17'),(643,2,90,'1','2020-02-19 10:22:19','2020-02-19 10:22:19'),(645,0,92,'0','2020-02-19 10:47:35','2020-02-19 10:47:35'),(646,2,92,'1','2020-02-19 10:47:37','2020-02-19 10:47:37'),(647,12,1,'0','2020-02-21 06:41:41','2020-02-21 06:41:41'),(648,12,2,'0','2020-02-21 06:41:41','2020-02-21 06:41:41'),(649,12,3,'0','2020-02-21 06:41:41','2020-02-21 06:41:41'),(650,12,4,'0','2020-02-21 06:41:41','2020-02-21 06:41:41'),(651,12,5,'0','2020-02-21 06:41:41','2020-02-21 06:41:41'),(652,12,6,'0','2020-02-21 06:41:41','2020-02-21 06:41:41'),(653,12,7,'0','2020-02-21 06:41:41','2020-02-21 06:41:41'),(654,12,8,'0','2020-02-21 06:41:41','2020-02-21 06:41:41'),(655,12,9,'0','2020-02-21 06:41:41','2020-02-21 06:41:41'),(656,12,10,'0','2020-02-21 06:41:41','2020-02-21 06:41:41'),(657,12,11,'0','2020-02-21 06:41:41','2020-02-21 06:41:41'),(658,12,12,'0','2020-02-21 06:41:41','2020-02-21 06:41:41'),(659,12,13,'0','2020-02-21 06:41:41','2020-02-21 06:41:41'),(660,12,14,'0','2020-02-21 06:41:41','2020-02-21 06:41:41'),(661,12,15,'0','2020-02-21 06:41:41','2020-02-21 06:41:41'),(662,12,16,'0','2020-02-21 06:41:41','2020-02-21 06:41:41'),(663,12,17,'0','2020-02-21 06:41:41','2020-02-21 06:41:41'),(664,12,18,'0','2020-02-21 06:41:41','2020-02-21 06:41:41'),(665,12,19,'0','2020-02-21 06:41:41','2020-02-21 06:41:41'),(666,12,20,'0','2020-02-21 06:41:41','2020-02-21 06:41:41'),(667,12,21,'0','2020-02-21 06:41:41','2020-02-21 06:41:41'),(668,12,22,'0','2020-02-21 06:41:41','2020-02-21 06:41:41'),(669,12,23,'0','2020-02-21 06:41:42','2020-02-21 06:41:42'),(670,12,24,'0','2020-02-21 06:41:42','2020-02-21 06:41:42'),(671,12,25,'0','2020-02-21 06:41:42','2020-02-21 06:41:42'),(672,12,26,'0','2020-02-21 06:41:42','2020-02-21 06:41:42'),(673,12,27,'0','2020-02-21 06:41:42','2020-02-21 06:41:42'),(674,12,28,'0','2020-02-21 06:41:42','2020-02-21 06:41:42'),(675,12,29,'0','2020-02-21 06:41:42','2020-02-21 06:41:42'),(676,12,30,'0','2020-02-21 06:41:42','2020-02-21 06:41:42'),(677,12,31,'0','2020-02-21 06:41:42','2020-02-21 06:41:42'),(678,12,32,'0','2020-02-21 06:41:42','2020-02-21 06:41:42'),(679,12,33,'0','2020-02-21 06:41:42','2020-02-21 06:41:42'),(680,12,34,'0','2020-02-21 06:41:42','2020-02-21 06:41:42'),(681,12,35,'0','2020-02-21 06:41:42','2020-02-21 06:41:42'),(682,12,36,'0','2020-02-21 06:41:42','2020-02-21 06:41:42'),(683,12,37,'0','2020-02-21 06:41:42','2020-02-21 06:41:42'),(684,12,38,'0','2020-02-21 06:41:42','2020-02-21 06:41:42'),(685,12,39,'0','2020-02-21 06:41:42','2020-02-21 06:41:42'),(686,12,40,'0','2020-02-21 06:41:42','2020-02-21 06:41:42'),(687,12,41,'0','2020-02-21 06:41:42','2020-02-21 06:41:42'),(688,12,42,'0','2020-02-21 06:41:42','2020-02-21 06:41:42'),(689,12,43,'0','2020-02-21 06:41:42','2020-02-21 06:41:42'),(690,12,44,'0','2020-02-21 06:41:42','2020-02-21 06:41:42'),(691,12,45,'0','2020-02-21 06:41:42','2020-02-21 06:41:42'),(692,12,46,'0','2020-02-21 06:41:42','2020-02-21 06:41:42'),(693,12,47,'0','2020-02-21 06:41:42','2020-02-21 06:41:42'),(694,12,48,'0','2020-02-21 06:41:42','2020-02-21 06:41:42'),(695,12,49,'0','2020-02-21 06:41:42','2020-02-21 06:41:42'),(696,12,50,'0','2020-02-21 06:41:42','2020-02-21 06:41:42'),(697,12,51,'0','2020-02-21 06:41:42','2020-02-21 06:41:42'),(698,12,52,'0','2020-02-21 06:41:42','2020-02-21 06:41:42'),(699,12,53,'0','2020-02-21 06:41:42','2020-02-21 06:41:42'),(700,12,54,'0','2020-02-21 06:41:42','2020-02-21 06:41:42'),(701,12,55,'0','2020-02-21 06:41:43','2020-02-21 06:41:43'),(702,12,56,'0','2020-02-21 06:41:43','2020-02-21 06:41:43'),(703,12,57,'0','2020-02-21 06:41:43','2020-02-21 06:41:43'),(704,12,58,'0','2020-02-21 06:41:43','2020-02-21 06:41:43'),(705,12,59,'0','2020-02-21 06:41:43','2020-02-21 06:41:43'),(706,12,60,'0','2020-02-21 06:41:43','2020-02-21 06:41:43'),(707,12,61,'0','2020-02-21 06:41:43','2020-02-21 06:41:43'),(708,12,62,'0','2020-02-21 06:41:43','2020-02-21 06:41:43'),(709,12,63,'0','2020-02-21 06:41:43','2020-02-21 06:41:43'),(710,12,64,'0','2020-02-21 06:41:43','2020-02-21 06:41:43'),(711,12,65,'0','2020-02-21 06:41:43','2020-02-21 06:41:43'),(712,12,66,'0','2020-02-21 06:41:43','2020-02-21 06:41:43'),(713,12,67,'0','2020-02-21 06:41:43','2020-02-21 06:41:43'),(714,12,68,'0','2020-02-21 06:41:43','2020-02-21 06:41:43'),(715,12,69,'0','2020-02-21 06:41:43','2020-02-21 06:41:43'),(716,12,70,'0','2020-02-21 06:41:43','2020-02-21 06:41:43'),(717,12,71,'0','2020-02-21 06:41:43','2020-02-21 06:41:43'),(718,12,73,'0','2020-02-21 06:41:43','2020-02-21 06:41:43'),(719,12,74,'0','2020-02-21 06:41:43','2020-02-21 06:41:43'),(720,12,75,'0','2020-02-21 06:41:43','2020-02-21 06:41:43'),(721,12,76,'0','2020-02-21 06:41:43','2020-02-21 06:41:43'),(722,12,77,'0','2020-02-21 06:41:43','2020-02-21 06:41:43'),(723,12,78,'0','2020-02-21 06:41:43','2020-02-21 06:41:43'),(724,12,79,'0','2020-02-21 06:41:43','2020-02-21 06:41:43'),(725,12,80,'0','2020-02-21 06:41:43','2020-02-21 06:41:43'),(726,12,81,'0','2020-02-21 06:41:43','2020-02-21 06:41:43'),(727,12,82,'0','2020-02-21 06:41:43','2020-02-21 06:41:43'),(728,12,83,'0','2020-02-21 06:41:43','2020-02-21 06:41:43'),(729,12,84,'0','2020-02-21 06:41:43','2020-02-21 06:41:43'),(730,12,85,'0','2020-02-21 06:41:43','2020-02-21 06:41:43'),(731,12,86,'0','2020-02-21 06:41:43','2020-02-21 06:41:43'),(732,12,87,'0','2020-02-21 06:41:43','2020-02-21 06:41:43'),(733,12,88,'0','2020-02-21 06:41:44','2020-02-21 06:41:44'),(734,12,89,'0','2020-02-21 06:41:44','2020-02-21 06:41:44'),(735,0,93,'0','2020-02-22 10:43:53','2020-02-22 10:43:53'),(736,0,94,'0','2020-02-22 10:43:53','2020-02-22 10:43:53'),(737,0,95,'0','2020-02-22 10:43:53','2020-02-22 10:43:53'),(738,0,96,'0','2020-02-22 10:43:53','2020-02-22 10:43:53'),(739,2,93,'1','2020-02-22 10:44:01','2020-02-22 10:44:01'),(740,2,94,'1','2020-02-22 10:44:01','2020-02-22 10:44:01'),(741,2,95,'1','2020-02-22 10:44:01','2020-02-22 10:44:01'),(742,2,96,'1','2020-02-22 10:44:01','2020-02-22 10:44:01'),(743,0,99,'0','2020-02-25 05:36:12','2020-02-25 05:36:12'),(744,2,99,'1','2020-02-25 05:36:15','2020-02-25 05:36:15'),(745,0,100,'0','2020-02-25 05:42:12','2020-02-25 05:42:12'),(746,0,101,'0','2020-02-25 05:42:12','2020-02-25 05:42:12'),(747,2,100,'1','2020-02-25 05:42:15','2020-02-25 05:42:15'),(748,2,101,'1','2020-02-25 05:42:15','2020-02-25 05:42:15'),(749,0,102,'0','2020-03-05 06:35:43','2020-03-05 06:35:43'),(750,2,102,'1','2020-03-05 06:35:46','2020-03-05 06:35:46'),(751,7,34,'0','2020-03-14 12:36:28','2020-03-14 12:36:28'),(752,7,35,'0','2020-03-14 12:36:28','2020-03-14 12:36:28'),(753,7,36,'0','2020-03-14 12:36:28','2020-03-14 12:36:28'),(754,7,37,'0','2020-03-14 12:36:28','2020-03-14 12:36:28'),(755,7,38,'0','2020-03-14 12:36:28','2020-03-14 12:36:28'),(756,7,39,'0','2020-03-14 12:36:28','2020-03-14 12:36:28'),(757,7,40,'0','2020-03-14 12:36:28','2020-03-14 12:36:28'),(758,7,41,'0','2020-03-14 12:36:28','2020-03-14 12:36:28'),(759,7,42,'0','2020-03-14 12:36:28','2020-03-14 12:36:28'),(760,7,43,'0','2020-03-14 12:36:28','2020-03-14 12:36:28'),(761,7,44,'0','2020-03-14 12:36:28','2020-03-14 12:36:28'),(762,7,45,'0','2020-03-14 12:36:28','2020-03-14 12:36:28'),(763,7,46,'0','2020-03-14 12:36:28','2020-03-14 12:36:28'),(764,7,47,'0','2020-03-14 12:36:28','2020-03-14 12:36:28'),(765,7,48,'0','2020-03-14 12:36:28','2020-03-14 12:36:28'),(766,7,49,'0','2020-03-14 12:36:28','2020-03-14 12:36:28'),(767,7,50,'0','2020-03-14 12:36:28','2020-03-14 12:36:28'),(768,7,51,'0','2020-03-14 12:36:28','2020-03-14 12:36:28'),(769,7,52,'0','2020-03-14 12:36:28','2020-03-14 12:36:28'),(770,7,53,'0','2020-03-14 12:36:28','2020-03-14 12:36:28'),(771,7,54,'0','2020-03-14 12:36:28','2020-03-14 12:36:28'),(772,7,55,'0','2020-03-14 12:36:28','2020-03-14 12:36:28'),(773,7,56,'0','2020-03-14 12:36:28','2020-03-14 12:36:28'),(774,7,57,'0','2020-03-14 12:36:28','2020-03-14 12:36:28'),(775,7,58,'0','2020-03-14 12:36:28','2020-03-14 12:36:28'),(776,7,59,'0','2020-03-14 12:36:28','2020-03-14 12:36:28'),(777,7,60,'0','2020-03-14 12:36:28','2020-03-14 12:36:28'),(778,7,61,'0','2020-03-14 12:36:28','2020-03-14 12:36:28'),(779,7,62,'0','2020-03-14 12:36:28','2020-03-14 12:36:28'),(780,7,63,'0','2020-03-14 12:36:28','2020-03-14 12:36:28'),(781,7,64,'0','2020-03-14 12:36:28','2020-03-14 12:36:28'),(782,7,65,'0','2020-03-14 12:36:29','2020-03-14 12:36:29'),(783,7,66,'0','2020-03-14 12:36:29','2020-03-14 12:36:29'),(784,7,67,'0','2020-03-14 12:36:29','2020-03-14 12:36:29'),(785,7,68,'0','2020-03-14 12:36:29','2020-03-14 12:36:29'),(786,7,69,'0','2020-03-14 12:36:29','2020-03-14 12:36:29'),(787,7,70,'0','2020-03-14 12:36:29','2020-03-14 12:36:29'),(788,7,71,'0','2020-03-14 12:36:29','2020-03-14 12:36:29'),(789,7,73,'0','2020-03-14 12:36:29','2020-03-14 12:36:29'),(790,7,74,'0','2020-03-14 12:36:29','2020-03-14 12:36:29'),(791,7,75,'0','2020-03-14 12:36:29','2020-03-14 12:36:29'),(792,7,76,'0','2020-03-14 12:36:29','2020-03-14 12:36:29'),(793,7,77,'0','2020-03-14 12:36:29','2020-03-14 12:36:29'),(794,7,78,'0','2020-03-14 12:36:29','2020-03-14 12:36:29'),(795,7,79,'0','2020-03-14 12:36:29','2020-03-14 12:36:29'),(796,7,80,'0','2020-03-14 12:36:29','2020-03-14 12:36:29'),(797,7,81,'0','2020-03-14 12:36:29','2020-03-14 12:36:29'),(798,7,82,'0','2020-03-14 12:36:29','2020-03-14 12:36:29'),(799,7,83,'0','2020-03-14 12:36:29','2020-03-14 12:36:29'),(800,7,84,'0','2020-03-14 12:36:29','2020-03-14 12:36:29'),(801,7,85,'0','2020-03-14 12:36:29','2020-03-14 12:36:29'),(802,7,86,'0','2020-03-14 12:36:29','2020-03-14 12:36:29'),(803,7,87,'0','2020-03-14 12:36:29','2020-03-14 12:36:29'),(804,7,88,'0','2020-03-14 12:36:29','2020-03-14 12:36:29'),(805,7,89,'0','2020-03-14 12:36:29','2020-03-14 12:36:29'),(806,7,93,'0','2020-03-14 12:36:29','2020-03-14 12:36:29'),(807,7,94,'0','2020-03-14 12:36:29','2020-03-14 12:36:29'),(808,7,95,'0','2020-03-14 12:36:29','2020-03-14 12:36:29'),(809,7,96,'0','2020-03-14 12:36:29','2020-03-14 12:36:29'),(810,7,99,'0','2020-03-14 12:36:29','2020-03-14 12:36:29'),(811,7,100,'0','2020-03-14 12:36:29','2020-03-14 12:36:29'),(812,7,101,'0','2020-03-14 12:36:29','2020-03-14 12:36:29'),(813,7,102,'0','2020-03-14 12:36:29','2020-03-14 12:36:29'),(814,13,1,'1','2020-04-08 16:16:09',NULL),(815,13,2,'1','2020-04-08 16:16:09',NULL),(816,13,3,'1','2020-04-08 16:16:09',NULL),(817,13,4,'1','2020-04-08 16:16:09',NULL),(818,13,5,'0','2020-04-08 16:16:09',NULL),(819,13,6,'0','2020-04-08 16:16:10',NULL),(820,13,7,'0','2020-04-08 16:16:10',NULL),(821,13,8,'0','2020-04-08 16:16:10',NULL),(822,13,9,'0','2020-04-08 16:16:10',NULL),(823,13,10,'0','2020-04-08 16:16:10',NULL),(824,13,11,'0','2020-04-08 16:16:10',NULL),(825,13,12,'0','2020-04-08 16:16:10',NULL),(826,13,13,'0','2020-04-08 16:16:10',NULL),(827,13,14,'0','2020-04-08 16:16:10',NULL),(828,13,15,'0','2020-04-08 16:16:10',NULL),(829,13,16,'0','2020-04-08 16:16:10',NULL),(830,13,17,'0','2020-04-08 16:16:11',NULL),(831,13,18,'0','2020-04-08 16:16:11',NULL),(832,13,19,'0','2020-04-08 16:16:11',NULL),(833,13,20,'0','2020-04-08 16:16:11',NULL),(834,13,21,'0','2020-04-08 16:16:11',NULL),(835,13,22,'0','2020-04-08 16:16:11',NULL),(836,13,23,'0','2020-04-08 16:16:11',NULL),(837,13,24,'0','2020-04-08 16:16:11',NULL),(838,13,25,'0','2020-04-08 16:16:11',NULL),(839,13,26,'0','2020-04-08 16:16:11',NULL),(840,13,27,'0','2020-04-08 16:16:12',NULL),(841,13,28,'0','2020-04-08 16:16:12',NULL),(842,13,29,'0','2020-04-08 16:16:12',NULL),(843,13,30,'0','2020-04-08 16:16:12',NULL),(844,13,31,'0','2020-04-08 16:16:12',NULL),(845,13,32,'0','2020-04-08 16:16:12',NULL),(846,13,33,'0','2020-04-08 16:16:12',NULL),(847,13,34,'0','2020-04-08 16:16:12',NULL),(848,13,35,'0','2020-04-08 16:16:12',NULL),(849,13,36,'0','2020-04-08 16:16:12',NULL),(850,13,37,'0','2020-04-08 16:16:12',NULL),(851,13,38,'0','2020-04-08 16:16:12',NULL),(852,13,39,'0','2020-04-08 16:16:12',NULL),(853,13,40,'0','2020-04-08 16:16:12',NULL),(854,13,41,'0','2020-04-08 16:16:12',NULL),(855,13,42,'0','2020-04-08 16:16:12',NULL),(856,13,43,'0','2020-04-08 16:16:12',NULL),(857,13,44,'0','2020-04-08 16:16:13',NULL),(858,13,45,'0','2020-04-08 16:16:13',NULL),(859,13,46,'0','2020-04-08 16:16:13',NULL),(860,13,47,'0','2020-04-08 16:16:13',NULL),(861,13,48,'0','2020-04-08 16:16:13',NULL),(862,13,49,'0','2020-04-08 16:16:13',NULL),(863,13,50,'0','2020-04-08 16:16:13',NULL),(864,13,51,'0','2020-04-08 16:16:13',NULL),(865,13,52,'0','2020-04-08 16:16:13',NULL),(866,13,53,'0','2020-04-08 16:16:13',NULL),(867,13,54,'0','2020-04-08 16:16:13',NULL),(868,13,55,'0','2020-04-08 16:16:13',NULL),(869,13,56,'0','2020-04-08 16:16:13',NULL),(870,13,57,'0','2020-04-08 16:16:13',NULL),(871,13,58,'0','2020-04-08 16:16:13',NULL),(872,13,59,'0','2020-04-08 16:16:13',NULL),(873,13,60,'0','2020-04-08 16:16:13',NULL),(874,13,61,'0','2020-04-08 16:16:13',NULL),(875,13,62,'0','2020-04-08 16:16:14',NULL),(876,13,63,'0','2020-04-08 16:16:14',NULL),(877,13,64,'0','2020-04-08 16:16:14',NULL),(878,13,65,'0','2020-04-08 16:16:14',NULL),(879,13,66,'0','2020-04-08 16:16:14',NULL),(880,13,67,'0','2020-04-08 16:16:14',NULL),(881,13,68,'0','2020-04-08 16:16:14',NULL),(882,13,69,'0','2020-04-08 16:16:14',NULL),(883,13,70,'0','2020-04-08 16:16:14',NULL),(884,13,71,'0','2020-04-08 16:16:14',NULL),(885,13,73,'0','2020-04-08 16:16:14',NULL),(886,13,74,'0','2020-04-08 16:16:14',NULL),(887,13,75,'0','2020-04-08 16:16:14',NULL),(888,13,76,'0','2020-04-08 16:16:14',NULL),(889,13,77,'0','2020-04-08 16:16:14',NULL),(890,13,78,'0','2020-04-08 16:16:14',NULL),(891,13,79,'0','2020-04-08 16:16:14',NULL),(892,13,80,'0','2020-04-08 16:16:14',NULL),(893,13,81,'0','2020-04-08 16:16:14',NULL),(894,13,82,'0','2020-04-08 16:16:14',NULL),(895,13,83,'0','2020-04-08 16:16:14',NULL),(896,13,84,'0','2020-04-08 16:16:14',NULL),(897,13,85,'0','2020-04-08 16:16:14',NULL),(898,13,86,'0','2020-04-08 16:16:15',NULL),(899,13,87,'0','2020-04-08 16:16:15',NULL),(900,13,88,'0','2020-04-08 16:16:15',NULL),(901,13,89,'0','2020-04-08 16:16:15',NULL),(902,13,93,'0','2020-04-08 16:16:15',NULL),(903,13,94,'0','2020-04-08 16:16:15',NULL),(904,13,95,'0','2020-04-08 16:16:15',NULL),(905,13,96,'0','2020-04-08 16:16:15',NULL),(906,13,99,'0','2020-04-08 16:16:15',NULL),(907,13,100,'0','2020-04-08 16:16:15',NULL),(908,13,101,'0','2020-04-08 16:16:15',NULL),(909,13,102,'0','2020-04-08 16:16:15',NULL),(910,14,1,'0','2020-07-01 11:34:29',NULL),(911,14,2,'0','2020-07-01 11:34:29',NULL),(912,14,3,'0','2020-07-01 11:34:29',NULL),(913,14,4,'0','2020-07-01 11:34:29',NULL),(914,14,5,'0','2020-07-01 11:34:29',NULL),(915,14,6,'0','2020-07-01 11:34:29',NULL),(916,14,7,'0','2020-07-01 11:34:30',NULL),(917,14,8,'0','2020-07-01 11:34:30',NULL),(918,14,9,'0','2020-07-01 11:34:30',NULL),(919,14,10,'0','2020-07-01 11:34:30',NULL),(920,14,11,'0','2020-07-01 11:34:30',NULL),(921,14,12,'0','2020-07-01 11:34:30',NULL),(922,14,13,'0','2020-07-01 11:34:30',NULL),(923,14,14,'0','2020-07-01 11:34:30',NULL),(924,14,15,'0','2020-07-01 11:34:30',NULL),(925,14,16,'0','2020-07-01 11:34:30',NULL),(926,14,17,'0','2020-07-01 11:34:30',NULL),(927,14,18,'0','2020-07-01 11:34:30',NULL),(928,14,19,'0','2020-07-01 11:34:30',NULL),(929,14,20,'0','2020-07-01 11:34:30',NULL),(930,14,21,'0','2020-07-01 11:34:30',NULL),(931,14,22,'0','2020-07-01 11:34:30',NULL),(932,14,23,'0','2020-07-01 11:34:31',NULL),(933,14,24,'0','2020-07-01 11:34:31',NULL),(934,14,25,'0','2020-07-01 11:34:31',NULL),(935,14,26,'0','2020-07-01 11:34:31',NULL),(936,14,27,'0','2020-07-01 11:34:31',NULL),(937,14,28,'0','2020-07-01 11:34:31',NULL),(938,14,29,'0','2020-07-01 11:34:31',NULL),(939,14,30,'0','2020-07-01 11:34:31',NULL),(940,14,31,'0','2020-07-01 11:34:31',NULL),(941,14,32,'0','2020-07-01 11:34:31',NULL),(942,14,33,'0','2020-07-01 11:34:31',NULL),(943,14,34,'0','2020-07-01 11:34:31',NULL),(944,14,35,'0','2020-07-01 11:34:31',NULL),(945,14,36,'0','2020-07-01 11:34:31',NULL),(946,14,37,'0','2020-07-01 11:34:31',NULL),(947,14,38,'0','2020-07-01 11:34:31',NULL),(948,14,39,'0','2020-07-01 11:34:31',NULL),(949,14,40,'0','2020-07-01 11:34:32',NULL),(950,14,41,'0','2020-07-01 11:34:32',NULL),(951,14,42,'0','2020-07-01 11:34:32',NULL),(952,14,43,'0','2020-07-01 11:34:32',NULL),(953,14,44,'0','2020-07-01 11:34:32',NULL),(954,14,45,'0','2020-07-01 11:34:32',NULL),(955,14,46,'0','2020-07-01 11:34:32',NULL),(956,14,47,'0','2020-07-01 11:34:33',NULL),(957,14,48,'0','2020-07-01 11:34:33',NULL),(958,14,49,'0','2020-07-01 11:34:33',NULL),(959,14,50,'0','2020-07-01 11:34:33',NULL),(960,14,51,'0','2020-07-01 11:34:33',NULL),(961,14,52,'0','2020-07-01 11:34:33',NULL),(962,14,53,'0','2020-07-01 11:34:33',NULL),(963,14,54,'0','2020-07-01 11:34:33',NULL),(964,14,55,'0','2020-07-01 11:34:33',NULL),(965,14,56,'0','2020-07-01 11:34:33',NULL),(966,14,57,'0','2020-07-01 11:34:33',NULL),(967,14,58,'0','2020-07-01 11:34:33',NULL),(968,14,59,'0','2020-07-01 11:34:33',NULL),(969,14,60,'0','2020-07-01 11:34:33',NULL),(970,14,61,'0','2020-07-01 11:34:33',NULL),(971,14,62,'0','2020-07-01 11:34:34',NULL),(972,14,63,'0','2020-07-01 11:34:34',NULL),(973,14,64,'0','2020-07-01 11:34:34',NULL),(974,14,65,'0','2020-07-01 11:34:34',NULL),(975,14,66,'0','2020-07-01 11:34:34',NULL),(976,14,67,'0','2020-07-01 11:34:34',NULL),(977,14,68,'0','2020-07-01 11:34:34',NULL),(978,14,69,'0','2020-07-01 11:34:34',NULL),(979,14,70,'0','2020-07-01 11:34:34',NULL),(980,14,71,'0','2020-07-01 11:34:34',NULL),(981,14,73,'0','2020-07-01 11:34:34',NULL),(982,14,74,'0','2020-07-01 11:34:34',NULL),(983,14,75,'0','2020-07-01 11:34:34',NULL),(984,14,76,'0','2020-07-01 11:34:34',NULL),(985,14,77,'0','2020-07-01 11:34:34',NULL),(986,14,78,'0','2020-07-01 11:34:34',NULL),(987,14,79,'0','2020-07-01 11:34:34',NULL),(988,14,80,'0','2020-07-01 11:34:34',NULL),(989,14,81,'0','2020-07-01 11:34:34',NULL),(990,14,82,'0','2020-07-01 11:34:35',NULL),(991,14,83,'0','2020-07-01 11:34:35',NULL),(992,14,84,'0','2020-07-01 11:34:35',NULL),(993,14,85,'0','2020-07-01 11:34:35',NULL),(994,14,86,'0','2020-07-01 11:34:35',NULL),(995,14,87,'0','2020-07-01 11:34:35',NULL),(996,14,88,'0','2020-07-01 11:34:35',NULL),(997,14,89,'0','2020-07-01 11:34:35',NULL),(998,14,93,'0','2020-07-01 11:34:35',NULL),(999,14,94,'0','2020-07-01 11:34:35',NULL),(1000,14,95,'0','2020-07-01 11:34:35',NULL),(1001,14,96,'0','2020-07-01 11:34:35',NULL),(1002,14,99,'0','2020-07-01 11:34:35',NULL),(1003,14,100,'0','2020-07-01 11:34:35',NULL),(1004,14,101,'0','2020-07-01 11:34:35',NULL),(1005,14,102,'0','2020-07-01 11:34:35',NULL),(1006,1,67,'0','2020-09-12 10:08:25',NULL),(1007,1,68,'0','2020-09-12 10:08:25',NULL),(1008,1,69,'0','2020-09-12 10:08:25',NULL),(1009,1,70,'0','2020-09-12 10:08:25',NULL),(1010,1,71,'0','2020-09-12 10:08:25',NULL),(1011,1,73,'0','2020-09-12 10:08:25',NULL),(1012,1,74,'0','2020-09-12 10:08:25',NULL),(1013,1,75,'0','2020-09-12 10:08:25',NULL),(1014,1,76,'0','2020-09-12 10:08:25',NULL),(1015,1,77,'0','2020-09-12 10:08:25',NULL),(1016,1,78,'0','2020-09-12 10:08:25',NULL),(1017,1,79,'0','2020-09-12 10:08:25',NULL),(1018,1,80,'0','2020-09-12 10:08:25',NULL),(1019,1,81,'0','2020-09-12 10:08:25',NULL),(1020,1,82,'0','2020-09-12 10:08:25',NULL),(1021,1,83,'0','2020-09-12 10:08:25',NULL),(1022,1,84,'0','2020-09-12 10:08:25',NULL),(1023,1,85,'0','2020-09-12 10:08:25',NULL),(1024,1,86,'0','2020-09-12 10:08:25',NULL),(1025,1,87,'0','2020-09-12 10:08:25',NULL),(1026,1,88,'0','2020-09-12 10:08:25',NULL),(1027,1,89,'0','2020-09-12 10:08:25',NULL),(1028,1,93,'0','2020-09-12 10:08:25',NULL),(1029,1,94,'0','2020-09-12 10:08:25',NULL),(1030,1,95,'0','2020-09-12 10:08:25',NULL),(1031,1,96,'0','2020-09-12 10:08:25',NULL),(1032,1,99,'0','2020-09-12 10:08:25',NULL),(1033,1,100,'0','2020-09-12 10:08:25',NULL),(1034,1,101,'0','2020-09-12 10:08:25',NULL),(1035,1,102,'0','2020-09-12 10:08:25',NULL),(1036,15,1,'0','2020-10-08 15:10:09',NULL),(1037,15,2,'0','2020-10-08 15:10:09',NULL),(1038,15,3,'0','2020-10-08 15:10:09',NULL),(1039,15,4,'0','2020-10-08 15:10:09',NULL),(1040,15,5,'0','2020-10-08 15:10:09',NULL),(1041,15,6,'0','2020-10-08 15:10:09',NULL),(1042,15,7,'0','2020-10-08 15:10:09',NULL),(1043,15,8,'0','2020-10-08 15:10:09',NULL),(1044,15,9,'0','2020-10-08 15:10:09',NULL),(1045,15,10,'0','2020-10-08 15:10:09',NULL),(1046,15,11,'0','2020-10-08 15:10:09',NULL),(1047,15,12,'0','2020-10-08 15:10:09',NULL),(1048,15,13,'0','2020-10-08 15:10:09',NULL),(1049,15,14,'0','2020-10-08 15:10:09',NULL),(1050,15,15,'0','2020-10-08 15:10:09',NULL),(1051,15,16,'0','2020-10-08 15:10:09',NULL),(1052,15,17,'0','2020-10-08 15:10:09',NULL),(1053,15,18,'0','2020-10-08 15:10:09',NULL),(1054,15,19,'0','2020-10-08 15:10:09',NULL),(1055,15,20,'0','2020-10-08 15:10:09',NULL),(1056,15,21,'0','2020-10-08 15:10:09',NULL),(1057,15,22,'0','2020-10-08 15:10:09',NULL),(1058,15,23,'0','2020-10-08 15:10:09',NULL),(1059,15,24,'0','2020-10-08 15:10:09',NULL),(1060,15,25,'0','2020-10-08 15:10:09',NULL),(1061,15,26,'0','2020-10-08 15:10:09',NULL),(1062,15,27,'0','2020-10-08 15:10:09',NULL),(1063,15,28,'0','2020-10-08 15:10:09',NULL),(1064,15,29,'0','2020-10-08 15:10:09',NULL),(1065,15,30,'0','2020-10-08 15:10:09',NULL),(1066,15,31,'0','2020-10-08 15:10:09',NULL),(1067,15,32,'0','2020-10-08 15:10:09',NULL),(1068,15,33,'0','2020-10-08 15:10:09',NULL),(1069,15,34,'0','2020-10-08 15:10:09',NULL),(1070,15,35,'0','2020-10-08 15:10:09',NULL),(1071,15,36,'0','2020-10-08 15:10:09',NULL),(1072,15,37,'0','2020-10-08 15:10:09',NULL),(1073,15,38,'0','2020-10-08 15:10:09',NULL),(1074,15,39,'0','2020-10-08 15:10:09',NULL),(1075,15,40,'0','2020-10-08 15:10:09',NULL),(1076,15,41,'0','2020-10-08 15:10:09',NULL),(1077,15,42,'0','2020-10-08 15:10:09',NULL),(1078,15,43,'0','2020-10-08 15:10:09',NULL),(1079,15,44,'0','2020-10-08 15:10:09',NULL),(1080,15,45,'0','2020-10-08 15:10:09',NULL),(1081,15,46,'0','2020-10-08 15:10:09',NULL),(1082,15,47,'0','2020-10-08 15:10:09',NULL),(1083,15,48,'0','2020-10-08 15:10:09',NULL),(1084,15,49,'0','2020-10-08 15:10:09',NULL),(1085,15,50,'0','2020-10-08 15:10:09',NULL),(1086,15,51,'0','2020-10-08 15:10:09',NULL),(1087,15,52,'0','2020-10-08 15:10:09',NULL),(1088,15,53,'0','2020-10-08 15:10:09',NULL),(1089,15,54,'0','2020-10-08 15:10:09',NULL),(1090,15,55,'0','2020-10-08 15:10:09',NULL),(1091,15,56,'0','2020-10-08 15:10:09',NULL),(1092,15,57,'0','2020-10-08 15:10:09',NULL),(1093,15,58,'0','2020-10-08 15:10:09',NULL),(1094,15,59,'0','2020-10-08 15:10:09',NULL),(1095,15,60,'0','2020-10-08 15:10:09',NULL),(1096,15,61,'0','2020-10-08 15:10:09',NULL),(1097,15,62,'0','2020-10-08 15:10:09',NULL),(1098,15,63,'0','2020-10-08 15:10:09',NULL),(1099,15,64,'0','2020-10-08 15:10:09',NULL),(1100,15,65,'0','2020-10-08 15:10:09',NULL),(1101,15,66,'0','2020-10-08 15:10:09',NULL),(1102,15,67,'0','2020-10-08 15:10:09',NULL),(1103,15,68,'0','2020-10-08 15:10:09',NULL),(1104,15,69,'0','2020-10-08 15:10:09',NULL),(1105,15,70,'0','2020-10-08 15:10:09',NULL),(1106,15,71,'0','2020-10-08 15:10:09',NULL),(1107,15,73,'0','2020-10-08 15:10:09',NULL),(1108,15,74,'0','2020-10-08 15:10:09',NULL),(1109,15,75,'0','2020-10-08 15:10:09',NULL),(1110,15,76,'0','2020-10-08 15:10:09',NULL),(1111,15,77,'0','2020-10-08 15:10:09',NULL),(1112,15,78,'0','2020-10-08 15:10:09',NULL),(1113,15,79,'0','2020-10-08 15:10:09',NULL),(1114,15,80,'0','2020-10-08 15:10:09',NULL),(1115,15,81,'0','2020-10-08 15:10:09',NULL),(1116,15,82,'0','2020-10-08 15:10:09',NULL),(1117,15,83,'0','2020-10-08 15:10:09',NULL),(1118,15,84,'0','2020-10-08 15:10:09',NULL),(1119,15,85,'0','2020-10-08 15:10:09',NULL),(1120,15,86,'0','2020-10-08 15:10:09',NULL),(1121,15,87,'0','2020-10-08 15:10:09',NULL),(1122,15,88,'0','2020-10-08 15:10:09',NULL),(1123,15,89,'0','2020-10-08 15:10:09',NULL),(1124,15,93,'0','2020-10-08 15:10:09',NULL),(1125,15,94,'0','2020-10-08 15:10:09',NULL),(1126,15,95,'0','2020-10-08 15:10:09',NULL),(1127,15,96,'0','2020-10-08 15:10:09',NULL),(1128,15,99,'0','2020-10-08 15:10:09',NULL),(1129,15,100,'0','2020-10-08 15:10:09',NULL),(1130,15,101,'0','2020-10-08 15:10:09',NULL),(1131,15,102,'0','2020-10-08 15:10:09',NULL),(1132,15,1,'0','2021-01-18 07:36:35',NULL),(1133,15,2,'0','2021-01-18 07:36:35',NULL),(1134,15,3,'0','2021-01-18 07:36:35',NULL),(1135,15,4,'0','2021-01-18 07:36:35',NULL),(1136,15,5,'0','2021-01-18 07:36:35',NULL),(1137,15,6,'0','2021-01-18 07:36:35',NULL),(1138,15,7,'0','2021-01-18 07:36:35',NULL),(1139,15,8,'0','2021-01-18 07:36:35',NULL),(1140,15,9,'0','2021-01-18 07:36:35',NULL),(1141,15,10,'0','2021-01-18 07:36:35',NULL),(1142,15,11,'0','2021-01-18 07:36:35',NULL),(1143,15,12,'0','2021-01-18 07:36:35',NULL),(1144,15,13,'0','2021-01-18 07:36:35',NULL),(1145,15,14,'0','2021-01-18 07:36:35',NULL),(1146,15,15,'0','2021-01-18 07:36:35',NULL),(1147,15,16,'0','2021-01-18 07:36:35',NULL),(1148,15,17,'0','2021-01-18 07:36:35',NULL),(1149,15,18,'0','2021-01-18 07:36:35',NULL),(1150,15,19,'0','2021-01-18 07:36:35',NULL),(1151,15,20,'0','2021-01-18 07:36:35',NULL),(1152,15,21,'0','2021-01-18 07:36:35',NULL),(1153,15,22,'0','2021-01-18 07:36:35',NULL),(1154,15,23,'0','2021-01-18 07:36:35',NULL),(1155,15,24,'0','2021-01-18 07:36:35',NULL),(1156,15,25,'0','2021-01-18 07:36:35',NULL),(1157,15,26,'0','2021-01-18 07:36:35',NULL),(1158,15,27,'0','2021-01-18 07:36:35',NULL),(1159,15,28,'0','2021-01-18 07:36:35',NULL),(1160,15,29,'0','2021-01-18 07:36:35',NULL),(1161,15,30,'0','2021-01-18 07:36:35',NULL),(1162,15,31,'0','2021-01-18 07:36:35',NULL),(1163,15,32,'0','2021-01-18 07:36:35',NULL),(1164,15,33,'0','2021-01-18 07:36:35',NULL),(1165,15,34,'0','2021-01-18 07:36:35',NULL),(1166,15,35,'0','2021-01-18 07:36:35',NULL),(1167,15,36,'0','2021-01-18 07:36:35',NULL),(1168,15,37,'0','2021-01-18 07:36:35',NULL),(1169,15,38,'0','2021-01-18 07:36:35',NULL),(1170,15,39,'0','2021-01-18 07:36:35',NULL),(1171,15,40,'0','2021-01-18 07:36:35',NULL),(1172,15,41,'0','2021-01-18 07:36:35',NULL),(1173,15,42,'0','2021-01-18 07:36:35',NULL),(1174,15,43,'0','2021-01-18 07:36:35',NULL),(1175,15,44,'0','2021-01-18 07:36:35',NULL),(1176,15,45,'0','2021-01-18 07:36:35',NULL),(1177,15,46,'0','2021-01-18 07:36:35',NULL),(1178,15,47,'0','2021-01-18 07:36:35',NULL),(1179,15,48,'0','2021-01-18 07:36:35',NULL),(1180,15,49,'0','2021-01-18 07:36:35',NULL),(1181,15,50,'0','2021-01-18 07:36:35',NULL),(1182,15,51,'0','2021-01-18 07:36:35',NULL),(1183,15,52,'0','2021-01-18 07:36:35',NULL),(1184,15,53,'0','2021-01-18 07:36:35',NULL),(1185,15,54,'0','2021-01-18 07:36:35',NULL),(1186,15,55,'0','2021-01-18 07:36:35',NULL),(1187,15,56,'0','2021-01-18 07:36:35',NULL),(1188,15,57,'0','2021-01-18 07:36:35',NULL),(1189,15,58,'0','2021-01-18 07:36:35',NULL),(1190,15,59,'0','2021-01-18 07:36:35',NULL),(1191,15,60,'0','2021-01-18 07:36:35',NULL),(1192,15,61,'0','2021-01-18 07:36:35',NULL),(1193,15,62,'0','2021-01-18 07:36:35',NULL),(1194,15,63,'0','2021-01-18 07:36:35',NULL),(1195,15,64,'0','2021-01-18 07:36:35',NULL),(1196,15,65,'0','2021-01-18 07:36:35',NULL),(1197,15,66,'0','2021-01-18 07:36:35',NULL),(1198,15,67,'0','2021-01-18 07:36:35',NULL),(1199,15,68,'0','2021-01-18 07:36:35',NULL),(1200,15,69,'0','2021-01-18 07:36:35',NULL),(1201,15,70,'0','2021-01-18 07:36:35',NULL),(1202,15,71,'0','2021-01-18 07:36:35',NULL),(1203,15,73,'0','2021-01-18 07:36:35',NULL),(1204,15,74,'0','2021-01-18 07:36:35',NULL),(1205,15,75,'0','2021-01-18 07:36:35',NULL),(1206,15,76,'0','2021-01-18 07:36:35',NULL),(1207,15,77,'0','2021-01-18 07:36:35',NULL),(1208,15,78,'0','2021-01-18 07:36:35',NULL),(1209,15,79,'0','2021-01-18 07:36:35',NULL),(1210,15,80,'0','2021-01-18 07:36:35',NULL),(1211,15,81,'0','2021-01-18 07:36:35',NULL),(1212,15,82,'0','2021-01-18 07:36:35',NULL),(1213,15,83,'0','2021-01-18 07:36:35',NULL),(1214,15,84,'0','2021-01-18 07:36:35',NULL),(1215,15,85,'0','2021-01-18 07:36:35',NULL),(1216,15,86,'0','2021-01-18 07:36:35',NULL),(1217,15,87,'0','2021-01-18 07:36:35',NULL),(1218,15,88,'0','2021-01-18 07:36:35',NULL),(1219,15,89,'0','2021-01-18 07:36:35',NULL),(1220,15,93,'0','2021-01-18 07:36:35',NULL),(1221,15,94,'0','2021-01-18 07:36:35',NULL),(1222,15,95,'0','2021-01-18 07:36:35',NULL),(1223,15,96,'0','2021-01-18 07:36:35',NULL),(1224,15,99,'0','2021-01-18 07:36:35',NULL),(1225,15,100,'0','2021-01-18 07:36:35',NULL),(1226,15,101,'0','2021-01-18 07:36:35',NULL),(1227,15,102,'0','2021-01-18 07:36:35',NULL),(1228,16,1,'1','2021-01-28 07:26:15',NULL),(1229,16,2,'0','2021-01-28 07:26:15',NULL),(1230,16,3,'0','2021-01-28 07:26:15',NULL),(1231,16,4,'0','2021-01-28 07:26:15',NULL),(1232,16,5,'1','2021-01-28 07:26:15',NULL),(1233,16,6,'1','2021-01-28 07:26:15',NULL),(1234,16,7,'1','2021-01-28 07:26:15',NULL),(1235,16,8,'0','2021-01-28 07:26:15',NULL),(1236,16,9,'0','2021-01-28 07:26:15',NULL),(1237,16,10,'0','2021-01-28 07:26:15',NULL),(1238,16,11,'0','2021-01-28 07:26:15',NULL),(1239,16,12,'0','2021-01-28 07:26:15',NULL),(1240,16,13,'0','2021-01-28 07:26:15',NULL),(1241,16,14,'0','2021-01-28 07:26:15',NULL),(1242,16,15,'0','2021-01-28 07:26:15',NULL),(1243,16,16,'0','2021-01-28 07:26:15',NULL),(1244,16,17,'0','2021-01-28 07:26:15',NULL),(1245,16,18,'0','2021-01-28 07:26:15',NULL),(1246,16,19,'0','2021-01-28 07:26:15',NULL),(1247,16,20,'0','2021-01-28 07:26:15',NULL),(1248,16,21,'0','2021-01-28 07:26:15',NULL),(1249,16,22,'0','2021-01-28 07:26:15',NULL),(1250,16,23,'0','2021-01-28 07:26:15',NULL),(1251,16,24,'0','2021-01-28 07:26:15',NULL),(1252,16,25,'0','2021-01-28 07:26:15',NULL),(1253,16,26,'0','2021-01-28 07:26:15',NULL),(1254,16,27,'0','2021-01-28 07:26:15',NULL),(1255,16,28,'0','2021-01-28 07:26:15',NULL),(1256,16,29,'0','2021-01-28 07:26:15',NULL),(1257,16,30,'0','2021-01-28 07:26:15',NULL),(1258,16,31,'0','2021-01-28 07:26:15',NULL),(1259,16,32,'0','2021-01-28 07:26:15',NULL),(1260,16,33,'0','2021-01-28 07:26:15',NULL),(1261,16,34,'0','2021-01-28 07:26:15',NULL),(1262,16,35,'0','2021-01-28 07:26:15',NULL),(1263,16,36,'0','2021-01-28 07:26:15',NULL),(1264,16,37,'0','2021-01-28 07:26:15',NULL),(1265,16,38,'0','2021-01-28 07:26:15',NULL),(1266,16,39,'0','2021-01-28 07:26:15',NULL),(1267,16,40,'0','2021-01-28 07:26:15',NULL),(1268,16,41,'0','2021-01-28 07:26:15',NULL),(1269,16,42,'0','2021-01-28 07:26:15',NULL),(1270,16,43,'0','2021-01-28 07:26:15',NULL),(1271,16,44,'0','2021-01-28 07:26:15',NULL),(1272,16,45,'0','2021-01-28 07:26:15',NULL),(1273,16,46,'0','2021-01-28 07:26:15',NULL),(1274,16,47,'0','2021-01-28 07:26:15',NULL),(1275,16,48,'0','2021-01-28 07:26:15',NULL),(1276,16,49,'0','2021-01-28 07:26:15',NULL),(1277,16,50,'0','2021-01-28 07:26:15',NULL),(1278,16,51,'0','2021-01-28 07:26:15',NULL),(1279,16,52,'0','2021-01-28 07:26:15',NULL),(1280,16,53,'0','2021-01-28 07:26:15',NULL),(1281,16,54,'0','2021-01-28 07:26:15',NULL),(1282,16,55,'0','2021-01-28 07:26:15',NULL),(1283,16,56,'0','2021-01-28 07:26:15',NULL),(1284,16,57,'0','2021-01-28 07:26:15',NULL),(1285,16,58,'0','2021-01-28 07:26:15',NULL),(1286,16,59,'0','2021-01-28 07:26:15',NULL),(1287,16,60,'0','2021-01-28 07:26:15',NULL),(1288,16,61,'0','2021-01-28 07:26:15',NULL),(1289,16,62,'0','2021-01-28 07:26:15',NULL),(1290,16,63,'0','2021-01-28 07:26:15',NULL),(1291,16,64,'0','2021-01-28 07:26:15',NULL),(1292,16,65,'0','2021-01-28 07:26:15',NULL),(1293,16,66,'0','2021-01-28 07:26:15',NULL),(1294,16,67,'0','2021-01-28 07:26:15',NULL),(1295,16,68,'0','2021-01-28 07:26:15',NULL),(1296,16,69,'0','2021-01-28 07:26:15',NULL),(1297,16,70,'0','2021-01-28 07:26:15',NULL),(1298,16,71,'0','2021-01-28 07:26:15',NULL),(1299,16,73,'0','2021-01-28 07:26:15',NULL),(1300,16,74,'0','2021-01-28 07:26:15',NULL),(1301,16,75,'0','2021-01-28 07:26:15',NULL),(1302,16,76,'0','2021-01-28 07:26:15',NULL),(1303,16,77,'0','2021-01-28 07:26:15',NULL),(1304,16,78,'0','2021-01-28 07:26:15',NULL),(1305,16,79,'0','2021-01-28 07:26:15',NULL),(1306,16,80,'0','2021-01-28 07:26:15',NULL),(1307,16,81,'0','2021-01-28 07:26:15',NULL),(1308,16,82,'0','2021-01-28 07:26:15',NULL),(1309,16,83,'0','2021-01-28 07:26:15',NULL),(1310,16,84,'0','2021-01-28 07:26:15',NULL),(1311,16,85,'0','2021-01-28 07:26:15',NULL),(1312,16,86,'0','2021-01-28 07:26:15',NULL),(1313,16,87,'0','2021-01-28 07:26:15',NULL),(1314,16,88,'0','2021-01-28 07:26:15',NULL),(1315,16,89,'0','2021-01-28 07:26:15',NULL),(1316,16,93,'0','2021-01-28 07:26:15',NULL),(1317,16,94,'0','2021-01-28 07:26:15',NULL),(1318,16,95,'0','2021-01-28 07:26:15',NULL),(1319,16,96,'0','2021-01-28 07:26:15',NULL),(1320,16,99,'0','2021-01-28 07:26:15',NULL),(1321,16,100,'0','2021-01-28 07:26:15',NULL),(1322,16,101,'0','2021-01-28 07:26:15',NULL),(1323,16,102,'0','2021-01-28 07:26:15',NULL),(1324,17,1,'1','2021-01-30 09:33:04',NULL),(1325,17,2,'0','2021-01-30 09:33:04',NULL),(1326,17,3,'1','2021-01-30 09:33:04',NULL),(1327,17,4,'0','2021-01-30 09:33:04',NULL),(1328,17,5,'0','2021-01-30 09:33:04',NULL),(1329,17,6,'0','2021-01-30 09:33:04',NULL),(1330,17,7,'1','2021-01-30 09:33:04',NULL),(1331,17,8,'0','2021-01-30 09:33:04',NULL),(1332,17,9,'0','2021-01-30 09:33:04',NULL),(1333,17,10,'0','2021-01-30 09:33:04',NULL),(1334,17,11,'0','2021-01-30 09:33:04',NULL),(1335,17,12,'0','2021-01-30 09:33:04',NULL),(1336,17,13,'0','2021-01-30 09:33:04',NULL),(1337,17,14,'0','2021-01-30 09:33:04',NULL),(1338,17,15,'0','2021-01-30 09:33:04',NULL),(1339,17,16,'0','2021-01-30 09:33:04',NULL),(1340,17,17,'0','2021-01-30 09:33:04',NULL),(1341,17,18,'0','2021-01-30 09:33:04',NULL),(1342,17,19,'0','2021-01-30 09:33:04',NULL),(1343,17,20,'0','2021-01-30 09:33:04',NULL),(1344,17,21,'0','2021-01-30 09:33:04',NULL),(1345,17,22,'0','2021-01-30 09:33:04',NULL),(1346,17,23,'0','2021-01-30 09:33:04',NULL),(1347,17,24,'0','2021-01-30 09:33:04',NULL),(1348,17,25,'0','2021-01-30 09:33:04',NULL),(1349,17,26,'0','2021-01-30 09:33:04',NULL),(1350,17,27,'0','2021-01-30 09:33:04',NULL),(1351,17,28,'0','2021-01-30 09:33:04',NULL),(1352,17,29,'0','2021-01-30 09:33:04',NULL),(1353,17,30,'0','2021-01-30 09:33:04',NULL),(1354,17,31,'0','2021-01-30 09:33:04',NULL),(1355,17,32,'0','2021-01-30 09:33:04',NULL),(1356,17,33,'0','2021-01-30 09:33:04',NULL),(1357,17,34,'0','2021-01-30 09:33:04',NULL),(1358,17,35,'0','2021-01-30 09:33:04',NULL),(1359,17,36,'0','2021-01-30 09:33:04',NULL),(1360,17,37,'0','2021-01-30 09:33:04',NULL),(1361,17,38,'0','2021-01-30 09:33:04',NULL),(1362,17,39,'0','2021-01-30 09:33:04',NULL),(1363,17,40,'0','2021-01-30 09:33:04',NULL),(1364,17,41,'0','2021-01-30 09:33:04',NULL),(1365,17,42,'0','2021-01-30 09:33:04',NULL),(1366,17,43,'0','2021-01-30 09:33:04',NULL),(1367,17,44,'0','2021-01-30 09:33:04',NULL),(1368,17,45,'0','2021-01-30 09:33:04',NULL),(1369,17,46,'0','2021-01-30 09:33:04',NULL),(1370,17,47,'0','2021-01-30 09:33:04',NULL),(1371,17,48,'0','2021-01-30 09:33:04',NULL),(1372,17,49,'0','2021-01-30 09:33:04',NULL),(1373,17,50,'0','2021-01-30 09:33:04',NULL),(1374,17,51,'0','2021-01-30 09:33:04',NULL),(1375,17,52,'0','2021-01-30 09:33:04',NULL),(1376,17,53,'0','2021-01-30 09:33:04',NULL),(1377,17,54,'0','2021-01-30 09:33:04',NULL),(1378,17,55,'0','2021-01-30 09:33:04',NULL),(1379,17,56,'0','2021-01-30 09:33:04',NULL),(1380,17,57,'0','2021-01-30 09:33:04',NULL),(1381,17,58,'0','2021-01-30 09:33:04',NULL),(1382,17,59,'0','2021-01-30 09:33:04',NULL),(1383,17,60,'0','2021-01-30 09:33:04',NULL),(1384,17,61,'0','2021-01-30 09:33:04',NULL),(1385,17,62,'0','2021-01-30 09:33:04',NULL),(1386,17,63,'0','2021-01-30 09:33:04',NULL),(1387,17,64,'0','2021-01-30 09:33:04',NULL),(1388,17,65,'0','2021-01-30 09:33:04',NULL),(1389,17,66,'0','2021-01-30 09:33:04',NULL),(1390,17,67,'0','2021-01-30 09:33:04',NULL),(1391,17,68,'0','2021-01-30 09:33:04',NULL),(1392,17,69,'0','2021-01-30 09:33:04',NULL),(1393,17,70,'0','2021-01-30 09:33:04',NULL),(1394,17,71,'0','2021-01-30 09:33:04',NULL),(1395,17,73,'0','2021-01-30 09:33:04',NULL),(1396,17,74,'0','2021-01-30 09:33:04',NULL),(1397,17,75,'0','2021-01-30 09:33:04',NULL),(1398,17,76,'0','2021-01-30 09:33:04',NULL),(1399,17,77,'0','2021-01-30 09:33:04',NULL),(1400,17,78,'0','2021-01-30 09:33:04',NULL),(1401,17,79,'0','2021-01-30 09:33:04',NULL),(1402,17,80,'0','2021-01-30 09:33:04',NULL),(1403,17,81,'0','2021-01-30 09:33:04',NULL),(1404,17,82,'0','2021-01-30 09:33:04',NULL),(1405,17,83,'0','2021-01-30 09:33:04',NULL),(1406,17,84,'0','2021-01-30 09:33:04',NULL),(1407,17,85,'0','2021-01-30 09:33:04',NULL),(1408,17,86,'0','2021-01-30 09:33:04',NULL),(1409,17,87,'0','2021-01-30 09:33:04',NULL),(1410,17,88,'0','2021-01-30 09:33:04',NULL),(1411,17,89,'0','2021-01-30 09:33:04',NULL),(1412,17,93,'0','2021-01-30 09:33:04',NULL),(1413,17,94,'0','2021-01-30 09:33:04',NULL),(1414,17,95,'0','2021-01-30 09:33:04',NULL),(1415,17,96,'0','2021-01-30 09:33:04',NULL),(1416,17,99,'0','2021-01-30 09:33:04',NULL),(1417,17,100,'0','2021-01-30 09:33:04',NULL),(1418,17,101,'0','2021-01-30 09:33:04',NULL),(1419,17,102,'0','2021-01-30 09:33:04',NULL);
/*!40000 ALTER TABLE `useraccess` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `doctor_degree` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `doctor_registration_number` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mobile` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role` int(11) DEFAULT '2',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (2,'Admin',NULL,NULL,'tejas@gmail.com','','$2y$10$h8Rin9bFZ/YjFUmiAYyBPOd9A7LoglHDphTmv9lyGCl2/EF9sgeI6','L9mIoxEuxGKRwgwukx6GrXM8bONSUYB3DW0B0uEZTjzkxSi33uF0mcoQyaeS',1,'2018-03-25 08:42:46','2020-03-24 05:51:18'),(9,'Bhagyshree Gore',NULL,NULL,'bhagyshree134@gmail.com','8600420132','$2y$10$PSerEPdN7X9gf4IJwWeCKez2wimJ9TzhqPMBE4YEGlTifC2I9bVHe','VtURalZsPHaR8C1Uj2d5KdIbI7F98aGC566M4fddBCdtB7nKl0yhLp9iQ2B3',4,'2023-05-12 05:53:37','2023-05-12 05:53:37'),(10,'Priti Shirsat',NULL,NULL,'pritishirsat900@gmail.com','9096866278','$2y$10$x3tcOQD.BWlToMUP3LiKNOGMtCKX/8ZPoLYYZz1k7i3D1buPh6XRO',NULL,4,'2023-05-12 05:58:37','2023-05-12 05:58:37'),(11,'Leena Pawar',NULL,NULL,'pawarleena2825@gmail.com','7666693529','$2y$10$w1N4rnk380Nf2U5y7n9vPeg79nSUbQROEWi5F500u0/jCQG0XEXFW',NULL,3,'2023-05-12 06:02:05','2023-05-12 06:02:05'),(12,'Asha Gavali',NULL,NULL,'ashagavali@gmail.com','86005164425','$2y$10$WjQLzrhGybcwy8.eoTTCJe7Byji3bbm6xMPQUG21lMkSFOJgO7m32',NULL,3,'2023-05-12 06:05:07','2023-05-12 06:05:07'),(13,'Trupti Bramhane',NULL,NULL,'truptibhamhane@gmail.com','7507492096','$2y$10$zWpYcS/WoFd/PImD1ViIBOpNTodhDQ.8OWECrEnf2Oq11MgHA8cEi',NULL,3,'2023-05-12 06:07:58','2023-05-12 06:07:58'),(14,'Sakshi Pavaskar',NULL,NULL,'sakshipavaskar@gmail.com','8149618204','$2y$10$w8r8zq2.OA64IkU/zVaW/.YKC6Q.Q60zlo4zm3enAT8PQRgMxeQqe','ualZGpTLcVExqnvfLXhvJzTCRVucLNc3aIY3lhF6QL5YdfSnib8HYty27Ptx',3,'2023-05-12 06:11:51','2023-05-12 06:11:51'),(15,'Mrunmayi Umavane',NULL,NULL,'varshaumavane93@gmail.com','9657865848','$2y$10$98STv7YUwz4cFEPgoTKknOWm6cDCiFI0hZE2Z8tV2LM2skeXVas16',NULL,3,'2023-05-12 06:14:38','2023-05-12 06:14:38'),(16,'Ruchitra Godbole',NULL,NULL,'ruchiragodbole1972@gmail.com','7775805469','$2y$10$mSOkoL16w4ff1XUTH3GSVOKUjc9644B6YrkQTGlsQg2AJ3dQxV.bG',NULL,3,'2023-05-12 06:17:38','2023-05-12 06:17:38');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `writing_casepaper`
--

DROP TABLE IF EXISTS `writing_casepaper`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `writing_casepaper` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `case_id` bigint(20) DEFAULT NULL,
  `image_data` text,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `writing_casepaper`
--

LOCK TABLES `writing_casepaper` WRITE;
/*!40000 ALTER TABLE `writing_casepaper` DISABLE KEYS */;
/*!40000 ALTER TABLE `writing_casepaper` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'admin_newtejas23may23'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-06-03 12:46:37
