<?php $__env->startSection('style'); ?>
<style>
    @media  screen and (max-width: 767px) {
        .select2 {
            width: 100% !important;
        }
    }
    .ui-autocomplete-loading {
        background: white url("<?php echo e(asset('images/ui-anim_basic_16x16.gif')); ?>") right center no-repeat;
    }

    .canvas{
        position:relative; width:150px; height:200px; background-color:#7a7a7a; margin:70px auto 20px auto;
    }

</style>
<link href="<?php echo e(url('/')); ?>/select2/css/select2.min.css" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
<div class="list-group list-group-horizontal">
        <?php $__empty_1 = true; $__currentLoopData = $DateWiseRecordLst; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $VisitListDateWise): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php if($case_master['id'] == $VisitListDateWise['id']): ?>
                    <a href="<?php echo e(url('/eyeOperationRecord').'/'.$VisitListDateWise['id'].'/edit'); ?>" class="list-group-item active"><?php echo e(Carbon\Carbon::parse($VisitListDateWise['created_at'])->format('d-M-Y')); ?></a> <span> &nbsp;</span>    
                <?php else: ?>
                    <a href="<?php echo e(url('/eyeOperationRecord').'/'.$VisitListDateWise['id'].'/edit'); ?>" class="list-group-item"><?php echo e(Carbon\Carbon::parse($VisitListDateWise['created_at'])->format('d-M-Y')); ?></a> <span> &nbsp;</span>
                <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

</div>
<div class="container-fluid">
<div class="row clearfix">
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
<div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <?php echo $__env->make('shared.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                          <?php if(Session::has('flash_message')): ?>
                          <div class="alert alert-success">
                          <?php echo e(Session::get('flash_message')); ?>

                          </div>
                          <?php endif; ?>


       

<div class="card">
<div class="header bg-pink">
<h2>Add/Edit Eye Operation Record Details </h2>
</div>
     
<div class="body">
<div class="row clearfix ">

 <form action="<?php echo e(url('/eyeOperationRecord'.( isset($case_master) ? "/" . $case_master['id'] : ""))); ?>" method="POST" class="form-horizontal" enctype = 'multipart/form-data' >
  <?php echo e(csrf_field()); ?>


 <?php if(isset($case_master)): ?>
   <input type="hidden" name="_method" value="PATCH">
<?php endif; ?>

<input type="hidden" id="case_id" name="case_id" value="<?php echo e(isset($case_master['id']) ? $case_master['id'] : ''); ?>" >

                          <div class="col-md-12">
                              <div class="col-md-2">
                              <div class="form-group labelgrp">
                              <label for="case_number" class="control-label">Case Number</label>
                              </div>
                              </div>

                              <div class="col-md-4">
                              <div class="form-group">
                              <div class="form-line">
                              <input type="text" name="case_number" id="case_number" class="form-control" readonly='readonly' value="<?php echo e(isset($case_master['case_number']) ? $case_master['case_number'] : ''); ?>">                          
                              </div>
                              </div>
                              </div>   


                              <div class="col-md-2">
                              <div class="form-group labelgrp">
                              <label for="patient_name" class="control-label">Name Of Patient</label>
                              </div>
                              </div>


                              <div class="col-md-4">
                              <div class="form-group">
                              <div class="form-line">
                              <input type="text" name="patient_name" id="patient_name" class="form-control" readonly='readonly' value="<?php echo e(isset($case_master['patient_name']) ? $case_master['patient_name'] : ''); ?>">                          
                              </div>
                              </div>
                              </div>
                          </div>

                          <div class="col-md-12">
                              <div class="col-md-2">
                              <div class="form-group labelgrp">
                              <?php echo e(Form::label('IPD_no','IPD no.')); ?> 
                              </div>
                              </div>


                              <div class="col-md-4">
                              <div class="form-group">
                              <div class="form-line">
                              <?php echo e(Form::text('IPD_no', Request::old('IPD_no',$case_master['IPD_no']), array('class' => 'form-control'))); ?>                           
                              </div>
                              </div>
                              </div>

                              <div class="col-md-2">
                              <div class="form-group labelgrp">
                              <?php echo e(Form::label('uhid','UHID No:')); ?> 
                              </div>
                              </div>


                              <div class="col-md-4">
                              <div class="form-group">
                              <div class="form-line">
                              <?php echo e(Form::text('uhid', Request::old('uhid',$case_master['uhid_no']), array('class' => 'form-control ', 'autocomplete'=>'off'))); ?>                      
                              </div>
                              </div>
                              </div>
                          </div>

                           <div class="col-md-12">
                              <div class="col-md-2">
                              <div class="form-group labelgrp">
                               <?php echo e(Form::label('Surgery','Surgery')); ?> 
                              </div>
                              </div>


                              <div class="col-md-4">
                              <div class="form-group">
                              <div class="form-line">
                              <?php echo e(Form::text('Surgery', Request::old('Surgery',$eyeOperationRecord->Surgery), array('class' => 'form-control'))); ?>                              
                              </div>
                              </div>
                              </div>

                              <div class="col-md-2">
                              <div class="form-group labelgrp">
                              <?php echo e(Form::label('admission_date_time','Admission Date & Time')); ?> 
                              </div>
                              </div>


                              <div class="col-md-4">
                              <div class="form-group">
                              <div class="form-line">
                              <?php echo e(Form::text('admission_date_time', Request::old('admission_date_time',$case_master['admission_date_time']), array('class' => 'form-control datetimepicker', 'autocomplete'=>'off'))); ?>                      
                              </div>
                              </div>
                              </div>
                          </div>


                           <div class="col-md-12">
                              <div class="col-md-2">
                              <div class="form-group labelgrp">
                              <?php echo e(Form::label('surgery_date_time','Surgery Date & Time')); ?> 
                              </div>
                              </div>


                              <div class="col-md-4">
                              <div class="form-group">
                              <div class="form-line">
                              <?php echo e(Form::text('surgery_date_time', Request::old('surgery_date_time',$case_master['surgery_date_time']), array('class' => 'form-control datetimepicker', 'autocomplete'=>'off'))); ?>                           
                              </div>
                              </div>
                              </div>

                              <div class="col-md-2">
                              <div class="form-group labelgrp">
                              <?php echo e(Form::label('discharge_date_time','Discharge Date & Time ')); ?>

                              </div>
                              </div>


                              <div class="col-md-4">
                              <div class="form-group">
                              <div class="form-line">
                              <?php echo e(Form::text('discharge_date_time', Request::old('discharge_date_time',$case_master['discharge_date_time']), array('class' => 'form-control datetimepicker'))); ?>                           
                              </div>
                              </div>
                              </div>
                          </div>

                            <div class="col-md-12">
                              <div class="col-md-2">
                              <div class="form-group labelgrp">
                              <?php echo e(Form::label('doctor_in_charge','Doctor-In-Charge')); ?> 
                              </div>
                              </div>


                              <div class="col-md-4">
                              <div class="form-group">
                              <div class="form-line">
                              <?php echo e(Form::select('Surgeon', array(''=>'Please select') + $doctorlist->toArray(), Request::old('Surgeon',$eyeOperationRecord->Surgeon), array('class' => 'form-control select2',  'id'=>'Surgeon','data-live-search'=>'true'))); ?>                          
                              </div>
                              </div>
                              </div>

                              <div class="col-md-2">
                              <div class="form-group labelgrp">
                              <?php echo e(Form::label('classes','Class')); ?> 
                              </div>
                              </div>


                              <div class="col-md-4">
                              <div class="form-group">
                              <div class="form-line">
                              <?php echo e(Form::text('classes', Request::old('classes',$case_master['classes']), array('class' => 'form-control'))); ?>                           
                              </div>
                              </div>
                              </div>
                          </div>
                           
                           <div class="col-md-12">
                              <div class="col-md-2">
                              <div class="form-group labelgrp">
                              <?php echo e(Form::label('referred_by','Referred By')); ?> 
                              </div>
                              </div>


                              <div class="col-md-4">
                              <div class="form-group">
                              <div class="form-line">
                              <?php echo e(Form::text('referedby', Request::old('referedby',$case_master['referedby']), array('class' => 'form-control'))); ?>                           
                              </div>
                              </div>
                              </div>

                              <div class="col-md-2">
                              <div class="form-group labelgrp">
                              <?php echo e(Form::label('discharge_sts','Discharge Status')); ?> 
                              </div>
                              </div>


                              <div class="col-md-4">
                              <div class="form-group">
                              <div class="form-line">
                              <?php echo e(Form::text('discharge_sts', Request::old('discharge_sts',$case_master['discharge_sts']), array('class' => 'form-control'))); ?>                           
                              </div>
                              </div>
                              </div>
                          </div>

                          <div class="col-md-12">
                              <div class="col-md-2">
                              <div class="form-group labelgrp">
                              <?php echo e(Form::label('final_diagnosis','Final Diagnosis')); ?> 
                              </div>
                              </div>


                              <div class="col-md-4">
                              <div class="form-group">
                              <div class="form-line">
                              <?php echo e(Form::text('final_diagnosis', Request::old('final_diagnosis',$case_master['final_diagnosis']), array('class' => 'form-control'))); ?>                           
                              </div>
                              </div>
                              </div>

                              <div class="col-md-2">
                              <div class="form-group labelgrp">
                             <?php echo e(Form::label('Anaesthes_name','Anaesthetist Name')); ?>

                              </div>
                              </div>


                              <div class="col-md-4">
                              <div class="form-group">
                              <div class="form-line">
                               <?php echo e(Form::text('Anaesthes_name', Request::old('Anaesthes_name',$eyeOperationRecord->Anaesthes_name), array('class' => 'form-control'))); ?>                          
                              </div>
                              </div>
                              </div>
                          </div>
                           <div class="col-md-12">
                              <div class="col-md-2">
                              <div class="form-group labelgrp">
                              <label for="diagnosis" class="control-label">Diagnosis</label>
                              </div>
                              </div>


                              <div class="col-md-4">
                              <div class="form-group">
                              <div class="form-line">
                              <?php echo e(Form::text('diagnosis', Request::old('diagnosis',$case_master['diagnosis']), array('class' => 'form-control'))); ?>                          
                              </div>
                              </div>
                              </div>
                              <div class="col-md-2">
                              <div class="form-group labelgrp">
                              <label for="upload_image" class="control-label">Image</label>
                              </div>
                              </div>


                              <div class="col-md-4">
                              <div class="form-group">
                              <div class="form-line">
                              <input type="file" name="upload_image" id="upload_image" class="form-control" >                         
                              </div>
                              </div>
                              </div>

                          </div>
                         
                        
                             
                 

                  <div class="row clearfix">
                                <div class="col-md-8 col-md-offset-2">
                                <div class="form-group">
                                 <button type="submit" name="submit" class="btn btn-success btn-lg" value="submit" >
                        <i class="fa fa-plus"></i> Submit
                    </button>
                    <a class="btn btn-default btn-lg" href="<?php echo e(url('/eyeOperationRecord')); ?>"><i class="glyphicon glyphicon-chevron-left"></i> Back</a>
                    
                    <a class="btn btn-default btn-lg" href="<?php echo e(url('/PatientMedicalDetails').'/'.$case_master->id); ?>"><i class="glyphicon glyphicon-chevron-left"></i> Patient Details</a>

                    <a  class="btn btn-default btn-lg" href="<?php echo e(url('/eyeOperationRecord/print').'/'.$case_master->id); ?>" target="_blank">
                        <i class="fa fa-print" aria-hidden="true"></i>Print
                    </a>
                    <a  class="btn btn-default btn-lg" href="<?php echo e(url('/eyeOperationRecord/view').'/'.$case_master->id); ?>" >
                        <i class="fa fa-print" aria-hidden="true"></i>View
                    </a>

                                      
                                </div>
                                </div>
                               
                            </div>
                            </form>   
                             </div>        
                </div>
           
            </div>
        </div>
</div>
</div>
</div>
</div>
</div>

        <?php $__env->stopSection(); ?>
  

  <?php $__env->startSection('scripts'); ?>
<!--<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/js/select2.min.js"></script>-->
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.9.0/moment.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/2.2.7/fullcalendar.min.js"></script>
<script src="<?php echo e(url('/')); ?>/assets/plugins/bootstrap-select/js/bootstrap-select.js"></script>
<script src="<?php echo e(url('/')); ?>/select2/js/select2.min.js"></script>
 <script type="text/javascript">
   $(document).ready(function() {
   });
   $(".select2").select2();
 </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlayouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>