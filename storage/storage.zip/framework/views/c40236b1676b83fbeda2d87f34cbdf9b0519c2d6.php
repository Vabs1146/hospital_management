<?php $__env->startSection('content'); ?>
<div class="container-fluid">
<div class="row clearfix">
  <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
    <?php if(Session::has('flash_message')): ?>
      <div class="alert alert-success">
      <?php echo e(Session::get('flash_message')); ?>

        </div>
        <?php endif; ?>
        </div>
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                         <div class="header bg-pink">
                            <h2> Doctors</h2>
                          </div>
                        
                        <div class="body">
                          <div class="row mb-2">
                              <div class="col-lg-12"> 
                              <div class="col-md-6">
                              <a class="btn btn-success btn-lg" href="<?php echo e(route('doctor.create')); ?>"> Add New Doctor
                              </a>
                               </div>
                              <div class="col-md-6">
                              <!-- <a class="btn btn-success btn-lg" style="float: right" href="<?php echo e(route('procedures.index')); ?>"> Procedures
                              </a> -->
							  <a class="btn btn-success btn-lg" style="float: right" href="<?php echo e(route('payment-modes.index')); ?>"> Payment Modes
                              </a>
                               </div>
                              </div>
                              </div>
                           <div class="table-responsive">
<table class="table table-bordered table-striped table-hover">
    <tr>
        <th>No</th>
        <th>Name</th>
        <th>isActive</th>
        <th width="280px">Action</th>
    </tr>
    <?php $__currentLoopData = $doctors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doctor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e(++$i); ?></td>
        <td><?php echo e($doctor->doctor_name); ?></td>
        <td><?php echo e($doctor->isActive); ?></td>
        <td>
            
            <a class="btn btn-primary" href="<?php echo e(route('doctor.edit',$doctor->id)); ?>">Edit</a> 
            
        </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
</div>
<?php echo e($doctors->render()); ?> 
                            </div>
                  
                    </div>
                </div>
            </div>


</div>



        <?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlayouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>