<?php $__env->startSection('style'); ?>
<style>
    @media  screen and (max-width: 767px) {
        .select2 {
            width: 100% !important;
        }
    }
    .ui-autocomplete-loading {
        background: white url("<?php echo e(asset('images/ui-anim_basic_16x16.gif')); ?>") right center no-repeat;
    }

    .canvas{
        position:relative; width:150px; height:200px; background-color:#7a7a7a; margin:70px auto 20px auto;
    }

</style>
<link href="<?php echo e(url('/')); ?>/select2/css/select2.min.css" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="list-group list-group-horizontal">
        <?php $__empty_1 = true; $__currentLoopData = $DateWiseRecordLst; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $VisitListDateWise): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php if($case_master['id'] == $VisitListDateWise['id']): ?>
                    <a href="<?php echo e(url('/insuranceBill').'/'.$VisitListDateWise['id'].'/edit'); ?>" class="list-group-item active"><?php echo e(Carbon\Carbon::parse($VisitListDateWise['created_at'])->format('d-M-Y')); ?></a> <span> &nbsp;</span>    
                <?php else: ?>
                    <a href="<?php echo e(url('/insuranceBill').'/'.$VisitListDateWise['id'].'/edit'); ?>" class="list-group-item"><?php echo e(Carbon\Carbon::parse($VisitListDateWise['created_at'])->format('d-M-Y')); ?></a> <span> &nbsp;</span>
                <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<div class="container-fluid">
<div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
					 <div class="form-group">
                          <?php echo $__env->make('shared.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                          <?php if(Session::has('flash_message')): ?>
                          <div class="alert alert-success">
                          <?php echo e(Session::get('flash_message')); ?>

                          </div>
                          <?php endif; ?>
                  </div>
                    <div class="card">
                         <div class="header bg-pink">
                            <h2>
                                Eye Operation Notes
                            </h2>
                          
                        </div>
                        
    <form action="<?php echo e(url('/eyeoperation'.( isset($case_master) ? "/" . $case_master['id'] : ""))); ?>" method="POST" class="form-horizontal" enctype = 'multipart/form-data' >
                <?php echo e(csrf_field()); ?>


                <?php if(isset($case_master)): ?>
                    <input type="hidden" name="_method" value="PATCH">
                <?php endif; ?>
                        <div class="body">
                           <input type="hidden" id="case_id" name="case_id" value="<?php echo e(isset($case_master['id']) ? $case_master['id'] : ''); ?>" >
                            <div class="row clearfix">
                              <div class="col-md-12">
                              <div class="col-md-2">
                              <div class="form-group labelgrp">
                              <label for="case_number" class="form-control">Case Number :</label>
                              </div>
                              </div>

                              <div class="col-md-4">
                              <div class="form-group">
                              <div class="form-line">
                              <input type="text" name="case_number" id="case_number" class="form-control" readonly='readonly' value="<?php echo e(isset($case_master['case_number']) ? $case_master['case_number'] : ''); ?>">              
                              </div>
                              </div>
                              </div>  

                               <div class="col-md-2">
                              <div class="form-group labelgrp">
                              <label for="patient_name" class="form-control">Name Of Patient :</label>
                              </div>
                              </div>
                               
                              <div class="col-md-4">
                              <div class="form-group">
                              <div class="form-line">
                                <input type="text" name="patient_name" id="patient_name" class="form-control" value="<?php echo e(isset($case_master['patient_name']) ? $case_master['patient_name'] : ''); ?>">
                              </div>  
                              </div>
                              </div>


                              </div>

                              <div class="col-md-12">
                             <div class="col-md-2">
                              <div class="form-group labelgrp">
                              <label for="name_of_age" class="form-control">Age :</label>
                              </div>
                              </div>


                              <div class="col-md-4">
                              <div class="form-group">
                              <div class="form-line">
                              <input type="text" name="patient_age" id="patient_age" class="form-control"  value="<?php echo e(isset($case_master['patient_age']) ? $case_master['patient_age'] : ''); ?>">                            
                              </div>
                              </div>
                              </div>

                              <div class="col-md-2">
                              <div class="form-group labelgrp">
                              <label for="male_female" class="form-control">Sex :</label>
                              </div>
                              </div>

                              <div class="col-md-4">
                                 <div class="form-group">
                              <div class="demo-radio-button" style="padding-top: 12px">
                              <input name="male_female" type="radio" id="radio_8" class=" with-gap radio-col-pink" value="Male" required  <?php echo e(($case_master->male_female == "Male")? "checked=\"checked\"" : ""); ?>  />
                              <label for="radio_8">Male</label>
                              <input name="male_female" type="radio" id="radio_10" class="with-gap radio-col-deep-purple"value="Female" required   <?php echo e(($case_master->male_female == "Female")? "checked=\"checked\"" : ""); ?> />
                              <label for="radio_10">Female</label>
                              </div>
                              </div>
                              
                              </div>   

                              </div>
                              
                              <div class="col-md-12">
                              <div class="col-md-2">
                              <div class="form-group labelgrp">
                              <label for="surgery_name" class="form-control">Surgery</label>
                              </div>
                              </div>
                              <div class="col-md-8">
                              <div class="form-group">
                              <div class="form-line">
                              <?php echo e(Form::text('surgery_name', Request::old('surgery_name',$eyeoperation->surgery_name), array('class' => 'form-control', 'autocomplete'=>'off'))); ?>

                              </div>
                              </div>
                              </div>
                              </div>

                                <div class="col-md-12" id="surgeryDetails">
                                    <legend class="text-center">Surgery Details </legend>
                                        <div class="col-md-2">
                                        <label for="surgery_details[]" class="control-label">&nbsp;</label>
                                        </div>
                                        <div class="col-md-8">
                                        <input type="text" name="surgery_details[]" id="patient_name" class="form-control" value=""> 
                                        </div>
                                        <div class="col-md-1 ">
                                        <button id="addSurgeryDetails" class="btn btn-default">Add</button>
                                        </div>  
                                </div>
                                
                              <div class="dbSurgeryName">
                                  <?php $__currentLoopData = $eyeoperation->eye_op_nt_surgery_details()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <div class="form-group dbSurgeryNameItem">
                                      <div class="col-md-2">
                                        <label for="surgery_details[]" class="control-label">&nbsp;</label>
                                        </div>
                                      <div class="col-md-8 ">
                                          <div class="form-line">
                                            <input type="text" class="form-control" readonly value="<?php echo e($item->surgery_details); ?>">
                                          <input type="hidden" class="surgeryDetail_id" value="<?php echo e($item->id); ?>" />
                                          </div>
                                          
                                      </div>
                                      <div class="col-md-1">
                                        
                                          <button class="removeDbSurgeryItem btn btn-default">Remove</button>
                                      </div>
                                  </div>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </div>

                              <div class="col-md-12">
                              <div class="col-md-2">
                              <div class="form-group labelgrp">
                              <label for="notes" class="form-control">Notes:</label>
                              </div>
                              </div>
                              <div class="col-md-8">
                              <div class="form-group">
                              <div class="form-line">
                              <?php echo e(Form::text('notes', Request::old('notes',$eyeoperation->notes), array('class' => 'form-control', 'autocomplete'=>'off'))); ?>

                              </div>
                              </div>
                              </div>
                              </div>
                              
                            </div>
                            <div class="row clearfix" id="AnesthetistNote"> 
                              <legend class="text-center">Anesthetist Notes</legend>
                              <div class="col-md-12">
                                  <?php echo e(Form::label('an_history','History')); ?> 
                                  <?php echo e(Form::text('an_history', Request::old('an_history',$anesthetist_notes->an_history), array('class' => 'form-control', 'autocomplete'=>'off'))); ?>

                              </div>
                              <div class="col-md-12">
                                  <?php echo e(Form::label('an_allergies','Allergies')); ?> 
                                  <?php echo e(Form::text('an_allergies', Request::old('an_allergies',$anesthetist_notes->an_allergies), array('class' => 'form-control', 'autocomplete'=>'off'))); ?>

                              </div>
                              <div class="col-md-12">
                                  <?php echo e(Form::label('an_pulse','Pulse')); ?> 
                                  <?php echo e(Form::text('an_pulse', Request::old('an_pulse',$anesthetist_notes->an_pulse), array('class' => 'form-control', 'autocomplete'=>'off'))); ?>

                              </div>
                              <div class="col-md-12">
                                  <?php echo e(Form::label('an_cardiac_history','Cardiac History')); ?> 
                                  <?php echo e(Form::text('an_cardiac_history', Request::old('an_cardiac_history',$anesthetist_notes->an_cardiac_history), array('class' => 'form-control', 'autocomplete'=>'off'))); ?>

                              </div>
                              <div class="col-md-12">
                                  <?php echo e(Form::label('an_bp','BP')); ?> 
                                  <?php echo e(Form::text('an_bp', Request::old('an_bp',$anesthetist_notes->an_bp), array('class' => 'form-control', 'autocomplete'=>'off'))); ?>

                              </div>
                              <div class="col-md-12">
                                  <?php echo e(Form::label('an_investigations','Investigations')); ?> 
                                  <?php echo e(Form::text('an_investigations', Request::old('an_investigations',$anesthetist_notes->an_investigations), array('class' => 'form-control', 'autocomplete'=>'off'))); ?>

                              </div>
                              <div class="col-md-12">
                                  <?php echo e(Form::label('an_nbm_notnbm','NBM/NotNBM')); ?> 
                                  <?php echo e(Form::text('an_nbm_notnbm', Request::old('an_nbm_notnbm',$anesthetist_notes->an_nbm_notnbm), array('class' => 'form-control', 'autocomplete'=>'off'))); ?>

                              </div>
                              <div class="col-md-12">
                                  <?php echo e(Form::label('an_dentition','Dentition')); ?> 
                                  <?php echo e(Form::text('an_dentition', Request::old('an_dentition',$anesthetist_notes->an_dentition), array('class' => 'form-control', 'autocomplete'=>'off'))); ?>

                              </div>
                              <legend class="text-center">Intra-Operative Notes</legend>
                              <div class="col-md-12">
                                  <?php echo e(Form::label('ion_anesthesia_topical_peribular_given_by','Anesthesia:Topical/Peribulbar given by')); ?> 
                                  <?php echo e(Form::text('ion_anesthesia_topical_peribular_given_by', Request::old('ion_anesthesia_topical_peribular_given_by',$anesthetist_notes->ion_anesthesia_topical_peribular_given_by), array('class' => 'form-control', 'autocomplete'=>'off'))); ?>

                              </div>
                              <div class="col-md-12">
                                  <?php echo e(Form::label('ion_pulse','Pulse')); ?> 
                                  <?php echo e(Form::text('ion_pulse', Request::old('ion_pulse',$anesthetist_notes->ion_pulse), array('class' => 'form-control', 'autocomplete'=>'off'))); ?>

                              </div>
                              <div class="col-md-12">
                                  <?php echo e(Form::label('ion_o_saturation','O2 Saturation')); ?> 
                                  <?php echo e(Form::text('ion_o_saturation', Request::old('ion_o_saturation',$anesthetist_notes->ion_o_saturation), array('class' => 'form-control', 'autocomplete'=>'off'))); ?>

                              </div>
                              <div class="col-md-12">
                                  <?php echo e(Form::label('ion_bp','BP')); ?> 
                                  <?php echo e(Form::text('ion_bp', Request::old('ion_bp',$anesthetist_notes->ion_bp), array('class' => 'form-control', 'autocomplete'=>'off'))); ?>

                              </div>
                              <legend class="text-center">Post-Operative Notes</legend>
                              <div class="col-md-12">
                                  <?php echo e(Form::label('pon_pulse','Pulse')); ?> 
                                  <?php echo e(Form::text('pon_pulse', Request::old('pon_pulse',$anesthetist_notes->pon_pulse), array('class' => 'form-control', 'autocomplete'=>'off'))); ?>

                              </div>
                              <div class="col-md-12">
                                  <?php echo e(Form::label('pon_bp','BP')); ?> 
                                  <?php echo e(Form::text('pon_bp', Request::old('pon_bp',$anesthetist_notes->pon_bp), array('class' => 'form-control', 'autocomplete'=>'off'))); ?>

                              </div>
                              <div class="col-md-12">
                                  <?php echo e(Form::label('pon_o_saturation','O2 Saturation')); ?> 
                                  <?php echo e(Form::text('pon_o_saturation', Request::old('pon_o_saturation',$anesthetist_notes->pon_o_saturation), array('class' => 'form-control', 'autocomplete'=>'off'))); ?>

                              </div>
                              <div class="col-md-12">
                                  <?php echo e(Form::label('pon_additional_note','Additional Note')); ?> 
                                  <?php echo e(Form::text('pon_additional_note', Request::old('pon_additional_note',$anesthetist_notes->pon_additional_note), array('class' => 'form-control', 'autocomplete'=>'off'))); ?>

                              </div>
                            </div>
                             <div class="row clearfix">
                              <div class="col-md-4 col-md-offset-4">
                              <button type="submit" name="submit" class="btn btn-success btn-lg" value="submit"><i class="fa fa-plus"></i> Submit
                              </button>&nbsp;
                              <a class="btn btn-default btn-lg" href="<?php echo e(url('/eyeoperation/print').'/'. $case_master->id); ?>" target="_blank"><i class="glyphicon glyphicon-print"></i> Print </a>&nbsp;
                              <a class="btn btn-default btn-lg" href="<?php echo e(url('/PatientMedicalDetails').'/'.$case_master->id); ?>"><i class="glyphicon glyphicon-chevron-left"></i> Patient Details</a>
                              </div>
                              </div>   
                            </div>

                            
                        </div>
                      </form>
                      <div id="templateContainner" style="display:none">
                        <div id="surgeryDetailsTemplate">
                            <div class="form-group">
                              <div class="col-md-2">
                                        <label for="surgery_details[]" class="control-label">&nbsp;</label>
                                        </div>
                                <div class="col-md-8">
                                    
                                    <div class="form-line">
                                       <input type="text" name="surgery_details[]" class="form-control surgeryDetailsTxt" value="">
                                    </div>
                                   
                                </div>
                                <div class="col-md-1">
                                
                                    <button class="removeSurgeryItem btn btn-default" data-loading-text="<i class='fa fa-spinner fa-spin '></i> Processing..">Remove</button>
                                </div>
                            </div>            
                        </div>
                    </div>
                    </div>
                </div>
            </div>


</div>

 <?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
 <script src="<?php echo e(url('/')); ?>/select2/js/select2.min.js"></script>
 <script type="text/javascript">
   $(document).ready(function() {
   });
   $(".select2").select2();
 </script>
<script type="text/javascript">
    $(document).ready(function(){
      //$('.datepicker').datepicker({
           // format: "dd/M/yyyy",
           // weekStart: 1,
           // clearBtn: true,
           // daysOfWeekHighlighted: "0,6",
           // autoclose: true,
       // });

        $('#addSurgeryDetails').click(function(e){
            e.preventDefault();
            var template = $("#surgeryDetailsTemplate").clone();
            $(template).find('.surgeryDetailsTxt').attr('value', $("#surgeryDetails").find('#patient_name').val());
            $("#surgeryDetails").find('#patient_name').val('');
            $("#surgeryDetails").append($(template).html());
        });
        $('#surgeryDetails').on('click', '.removeSurgeryItem', function(e){
          e.preventDefault();
          $(this).closest('div.form-group').remove();
          //$('#surgeryDetails').remove($(this).closest('div.form-group'));
          return false;
        });
        $(".removeDbSurgeryItem").click(function(e){
            e.preventDefault();
            if(confirm('You really want to delete this record?')) {
               var ClickedButton = $(this);
               var containerDiv = $(this).closest('div.dbSurgeryNameItem');
               $(ClickedButton).button('loading');
               $.ajax({ url: '<?php echo e(url('/eyeoperation/deleteSurgeryDetials')); ?>/' + $(containerDiv).find('.surgeryDetail_id').val(), 
                    type: 'DELETE',
                    data: {_method: 'delete', 
                           _token :$("input[name='_token'][type='hidden']").val(),
                           surgery_details_id : $(containerDiv).find('.surgeryDetail_id').val()
                          }
                    })
                .success(function() {
                    $(containerDiv).remove();
                    $(ClickedButton).button('reset');
                }).error(function(){
                    $(ClickedButton).button('reset');
                });
            }
        });
    });
</script>
<?php $__env->stopSection(); ?>
  
<?php echo $__env->make('adminlayouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>