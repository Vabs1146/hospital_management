<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
    <div class="col-md-12 ">
        <div class="panel panel-default">
            <div class="panel-heading">Dashboard</div>

            <div class="panel-body">
                 <?php if(isset(Auth::user()->email)): ?>
                Welcome <?php echo e(Auth::user()->name); ?> You are logged in!
                  <?php else: ?>
                   Welcome Admin.  You are logged in!
                     <?php endif; ?>
               
            </div>
        </div>
    </div>
</div>
            <!-- #END# Widgets -->
            <!-- CPU Usage -->
            
            <!-- #END# CPU Usage -->
           

            
        </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlayouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>