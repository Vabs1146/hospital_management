

<span class="dropdown-container">
<div class="col-md-12">
<div class="col-md-2">
<div class="form-group labelgrp">
<label> Colour  Vision</label>
</div>       
</div>

<div class="col-md-3">
<?php echo e(Form::select('colour_OD', array(' '=>'-Select-') + $form_dropdowns->where('fieldName', 'colour OD')->pluck('ddText','ddText')->toArray(), array_key_exists('colour_OD', $defaultValues)?$defaultValues['colour_OD']:null, array('class'=> 'form-control select2'))); ?>

</div>

<div class="col-md-3">

<?php echo e(Form::select('colour_OS', array(' '=>'-Select-') + $form_dropdowns->where('fieldName', 'colour OS')->pluck('ddText','ddText')->toArray(), array_key_exists('colour_OS', $defaultValues)?$defaultValues['colour_OS']:null, array('class'=> 'form-control select2'))); ?>


</div>
<div class="col-md-4">
<button type="button" name="add" id='ColourVisionbtn' class="btn btn-success  set-dropdown-options"  data-field_name="colour OD" data-form_name="EyeForm" >Set Option </button>
<button type='button' class="btn btn-primary" id='ColourVisionbtnsave'>Save Option</button>
</div>

</div>
<div id='ColourVisionTextBoxesGroup' class="col-md-12">

</div>

<!-- ================================================================================= -->

<!-- set-dropdown-options -->
<!-- <span class="dropdown-container"> -->
<div class='dropdown-options-initial-div' class="col-md-12" style="display:none;">
<?php  
$dropdown_options_field_name = 'colour_OD';
$dropdown_options_form_name = 'EyeForm';
 ?>

</div>
</span>
<!-- ================================================================================= -->

<span class="dropdown-container">
<div class="col-md-12">
<div class="col-md-2">
<div class="form-group labelgrp">
<label> Schimer Test 1</label>
</div>     
</div>

<div class="col-md-3">
<div class="input-group">
<?php echo e(Form::select('schimerTest1_OD', array(' '=>'-Select-') + $form_dropdowns->where('fieldName', 'schimerTest1_OD')->pluck('ddText','ddText')->toArray(), array_key_exists('schimerTest1_OD', $defaultValues)?$defaultValues['schimerTest1_OD']:null, array('class'=> 'form-control select2','data-live-search'=>'true'))); ?>

<span class="input-group-addon myaddontest" id="basic-addon">MM</span>
</div>
</div>

<div class="col-md-3">
<div class="input-group">
<?php echo e(Form::select('schimerTest1_OS', array(' '=>'-Select-') + $form_dropdowns->where('fieldName', 'schimerTest1_OS')->pluck('ddText','ddText')->toArray(), array_key_exists('schimerTest1_OS', $defaultValues)?$defaultValues['schimerTest1_OS']:null, array('class'=> 'form-control select2','data-live-search'=>'true'))); ?>

<span class="input-group-addon myaddontest" id="basic-addon">MM</span>
</div>
</div> 
<div class="col-md-4">
<button type="button" name="add" id='schimertestonebtn' class="btn btn-success  set-dropdown-options"  data-field_name="schimerTest1_OD" data-form_name="EyeForm" >Set Option </button>
<button type='button' class="btn btn-primary" id='schimertestonebtnsave'>Save Option</button>
</div> 
</div>
<div id='SchimerTestOneTextBoxesGroup' class="col-md-12">

</div>

<!-- ================================================================================= -->

<!-- set-dropdown-options -->
<!-- <span class="dropdown-container"> -->
<div class='dropdown-options-initial-div' class="col-md-12" style="display:none;">
<?php  
$dropdown_options_field_name = 'schimerTest1_OD';
$dropdown_options_form_name = 'EyeForm';
 ?>

</div>
</span>
<!-- ================================================================================= -->

<span class="dropdown-container">
<div class="col-md-12">
<div class="col-md-2">
<div class="form-group labelgrp">
<label> Schimer Test 2</label>
</div> 
</div>

<div class="col-md-3">
<div class="input-group">
<?php echo e(Form::select('schimerTest2_OD', array(' '=>'-Select-') + $form_dropdowns->where('fieldName', 'schimerTest2_OD')->pluck('ddText','ddText')->toArray(), array_key_exists('schimerTest2_OD', $defaultValues)?$defaultValues['schimerTest2_OD']:null, array('class'=> 'form-control select2','data-live-search'=>'true'))); ?>


<span class="input-group-addon myaddontest" id="basic-addon">MM</span>
</div>
</div>

<div class="col-md-3">
<div class="input-group">
<?php echo e(Form::select('schimerTest2_OS', array(' '=>'-Select-') + $form_dropdowns->where('fieldName', 'schimerTest2_OS')->pluck('ddText','ddText')->toArray(), array_key_exists('schimerTest2_OS', $defaultValues)?$defaultValues['schimerTest2_OS']:null, array('class'=> 'form-control select2','data-live-search'=>'true'))); ?>

<!--  <div class="form-line">
<?php echo e(Form::text('schimerTest2_OS', Request::old('schimerTest2_OS',$form_details->schimerTest2_OS), array('class'=> 'form-control','aria-describedby'=>"basic-addon" ))); ?>

</div> -->
<span class="input-group-addon myaddontest" id="basic-addon">MM</span>
</div>
</div> 
<div class="col-md-4">
<button type="button" name="add" id='schimertesttwobtn' class="btn btn-success  set-dropdown-options"  data-field_name="schimerTest2_OD" data-form_name="EyeForm" >Set Option </button>
<button type='button' class="btn btn-primary" id='schimertesttwobtnsave'>Save Option</button>
</div> 
</div>
<div id='SchimerTestTwoTextBoxesGroup' class="col-md-12">

</div>

<!-- ================================================================================= -->

<!-- set-dropdown-options -->
<!-- <span class="dropdown-container"> -->
<div class='dropdown-options-initial-div' class="col-md-12" style="display:none;">
<?php  
$dropdown_options_field_name = 'schimerTest2_OD';
$dropdown_options_form_name = 'EyeForm';
 ?>

</div>
</span>
<!-- ================================================================================= -->

<span class="dropdown-container">
<div id="OCT" class="ContainerToAppend">
<div class="col-md-12">
<div class="col-md-2">
<div class="form-group labelgrp">
<label> Optical Coherence tomography (OCT)
</label>
</div>
<input type="hidden" id="OCT[]" name="OCT[]" class="hiddenCounter" value="1" />
</div>

<div class="col-md-3">
<?php echo e(Form::select('OCT_OD[]', array(' '=>'-Select-') + $form_dropdowns->where('fieldName', 'OCT OD')->pluck('ddText','ddText')->toArray(), array_key_exists('OCT OD', $defaultValues)?$defaultValues['OCT OD']:null, array('class'=> 'form-control select2','data-live-search'=>'true'))); ?></div> 

<div class="col-md-3">
<?php echo e(Form::select('OCT_OS[]', array(' '=>'-Select-') + $form_dropdowns->where('fieldName', 'OCT OS')->pluck('ddText','ddText')->toArray(), array_key_exists('OCT OS', $defaultValues)?$defaultValues['OCT OS']:null, array('class'=> 'form-control select2','data-live-search'=>'true'))); ?></div>

<div class="col-md-4">
<button type="button" name="add" id='octbtn' class="btn btn-success set-dropdown-options"  data-field_name="OCT OD" data-form_name="EyeForm" >Set Option </button>
<button type='button' class="btn btn-primary" id='octbtnsave'>Save Option</button>
<button id="OCT" class="btn btn-default addmore" data-templateDiv="OCTTemplate">Add</button>
</div>
</div>
</div>
<div id='OCTTextBoxesGroup' class="col-md-12"></div>

<!-- ================================================================================= -->

<!-- set-dropdown-options -->
<!-- <span class="dropdown-container"> -->
<div class='dropdown-options-initial-div' class="col-md-12" style="display:none;">
<?php  
$dropdown_options_field_name = 'OCT OD';
$dropdown_options_form_name = 'EyeForm';
 ?>

</div>
</span>
<!-- ================================================================================= -->


<div class="dbMultiEntryContainer">
<div class="col-md-12">
<?php $__currentLoopData = $form_details->eyeformmultipleentry()->where('field_name', 'OCT')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="col-md-2">   
</div>

<div class="col-md-3">
<input type="text" class="form-control" readonly value="<?php echo e($item->field_value_OD); ?>">
</div>

<div class="col-md-3">
<input type="text" class="form-control" readonly value="<?php echo e($item->field_value_OS); ?>">
</div>

<div class="col-md-2">
<button class="removeDbItem btn btn-default" data-deleteid="<?php echo e($item->id); ?>">Remove</button>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
</div>

<span class="dropdown-container">
<div id="EOM" class="ContainerToAppend">   
<div class="col-md-12"> 
<div class="col-md-2">
<div class="form-group labelgrp">
<label>Extra Ocular Movement (EOM)</label>
<input type="hidden" id="EOM[]" name="EOM[]" class="hiddenCounter" value="1" />
</div>          
</div>

<div class="col-md-3">
<?php echo e(Form::select('EOM_OD[]', array(' '=>'-Select-') + $form_dropdowns->where('fieldName', 'EOM OD')->pluck('ddText','ddText')->toArray(), array_key_exists('EOM OD', $defaultValues)?$defaultValues['EOM OD']:null, array('class'=> 'form-control select2','data-live-search'=>'true'))); ?>  
</div>  

<div class="col-md-3">
<?php echo e(Form::select('EOM_OS[]', array(' '=>'-Select-') + $form_dropdowns->where('fieldName', 'EOM OS')->pluck('ddText','ddText')->toArray(), array_key_exists('EOM OS', $defaultValues)?$defaultValues['EOM OS']:null, array('class'=> 'form-control select2','data-live-search'=>'true'))); ?>   
</div> 

<div class="col-md-4">
<button type="button" name="add" id='eombtn' class="btn btn-success set-dropdown-options"  data-field_name="EOM OD" data-form_name="EyeForm" >Set Option </button>
<button type='button' class="btn btn-primary" id='eombtnsave'>Save Option</button>
<button id="EOM" class="btn btn-default addmore" data-templateDiv="EOMTemplate">Add</button>
</div>    
</div>
</div>
<div id='EOMTextBoxesGroup' class="col-md-12">

</div>

<!-- ================================================================================= -->

<!-- set-dropdown-options -->
<!-- <span class="dropdown-container"> -->
<div class='dropdown-options-initial-div' class="col-md-12" style="display:none;">
<?php  
$dropdown_options_field_name = 'EOM OD';
$dropdown_options_form_name = 'EyeForm';
 ?>

</div>
</span>
<!-- ================================================================================= -->
<div class="dbMultiEntryContainer js-sweetalert">
<div class="col-md-12">
<?php $__currentLoopData = $form_details->eyeformmultipleentry()->where('field_name', 'EOM')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="col-md-2">    
</div>

<div class="col-md-3">
<input type="text" class="form-control" readonly value="<?php echo e($item->field_value_OD); ?>">
</div>

<div class="col-md-3">
<input type="text" class="form-control" readonly value="<?php echo e($item->field_value_OS); ?>">
</div>

<div class="col-md-4">
<button class="removeDbItem btn btn-default" data-deleteid="<?php echo e($item->id); ?>">Remove </button>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
</div>
<!-- ==================New fields======================================-->
<span class="dropdown-container">
<div class="col-md-12">
<div class="col-md-2">
<div class="form-group labelgrp">
<label>Perimetry</label>
</div>       
</div>

<div class="col-md-3">
<?php echo e(Form::select('perimetry_sp_od', array(' '=>'-Select-') + $form_dropdowns->where('fieldName', 'perimetry_sp OD')->pluck('ddText','ddText')->toArray(), array_key_exists('perimetry_sp_od', $defaultValues)?$defaultValues['perimetry_sp_od']:null, array('class'=> 'form-control select2'))); ?>

</div>

<div class="col-md-3">

<?php echo e(Form::select('perimetry_sp_os', array(' '=>'-Select-') + $form_dropdowns->where('fieldName', 'perimetry_sp OS')->pluck('ddText','ddText')->toArray(), array_key_exists('perimetry_sp_os', $defaultValues)?$defaultValues['perimetry_sp_os']:null, array('class'=> 'form-control select2'))); ?>


</div>
<div class="col-md-4">
<button type="button" name="add" id='PerimetrySpbtn' class="btn btn-success  set-dropdown-options"  data-field_name="perimetry_sp OD" data-form_name="EyeForm" >Set Option </button>
<button type='button' class="btn btn-primary" id='PerimetrySpbtnsave'>Save Option</button>
</div>

</div>
<div id='PerimetrySpTextBoxesGroup' class="col-md-12">

</div>

<!-- ================================================================================= -->

<!-- set-dropdown-options -->
<!-- <span class="dropdown-container"> -->
<div class='dropdown-options-initial-div' class="col-md-12" style="display:none;">
<?php  
$dropdown_options_field_name = 'perimetry_sp';
$dropdown_options_form_name = 'EyeForm';
 ?>

</div>
</span>
<!-- ================================================================================= -->
<!-- =====================================================================-->
<!-- ==================New fields======================================-->
<span class="dropdown-container">
<div class="col-md-12">
<div class="col-md-2">
<div class="form-group labelgrp">
<label>Laser</label>
</div>       
</div>

<div class="col-md-3">
<?php echo e(Form::select('laser_sp_od', array(' '=>'-Select-') + $form_dropdowns->where('fieldName', 'laser_sp OD')->pluck('ddText','ddText')->toArray(), array_key_exists('laser_sp_od', $defaultValues)?$defaultValues['laser_sp_od']:null, array('class'=> 'form-control select2'))); ?>

</div>

<div class="col-md-3">

<?php echo e(Form::select('laser_sp_os', array(' '=>'-Select-') + $form_dropdowns->where('fieldName', 'laser_sp OS')->pluck('ddText','ddText')->toArray(), array_key_exists('laser_sp_os', $defaultValues)?$defaultValues['laser_sp_os']:null, array('class'=> 'form-control select2'))); ?>


</div>
<div class="col-md-4">
<button type="button" name="add" id='LaserSpbtn' class="btn btn-success  set-dropdown-options"  data-field_name="laser_sp OD" data-form_name="EyeForm" >Set Option </button>
<button type='button' class="btn btn-primary" id='LaserSpbtnsave'>Save Option</button>
</div>

</div>
<div id='LaserSpTextBoxesGroup' class="col-md-12">

</div>

<!-- ================================================================================= -->

<!-- set-dropdown-options -->
<!-- <span class="dropdown-container"> -->
<div class='dropdown-options-initial-div' class="col-md-12" style="display:none;">
<?php  
$dropdown_options_field_name = 'laser_sp OD';
$dropdown_options_form_name = 'EyeForm';
 ?>

</div>
</span>
<!-- ================================================================================= -->
<!-- =====================================================================-->
<!-- ==================New fields======================================-->
<span class="dropdown-container">
<div class="col-md-12">
<div class="col-md-2">
<div class="form-group labelgrp">
<label>Oculizer</label>
</div>       
</div>

<div class="col-md-3">
<?php echo e(Form::select('oculizer_sp_od', array(' '=>'-Select-') + $form_dropdowns->where('fieldName', 'oculizer_sp OD')->pluck('ddText','ddText')->toArray(), array_key_exists('oculizer_sp_od', $defaultValues)?$defaultValues['oculizer_sp_od']:null, array('class'=> 'form-control select2'))); ?>

</div>

<div class="col-md-3">

<?php echo e(Form::select('oculizer_sp_os', array(' '=>'-Select-') + $form_dropdowns->where('fieldName', 'oculizer_sp OS')->pluck('ddText','ddText')->toArray(), array_key_exists('oculizer_sp_os', $defaultValues)?$defaultValues['oculizer_sp_os']:null, array('class'=> 'form-control select2'))); ?>


</div>
<div class="col-md-4">
<button type="button" name="add" id='OculizerSpbtn' class="btn btn-success  set-dropdown-options"  data-field_name="oculizer_sp OD" data-form_name="EyeForm" >Set Option </button>
<button type='button' class="btn btn-primary" id='OculizerSpbtnsave'>Save Option</button>
</div>

</div>
<div id='OculizerSpTextBoxesGroup' class="col-md-12">

</div>

<!-- ================================================================================= -->

<!-- set-dropdown-options -->
<!-- <span class="dropdown-container"> -->
<div class='dropdown-options-initial-div' class="col-md-12" style="display:none;">
<?php  
$dropdown_options_field_name = 'oculizer_sp OD';
$dropdown_options_form_name = 'EyeForm';
 ?>

</div>
</span>
<!-- ================================================================================= -->
<!-- =====================================================================-->
<!-- ==================New fields======================================-->
<span class="dropdown-container">
<div class="col-md-12">
<div class="col-md-2">
<div class="form-group labelgrp">
<label>FFA</label>
</div>       
</div>

<div class="col-md-3">
<?php echo e(Form::select('ffa_sp_od', array(' '=>'-Select-') + $form_dropdowns->where('fieldName', 'ffa_sp OD')->pluck('ddText','ddText')->toArray(), array_key_exists('ffa_sp_od', $defaultValues)?$defaultValues['ffa_sp_od']:null, array('class'=> 'form-control select2'))); ?>

</div>

<div class="col-md-3">

<?php echo e(Form::select('ffa_sp_os', array(' '=>'-Select-') + $form_dropdowns->where('fieldName', 'ffa_sp OS')->pluck('ddText','ddText')->toArray(), array_key_exists('ffa_sp_os', $defaultValues)?$defaultValues['ffa_sp_os']:null, array('class'=> 'form-control select2'))); ?>


</div>
<div class="col-md-4">
<button type="button" name="add" id='FfaSpbtn' class="btn btn-success  set-dropdown-options"  data-field_name="ffa_sp OD" data-form_name="EyeForm" >Set Option </button>
<button type='button' class="btn btn-primary" id='FfaSpbtnsave'>Save Option</button>
</div>

</div>
<div id='FfaSpTextBoxesGroup' class="col-md-12">

</div>

<!-- ================================================================================= -->

<!-- set-dropdown-options -->
<!-- <span class="dropdown-container"> -->
<div class='dropdown-options-initial-div' class="col-md-12" style="display:none;">
<?php  
$dropdown_options_field_name = 'ffa_sp OD';
$dropdown_options_form_name = 'EyeForm';
 ?>

</div>
</span>
<!-- ================================================================================= -->
<!-- =====================================================================-->
<!-- ================================================================================= -->
<!-- =====================================================================-->
<div class="col-md-12 custom-item-parent-div">
<div class="row custom-item">
<div class="col-md-4">
<select class="custom-item-dropdown form-control select2">
<option value="">Select Option</option>

<option value="colour" data-title="Colour Vision" data-od="1" data-os="1">Colour Vision</option>
<option value="schimerTest1" data-title="Schimer Test 1" data-od="1" data-os="1">Schimer Test 1</option>

<option value="schimerTest2" data-title="Schimer Test 2" data-od="1" data-os="1">Schimer Test 2</option>
<option value="OCT" data-title="Optical Coherence tomography (OCT)" data-od="1" data-os="1">Optical Coherence tomography (OCT)</option>
<option value="EOM" data-title="Extra Ocular Movement (EOM)" data-od="1" data-os="1">Extra Ocular Movement (EOM)</option>
<option value="perimetry_sp" data-title="Perimetry" data-od="1" data-os="1">Perimetry</option>
<option value="laser_sp" data-title="Laser" data-od="1" data-os="1">Laser</option>
<option value="oculizer_sp" data-title="Oculizer" data-od="1" data-os="1">Oculizer</option>
<option value="ffa_sp" data-title="FFA" data-od="1" data-os="1">FFA</option>
</select>
</div>
<div class="col-md-3">

</div>
<div class="col-md-3">

</div>
<div class="col-md-2">
<span class="add-custom-item btn btn-default">Add</span>
</div>
</div>
<div class="custom-item-container">

</div>
</div>


<!-- ========================================================= -->  

<div class="col-md-12">
<div class="col-md-6 col-md-offset-4">
<div class="form-group">
<button type="submit" formaction="<?php echo e(url('/patientDetails/SaveEyeExamination')); ?>" type="submit" name="submit" class="btn btn-primary btn-lg" value="submit">Submit</button> 
<button type="submit" formaction="<?php echo e(url('/patientDetails/SaveEyeExamination1')); ?>" name="submit" class="btn btn-primary btn-lg" value="submit">Submit & View
</button>
</div>
</div>
</div>
