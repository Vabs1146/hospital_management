<div class="col-md-12">
                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>&nbsp;</th>
                                    <th colspan="6" class="text-center">Right</th>
                                    <th colspan="6" class="text-center">Left</th>
                                </tr>
                                <tr>
                                    <th>&nbsp;</th>
                                    <th>SPH</th>
                                    <th>CYL</th>
                                    <th>Axis</th>
                                    <th>Vision</th>
                                    <th>SPH</th>
                                    <th>CYL</th>
                                    <th>Axis</th>
                                    <th>Vision</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
           
                                    <td>D.V.</td>
                                    <td>
                                        <?php echo e($eyform_vision_pgp_details->vision_pgp_dv_sph_r); ?>

                                    </td>
                                    <td>
                                        <?php echo e($eyform_vision_pgp_details->vision_pgp_dv_cyl_r); ?>

                                    </td>
                                    <td>
                                        <?php echo e($eyform_vision_pgp_details->vision_pgp_dv_axis_r); ?>

                                    </td>
                                    <td>
                                        <?php echo e($eyform_vision_pgp_details->vision_pgp_dv_vision_r); ?>

                                    </td>
                                    
                                    <td>
                                        <?php echo e($eyform_vision_pgp_details->vision_pgp_dv_sph_l); ?>

                                    </td>
                                    <td>
                                        <?php echo e($eyform_vision_pgp_details->vision_pgp_dv_cyl_l); ?>

                                    </td>
                                    <td>
                                        <?php echo e($eyform_vision_pgp_details->vision_pgp_dv_axis_l); ?>

                                    </td>
                                    <td>
                                        <?php echo e($eyform_vision_pgp_details->vision_pgp_dv_vision_l); ?>

                                    </td>
                                </tr>
                                <tr>
                                    <td>N.V.</td>
                                    <td>
                                        <?php echo e($eyform_vision_pgp_details->vision_pgp_nv_sph_r); ?>

                                    </td>
                                    <td>
                                        <?php echo e($eyform_vision_pgp_details->vision_pgp_nv_cyl_r); ?>

                                    </td>
                                    <td>
                                        <?php echo e($eyform_vision_pgp_details->vision_pgp_nv_axis_r); ?>

                                    </td>
                                    <td>
                                        <?php echo e($eyform_vision_pgp_details->vision_pgp_nv_vision_r); ?>

                                    </td>
                                    
                                    <td>
                                        <?php echo e($eyform_vision_pgp_details->vision_pgp_nv_sph_l); ?>

                                    </td>
                                    <td>
                                        <?php echo e($eyform_vision_pgp_details->vision_pgp_nv_cyl_l); ?>

                                    </td>
                                    <td>
                                        <?php echo e($eyform_vision_pgp_details->vision_pgp_nv_axis_l); ?>

                                    </td>
                                    <td>
                                        <?php echo e($eyform_vision_pgp_details->vision_pgp_nv_vision_l); ?>

                                    </td>
                                    
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>