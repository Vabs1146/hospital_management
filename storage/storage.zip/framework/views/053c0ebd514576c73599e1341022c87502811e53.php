<!DOCTYPE html>
<?php $CheckField = app('App\Http\Controllers\EyeFormController'); ?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link href="<?php echo e(asset('css/bootstrap.css')); ?>" rel="stylesheet">
    <style>
    /* Print styling */

    @media  print {
        [class*="col-sm-"] {
            float: left;
        }
        [class*="col-xs-"] {
            float: left;
        }
        .col-sm-12,
        .col-xs-12 {
            width: 100% !important;
        }
        .col-sm-11,
        .col-xs-11 {
            width: 91.66666667% !important;
        }
        .col-sm-10,
        .col-xs-10 {
            width: 83.33333333% !important;
        }
        .col-sm-9,
        .col-xs-9 {
            width: 75% !important;
        }
        .col-sm-8,
        .col-xs-8 {
            width: 66.66666667% !important;
        }
        .col-sm-7,
        .col-xs-7 {
            width: 58.33333333% !important;
        }
        .col-sm-6,
        .col-xs-6 {
            width: 50% !important;
        }
        .col-sm-5,
        .col-xs-5 {
            width: 41.66666667% !important;
        }
        .col-sm-4,
        .col-xs-4 {
            width: 33.33333333% !important;
        }
        .col-sm-3,
        .col-xs-3 {
            width: 25% !important;
        }
        .col-sm-2,
        .col-xs-2 {
            width: 16.66666667% !important;
        }
        .col-sm-1,
        .col-xs-1 {
            width: 8.33333333% !important;
        }
        .col-sm-1,
        .col-sm-2,
        .col-sm-3,
        .col-sm-4,
        .col-sm-5,
        .col-sm-6,
        .col-sm-7,
        .col-sm-8,
        .col-sm-9,
        .col-sm-10,
        .col-sm-11,
        .col-sm-12,
        .col-xs-1,
        .col-xs-2,
        .col-xs-3,
        .col-xs-4,
        .col-xs-5,
        .col-xs-6,
        .col-xs-7,
        .col-xs-8,
        .col-xs-9,
        .col-xs-10,
        .col-xs-11,
        .col-xs-12 {
            float: left !important;
        }
        body {
            margin: 0;
            padding: 0 !important;
            min-width: 768px;
        }
        .container {
            width: auto;
            min-width: 750px;
        }
        body {
            font-size: 10px;
        }
        a[href]:after {
            content: none;
        }
        .noprint,
        div.alert,
        header,
        .group-media,
        .btn,
        .footer,
        form,
        #comments,
        .nav,
        ul.links.list-inline,
        ul.action-links {
            display: none !important;
        }
    }

    </style>
</head>
<body>
 <div class="container-fluid">    
    
    <div class="row">
        <div class="col-lg-12">
            <img src=<?php echo e(Storage::disk('local')->url($logoUrl)); ?> class="img-rounded" alt="letter head top" width="100%" height="100%" />
        </div>
        <div class="col-lg-12">&nbsp;</div>
    </div>

<div class="row">
    <div class="col-sm-6">
        <label for="date" class="control-label">Date :</label>   <?php echo e(\Carbon\Carbon::now()->format('d/M/Y')); ?>

    </div>
    <div class="col-sm-6">

    </div>
</div>
<div class="row">
    <div class="col-sm-6">
        <label for="date" class="control-label">Case Number :</label>   <?php echo e($casedata['case_number']); ?>

    </div>
    <div class="col-sm-6">
        <label class="control-label">UHID Number :</label>   <?php echo e($casedata['uhid_no']); ?> 
    </div>
</div>
<div class="row">
    <div class="col-sm-6">
        <label for="date" class="control-label">Patient Name :</label>   <?php echo e(strtoupper($casedata['patient_name'])); ?>

    </div>
    <div class="col-sm-6">

    </div>
</div>
<div class="row">
    
    <div class="col-sm-6">
        <label class="control-label">Address :</label>   <?php echo e($casedata['patient_address']); ?> 
    </div>
    <div class="col-sm-6">
        <label class="control-label">Contact No. :</label>   <?php echo e($casedata['patient_mobile']); ?>

    </div>
</div>



   
<!--------------------------------------->
 <div class="panel-body" >
    <div class="container-fluid">
     <div class="table-responsive">
	 
    <table class="table  table-bordered">
        <tbody>
             <?php if(!$CheckField::IsFieldEmpty($patient_details->wife_name)): ?>
            <tr>
              <td> <label for="MensturationHistory" class="control-label">Wife Name </label></td>
                <td>
                 <?php echo e(($patient_details->wife_name)); ?>

                 
                </td>
            </tr>
            <?php endif; ?>
            <?php if(!$CheckField::IsFieldEmpty($patient_details->wife_age)): ?>
            <tr>
              <td> <label for="MensturationHistory" class="control-label">Wife Age</label></td>
                <td>
                 <?php echo e(($patient_details->wife_age)); ?>

                </td>
            </tr>
            <?php endif; ?>
             <?php if(!$CheckField::IsFieldEmpty($patient_details->husband_name)): ?>
            <tr>
              <td> <label for="MensturationHistory" class="control-label">Husband Name </label></td>
                <td>
                 <?php echo e(($patient_details->husband_name)); ?>

                </td>
            </tr>
            <?php endif; ?>
            <?php if(!$CheckField::IsFieldEmpty($patient_details->husband_age)): ?>
            <tr>
              <td> <label for="MensturationHistory" class="control-label">Husband Age </label></td>
                <td>
                 <?php echo e(($patient_details->husband_age)); ?>

                </td>
            </tr>
            <?php endif; ?>

			
   

            <?php if(!$CheckField::IsFieldEmpty($patient_details->married_since)): ?>
            <tr>
              <td> <label for="MensturationHistory" class="control-label">Married Since </label></td>
                <td>
                 <?php echo e(($patient_details->married_since)); ?>

                </td>
            </tr>
            <?php endif; ?>
            <?php if(!$CheckField::IsFieldEmpty($patient_details->menstrual_history)): ?>
            <tr>
              <td> <label for="MensturationHistory" class="control-label">Menstrual History</label></td>
                <td>
                 <?php echo e(($patient_details->menstrual_history)); ?>

                </td>
            </tr>
            <?php endif; ?>

			 
   

            <?php if(!$CheckField::IsFieldEmpty($patient_details->lmp)): ?>
            <tr>
              <td> <label for="MensturationHistory" class="control-label">LMP </label></td>
                <td>
                 <?php echo e(($patient_details->lmp)); ?>

                </td>
            </tr>
            <?php endif; ?>
            <?php if(!$CheckField::IsFieldEmpty($patient_details->ObstetricP)): ?>
            <tr>
              <td> <label for="MensturationHistory" class="control-label">P</label></td>
                <td>
                 <?php echo e(($patient_details->ObstetricP)); ?>

                </td>
            </tr>
            <?php endif; ?>
            <?php if(!$CheckField::IsFieldEmpty($patient_details->obstetric_history)): ?>
            <tr>
              <td> <label for="MensturationHistory" class="control-label">Obstetric History </label></td>
                <td>
                 <?php echo e(($patient_details->obstetric_history)); ?>

                </td>
            </tr>
            <?php endif; ?>
            <?php if(!$CheckField::IsFieldEmpty($patient_details->other_medical_surgical_illness)): ?>
            <tr>
              <td> <label for="MensturationHistory" class="control-label">Other Medical Surgical Illness </label></td>
                <td>
                 <?php echo e(($patient_details->other_medical_surgical_illness)); ?>

                </td>
            </tr>
            <?php endif; ?>
            <?php if(!$CheckField::IsFieldEmpty($patient_details->other_art_procedure_past)): ?>
            <tr>
              <td> <label for="MensturationHistory" class="control-label">Other ART Procedure In Past </label></td>
                <td>
                 <?php echo e(($patient_details->other_art_procedure_past)); ?>

                </td>
            </tr>
            <?php endif; ?>
            <?php if(!$CheckField::IsFieldEmpty($patient_details->hsg)): ?>
            <tr>
              <td> <label for="MensturationHistory" class="control-label">HSG</label></td>
                <td>
                 <?php echo e(($patient_details->hsg)); ?>

                </td>
            </tr>
            <?php endif; ?>
            <?php if(!$CheckField::IsFieldEmpty($patient_details->laproscopy)): ?>
            <tr>
              <td> <label for="MensturationHistory" class="control-label">Laproscopty</label></td>
                <td>
                 <?php echo e(($patient_details->laproscopy)); ?>

                </td>
            </tr>
            <?php endif; ?>
            <?php if(!$CheckField::IsFieldEmpty($patient_details->hsf)): ?>
            <tr>
              <td> <label for="MensturationHistory" class="control-label">HSF</label></td>
                <td>
                 <?php echo e(($patient_details->hsf)); ?>

                </td>
            </tr>
            <?php endif; ?>
	
 </tbody>
    </table>


<?php if(!$CheckField::IsFieldEmpty($patient_details->lh) || !$CheckField::IsFieldEmpty($patient_details->fsh) || !$CheckField::IsFieldEmpty($patient_details->tsh) || !$CheckField::IsFieldEmpty($patient_details->prolactin) || !$CheckField::IsFieldEmpty($patient_details->amh)): ?>
		 <table class="table  table-bordered">
        <tbody>
		<tr>
				<td colspan="10">
					<label for="MensturationHistory" class="control-label">Hormones</label>
				</td>
		</tr>
		<tr>
            <?php if(!$CheckField::IsFieldEmpty($patient_details->lh)): ?>
            
              <td> <label for="MensturationHistory" class="control-label">LH</label></td>
                <td>
                 <?php echo e(($patient_details->lh)); ?>

                </td>
            
            <?php endif; ?>
            <?php if(!$CheckField::IsFieldEmpty($patient_details->fsh)): ?>
            
              <td> <label for="MensturationHistory" class="control-label">FSH</label></td>
                <td>
                 <?php echo e(($patient_details->fsh)); ?>

                </td>
           
            <?php endif; ?>
           
            <?php if(!$CheckField::IsFieldEmpty($patient_details->tsh)): ?>
           
              <td> <label for="MensturationHistory" class="control-label">TSH</label></td>
                <td>
                 <?php echo e(($patient_details->tsh)); ?>

                </td>
            
            <?php endif; ?>

             <?php if(!$CheckField::IsFieldEmpty($patient_details->prolactin)): ?>
            
              <td> <label for="MensturationHistory" class="control-label">Prolactin</label></td>
                <td>
                 <?php echo e($patient_details->prolactin); ?>

                </td>
            
            <?php endif; ?>
             <?php if(!$CheckField::IsFieldEmpty($patient_details->amh)): ?>
           
              <td><label for="MensturationHistory" class="control-label">AMH </label></td>
                <td>
                  <?php echo e($patient_details->amh); ?>

                </td>
            
            <?php endif; ?>
			</tr>
	 </tbody>
    </table>
	<?php endif; ?>

	<?php if(!$CheckField::IsFieldEmpty($patient_details->folliculometry) || !$CheckField::IsFieldEmpty($patient_details->adviced)): ?>
	<table class="table  table-bordered">
        <tbody>
         
             <?php if(!$CheckField::IsFieldEmpty($patient_details->folliculometry)): ?>
            <tr>
              <td><label for="MensturationHistory" class="control-label">Folliculometry </label></td>
                <td>
                  <?php echo e($patient_details->folliculometry); ?>

                </td>
            </tr>
            <?php endif; ?>
              <?php if(!$CheckField::IsFieldEmpty($patient_details->adviced)): ?>
            <tr>
              <td><label for="MensturationHistory" class="control-label">Adviced </label></td>
                <td>
                  <?php echo e($patient_details->adviced); ?>

                </td>
            </tr>
            <?php endif; ?>
            
        </tbody>
    </table>
	<?php endif; ?>
 
	 </div>
	</div>
</div>
<!---------------------------------------->


<?php $__currentLoopData = old('Report_file',$casedata['Reports_file']); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reportfile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                        
<div class="row">
    <div class="col-sm-12">
        <?php echo e($reportfile->report_title); ?> 
    </div>
    <div class="col-sm-12">
        <?php echo e($reportfile->report_description); ?> 
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php if(null !== old('prescriptions',$casedata['prescriptions']) && count(old('prescriptions',$casedata['prescriptions']))> 0 ): ?>
<BR/>
<div class="row">
    <div class="col-sm-12">
        <label class="control-label">Prescription</label>  
    </div>
</div>
<table class="table">
    <tr>
        <th>
            Medicine
        </th>
        <th>
            Strength
        </th>
        <th>
            Quantity
        </th>
        <th>
            Times a Day    
        </th>
    </tr>
        <?php $__currentLoopData = old('prescriptions',$casedata['prescriptions']); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prescption): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>   
                <td>
                    <?php echo e($prescption->Medical_store->medicine_name); ?>

                </td>
                <td>
                    <?php echo e($prescption->strength); ?>

                </td>
                <td>
                    <?php echo e($prescption->medicine_Quntity); ?>

                </td>
                <td>
                    <?php echo e($prescption->numberoftimes); ?>

                </td>
            <tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php endif; ?>
<!-- asdfasdfa sdf asdf asdf -->
<br/>
<div class="row">
    <div class="col-sm-12">
        <label class="control-label">Note : </label> 
    </div>
</div>
<div class="row">
    <div class="col-sm-12">
        Please bring this paper on every visist 
    </div>
    <div class="col-sm-12">
        Please follow the time 
    </div>
    <div class="col-sm-12">
        Please inform allergy immediately 
    </div>
</div>
<div class="row">
    <div class="col-sm-12 pull-right">
            <?php echo e(config('app.name', 'Dr')); ?>

    </div>
</div>
</div>
    <!-- jQuery -->
    <script src="<?php echo e(asset('js/jquery.min.js')); ?> "></script>
        <!-- Bootstrap -->
    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
    <script type="text/javascript">
        $(document).ready(function(){
            setTimeout(function () { window.print(); }, 500);
            window.onfocus = function () { setTimeout(function () { window.close(); }, 50); }
        });
    </script>

</body>
</html>