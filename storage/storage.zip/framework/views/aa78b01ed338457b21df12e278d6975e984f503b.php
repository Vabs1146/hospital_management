
<?php $__env->startSection('style'); ?>
<link href="<?php echo e(url('/')); ?>/select2/css/select2.min.css" rel="stylesheet">
<style>
    @media  screen and (max-width: 767px) {
        .select2 {
            width: 100% !important;
        }
    }
    .ui-autocomplete-loading {
        background: white url("<?php echo e(asset('images/ui-anim_basic_16x16.gif')); ?>") right center no-repeat;
    }
</style>
<!-- Styles -->
<link rel="stylesheet" href="<?php echo e(asset('JqueryUI/jquery-ui.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
<div class="row clearfix">
       <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <?php echo $__env->make('shared.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          <?php if(Session::has('flash_message')): ?>
          <div class="alert alert-success">
          <?php echo e(Session::get('flash_message')); ?>

          </div>
          <?php endif; ?>
          <div class="card">
             
         <form class="form-horizontal" method="post" action="<?php echo e(route('stored_images')); ?>" enctype="multipart/form-data">
              <?php echo e(csrf_field()); ?>

              <div class="header bg-pink">
              <h2>ADD Gallery</h2>
              </div>
              <div class="body">
                  <div class="row clearfix ">
                      <div class="col-md-12">
                          <div class="col-md-2">
                            <div class="form-group labelgrp">
                            <?php echo e(Form::label('gallery_name', 'Gallery Name :')); ?>

                            </div>
                          </div>

                           <div class="col-md-4">
                            <div class="form-group">
                            <div class="form-line">
                              <input type="text" class="form-control" id="gallery_name" placeholder="gallery_name here" name="gallery_name" required>                           
                            </div>
                            </div>
                          </div>   

                         <div class="col-md-2">
                          <div class="form-group labelgrp">
                          <label class="form-control">Gallery Images<br><span class="text-success">Multiple Image select Gallery</span> :</label>
                          </div>
                          </div>

                          <div class="col-md-4">
                            <div class="form-group">
                            <div class="form-line">
                           <input type="file" class="custom-file-input" id="filenames" name="filenames[]"  required multiple>
                            <label class="custom-file-label" for="filenames">Choose Image...</label>                          
                            </div>
                            </div>
                          </div>
                      </div>

                      <div class="col-md-12">
                          <div class="col-md-2">
                              <div class="form-group labelgrp">
                              <label class="form-control">Display Image :</label>
                              </div>
                          </div>

                          <div class="col-md-4">
                              <div class="form-group">
                              <div class="form-line">
                              <input type="file" class="custom-file-input" id="filenames1" name="filenames1"  required>
                              <label class="custom-file-label" for="filenames1">Choose Image...</label>                        
                              </div>
                              </div>
                          </div>


                       
                      </div>
                            

                  </div>    

                  <div class="row clearfix">
                      <div class="col-md-8 col-md-offset-2" >
                         
                         <button type="submit" class="btn btn-primary btn-lg">Submit</button>
                           </div>
                      
                               
                  </div>
                </div>
                </form>
                </div>
                </div>
                </div>
               </div>
  <?php $__env->stopSection(); ?>


<?php echo $__env->make('adminlayouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>