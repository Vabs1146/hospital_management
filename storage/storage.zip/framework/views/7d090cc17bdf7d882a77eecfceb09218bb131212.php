<?php $__env->startSection('style'); ?>
<style>
    @media  screen and (max-width: 767px) {
        .select2 {
            width: 100% !important;
        }
    }
    .ui-autocomplete-loading {
        background: white url("<?php echo e(asset('images/ui-anim_basic_16x16.gif')); ?>") right center no-repeat;
    }
</style>
<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/css/select2.min.css" rel="stylesheet" />
<!-- Styles -->
<link rel="stylesheet" href="<?php echo e(asset('JqueryUI/jquery-ui.css')); ?>">


<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="container">
    <div class="list-group list-group-horizontal">
        <?php $__empty_1 = true; $__currentLoopData = $DateWiseRecordLst; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $VisitListDateWise): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php if($case_master['id'] == $VisitListDateWise['id']): ?>
                    <a href="<?php echo e(url('/glassPrescription').'/'.$VisitListDateWise['id'].'/edit'); ?>" class="list-group-item active"><?php echo e(Carbon\Carbon::parse($VisitListDateWise['created_at'])->format('d-M-Y')); ?></a> <span> &nbsp;</span>    
                <?php else: ?>
                    <a href="<?php echo e(url('/glassPrescription').'/'.$VisitListDateWise['id'].'/edit'); ?>" class="list-group-item"><?php echo e(Carbon\Carbon::parse($VisitListDateWise['created_at'])->format('d-M-Y')); ?></a> <span> &nbsp;</span>
                <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    </div>
<div class="container-fluid">
<div class="row clearfix">
       <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                  <?php echo $__env->make('shared.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                  <?php if(Session::has('flash_message')): ?>
                  <div class="alert alert-success">
                  <?php echo e(Session::get('flash_message')); ?>

                  </div>
                  <?php endif; ?>



          <div class="card">
          <form action="<?php echo e(url('/glassPrescription'.( isset($case_master) ? "/" . $case_master['id'] : ""))); ?>" method="POST" class="form-horizontal" enctype = 'multipart/form-data' >
                <?php echo e(csrf_field()); ?>


                <?php if(isset($case_master)): ?>
                    <input type="hidden" name="_method" value="PATCH">
                <?php endif; ?>

          <div class="header bg-pink">
          <h2>Add/Edit Glass Prescription </h2>
          </div>
           
              <input type="hidden" id="case_id" name="case_id" value="<?php echo e(isset($case_master['id']) ? $case_master['id'] : ''); ?>" >
                <?php echo e(Form::hidden('case_number', Request::old('case_number'), array('class'=> 'form-control'))); ?>

                 <?php echo e(Form::hidden('patient_emailId', Request::old('patient_emailId'), array('class'=> 'form-control'))); ?>

              <div class="body">
                  <div class="row clearfix ">
                            <div class="col-md-12">
                              <div class="col-md-2">
                              <div class="form-group labelgrp">
                              <label for="case_number" class="control-label">Case Number</label>
                              </div>
                              </div>

                              <div class="col-md-4">
                              <div class="form-group">
                              <div class="form-line">
                                <input type="text" name="case_number" id="case_number" class="form-control" readonly='readonly' value="<?php echo e(isset($case_master['case_number']) ? $case_master['case_number'] : ''); ?>">                        
                              </div>
                              </div>
                              </div>   


                              <div class="col-md-2">
                              <div class="form-group labelgrp">
                              <label for="name_of_patient" class="control-label">Name Of Patient</label>
                              </div>
                              </div>


                              <div class="col-md-4">
                              <div class="form-group">
                              <div class="form-line">
                              <input type="text" name="name_of_patient" id="name_of_patient" class="form-control"  readonly='readonly' value="<?php echo e(isset($case_master['patient_name']) ? $case_master['patient_name'] : ''); ?>">                        
                              </div>
                              </div>
                              </div>
                          </div>

                        <div class="col-md-12">
                            <div class="table-responsive">
                                <table class="table table-condensed">
                                        <thead>
                                            <tr>
                                                <td colspan="5" align="center">
                                                    <strong>Right</strong>
                                                </td>
                                                <td colspan="4" align="center">
                                                <strong>Left Eye</strong>
                                                </td>                           
                                            </tr>
                                            <tr>
                                                <td>
                                                    <strong>&nbsp;</strong>
                                                </td>
                                                <td align="center">
                                                <strong>SPH</strong>
                                                </td>                           
                                                <td align="center">
                                                    <strong>CYL</strong>
                                                </td>
                                                <td align="center">
                                                <strong>AXIS</strong>
                                                </td>                           
                                                <td align="center">
                                                <strong>VISION</strong>
                                                </td>
                                                <td align="center">
                                                <strong>SPH</strong>
                                                </td>                           
                                                <td align="center">
                                                    <strong>CYL</strong>
                                                </td>
                                                <td align="center">
                                                    <strong>AXIS</strong>
                                                </td>                           
                                                <td align="center">
                                                    <strong>VISION</strong>
                                                </td>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>
                                                    <strong>D.V.</strong>
                                                </td>
                                                <td>
                                                    <?php echo e(Form::text('r_dv_sph', Request::old('r_dv_sph',$glass_prescription->r_dv_sph), array('class' => 'form-control autocompleteTxt'))); ?>

                                                </td>                           
                                                <td>
                                                        <?php echo e(Form::text('r_dv_cyl', Request::old('r_dv_cyl',$glass_prescription->r_dv_cyl), array('class' => 'form-control autocompleteTxt'))); ?>

                                                </td>
                                                <td>
                                                        <?php echo e(Form::text('r_dv_axi', Request::old('r_dv_axi',$glass_prescription->r_dv_axi), array('class' => 'form-control autocompleteTxt'))); ?>

                                                </td>                           
                                                <td>
                                                        <?php echo e(Form::text('r_dv_vision', Request::old('r_dv_vision',$glass_prescription->r_dv_vision), array('class' => 'form-control autocompleteTxt'))); ?>

                                                </td>
                                                <td>
                                                    <?php echo e(Form::text('l_dv_sph', Request::old('l_dv_sph',$glass_prescription->l_dv_sph), array('class' => 'form-control autocompleteTxt'))); ?>

                                                </td>                           
                                                <td>
                                                        <?php echo e(Form::text('l_dv_cyl', Request::old('l_dv_cyl',$glass_prescription->l_dv_cyl), array('class' => 'form-control autocompleteTxt'))); ?>

                                                </td>
                                                <td>
                                                        <?php echo e(Form::text('l_dv_axi', Request::old('l_dv_axi',$glass_prescription->l_dv_axi), array('class' => 'form-control autocompleteTxt'))); ?>

                                                </td>                           
                                                <td>
                                                        <?php echo e(Form::text('l_dv_vision', Request::old('l_dv_vision',$glass_prescription->l_dv_vision), array('class' => 'form-control autocompleteTxt'))); ?>

                                                </td>
                                            </tr>
                                            <tr>
                                                <td>
                                                    <strong>N.V.</strong>
                                                </td>
                                                <td>
                                                    <?php echo e(Form::text('r_nv_sph', Request::old('r_nv_sph',$glass_prescription->r_nv_sph), array('class' => 'form-control autocompleteTxt'))); ?>

                                                </td>                           
                                                <td>
                                                        <?php echo e(Form::text('r_nv_cyl', Request::old('r_nv_cyl',$glass_prescription->r_nv_cyl), array('class' => 'form-control autocompleteTxt'))); ?>

                                                </td>
                                                <td>
                                                        <?php echo e(Form::text('r_nv_axi', Request::old('r_nv_axi',$glass_prescription->r_nv_axi), array('class' => 'form-control autocompleteTxt'))); ?>

                                                </td>                           
                                                <td>
                                                        <?php echo e(Form::text('r_nv_vision', Request::old('r_nv_vision',$glass_prescription->r_nv_vision), array('class' => 'form-control autocompleteTxt'))); ?>

                                                </td>
                                                <td>
                                                    <?php echo e(Form::text('l_nv_sph', Request::old('l_nv_sph',$glass_prescription->l_nv_sph), array('class' => 'form-control autocompleteTxt'))); ?>

                                                </td>                           
                                                <td>
                                                        <?php echo e(Form::text('l_nv_cyl', Request::old('l_nv_cyl',$glass_prescription->l_nv_cyl), array('class' => 'form-control autocompleteTxt'))); ?>

                                                </td>
                                                <td>
                                                        <?php echo e(Form::text('l_nv_axi', Request::old('l_nv_axi',$glass_prescription->l_nv_axi), array('class' => 'form-control autocompleteTxt'))); ?>

                                                </td>                           
                                                <td>
                                                        <?php echo e(Form::text('l_nv_vision', Request::old('l_nv_vision',$glass_prescription->l_nv_vision), array('class' => 'form-control autocompleteTxt'))); ?>

                                                </td>
                                            </tr>                    
                                        </tbody>
                                </table>
                        </div>
                        </div>


                           <div class="col-md-12">
                              <div class="col-md-2">
                              <div class="form-group labelgrp">
                              <?php echo e(Form::label('Report_1','Remark')); ?> 
                              </div>
                              </div>


                              <div class="col-md-8">
                              <div class="form-group">
                              <div class="form-line">
                              <?php echo e(Form::text('Report_1', Request::old('Report_1', $glass_prescription->Report_1), array('class' => 'form-control', 'autocomplete'=>'off'))); ?>                           
                              </div>
                              </div>
                              </div>

                             

                          </div>
					  
					   <div class="col-md-12">
                                    <div class="col-md-2">
                                        <div class="form-group labelgrp">
                                        <label>Email To </label>
                                        </div>
                                        </div>
                                        <div class="col-md-6">
                                        <div class="form-group">
                                        <div class="form-line">
                                          <input type="email" name="email" id="email" class="form-control">
                                        </div>
                                         </div>
                                        </div> 
                                        <div class="col-md-2">
                                          <button type="submit" formaction="<?php echo e(url('glass_prescriptionEmail')); ?>" name="submit" class="btn btn-success btn-lg" value="submit" >Email To Other</button>&nbsp;
                                           
                                        
                                        </div>
                                      </div>


                                     
                  </div>    

                  <div class="row clearfix">
                    <div class="col-md-8 col-md-offset-2">
                    <div class="form-group">
                    <button type="submit" name="submit" class="btn btn-success btn-lg" value="submit"><i class="fa fa-plus"></i> Submit
                    </button>
                    <a class="btn btn-default btn-lg" href="<?php echo e(url('/glassPrescription')); ?>"><i class="glyphicon glyphicon-chevron-left"></i> Back</a>
                    <a class="btn btn-default btn-lg" href="<?php echo e(url('/PatientMedicalDetails').'/'.$case_master->id); ?>"><i class="glyphicon glyphicon-chevron-left"></i> Patient Details </a>
                    <a class="btn btn-default btn-lg" href="<?php echo e(url('/glassPrescription/print').'/'. $case_master->id); ?>" target="_blank"><i class="glyphicon glyphicon-print"></i> Print </a>
                    
						
					<button type="submit" formaction="<?php echo e(url('glass_prescriptionEmail1')); ?>" name="submit" class="btn btn-success btn-lg" value="submit" >Submit & Email</button>&nbsp;

                    </div>
                    </div>
                               
                  </div>
                </div>
           </form>
            </div>
        </div>
</div>
</div>

        <?php $__env->stopSection(); ?>
  
<?php $__env->startSection('scripts'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/js/select2.min.js"></script>
<script type="text/javascript">
    $(document).ready(function(){
      $('#medicine_id').select2();  
      $('.datepicker').datepicker({
            format: "dd/M/yyyy",
            weekStart: 1,
            clearBtn: true,
            daysOfWeekHighlighted: "0,6",
            autoclose: true,
        });    
    });
</script>

<!-- jQuery Easing -->
<script src="<?php echo e(asset('JqueryUI/jquery.js')); ?> ">
</script>

<script>    
     jq = $.noConflict(true);
</script>
<script src="<?php echo e(asset('JqueryUI/jquery-ui.js')); ?> ">
</script>
<script>
        var url = "<?php echo e(url('/genericAutocomplete')); ?>";
        jq(".autocompleteTxt").autocomplete({
            source: function(request, response) {
                $.ajax({
                    url: "<?php echo e(url('/genericAutocomplete')); ?>",
                    dataType: "json",
                    data: {
                        query: request.term,
                        PropertyName: jq(this.element).attr('name'),//'Complaints' 
                        tableName: 'glass_prescriptions'
                    },
                    success: function(data) {
                        data = JSON.parse(JSON.stringify(data));
                        response(data);
                    }
                });
            }
        });
</script>

<?php $__env->stopSection(); ?>









<?php echo $__env->make('adminlayouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>