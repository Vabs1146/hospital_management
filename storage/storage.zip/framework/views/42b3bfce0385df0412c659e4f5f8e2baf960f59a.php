<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Document</title>
    <link href="<?php echo e(asset('css/bootstrap.css')); ?>" rel="stylesheet">
    <style type="text/css">
        .invoice-title h2,
        .invoice-title h3 {
            display: inline-block;
        }
        
        .table > tbody > tr > .no-line {
            border-top: none;
        }
        
        .table > thead > tr > .no-line {
            border-bottom: none;
        }
        
        .table > tbody > tr > .thick-line {
            border-top: 2px solid;
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <img src=<?php echo e(Storage::disk('local')->url($logoUrl)); ?> class="img-rounded" alt="letter head top" width="100%" height="100%" />
            </div>
            <div class="col-lg-12">&nbsp;</div>
        </div>
        <div class="row">
            <div class="col-xs-12">
                <div class="invoice-title">
                    <h4>Prescriptions2</h4>
                    <h5 class="pull-right">Patient Number # <?php echo e($casedata['case_number']); ?></h5>
                </div>
                <div class="row">
                    <div class="col-xs-6">
                        <address>Date:					<?php echo e(\Carbon\Carbon::now()->format('d/M/Y')); ?>

                            <br/>Name: <?php echo e($casedata['patient_name']); ?> 
                            <br/> Address: <?php echo e($casedata['patient_address']); ?>

                            <br/> Mobile no:  <?php echo e($casedata['patient_mobile']); ?>

                            <br/> Follow-up Dt:  <?php echo e($casedata['appointment_dt']); ?>

                        </address>
                    </div>
                </div>
                <div class="row">
                    <div class="col-xs-6">

                    </div>
                    <div class="col-xs-6 text-right">
                    </div>
                </div>
            </div>
        </div>
        
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title">Prescption summary</h3>
                    </div>
                    <div class="panel-body">
                        
                        <div class="table-responsive">
                            <table class="table table-condensed">
                                <thead>
                                    <tr>
                         <td><strong>Sr. No.</strong></td>
                         <td><strong>Medicine</strong></td>
                         <td><strong>Eye</strong></td>
                         <td><strong>Frequency</strong></td>
                         <td><strong>Duration</strong></td>
                         
                </tr>
                                </thead>
                                <tbody>
                                    <!-- foreach ($order->lineItems as $line) or some such thing here -->
                                <?php $Sumtotal = 0; ?>
                                <?php $__currentLoopData = $casedata['prescriptions']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prescption): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                <td>
                    <?php echo e($loop->iteration); ?>

                </td>   
                <td>
                    <?php echo e($prescption->Medical_store->medicine_name); ?>

                </td>
                
                <td>
                    <?php echo e($prescption->strength); ?>

                </td>
                <td >
                    <?php echo e($prescption->numberoftimes); ?>

                </td>
                <td>
                    <?php echo e($prescption->medicine_Quntity); ?>

                </td>
                
                
            <tr>
                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="row">
            <div class="col-sm-6"></div>
            <div class="col-sm-6">
                <div class="pull-right">
                    <?php if($doctor): ?>
						<p><?php echo e($doctor->name); ?></p>
						<p><?php echo e($doctor->doctor_degree); ?></p>
						<p><?php echo e($doctor->doctor_registration_number); ?></p>
					<?php endif; ?>
                    <b><?php echo e(config('app.name', 'Dr')); ?></b>  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </div>
            </div>
        </div>
        
    <!-- jQuery -->
    <script src="<?php echo e(asset('js/jquery.min.js')); ?> "></script>
        <!-- Bootstrap -->
    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
    <script type="text/javascript">
        $(document).ready(function(){
            setTimeout(function () { window.print(); }, 500);
            window.onfocus = function () { setTimeout(function () { window.close(); }, 50); }
            //Added comment to incluede file in commit
        });
    </script>
</body>

</html>