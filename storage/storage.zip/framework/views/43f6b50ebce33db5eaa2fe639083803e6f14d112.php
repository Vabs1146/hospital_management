<?php $__env->startSection('pageheader'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('owl-carousel/owl-gallery.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/font-awesome.min.css')); ?>">
    <style>
        .well {
            width: 200px;
            display: inline-block;
        }
        .well img {
            display: block;
            width: 100%;
            margin: 0 auto;
        }
        a:active, a:focus, a:hover {
            text-decoration: none;
        }
        #gallery-slider .owl-item img {
            height: 95% !important;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('pagebody'); ?>
<div class="container">
<br/>
<br/>
    <div style="text-align: center;">
            <?php $__currentLoopData = $galleryData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="#" onclick="$(this).galleryShow(); return false;">
                    <div class="well">
                        <img src=<?php echo e(Storage::disk('local')->url($item->imgUrl)); ?> alt="" title="Portfolio Image 1" style="widht:150px; height:150px;" />
                    </div>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
<br/>
<br/>
</div>
      <script src="<?php echo e(asset('owl-carousel/owl-gallery.js')); ?> "></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footescripts'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('shared/layoutProspera', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>