<?php $__env->startSection('title', $title ); ?>
<?php $__env->startSection('pagebody'); ?>
          <!-- Content -->
      <article>
        <header class="section background-primary text-center">
            <h1 class="text-white margin-bottom-0 text-size-50 text-thin text-line-height-1"> <?php echo e($dynamicText->name); ?> </h1>
        </header>
        <div class="section background-white"> 
          <div class="line">
            <div class="margin text-center">
                <?php echo $dynamicText->html_text; ?>

            </div>
          </div> 
        </div> 
      </article>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footescripts'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make(env('layoutTemplate'), array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>