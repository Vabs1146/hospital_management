<?php if(isset($form_dropdowns_array[$dropdown_options_field_name]) && !empty($form_dropdowns_array[$dropdown_options_field_name])): ?>

<?php  
	$form_id = $dropdown_options_form_name .'_'. str_replace(' ', '-', $dropdown_options_field_name);
 ?>
<div name="" class="update-dropdown-options-form" id="<?php echo e($form_id); ?>" method="POST" action="<?php echo e(route('update-dropdown-options')); ?>">

<input class="form-control" type="hidden" name="tableName" class="tableName" value="<?php echo e($dropdown_options_table_name); ?>">
<input class="form-control" type="hidden" name="formName" class="formName" value="<?php echo e($dropdown_options_form_name); ?>">
<input class="form-control" type="hidden" name="fieldName" class="fieldName" value="<?php echo e($dropdown_options_field_name); ?>">

<?php $__currentLoopData = $form_dropdowns_array[$dropdown_options_field_name]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $form_dropdowns_array_row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<input type="hidden" name="initial_options_ids[]" value="<?php echo e($key); ?>">
	<div class="col-md-3 initial_options">
		<div class="input-group">
			<div class="form-line">
				<input class="form-control" type="hidden" placeholder="value1" class="initial_optionsid" name="initial_optionsid[]" value="<?php echo e($key); ?>">
				<input class="form-control" type="text" placeholder="value1" class="initial_optionsval" name="initial_optionsval[]" value="<?php echo e($form_dropdowns_array_row['ddValue']); ?>">
			</div>
			<span class="input-group-addon remove-initial-options" type="button"><i class="fa fa-times" aria-hidden="true"></i></span>
		</div>
	</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<span class="update-dropdown-options-btn btn btn-success" data-table_name="<?php echo e($dropdown_options_table_name); ?>">Update</span>
<span class="cancel-dropdown-options-btn btn btn-success">Cancel</span>
</div>
<?php endif; ?>