<style type="text/css">
  .medicineremoveButton,.eyeremoveButton,.dayremoveButton,.timesadayremoveButton{
  color: #700;
  cursor: pointer;
}

.medicineremoveButton,.eyeremoveButton,.dayremoveButton,.timesadayremoveButton:hover {
  color: #f00;
}

</style>
<?php $__env->startSection('style'); ?>
<link href="<?php echo e(url('/')); ?>/select2/css/select2.min.css" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="list-group list-group-horizontal">
        <?php $__empty_1 = true; $__currentLoopData = $DateWiseRecordLst; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $VisitListDateWise): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php if($case_master['id'] == $VisitListDateWise['id']): ?>
                    <a href="<?php echo e(url('/insuranceBill').'/'.$VisitListDateWise['id'].'/edit'); ?>" class="list-group-item active"><?php echo e(Carbon\Carbon::parse($VisitListDateWise['created_at'])->format('d-M-Y')); ?></a> <span> &nbsp;</span>    
                <?php else: ?>
                    <a href="<?php echo e(url('/insuranceBill').'/'.$VisitListDateWise['id'].'/edit'); ?>" class="list-group-item"><?php echo e(Carbon\Carbon::parse($VisitListDateWise['created_at'])->format('d-M-Y')); ?></a> <span> &nbsp;</span>
                <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<div class="container-fluid">
<div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                  <?php echo $__env->make('shared.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 
                    <?php if(Session::has('flash_message')): ?>
                        <div class="alert alert-success">
                            <?php echo e(Session::get('flash_message')); ?>

                        </div>
                    <?php endif; ?>
                    <div class="card">
                         <div class="header bg-pink">
                            <h2>
                               Discharge Summary
                            </h2>
                          
                        </div>
                    
               

                        <div class="body">
                          <form action="<?php echo e(url('/discharge'.( isset($case_master) ? "/1/" . $case_master['id'] : ""))); ?>" method="POST" enctype = 'multipart/form-data' >
                          <?php echo e(csrf_field()); ?>

                         <input type="hidden" id="case_id" name="case_id" value="<?php echo e(isset($case_master['id']) ? $case_master['id'] : ''); ?>" >
                            <div class="row clearfix">
                              <div class="col-md-12">
                              <div class="col-md-2">
                              <div class="form-group labelgrp">
                              <label for="case_number" class="form-control">Case Number :</label>
                              </div>
                              </div>

                              <div class="col-md-4">
                              <div class="form-group">
                              <div class="form-line">
                              <input type="text" name="case_number" id="case_number" class="form-control" readonly='readonly' value="<?php echo e(isset($case_master['case_number']) ? $case_master['case_number'] : ''); ?>">              
                              </div>
                              </div>
                              </div> 

                               <div class="col-md-2">
                              <div class="form-group labelgrp">
                              <label for="patient_name" class="form-control">Name Of Patient :</label>
                              </div>
                              </div>


                              <div class="col-md-4">
                              <div class="form-group">
                              <div class="form-line">
                                <input type="text" name="patient_name" id="patient_name" class="form-control" value="<?php echo e(isset($case_master['patient_name']) ? $case_master['patient_name'] : ''); ?>">
                              </div>  
                              </div>
                              </div>
                              </div>

                              <div class="col-md-12">
                              <div class="col-md-2">
                              <div class="form-group labelgrp">
                              <label for="name_of_age" class="form-control">Age :</label>
                              </div>
                              </div>


                              <div class="col-md-4">
                              <div class="form-group">
                              <div class="form-line">
                              <input type="text" name="patient_age" id="patient_age" class="form-control"  value="<?php echo e(isset($case_master['patient_age']) ? $case_master['patient_age'] : ''); ?>"></div>
                              </div>
                              </div>

                              <div class="col-md-2">
                              <div class="form-group labelgrp">
                              <label for="male_female" class="form-control">Sex :</label>
                              </div>
                              </div>

                              <div class="col-md-4">
                               <div class="form-group" style="padding-top: 6px">
                          
                              <input name="male_female" type="radio" id="radio_8" class=" with-gap radio-col-pink" value="Male" required  <?php echo e(($case_master->male_female == "Male")? "checked=\"checked\"" : ""); ?>   />
                              <label for="radio_8">Male</label>
                              <input name="male_female" type="radio" id="radio_10" class="with-gap radio-col-deep-purple" value="Female" required   <?php echo e(($case_master->male_female == "Female")? "checked=\"checked\"" : ""); ?> />
                              <label for="radio_10">Female</label>
                             
                              </div>
                              </div>   
                              </div> 

                              <div class="col-md-12">
                              <div class="col-md-2">
                              <div class="form-group labelgrp">
                              <?php echo e(Form::label('IPD_no','IPD no.')); ?> 
                              </div>
                              </div>
 
                              <div class="col-md-4">
                              <div class="form-group">
                              <div class="form-line">
                              <?php echo e(Form::text('IPD_no', Request::old('IPD_no',$discharge->IPD_no), array('class' => 'form-control'))); ?></div>
                              </div>
                              </div>

                               <div class="col-md-2">
                              <div class="form-group labelgrp">
                              <?php echo e(Form::label('patient_address','Address')); ?>

                              </div>
                              </div>

                              <div class="col-md-4">
                              <div class="form-group">
                              <div class="form-line">
                              <?php echo e(Form::text('patient_address', Request::old('patient_address',$case_master->patient_address), array('class' => 'form-control'))); ?>

                              </div>
                              </div>
                              </div>
                              </div> 

                              <div class="col-md-12">
                              <div class="col-md-2">
                              <div class="form-group labelgrp">
                              <?php echo e(Form::label('patient_mobile','Tel.')); ?> 
                              </div>
                              </div>

                              <div class="col-md-4">
                              <div class="form-group">
                              <div class="form-line">
                              <?php echo e(Form::text('patient_mobile', Request::old('patient_mobile',$case_master->patient_mobile), array('class' => 'form-control'))); ?>            
                              </div>
                              </div>
                              </div>  

                               <div class="col-md-2">
                              <div class="form-group labelgrp">
                             <?php echo e(Form::label('admission_date_time','Admission Date & Time')); ?> 
                              </div>
                              </div>

                              <div class="col-md-4">
                              <div class="form-group">
                              <div class="form-line">
                              <?php echo e(Form::text('admission_date_time', Request::old('admission_date_time',$case_master['admission_date_time']), array('class' => 'form-control datetimepicker', 'autocomplete'=>'off'))); ?>            
                              </div>
                              </div>
                              </div>
                              </div>

                              <div class="col-md-12">
                              <div class="col-md-2">
                              <div class="form-group labelgrp">
                               <?php echo e(Form::label('surgery_date_time','Surgery Date & Time')); ?> 
                              </div>
                              </div>

                              <div class="col-md-4">
                              <div class="form-group">
                              <div class="form-line">
                              <?php echo e(Form::text('surgery_date_time', Request::old('surgery_date_time',$case_master['surgery_date_time']), array('class' => 'form-control datetimepicker', 'autocomplete'=>'off'))); ?>            
                              </div>
                              </div>
                              </div>  

                               <div class="col-md-2">
                              <div class="form-group labelgrp">
                              <?php echo e(Form::label('discharge_date_time','Discharge Date & Time ')); ?>

                              </div>
                              </div>

                              <div class="col-md-4">
                              <div class="form-group">
                              <div class="form-line">
                              <?php echo e(Form::text('discharge_date_time', Request::old('discharge_date_time',$case_master['discharge_date_time']), array('class' => 'form-control datetimepicker'))); ?>

                              </div>
                              </div>
                              </div>
                              </div>

                              <div class="col-md-12">
                              <div class="col-md-2">
                              <div class="form-group labelgrp">
                               <?php echo e(Form::label('diagnosis','Diagnosis')); ?> 
                              </div>
                              </div>

                              <div class="col-md-4">
                              <div class="form-group">
                              <div class="form-line">
                             <?php echo e(Form::text('diagnosis', Request::old('diagnosis',$case_master['diagnosis']), array('class' => 'form-control'))); ?>            
                              </div>
                              </div>
                              </div>  

                               <div class="col-md-2">
                              <div class="form-group labelgrp">
                               <?php echo e(Form::label('systemic_diseases','Systemic Diseases')); ?>

                              </div>
                              </div>

                              <div class="col-md-4">
                              <div class="form-group">
                              <div class="form-line">
                               <?php echo e(Form::text('systemic_diseases', Request::old('systemic_diseases',$discharge->systemic_diseases), array('class' => 'form-control'))); ?>

                              </div>
                              </div>
                              </div>
                              </div>

                             
                              <div class="col-md-12">
                                

                                 <div class="col-md-2">
                                <div class="form-group labelgrp">
                                <?php echo e(Form::label('general_condition','General Condition')); ?>

                                </div>
                                </div>

                                <div class="col-md-4">
                                <div class="form-group">
                                <div class="form-line">
                                <?php echo e(Form::text('general_condition', Request::old('general_condition',$discharge->general_condition), array('class' => 'form-control'))); ?>

                                </div>
                                </div>
                                </div>
                                
                              </div>
                               <div class="col-md-12">
                                <legend>OPERATION NOTES</legend>
                                <div class="col-md-2">
                                <div class="form-group labelgrp">
                                <?php echo e(Form::label('anesthesia_procedure','Anesthesia ')); ?>

                                </div>
                                </div>

                                <div class="col-md-4">
                                <div class="form-group">
                                <div class="form-line">
                                <?php echo e(Form::text('anesthesia_procedure', Request::old('anesthesia_procedure',$discharge->anesthesia_procedure), array('class' => 'form-control'))); ?>

                                </div>
                                </div>
                                </div>

                                 <div class="col-md-2">
                                <div class="form-group labelgrp">
                                <?php echo e(Form::label('procedure','Procedure')); ?>

                                </div>
                                </div>

                                <div class="col-md-4">
                                <div class="form-group">
                                <div class="form-line">
                                <?php echo e(Form::text('procedures', Request::old('procedures',$discharge->procedures), array('class' => 'form-control'))); ?>

                                </div>
                                </div>
                                </div>
                                
                              </div>
                               <div class="col-md-12">
                                <div class="col-md-2">
                                <div class="form-group labelgrp">
                                <?php echo e(Form::label('name_of_iol','Name Of IOL')); ?>

                                </div>
                                </div>

                                <div class="col-md-4">
                                <div class="form-group">
                                <div class="form-line">
                                <?php echo e(Form::text('name_of_iol', Request::old('name_of_iol',$discharge->name_of_iol), array('class' => 'form-control'))); ?>

                                </div>
                                </div>
                                </div>

                                 <div class="col-md-2">
                                <div class="form-group labelgrp">
                                <?php echo e(Form::label('post_operative','Post Operative')); ?>

                                </div>
                                </div>

                                <div class="col-md-4">
                                <div class="form-group">
                                <div class="form-line">
                                <?php echo e(Form::text('post_operative', Request::old('post_operative',$discharge->post_operative), array('class' => 'form-control'))); ?>

                                </div>
                                </div>
                                </div>
                                
                              </div>
                              <div class="col-md-12">
                                <div class="col-md-2">
                                <div class="form-group labelgrp">
                                <?php echo e(Form::label('advice','Advice')); ?>

                                </div>
                                </div>

                                <div class="col-md-8">
                                <div class="form-group">
                                <div class="form-line">
                                <?php echo e(Form::textarea('advice', Request::old('advice',$discharge->advice), array('class' => 'form-control advicetxtarea'))); ?>

                                </div>
                                </div>
                                </div>

                                 
                                
                              </div>

                               <div class="col-md-12">
                                <div class="col-md-2">
                                <div class="form-group labelgrp">
                                <?php echo e(Form::label('review','Review')); ?>

                                </div>
                                </div>

                                <div class="col-md-4">
                                <div class="form-group">
                                <div class="form-line">
                                <?php echo e(Form::text('review', Request::old('review',$discharge->review), array('class' => 'form-control'))); ?>

                                </div>
                                </div>
                                </div>
                                <div class="col-md-2">
                                <div class="form-group labelgrp">
                                <?php echo e(Form::label('surgeon_name','Surgeon Name')); ?>

                                </div>
                                </div>

                                <div class="col-md-4">
                                <div class="form-group">
                                <div class="form-line">
                                <?php echo e(Form::text('surgeon_name', Request::old('surgeon_name',$discharge->surgeon_name), array('class' => 'form-control'))); ?>

                                </div>
                                </div>
                                </div>

                                
                                
                              </div>
                              <!-- <div class="col-md-12">
                                 <?php echo e(Form::label('surgery','Surgery')); ?> 
                              </div>
                              <div class="col-md-12">
                                  <div class="input-group">
                                  <div class="form-line" style="display: flex;border: 1px solid #ddd;">
                                  <?php echo e(Form::text('surgery', Request::old('surgery',$discharge->surgery), array('class' => 'form-control','aria-describedby'=>"basic-addon"))); ?>

                                  </div> 
                                  <span class="input-group-addon myaddon" id="basic-addon"></span>
                                  </div>
                                </div>

                                <div class="col-md-12">
                                  <div class="input-group">
                                    <span class="input-group-addon myaddon" id="basic-addon"></span>
                                  <div class="form-line" style="display: flex;border: 1px solid #ddd;">
                                  <?php echo e(Form::text('cataract_thru', Request::old('cataract_thru',$discharge->cataract_thru), array('class' => 'form-control','aria-describedby'=>"basic-addon"))); ?>

                                  </div> 
                                  <span class="input-group-addon myaddon" id="basic-addon"></span>
                                  </div>
                                </div>

                                <div class="col-md-12">
                                  <div class="input-group">
                                    <span class="input-group-addon myaddon" id="basic-addon"></span>
                                  <div class="form-line" style="display: flex;border: 1px solid #ddd;">
                                  <?php echo e(Form::text('diminished_vision_in', Request::old('diminished_vision_in',$discharge->diminished_vision_in), array('class' => 'form-control','aria-describedby'=>"basic-addon"))); ?>

                                  </div> 
                                  <span class="input-group-addon myaddon" id="basic-addon"></span>
                                  </div>
                                </div> -->
                         
                           
                           <!--  <div class="col-md-12">
                              <div class="col-md-2">
                              </div>
                              <div class="col-md-5">
                                  Right Eye
                              </div>
                              <div class="col-md-5">
                                  Left Eye
                              </div>
                            </div>
                            <div class="col-md-12">
                              <div class="col-md-2">
                                  D.V
                              </div>
                              <div class="col-md-5">
                                  <?php echo e(Form::text('re_dv', Request::old('re_dv',$discharge->re_dv), array('class' => 'form-control'))); ?>

                              </div>
                              <div class="col-md-5">
                                  <?php echo e(Form::text('lf_dv', Request::old('lf_dv',$discharge->lf_dv), array('class' => 'form-control'))); ?>

                              </div>
                            </div>
                            <div class="col-md-12">
                              <div class="col-md-2">
                                  IOP
                              </div>
                              <div class="col-md-5">
                                  <?php echo e(Form::text('re_iop', Request::old('re_iop',$discharge->re_iop), array('class' => 'form-control'))); ?>

                              </div>
                              <div class="col-md-5">
                                  <?php echo e(Form::text('lf_iop', Request::old('lf_iop',$discharge->lf_iop), array('class' => 'form-control'))); ?>

                              </div>
                            </div>
                            <div class="col-md-12">
                              <div class="col-md-2">
                                  I/O
                              </div>
                              <div class="col-md-5">
                                  <?php echo e(Form::text('re_io', Request::old('re_io',$discharge->re_io), array('class' => 'form-control'))); ?>

                              </div>
                              <div class="col-md-5">
                                  <?php echo e(Form::text('lf_io', Request::old('lf_io',$discharge->lf_io), array('class' => 'form-control'))); ?>

                              </div>
                             </div>
                             <div class="col-md-12">
                                <div class="col-md-2">
                                    Investigations 
                                </div>
                                <div class="col-md-5">
                                    <label for="bsf" class="col-sm-2 col-form-label">BSF</label>
                                    <div class="col-sm-10">
                                        <input type="text" name="bsf" id="bsf" class="form-control"  value="<?php echo e(isset($discharge['bsf']) ? $discharge['bsf'] : ''); ?>">
                                    </div>
                                </div>
                                <div class="col-md-5">
                                    <label for="bspp" class="col-sm-2 col-form-label">BSPP</label>
                                    <div class="col-sm-10">
                                        <input type="text" name="bspp" id="bspp" class="form-control"  value="<?php echo e(isset($discharge['bspp']) ? $discharge['bspp'] : ''); ?>">
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12">
                              <div class="col-md-2"> 
                              </div>
                              <div class="col-md-5">
                                  <label for="hb" class="col-sm-2 col-form-label">HB</label>
                                  <div class="col-sm-10">
                                      <input type="text" name="hb" id="hb" class="form-control"  value="<?php echo e(isset($discharge['hb']) ? $discharge['hb'] : ''); ?>">
                                  </div>
                              </div>
                              <div class="col-md-5">
                                  <label for="cbc" class="col-sm-2 col-form-label">CBC</label>
                                  <div class="col-sm-10">
                                      <input type="text" name="cbc" id="cbc" class="form-control"  value="<?php echo e(isset($discharge['cbc']) ? $discharge['cbc'] : ''); ?>">
                                  </div>
                              </div>
                          </div>
                          <div class="col-md-12">
                              <div class="col-md-2"> 
                              </div>
                              <div class="col-md-5">
                                  <label for="esr" class="col-sm-2 col-form-label">ESR</label>
                                  <div class="col-sm-10">
                                      <input type="text" name="esr" id="esr" class="form-control"  value="<?php echo e(isset($discharge['esr']) ? $discharge['esr'] : ''); ?>">
                                  </div>
                              </div>
                              <div class="col-md-5">
                                  <label for="hiv" class="col-sm-2 col-form-label">HIV</label>
                                  <div class="col-sm-10">
                                      <input type="text" name="hiv" id="hiv" class="form-control"  value="<?php echo e(isset($discharge['hiv']) ? $discharge['hiv'] : ''); ?>">
                                  </div>
                              </div>
                          </div>
                          <div class="col-md-12">
                              <div class="col-md-2"> 
                              </div>
                              <div class="col-md-5">
                                  <label for="hbsag" class="col-sm-2 col-form-label">HBsAg</label>
                                  <div class="col-sm-10">
                                      <input type="text" name="hbsag" id="hbsag" class="form-control"  value="<?php echo e(isset($discharge['hbsag']) ? $discharge['hbsag'] : ''); ?>">
                                  </div>
                              </div>
                              <div class="col-md-5">
                                  <label for="urinal_analysis" class="col-sm-2 col-form-label">Urine Analysis </label>
                                  <div class="col-sm-10">
                                      <input type="text" name="urinal_analysis" id="urinal_analysis" class="form-control"  value="<?php echo e(isset($discharge['urinal_analysis']) ? $discharge['urinal_analysis'] : ''); ?>">
                                  </div>
                              </div>
                          </div>
                          <div class="col-md-12">
                              <div class="col-md-2"> 
                              </div>
                              <div class="col-md-5">
                                  <label for="ecg" class="col-sm-2 col-form-label">ECG</label>
                                  <div class="col-sm-10">
                                      <input type="text" name="ecg" id="ecg" class="form-control"  value="<?php echo e(isset($discharge['ecg']) ? $discharge['ecg'] : ''); ?>">
                                  </div>
                              </div>
                              <div class="col-md-5">
                                  <label for="medical_fitness" class="col-sm-2 col-form-label">Medical Fitness</label>
                                  <div class="col-sm-10">
                                      <input type="text" name="medical_fitness" id="medical_fitness" class="form-control"  value="<?php echo e(isset($discharge['medical_fitness']) ? $discharge['medical_fitness'] : ''); ?>">
                                  </div>
                              </div>
                          </div> -->
                          <div class="col-md-12">
                          <div class="col-md-2">
                          <div class="form-group">
                           <?php echo e(Form::label('treatment_advised','Treatment Advised')); ?> 
                          </div> 
                          </div> 
                          <div class="col-md-10">
                         
                            <?php echo e(Form::textarea('treatment_advised', Request::old('treatment_advised',$discharge->treatment_advised), array('class' => 'form-control'))); ?>

                     
                          </div>
                        </div>
                        <div class="col-md-12">
                          <div class="col-md-2">
                          <div class="form-group">
                            <?php echo e(Form::label('followup','Followup')); ?>  
                          </div> 
                          </div> 
                          <div class="col-md-4">
                          <div class="form-group">
                          <div class="form-line">
                          <?php echo e(Form::text('followup', Request::old('followup',$discharge->followup), array('class' => 'form-control datepicker', 'autocomplete'=>'off'))); ?>

                          </div> 
                          </div> 
                          </div>
                          <div class="col-md-2">
                          <div class="form-group">
                            <?php echo e(Form::label('followup','Image Upload')); ?>  
                          </div> 
                          </div> 
                          <div class="col-md-4">
                          <div class="form-group">
                          <div class="form-line">
                         <?php echo e(Form::file('dischargeimg', Request::old('dischargeimg'), array('class'=> 'form-control', "accept"=> "image/png, image/gif, image/jpeg" ))); ?>

                          </div> 
                          </div> 
                          </div>
                        </div>
                        
                         <div class="col-md-12">
                            <label class="form-label">
                                    In case of Emergency : 1. Severe Redness/watering pain or 2. Sudden diminished vision
                                    Pls. contact : 8055821212 ( Dr. Sandeep C. Joshi)                           
                            </label>
                        </div>
                            
                          
                             <div class="col-md-12">
                              <div class="col-md-9 col-md-offset-3">
                              <button type="submit" name="submit" class="btn btn-success btn-lg" value="submit"><i class="fa fa-plus"></i> Submit
                              </button>&nbsp;
                              <a class="btn btn-default btn-lg" href="<?php echo e(url('/discharge')); ?>"><i class="glyphicon glyphicon-chevron-left"></i> Back</a>&nbsp;
                              <a class="btn btn-default btn-lg" href="<?php echo e(url('/discharge/print/1').'/'. $case_master->id); ?>" target="_blank"><i class="glyphicon glyphicon-print"></i> Print </a>&nbsp;
                              <a class="btn btn-default btn-lg" href="<?php echo e(url('/PatientMedicalDetails').'/'.$case_master->id); ?>"><i class="glyphicon glyphicon-chevron-left"></i> Patient Details</a>
                              </div>
                              </div> 
                              </div>
                               </form> 
                                <?php echo $__env->make('shared.add_prescription', ['id'=>$case_master->id], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                            </div>                             
                                              
                        </div>
                        
             
                    </div>
                </div>
            </div>




 <?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(url('/')); ?>/select2/js/select2.min.js"></script>
<script type="text/javascript">
    $(document).ready(function(){
        $('.select2').select2();
      $('.datepicker').datepicker({
            format: "dd/M/yyyy",
            weekStart: 1,
            clearBtn: true,
            daysOfWeekHighlighted: "0,6",
            autoclose: true,
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlayouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>