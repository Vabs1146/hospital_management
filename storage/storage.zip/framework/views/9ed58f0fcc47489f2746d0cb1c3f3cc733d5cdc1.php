<?php $__env->startSection('content'); ?>

<div class="container-fluid">
<div class="row clearfix">
       <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                  <?php echo $__env->make('shared.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                  <?php if(Session::has('flash_message')): ?>
                  <div class="alert alert-success">
                  <?php echo e(Session::get('flash_message')); ?>

                  </div>
                  <?php endif; ?>
          <div class="card">
          <form action="<?php echo e(url('/stop_appointments')); ?>" method="POST" class="form-horizontal">
            <?php echo e(csrf_field()); ?>


            
          <div class="header bg-pink">
          <h2>View Stop_appointment </h2>
          </div>
  
              <div class="body">
                  <div class="row clearfix ">
                              <div class="col-md-12">
                              <div class="col-md-2">
                              <div class="form-group labelgrp">
                              <label class="form-control">Id :</label>
                              </div>
                              </div>

                             <div class="col-md-4">
                              <div class="form-group">
                              <div class="form-line">
                              <input type="text" name="id" id="id" class="form-control" value="<?php echo e(isset($model['id']) ? $model['id'] : ''); ?>" readonly="readonly">                        
                              </div>
                              </div>
                              </div>    


                              <div class="col-md-2">
                              <div class="form-group labelgrp">
                              <label class="form-control">Date :</label>
                              </div>
                              </div>


                              <div class="col-md-4">
                              <div class="form-group">
                              <div class="form-line">
                              <input type="text" name="date" id="date" class="form-control" value="<?php echo e(isset($model['date']) ? $model['date'] : ''); ?>" readonly="readonly">                       
                              </div>
                              </div>
                              </div>   
                          </div>

                          <div class="col-md-12">
                              <div class="col-md-2">
                              <div class="form-group labelgrp">
                              <label class="form-control">DoctorId :</label>
                              </div>
                              </div>


                              <div class="col-md-4">
                              <div class="form-group">
                              <div class="form-line">
                              <input type="text" name="DoctorId" id="DoctorId" class="form-control" value="<?php echo e(isset($model['DoctorId']) ? $model['DoctorId'] : ''); ?>" readonly="readonly">                            
                              </div>
                              </div>
                              </div>

                              <div class="col-md-2">
                              <div class="form-group labelgrp">
                              <label class="form-control">TimeSlotId :</label>
                              </div>
                              </div>

                              <div class="col-md-4">
                              <div class="form-group">
                              <div class="form-line">
                              <input type="text" name="TimeSlotId" id="TimeSlotId" class="form-control" value="<?php echo e(isset($model['TimeSlotId']) ? $model['TimeSlotId'] : ''); ?>" readonly="readonly">                            
                              </div>
                              </div>
                              </div>

                          </div>


                          <div class="col-md-12">
                              <div class="col-md-2">
                              <div class="form-group labelgrp">
                              <label class="form-control">Description :</label>
                              </div>
                              </div>


                              <div class="col-md-4">
                              <div class="form-group">
                              <div class="form-line">
                              <input type="text" name="description" id="description" class="form-control" value="<?php echo e(isset($model['description']) ? $model['description'] : ''); ?>" readonly="readonly">                           
                              </div>
                              </div>
                              </div>

                              <div class="col-md-2">
                              <div class="form-group labelgrp">
                              <label class="form-control">Created At :</label>
                              </div>
                              </div>

                              <div class="col-md-4">
                              <div class="form-group">
                              <div class="form-line">
                              <input type="text" name="created_dt" id="created_dt" class="form-control" value="<?php echo e(isset($model['created_dt']) ? $model['created_dt'] : ''); ?>" readonly="readonly">                          
                              </div>
                              </div>
                              </div>

                          </div>
                           
                           <div class="col-md-12">
                            <div class="col-md-2">
                              <div class="form-group labelgrp">
                              <label class="form-control">Updated Dt :</label>
                              </div>
                              </div>

                              <div class="col-md-4">
                              <div class="form-group">
                              <div class="form-line">
                              <input type="text" name="updated_dt" id="updated_dt" class="form-control" value="<?php echo e(isset($model['updated_dt']) ? $model['updated_dt'] : ''); ?>" readonly="readonly">                          
                              </div>
                              </div>
                              </div>

                          </div>

                             
                              
                                    
                  </div>    

                  <div class="row clearfix">
                                <div class="col-md-4 col-md-offset-2">
                                <div class="form-group">
                                 <a class="btn btn-default btn-lg" href="<?php echo e(url('/stop_appointments')); ?>"><i class="glyphicon glyphicon-chevron-left"></i> Back</a>
                                      
                                </div>
                                </div>
                               
                            </div>
                </div>
          <?php echo e(Form::close()); ?>

            </div>
        </div>
</div>
</div>


        <?php $__env->stopSection(); ?>
  
<?php echo $__env->make('adminlayouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>