<div id="Glaucoma" class="ContainerToAppend dropdown-container">
	<div class="col-md-12">
		<div class="col-md-1">
			<div class="form-group labelgrp">
			<label> IOP  </label>
			</div>      
		</div>
		<div class="col-md-4">
		<?php echo e(Form::select('IOP_OD', array(' '=>'-Select-') + $form_dropdowns->where('fieldName', 'IOP_OD')->pluck('ddText','ddText')->toArray(), array_key_exists('IOP_OD', $defaultValues)?$defaultValues['IOP_OD']:null, array('class'=> 'form-control select2 iop-field','data-live-search'=>'true', 'id' => 'iop_od_field'))); ?>

		<input readonly class="form-control" type="text" name="iop_od_time" id="iop_od_time" value="<?php echo e(isset($defaultValues['iop_od_time']) ? $defaultValues['iop_od_time'] : ''); ?>"> 
		</div>
		

		<div class="col-md-4">
		<?php echo e(Form::select('IOP_OS', array(' '=>'-Select-') + $form_dropdowns->where('fieldName', 'IOP_OS')->pluck('ddText','ddText')->toArray(), array_key_exists('IOP_OS', $defaultValues)?$defaultValues['IOP_OS']:null, array('class'=> 'form-control select2  iop-field','data-live-search'=>'true', 'id' => 'iop_os_field'))); ?>

		<input readonly class="form-control" type="text" name="iop_os_time" id="iop_os_time" value="<?php echo e(isset($defaultValues['iop_os_time']) ? $defaultValues['iop_os_time'] : ''); ?>">
		
			
		</div>

		<div class="col-md-3">
		<button type="button" name="add" id='IOPbtn' class="btn btn-success  set-dropdown-options"  data-field_name="IOP_OD" data-form_name="EyeForm" >Set Option </button>
		<button type='button' class="btn btn-primary" id='IOPbtnsave'>Save Option</button>
		</div>
	</div>
	<div id='IOPTextBoxesGroup' class="col-md-12">

	</div>

	<!-- ================================================================================= -->

	<!-- set-dropdown-options -->
	<!-- <span class="dropdown-container"> -->
	<div class='dropdown-options-initial-div' class="col-md-12" style="display:none;">
	<?php  
	$dropdown_options_field_name = 'IOP_OS';
	$dropdown_options_form_name = 'EyeForm';
	 ?>
	
	</div>

	<!-- ================================================================================= -->

</div>

<div class="col-md-12">
	<div class="table-responsive">
		<table class="table table-bordered">
			<thead>
			<tr>
			<th>&nbsp;</th>
			<th colspan="3" class="text-center">Right</th>
			<th colspan="3" class="text-center">Left</th>
			</tr>
			<tr>
			<th>&nbsp;</th>
			<th>SPH</th>
			<th>CYL</th>
			<th>Axis</th>
			<th>SPH</th>
			<th>CYL</th>
			<th>Axis</th>
			</tr>
			</thead>
			<tbody>
			<tr>
			<td>AR Undilated</td>
			<td>
			<?php echo e(Form::text('sph_r_undi', Request::old('sph_r_undi', $form_details->sph_r_undi), array('class'=> 'form-control', 'autocomplete'=>'off'))); ?>

			</td>
			<td>
			<?php echo e(Form::text('cyl_r_undi', Request::old('cyl_r_undi', $form_details->cyl_r_undi), array('class'=> 'form-control', 'autocomplete'=>'off'))); ?>

			</td>
			<td>
			<?php echo e(Form::text('Axis_r_undi', Request::old('Axis_r_undi', $form_details->Axis_r_undi), array('class'=> 'form-control', 'autocomplete'=>'off'))); ?>

			</td>
			<td>
			<?php echo e(Form::text('sph_l_undi', Request::old('sph_l_undi', $form_details->sph_l_undi), array('class'
			=> 'form-control', 'autocomplete'=>'off'))); ?>

			</td>
			<td>
			<?php echo e(Form::text('cyl_l_undi', Request::old('cyl_l_undi', $form_details->cyl_l_undi), array('class'=> 'form-control', 'autocomplete'=>'off'))); ?>

			</td>
			<td>
			<?php echo e(Form::text('Axis_l_undi', Request::old('Axis_l_undi', $form_details->Axis_l_undi), array('class'=> 'form-control', 'autocomplete'=>'off'))); ?>

			</td>
			</tr>
			<tr>
			<td>Subjective Undilated</td>
			<td>
			<?php echo e(Form::text('sph_r_undi_sub', Request::old('sph_r_undi_sub', $form_details->sph_r_undi_sub), array('class'=> 'form-control', 'autocomplete'=>'off'))); ?>

			</td>
			<td>
			<?php echo e(Form::text('cyl_r_undi_sub', Request::old('cyl_r_undi_sub', $form_details->cyl_r_undi_sub), array('class'=> 'form-control', 'autocomplete'=>'off'))); ?>

			</td>
			<td>
			<?php echo e(Form::text('Axis_r_undi_sub', Request::old('Axis_r_undi_sub', $form_details->Axis_r_undi_sub), array('class'=> 'form-control', 'autocomplete'=>'off'))); ?>

			</td>
			<td>
			<?php echo e(Form::text('sph_l_undi_sub', Request::old('sph_l_undi_sub', $form_details->sph_l_undi_sub), array('class'
			=> 'form-control', 'autocomplete'=>'off'))); ?>

			</td>
			<td>
			<?php echo e(Form::text('cyl_l_undi_sub', Request::old('cyl_l_undi_sub', $form_details->cyl_l_undi_sub), array('class'=> 'form-control', 'autocomplete'=>'off'))); ?>

			</td>
			<td>
			<?php echo e(Form::text('Axis_l_undi_sub', Request::old('Axis_l_undi_sub', $form_details->Axis_l_undi_sub), array('class'=> 'form-control', 'autocomplete'=>'off'))); ?>

			</td>
			</tr>
			<tr>
			<td>AR Dilated</td>
			<td>
			<?php echo e(Form::text('sph_r_di', Request::old('sph_r_di', $form_details->sph_r_di), array('class'=> 'form-control', 'autocomplete'=>'off'))); ?>

			</td>
			<td>
			<?php echo e(Form::text('cyl_r_di', Request::old('cyl_r_di', $form_details->cyl_r_di), array('class'=> 'form-control', 'autocomplete'=>'off'))); ?>

			</td>
			<td>
			<?php echo e(Form::text('Axis_r_di', Request::old('Axis_r_di', $form_details->Axis_r_di), array('class'=> 'form-control', 'autocomplete'=>'off'))); ?>

			</td>
			<td>
			<?php echo e(Form::text('sph_l_di', Request::old('sph_l_di', $form_details->sph_l_di), array('class'=> 'form-control', 'autocomplete'=>'off'))); ?>

			</td>
			<td>
			<?php echo e(Form::text('cyl_l_di', Request::old('cyl_l_di', $form_details->cyl_l_di), array('class'=> 'form-control', 'autocomplete'=>'off'))); ?>

			</td>
			<td>
			<?php echo e(Form::text('Axis_l_di', Request::old('Axis_l_di', $form_details->Axis_l_di), array('class'=> 'form-control', 'autocomplete'=>'off'))); ?>

			</td>
			</tr>
			<tr>
			<td>Subjective Dilated</td>
			<td>
			<?php echo e(Form::text('sph_r_di_sub', Request::old('sph_r_di_sub', $form_details->sph_r_di_sub), array('class'=> 'form-control', 'autocomplete'=>'off'))); ?>

			</td>
			<td>
			<?php echo e(Form::text('cyl_r_di_sub', Request::old('cyl_r_di_sub', $form_details->cyl_r_di_sub), array('class'=> 'form-control', 'autocomplete'=>'off'))); ?>

			</td>
			<td>
			<?php echo e(Form::text('Axis_r_di_sub', Request::old('Axis_r_di_sub', $form_details->Axis_r_di_sub), array('class'=> 'form-control', 'autocomplete'=>'off'))); ?>

			</td>
			<td>
			<?php echo e(Form::text('sph_l_di_sub', Request::old('sph_l_di_sub', $form_details->sph_l_di_sub), array('class'=> 'form-control', 'autocomplete'=>'off'))); ?>

			</td>
			<td>
			<?php echo e(Form::text('cyl_l_di_sub', Request::old('cyl_l_di_sub', $form_details->cyl_l_di_sub), array('class'=> 'form-control', 'autocomplete'=>'off'))); ?>

			</td>
			<td>
			<?php echo e(Form::text('Axis_l_di_sub', Request::old('Axis_l_di_sub', $form_details->Axis_l_di_sub), array('class'=> 'form-control', 'autocomplete'=>'off'))); ?>

			</td>
			</tr>
			</tbody>
		</table>
	</div>
</div>

<!--==============================================================-->
<div class="col-md-12">
<div class="table-responsive">
<h1>Refraction</h1>
<table class="table table-bordered">
<thead>
<tr>
<th>&nbsp;</th>
<th colspan="4" class="text-center">Right</th>
<th colspan="4" class="text-center">Left</th>
</tr>
<tr>
<th>&nbsp;</th>
<th>SPH</th>
<th>CYL</th>
<th>Axis</th>
<th>Vision</th>
<th>SPH</th>
<th>CYL</th>
<th>Axis</th>
<th>Vision</th>
</tr>
</thead>
<tbody>
<tr>
<td>D.V.</td>
<td>

<?php echo e(Form::text('r_dv_sph', Request::old('r_dv_sph', $glass_prescription->r_dv_sph??''), array('class'=> 'form-control', 'autocomplete'=>'off'))); ?>

</td>
<td>
<?php echo e(Form::text('r_dv_cyl', Request::old('r_dv_cyl', $glass_prescription->r_dv_cyl??''), array('class'=> 'form-control', 'autocomplete'=>'off'))); ?>

</td>
<td>
<?php echo e(Form::text('r_dv_axi', Request::old('r_dv_axi', $glass_prescription->r_dv_axi??''), array('class'=> 'form-control', 'autocomplete'=>'off'))); ?>

</td>
<td>
<?php echo e(Form::text('r_dv_vision', Request::old('r_dv_vision', $glass_prescription->r_dv_vision??''), array('class'=> 'form-control', 'autocomplete'=>'off'))); ?>

</td>

<td>
<?php echo e(Form::text('l_dv_sph', Request::old('l_dv_sph', $glass_prescription->l_dv_sph??''), array('class' => 'form-control', 'autocomplete'=>'off'))); ?>

</td>
<td>
<?php echo e(Form::text('l_dv_cyl', Request::old('l_dv_cyl', $glass_prescription->l_dv_cyl??''), array('class'=> 'form-control', 'autocomplete'=>'off'))); ?>

</td>
<td>
<?php echo e(Form::text('l_dv_axi', Request::old('l_dv_axi', $glass_prescription->l_dv_axi??''), array('class'=> 'form-control', 'autocomplete'=>'off'))); ?>

</td>
<td>
<?php echo e(Form::text('l_dv_vision', Request::old('l_dv_vision', $glass_prescription->l_dv_vision??''), array('class'=> 'form-control', 'autocomplete'=>'off'))); ?>

</td>
</tr>

<tr>
<td>N.V.</td>
<td>
<?php echo e(Form::text('r_nv_sph', Request::old('r_nv_sph', $glass_prescription->r_nv_sph??''), array('class'=> 'form-control', 'autocomplete'=>'off'))); ?>

</td>
<td>
<?php echo e(Form::text('r_nv_cyl', Request::old('r_nv_cyl', $glass_prescription->r_nv_cyl??''), array('class'=> 'form-control', 'autocomplete'=>'off'))); ?>

</td>
<td>
<?php echo e(Form::text('r_nv_axi', Request::old('r_nv_axi', $glass_prescription->r_nv_axi??''), array('class'=> 'form-control', 'autocomplete'=>'off'))); ?>

</td>
<td>
<?php echo e(Form::text('r_nv_vision', Request::old('r_nv_vision', $glass_prescription->r_nv_vision??''), array('class'=> 'form-control', 'autocomplete'=>'off'))); ?>

</td>

<td>
<?php echo e(Form::text('l_nv_sph', Request::old('l_nv_sph', $glass_prescription->l_nv_sph??''), array('class'
=> 'form-control', 'autocomplete'=>'off'))); ?>

</td>
<td>
<?php echo e(Form::text('l_nv_cyl', Request::old('l_nv_cyl', $glass_prescription->l_nv_cyl??''), array('class'=> 'form-control', 'autocomplete'=>'off'))); ?>

</td>
<td>
<?php echo e(Form::text('l_nv_axi', Request::old('l_nv_axi', $glass_prescription->l_nv_axi??''), array('class'=> 'form-control', 'autocomplete'=>'off'))); ?>

</td>
<td>
<?php echo e(Form::text('l_nv_vision', Request::old('l_nv_vision', $glass_prescription->l_nv_vision??''), array('class'=> 'form-control', 'autocomplete'=>'off'))); ?>

</td>
</tr>
</tbody>
</table>
</div>
</div>
<!--==================================================================-->
<div class="col-md-12">
<h1>Retinoscopy</h1>
<div class="col-md-2">

</div>
<div class="col-md-5">
<div class="col-md-6">
<div class="example1" data-example="retino_scopy_OD">
<div class="board" id="retino_scopy_OD_canvas"  style="min-height:150px"></div>
</div>
<input type="hidden" name="retino_scopy_OD" id="retino_scopy_OD">
</div>
<div class="col-md-6" style="min-height:100px">
<?php if(!empty($form_details->retino_scopy_OD) && !is_null($form_details->retino_scopy_OD)): ?>   
<button type="button" value="retino_scopy_OD" class="ImageDelete pull-right" >Delete</button>
<p>&nbsp;</p>
<center id="wPaint-retino_scopy_OD"> 
<img src=<?php echo e(Storage::disk('local')->url($form_details->retino_scopy_OD)."?".filemtime(Storage::path($form_details->retino_scopy_OD))); ?> class="img-rounded" alt="Image Not found" width="100%" height="100%" />
</center>
<?php endif; ?>
</div>
</div>
<div class="col-md-5">
<div class="col-md-6">
<div class="example1" data-example1="retino_scopy_OS">
<div class="board" id="retino_scopy_OS_canvas" style="min-height:150px"></div>
</div>
<input type="hidden" name="retino_scopy_OS" id="retino_scopy_OS">
</div>
<div class="col-md-6">
<?php if(!empty($form_details->retino_scopy_OS) && !is_null($form_details->retino_scopy_OS)): ?>
<button type="button" value="retino_scopy_OS" class="ImageDelete pull-right" >Delete</button>
<p>&nbsp;</p>
<center id="wPaint-retino_scopy_OS"> 
<img src=<?php echo e(Storage::disk('local')->url($form_details->retino_scopy_OS)."?".filemtime(Storage::path($form_details->retino_scopy_OS))); ?> class="img-rounded" alt="Image Not found" width="100%" height="100%" />  
</center>
<?php endif; ?>
</div>
</div>
</div> 
<div class="col-md-12">
<div class="col-md-6 col-md-offset-4">
<div class="form-group">
<button type="submit" formaction="<?php echo e(url('/patientDetails/SaveEyeExamination')); ?>" type="submit" name="submit" class="btn btn-primary btn-lg" value="submit">Submit</button>
<button type="submit" formaction="<?php echo e(url('/patientDetails/SaveEyeExamination1')); ?>" name="submit" class="btn btn-primary btn-lg" value="submit">Submit & View
</button>                                        </div>
</div>
</div>       

<script>
$(document).ready(function() {
	$('.iop-field').on('select2:select', function (e) {
		var time = new Date();
		var time_selected = time.toLocaleString('en-US', { hour: 'numeric', minute: 'numeric', hour12: true });
		//alert(time_selected);

		$(this).closest('.col-md-4').find('input').val(time_selected);
	});
});
</script>