<link href="<?php echo e(url('/')); ?>/select2/css/select2.min.css" rel="stylesheet">

<div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <?php echo e(Form::model($casedata, array('url' => url('/AddEdit/prescription/'.$casedata['id']), 'method' => 'POST', 'class' => 'form-horizontal', 'enctype' => 'multipart/form-data' ))); ?>

                        <?php echo e(csrf_field()); ?>

                         <?php echo e(Form::hidden('id', Request::old('id'), array('class'=> 'form-control'))); ?>

                        <?php echo e(Form::hidden('case_number', Request::old('case_number'), array('class'=> 'form-control'))); ?>

                         <div class="header bg-pink">
                            <h2>
                               Add/Modify Prescription
                            </h2>
                        </div>
                        <div class="body">
                        <div class="row clearfix">
                             <div class="col-md-12">
                              <div class="col-md-2">
                              <div class="form-group labelgrp">
                              <?php echo e(Form::label('medicine_id', 'Medicine')); ?>

                              </div>
                              </div>

                              <div class="col-md-4">
                             
                              <?php echo e(Form::select('medicine_id', array(''=>'Please select') + $casedata['medicinlist']->pluck('medicine_name','id')->toArray(), Request::old('medicine_id'), array('class' => 'form-control select2','data-live-search'=>'true'))); ?>                            
                              
                              </div>  

                               <div class="col-md-2">
                              <div class="form-group labelgrp">
                              <?php echo e(Form::label('strength', 'Eye')); ?>

                              </div>
                              </div>


                              <div class="col-md-4">
                              
                              <?php echo e(Form::select('strength', array(''=>'Please select') + $casedata['medicine_strength']->toArray(), Request::old('strength'), array('class' => 'form-control select2','data-live-search'=>'true'))); ?>                             
                              
                              </div>
                              </div>

                              <div class="col-md-12">

							  <div class="col-md-2">
                              <div class="form-group labelgrp">
                              <?php echo e(Form::label('numberoftimes', 'Frequency')); ?>

                              </div>
                              </div>

                              <div class="col-md-4">
                              <?php echo e(Form::select('numberoftimes', array(''=>'Please select') + $casedata['numberOfTimes_drpdwn']->toArray(), Request::old('numberoftimes'), array('class' => 'form-control select2','data-live-search'=>'true'))); ?>

                              </div> 

                             <div class="col-md-2">
                              <div class="form-group labelgrp">
                              <?php echo e(Form::label('medicine_quantity', 'Duration')); ?>

                              </div>
                              </div>


                              <div class="col-md-4">
                             
                              <?php echo e(Form::select('medicine_quantity', array(''=>'Please select') + $casedata['quantity']->toArray(), Request::old('medicine_quantity'), array('class' => 'form-control select2','data-live-search'=>'true'))); ?>                             
                             
                              </div>

                                

                              </div>

                                <div class="row clearfix">
                                <div class="col-md-6 col-md-offset-2">
                                <?php echo e(Form::submit('Add Prescription', array('class' => 'btn btn-primary btn-lg', 'value' => 'prescription_save', 'name' => 'prescription_save'))); ?>     
                                </div>
                                <br>
                                <div class="col-md-12">
                                <div class="table-responsive ">
                                <?php if(null !== old('prescriptions',$casedata['prescriptions']) && count(old('prescriptions',$casedata['prescriptions']))> 0 ): ?>
                                <table class="table">
                                    <tr>
                                        <th>
                                            Medicine
                                        </th>
                                        
                                        <th>
                                           Frequency
                                          
                                        </th>
                                        <th>
                                            Duration
                                        </th>
                                        <th>
                                             Eye   
                                        </th>
                                        
                                        <th>
                                            <!-- Used for delete button -->    
                                        </th>
                                    </tr>
                                        <?php $__currentLoopData = old('prescriptions',$casedata['prescriptions']); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prescption): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>   
                                                <td>
                                                    <?php echo e($prescption->Medical_store->medicine_name); ?>

                                                </td>
                                                
                                                <td>
                                                  <?php echo e($prescption->numberoftimes); ?>

                                                    
                                                </td>
                                                <td>
                                                    <?php echo e($prescption->medicine_Quntity); ?>

                                                </td>
                                                <td>
                                                   <?php echo e($prescption->strength); ?> 
                                                </td>
                                                
                                                <td>
                                                    <?php echo e(Form::button('Delete Prescription', array('class' => 'btn btn-primary', 'Value' => $prescption->id, 'name' => 'prescription_delete', 'type'=>'submit'))); ?>

                                                    
                                                </td>
                                            <tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </table>
                                </div>
                                </div>
                            </div>
                        </div>
                        </div>
                        </div>

                            
                        </div>
                        <?php echo e(Form::close()); ?>

                    </div>
               
<?php $__env->startSection('scripts'); ?>
 <script src="<?php echo e(url('/')); ?>/select2/js/select2.min.js"></script>
<script type="text/javascript">
    $('.select2').select2();
    </script>
<?php $__env->stopSection(); ?>

