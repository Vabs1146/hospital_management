
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
    <div class="col-md-12 ">
        <div class="panel panel-default">
            <div class="panel-heading">Dashboard</div>

            <div class="panel-body" style="text-align:center">
			
                 <?php if(isset(Auth::user()->email)): ?>
                Welcome <?php echo e(Auth::user()->name); ?> You are logged in!
                  <?php else: ?>
                   Welcome Admin.  You are logged in!
                     <?php endif; ?>
              

			   <div class="row">
					<div class="col-md-12">
						<h1><?php echo e($all_settings['hospital_name']->value); ?></h1>
					</div>
			   </div>
			   <?php if($all_settings['hospital_logo']->value != ""): ?>
			   <div class="row">
					<div class="col-md-12">
						<img src="<?php echo e(url('/')); ?>/uploads/images/<?php echo e($all_settings['hospital_logo']->value); ?>">
					</div>
			   </div>
			   <?php endif; ?>
            </div>
        </div>
    </div>
</div>
            <!-- #END# Widgets -->
            <!-- CPU Usage -->
            
            <!-- #END# CPU Usage -->
           

            
        </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlayouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>