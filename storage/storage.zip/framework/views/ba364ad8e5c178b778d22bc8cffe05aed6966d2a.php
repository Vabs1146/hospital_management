<?php $__env->startSection('style'); ?>
<?php $CheckField = app('App\Http\Controllers\EyeFormController'); ?>
<style>
    @media  screen and (max-width: 767px) {
        .select2 {
            width: 100% !important;
        }
    }
    .ui-autocomplete-loading {
        background: white url("<?php echo e(asset('images/ui-anim_basic_16x16.gif')); ?>") right center no-repeat;
    }
	
.details-section {
    color: initial;
    text-align: center;
    margin-bottom: 7px;
    padding-top: 4px;
    padding-bottom: 1px;
    margin-top: -2px;
}

.hide_print {
	position: relative !important;
    left: auto !important;
    opacity: 1 !important;
   /* margin-left: 47px !important; */
    margin-right: 8px !important;
}
</style>
<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/css/select2.min.css" rel="stylesheet" />
<!-- Styles -->
<link rel="stylesheet" href="<?php echo e(asset('JqueryUI/jquery-ui.css')); ?>">
 
 
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="list-group list-group-horizontal">
        <?php $__currentLoopData = $casedata['DateWiseRecordLst']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $VisitListDateWise): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($casedata['id'] == $VisitListDateWise['id']): ?>
                <a href="<?php echo e(url('/ViewMedicalDetails').'/'.$VisitListDateWise['id']); ?>" class="list-group-item active"><?php echo e(Carbon\Carbon::parse($VisitListDateWise['created_at'])->format('d-M-Y')); ?></a> <span> &nbsp;</span>    
            <?php else: ?>
                <a href="<?php echo e(url('/ViewMedicalDetails').'/'.$VisitListDateWise['id']); ?>" class="list-group-item"><?php echo e(Carbon\Carbon::parse($VisitListDateWise['created_at'])->format('d-M-Y')); ?></a> <span> &nbsp;</span>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<div class="container-fluid">
<div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <?php echo $__env->make('shared.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                          <?php if(Session::has('flash_message')): ?>
                          <div class="alert alert-success">
                          <?php echo e(Session::get('flash_message')); ?>

                          </div>
                          <?php endif; ?>
                    <div class="card">
                        <form action="<?php echo e(url('/AddEditEyeDetails/').'/'.$casedata['id']); ?>" method="GET" class="form-horizontal">
                          <?php echo e(csrf_field()); ?>

                         <div class="header bg-pink">
                            <h2> 
                                Patient History  View
                            </h2>
                          
                        </div>
                        <div class="body">
                            <div class="row clearfix">
                             <div class="col-xs-12 ol-sm-12 col-md-12 col-lg-12">
                                    <div class="panel-group" id="accordion_9" role="tablist" aria-multiselectable="true">
                                        <div class="panel panel-col-pink">
                                            <div class="panel-heading" role="tab" id="headingOne_9">
                                                <h4 class="panel-title">
                                                    <a role="button" data-toggle="collapse" data-parent="#accordion_9" href="#collapseOne_9" aria-expanded="true" aria-controls="collapseOne_9">
                                                        Patient History | Case Number : <?php echo e($casedata['case_number']); ?>  | <?php echo e('Time :' . $casedata['visit_time']); ?>

                                                    </a>
                                                </h4>
                                            </div>
											<?php if(!empty($casedata['infection']) || !empty($casedata['miscellaneous_history'])) {?>
                         <div class="header bg-yellow">
                            <div class="col-md-12" style="margin-top: -10px;"><h2>
							<marquee>
                                <div class="col-md-2">Infection</div><div class="col-md-3 details-section"><?php echo e($casedata['infection']); ?></div> 
                                <div class="col-md-3">Miscellaneous History</div><div class="col-md-4 details-section"><?php echo e($casedata['miscellaneous_history']); ?></div></h2>
								</marquee>
                            </div>
                        </div>
                        <?php } ?>
                          <div id="collapseOne_9" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingOne_9">
                          <?php echo e(Form::hidden('case_id', Request::old('case_id',$casedata['id']), array('class'=> 'form-control'))); ?>

            <div class="panel-body">
            <div class="row clearfix">
            <div class="col-md-12">
              <div class="form-group">
              <?php echo e(Form::hidden('case_number', Request::old('case_number', $casedata['case_number']), array('class'=> 'form-control', 'readonly'=>'readonly'))); ?>

              </div>
            </div>

			<?php if(!$CheckField::IsFieldEmpty($form_details->CNS)): ?>   
            <div class="col-md-12">
                <label class="control-label"><input type="checkbox" class="hide_print" name="hide_print[]" value="CNS" <?php echo e(in_array('CNS', $print_eyeformFields) ? 'checked' : ''); ?>>General Complaints :</label>   <?php echo nl2br($form_details->CNS); ?> 
              </div>
			  <?php endif; ?>
            </div>

              <div class="col-md-12">
                  <div class="table-responsive">
                    <table class="table  table-bordered">
                        <thead>
                            <tr>
                                <td >
                                     
                                </td>
                                <td >
                                    <strong>OD</strong>
                                </td>
                                <td >
                                    <strong>OS</strong>
                                </td>
                            </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $form_details->eyeformmultipleentry()->where('field_name', 'ChiefComplaint')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <?php if($loop->iteration == 1): ?>
                                    <input type="checkbox" class="hide_print" name="hide_print[]" value="ChiefComplaint" <?php echo e(in_array('ChiefComplaint', $print_eyeformFields) ? 'checked' : ''); ?>>Chief Complaint
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php echo e($item->field_value_OD); ?> <?php if($item->duration_od): ?> - <?php echo e($item->duration_od); ?> <?php endif; ?>
                                </td>
                                <td>
                                    <?php echo e($item->field_value_OS); ?> <?php if($item->duration_os): ?> - <?php echo e($item->duration_os); ?> <?php endif; ?>
                                </td>
                            </tr>                            
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                        <?php $__currentLoopData = $form_details->eyeformmultipleentry()->where('field_name', 'OpthalHistory')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <?php if($loop->iteration == 1): ?>
                                    <input type="checkbox" class="hide_print" name="hide_print[]" value="OpthalHistory" <?php echo e(in_array('OpthalHistory', $print_eyeformFields) ? 'checked' : ''); ?>>Ophthalmic History      
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php echo e($item->field_value_OD); ?> <?php if($item->duration_od): ?> - <?php echo e($item->duration_od); ?> <?php endif; ?>
                                </td>
                                <td>
                                    <?php echo e($item->field_value_OS); ?> <?php if($item->duration_os): ?> - <?php echo e($item->duration_os); ?> <?php endif; ?>
                                </td>
                            </tr>                            
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       <?php $__currentLoopData = $form_details->patients_systemic_history; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <?php if($loop->iteration == 1): ?>
                                <input type="checkbox" class="hide_print" name="hide_print[]" value="patients_systemic_history" <?php echo e(in_array('patients_systemic_history', $print_eyeformFields) ? 'checked' : ''); ?>>Systemic History
                            <?php endif; ?>
                        </td>
                        <td colspan="2">
                            <?php echo e($item->value); ?> <?php if($item->duration): ?> - <?php echo e($item->duration); ?> <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php if(!$CheckField::IsFieldEmpty($form_details->familyHistory)): ?>
                        <tr>
                            <td>
                                <input type="checkbox" class="hide_print" name="hide_print[]" value="familyHistory" <?php echo e(in_array('familyHistory', $print_eyeformFields) ? 'checked' : ''); ?>>Family History
                            </td>
                            <td colspan="2">
                                <?php echo e(nl2br($form_details->familyHistory)); ?>

                            </td>
                        </tr>
                        <?php endif; ?>
                        <?php if(!$CheckField::IsFieldEmpty($form_details->birthHistory) && !in_array('birthHistory', $print_eyeformFields)): ?>
                        <tr>
                            <td>
                                <input type="checkbox" class="hide_print" name="hide_print[]" value="birthHistory" <?php echo e(in_array('birthHistory', $print_eyeformFields) ? 'checked' : ''); ?>>Birth History
                            </td>
                            <td colspan="2">
                                <?php echo e(nl2br($form_details->birthHistory)); ?>

                            </td>
                        </tr>
                        <?php endif; ?>
                        <?php if(!$CheckField::IsFieldEmpty($form_details->dvn_od) && !$CheckField::IsFieldEmpty($form_details->dvn_os) && !in_array('dvn_os', $print_eyeformFields)): ?>
                            <tr>
                                <td>
                                   <input type="checkbox" class="hide_print" name="hide_print[]" value="dvn_od" <?php echo e(in_array('dvn_od', $print_eyeformFields) ? 'checked' : ''); ?>>Distant Vision UNAIDED
                                </td>
                                <td>
                                    <?php echo e($form_details->dvn_od); ?>

                                </td>
                                <td>
                                    <?php echo e($form_details->dvn_os); ?>

                                </td>
                            </tr>
                        <?php endif; ?>
                        <?php if(!$CheckField::IsFieldEmpty($form_details->nvn_od) && !$CheckField::IsFieldEmpty($form_details->nvn_os)): ?>
                            <tr>
                                <td>
                                    <input type="checkbox" class="hide_print" name="hide_print[]" value="nvn_od" <?php echo e(in_array('nvn_od', $print_eyeformFields) ? 'checked' : ''); ?>>Near Vision UNAIDED
                                </td>
                                <td>
                                    <?php echo e($form_details->nvn_od); ?>

                                </td>
                                <td>
                                    <?php echo e($form_details->nvn_os); ?>

                                </td>
                            </tr>
                        <?php endif; ?>
                        <?php if(!$CheckField::IsFieldEmpty($form_details->visualacuity_OD) && !$CheckField::IsFieldEmpty($form_details->visualacuity_OS)): ?>
                            <tr>
                                <td>
                                    <input type="checkbox" class="hide_print" name="hide_print[]" value="visualacuity_OD" <?php echo e(in_array('visualacuity_OD', $print_eyeformFields) ? 'checked' : ''); ?>>Distant Vision Aided
                                </td>
                                <td>
                                    <?php echo e($form_details->visualacuity_OD); ?>

                                </td>
                                <td>
                                    <?php echo e($form_details->visualacuity_OS); ?>

                                </td>
                            </tr>
                        <?php endif; ?>
                        <?php if(!$CheckField::IsFieldEmpty($form_details->withglasses_OD) && !$CheckField::IsFieldEmpty($form_details->withglasses_OS)): ?>
<!--                            <tr>
                                <td>
                                    PGP
                                </td>
                                <td>
                                    <?php echo e($form_details->withglasses_OD); ?>

                                </td>
                                <td>
                                    <?php echo e($form_details->withglasses_OS); ?>

                                </td>
                            </tr>-->
                        <?php endif; ?>
                        <?php if(!$CheckField::IsFieldEmpty($form_details->withpinhole_OD) && !$CheckField::IsFieldEmpty($form_details->withpinhole_OS)): ?>
                            <tr>
                                <td>
                                    <input type="checkbox" class="hide_print" name="hide_print[]" value="withpinhole_OD" <?php echo e(in_array('withpinhole_OD', $print_eyeformFields) ? 'checked' : ''); ?>>With Pinhole
                                </td>
                                <td>
                                    <?php echo e($form_details->withpinhole_OD); ?>

                                </td>
                                <td>
                                    <?php echo e($form_details->withpinhole_OS); ?>

                                </td>
                            </tr>
                        <?php endif; ?>
                        <?php if(!$CheckField::IsFieldEmpty($form_details->colour_vision_OD) && !$CheckField::IsFieldEmpty($form_details->colour_vision_OS)): ?>
                            <tr>
                                <td>
                                    <input type="checkbox" class="hide_print" name="hide_print[]" value="colour_vision_OD" <?php echo e(in_array('colour_vision_OD', $print_eyeformFields) ? 'checked' : ''); ?>>Colour vision
                                </td>
                                <td>
                                    <?php echo e($form_details->colour_vision_OD); ?>

                                </td>
                                <td>
                                    <?php echo e($form_details->colour_vision_OS); ?>

                                </td>
                            </tr>
                        <?php endif; ?>


<!--          =====================================================               -->
                        <?php if(!$CheckField::IsFieldEmpty($form_details->perimetry_sp_od) && !$CheckField::IsFieldEmpty($form_details->perimetry_sp_os)): ?>
                            <tr>
                                <td>
                                    <input type="checkbox" class="hide_print" name="hide_print[]" value="perimetry_sp_od" <?php echo e(in_array('perimetry_sp_od', $print_eyeformFields) ? 'checked' : ''); ?>>Perimetry
                                </td>
                                <td>
                                    <?php echo e($form_details->perimetry_sp_od); ?>

                                </td>
                                <td>
                                    <?php echo e($form_details->perimetry_sp_os); ?>

                                </td>
                            </tr>
                        <?php endif; ?>
                        
                         <?php if(!$CheckField::IsFieldEmpty($form_details->laser_sp_od) && !$CheckField::IsFieldEmpty($form_details->laser_sp_os)): ?>
                            <tr>
                                <td>
                                    <input type="checkbox" class="hide_print" name="hide_print[]" value="laser_sp_od" <?php echo e(in_array('laser_sp_od', $print_eyeformFields) ? 'checked' : ''); ?>>Laser
                                </td>
                                <td>
                                    <?php echo e($form_details->laser_sp_od); ?>

                                </td>
                                <td>
                                    <?php echo e($form_details->laser_sp_os); ?>

                                </td>
                            </tr>
                        <?php endif; ?>
                        
                         <?php if(!$CheckField::IsFieldEmpty($form_details->oculizer_sp_od) && !$CheckField::IsFieldEmpty($form_details->oculizer_sp_os)): ?>
                            <tr>
                                <td>
                                    <input type="checkbox" class="hide_print" name="hide_print[]" value="oculizer_sp_od" <?php echo e(in_array('oculizer_sp_od', $print_eyeformFields) ? 'checked' : ''); ?>>Oculizer
                                </td>
                                <td>
                                    <?php echo e($form_details->oculizer_sp_od); ?>

                                </td>
                                <td>
                                    <?php echo e($form_details->oculizer_sp_os); ?>

                                </td>
                            </tr>
                        <?php endif; ?>
                         <?php if(!$CheckField::IsFieldEmpty($form_details->ffa_sp_od) && !$CheckField::IsFieldEmpty($form_details->ffa_sp_os)): ?>
                            <tr>
                                <td>
                                    <input type="checkbox" class="hide_print" name="hide_print[]" value="ffa_sp_od" <?php echo e(in_array('ffa_sp_od', $print_eyeformFields) ? 'checked' : ''); ?>>Ffa
                                </td>
                                <td>
                                    <?php echo e($form_details->ffa_sp_od); ?>

                                </td>
                                <td>
                                    <?php echo e($form_details->ffa_sp_os); ?>

                                </td>
                            </tr>
                        <?php endif; ?>
                        
<!--      ==============================================================-->
                        
                        <?php if(!$CheckField::IsFieldEmpty($form_details->withglasses_OD) && !$CheckField::IsFieldEmpty($form_details->withglasses_OS)): ?>
                            <tr>
                                <td>
                                    <input type="checkbox" class="hide_print" name="hide_print[]" value="withglasses_OD" <?php echo e(in_array('withglasses_OD', $print_eyeformFields) ? 'checked' : ''); ?>>With glasses
                                </td>
                                <td>
                                    <?php echo e($form_details->withglasses_OD); ?>

                                </td>
                                <td>
                                    <?php echo e($form_details->withglasses_OS); ?>

                                </td>
                            </tr>
                        <?php endif; ?>
                        <?php $__currentLoopData = $form_details->eyeformmultipleentry()->where('field_name', 'ConjAndLids')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <?php if($loop->iteration == 1): ?>
                                    <input type="checkbox" class="hide_print" name="hide_print[]" value="ConjAndLids" <?php echo e(in_array('ConjAndLids', $print_eyeformFields) ? 'checked' : ''); ?>>Conj
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php echo e($item->field_value_OD); ?>

                                </td>
                                <td>
                                    <?php echo e($item->field_value_OS); ?>

                                </td>
                            </tr>                            
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $form_details->eyeformmultipleentry()->where('field_name', 'Lids')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <?php if($loop->iteration == 1): ?>
                                    <input type="checkbox" class="hide_print" name="hide_print[]" value="Lids" <?php echo e(in_array('Lids', $print_eyeformFields) ? 'checked' : ''); ?>>Lids
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php echo e($item->field_value_OD); ?>

                                </td>
                                <td>
                                    <?php echo e($item->field_value_OS); ?>

                                </td>
                            </tr>                            
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $form_details->eyeformmultipleentry()->where('field_name', 'AC')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <?php if($loop->iteration == 1): ?>
                                    <input type="checkbox" class="hide_print" name="hide_print[]" value="AC" <?php echo e(in_array('AC', $print_eyeformFields) ? 'checked' : ''); ?>>AC
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php echo e($item->field_value_OD); ?>

                                </td>
                                <td>
                                    <?php echo e($item->field_value_OS); ?>

                                </td>
                            </tr>                            
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $form_details->eyeformmultipleentry()->where('field_name', 'IRIS')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <?php if($loop->iteration == 1): ?>
                                    <input type="checkbox" class="hide_print" name="hide_print[]" value="IRIS" <?php echo e(in_array('IRIS', $print_eyeformFields) ? 'checked' : ''); ?>>IRIS
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php echo e($item->field_value_OD); ?>

                                </td>
                                <td>
                                    <?php echo e($item->field_value_OS); ?>

                                </td>
                            </tr>                            
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $form_details->eyeformmultipleentry()->where('field_name', 'sac')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <?php if($loop->iteration == 1): ?>
                                    <input type="checkbox" class="hide_print" name="hide_print[]" value="sac" <?php echo e(in_array('sac', $print_eyeformFields) ? 'checked' : ''); ?>>sac
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php echo e($item->field_value_OD); ?>

                                </td>
                                <td>
                                    <?php echo e($item->field_value_OS); ?>

                                </td>
                            </tr>                            
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $form_details->eyeformmultipleentry()->where('field_name', 'Retina')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <?php if($loop->iteration == 1): ?>
                                    <input type="checkbox" class="hide_print" name="hide_print[]" value="Retina" <?php echo e(in_array('Retina', $print_eyeformFields) ? 'checked' : ''); ?>>Retina
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php echo e($item->field_value_OD); ?>

                                </td>
                                <td>
                                    <?php echo e($item->field_value_OS); ?>

                                </td>
                            </tr>                            
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $form_details->eyeformmultipleentry()->where('field_name', 'Macula')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <?php if($loop->iteration == 1): ?>
                                    <input type="checkbox" class="hide_print" name="hide_print[]" value="Macula" <?php echo e(in_array('Macula', $print_eyeformFields) ? 'checked' : ''); ?>>Macula
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php echo e($item->field_value_OD); ?>

                                </td>
                                <td>
                                    <?php echo e($item->field_value_OS); ?>

                                </td>
                            </tr>                            
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $form_details->eyeformmultipleentry()->where('field_name', 'ONH')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <?php if($loop->iteration == 1): ?>
                                    <input type="checkbox" class="hide_print" name="hide_print[]" value="ONH" <?php echo e(in_array('ONH', $print_eyeformFields) ? 'checked' : ''); ?>>ONH
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php echo e($item->field_value_OD); ?>

                                </td>
                                <td>
                                    <?php echo e($item->field_value_OS); ?>

                                </td>
                            </tr>                            
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $form_details->eyeformmultipleentry()->where('field_name', 'OrbitSacsEyeMotility')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <?php if($loop->iteration == 1): ?>
                                    <input type="checkbox" class="hide_print" name="hide_print[]" value="OrbitSacsEyeMotility" <?php echo e(in_array('OrbitSacsEyeMotility', $print_eyeformFields) ? 'checked' : ''); ?>>Orbit
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php echo e($item->field_value_OD); ?>

                                </td>
                                <td>
                                    <?php echo e($item->field_value_OS); ?>

                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $form_details->eyeformmultipleentry()->where('field_name', 'cornia')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <?php if($loop->iteration == 1): ?>
                                    <input type="checkbox" class="hide_print" name="hide_print[]" value="cornia" <?php echo e(in_array('cornia', $print_eyeformFields) ? 'checked' : ''); ?>>CORNEA
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php echo e($item->field_value_OD); ?>

                                </td>
                                <td>
                                    <?php echo e($item->field_value_OS); ?>

                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php if(!empty($form_details->OdImg1) && !is_null($form_details->OdImg1) && !empty($form_details->OsImg1) && !is_null($form_details->OsImg1)): ?>
                        <tr>
                           <td></td>
                           <td>
                                <?php if(!empty($form_details->OdImg1) && !is_null($form_details->OdImg1)): ?>
                                    <p>&nbsp;</p>
                                    <center id="wPaint-OdImg1"> 
                                            <img src=<?php echo e(Storage::disk('local')->url($form_details->OdImg1)."?".filemtime(Storage::path($form_details->OdImg1))); ?> class="img-rounded" alt="Image Not found" width="100%" height="150" />
                                    </center>
                                <?php endif; ?>
                           </td>
                           <td>
                                <?php if(!empty($form_details->OsImg1) && !is_null($form_details->OsImg1)): ?>                        
                                    <p>&nbsp;</p>
                                    <center id="wPaint-OsImg1"> 
                                            <img src=<?php echo e(Storage::disk('local')->url($form_details->OsImg1)."?".filemtime(Storage::path($form_details->OsImg1))); ?> class="img-rounded" alt="Image Not found" width="100%" height="150" />  
                                    </center>
                                <?php endif; ?>
                           </td>
                        </tr>
                        <?php endif; ?>
                        <?php $__currentLoopData = $form_details->eyeformmultipleentry()->where('field_name', 'pupilIrisac')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <?php if($loop->iteration == 1): ?>
                                    <input type="checkbox" class="hide_print" name="hide_print[]" value="pupilIrisac" <?php echo e(in_array('pupilIrisac', $print_eyeformFields) ? 'checked' : ''); ?>>pupil
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php echo e($item->field_value_OD); ?>

                            </td>
                            <td>
                                <?php echo e($item->field_value_OS); ?>

                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $form_details->eyeformmultipleentry()->where('field_name', 'lens')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <?php if($loop->iteration == 1): ?>
                                    <input type="checkbox" class="hide_print" name="hide_print[]" value="lens" <?php echo e(in_array('lens', $print_eyeformFields) ? 'checked' : ''); ?>>LENS
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php echo e($item->field_value_OD); ?>

                            </td>
                            <td>
                                <?php echo e($item->field_value_OS); ?>

                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php if(!empty($form_details->OdImg2) && !is_null($form_details->OdImg2) && !empty($form_details->OsImg2) && !is_null($form_details->OsImg2)): ?>
                        <tr>
                           <td></td>
                           <td>
                                <?php if(!empty($form_details->OdImg2) && !is_null($form_details->OdImg2)): ?>
                                    <p>&nbsp;</p>
                                    <center id="wPaint-OdImg2"> 
                                            <img src=<?php echo e(Storage::disk('local')->url($form_details->OdImg2)."?".filemtime(Storage::path($form_details->OdImg2))); ?> class="img-rounded" alt="Image Not found" width="100%" height="150" />
                                    </center>
                                <?php endif; ?>
                           </td>
                           <td>
                                <?php if(!empty($form_details->OsImg2) && !is_null($form_details->OsImg2)): ?>                        
                                    <p>&nbsp;</p>
                                    <center id="wPaint-OsImg2"> 
                                            <img src=<?php echo e(Storage::disk('local')->url($form_details->OsImg2)."?".filemtime(Storage::path($form_details->OsImg2))); ?> class="img-rounded" alt="Image Not found" width="100%" height="150" />  
                                    </center>
                                <?php endif; ?>
                           </td>
                        </tr>
                        <?php endif; ?>
                        <?php $__currentLoopData = $form_details->eyeformmultipleentry()->where('field_name', 'vitreoretinal')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <?php if($loop->iteration == 1): ?>
                                    <input type="checkbox" class="hide_print" name="hide_print[]" value="vitreoretinal" <?php echo e(in_array('vitreoretinal', $print_eyeformFields) ? 'checked' : ''); ?>>vitreo retinal
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php echo e($item->field_value_OD); ?>

                            </td>
                            <td>
                                <?php echo e($item->field_value_OS); ?>

                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php if(!$CheckField::IsFieldEmpty($form_details->IOP_OD) && !$CheckField::IsFieldEmpty($form_details->IOP_OS)): ?>
                            <tr>
                                <td>
                                    <input type="checkbox" class="hide_print" name="hide_print[]" value="IOP_OD" <?php echo e(in_array('IOP_OD', $print_eyeformFields) ? 'checked' : ''); ?>>IOP
                                </td>
                                <td>
                                    <?php echo e($form_details->IOP_OD); ?> <?php echo e(($form_details->iop_od_time) ? '['.$form_details->iop_od_time.']': ''); ?>

                                </td>
                                <td>
                                    <?php echo e($form_details->IOP_OS); ?> <?php echo e(($form_details->iop_os_time) ? '['.$form_details->iop_os_time.']': ''); ?>

                                </td>
                            </tr>
                        <?php endif; ?>
                        <?php if(!$CheckField::IsFieldEmpty($form_details->Ratio_OD) && !$CheckField::IsFieldEmpty($form_details->Ratio_OS)): ?>
                            <tr>
                                <td>
                                   <input type="checkbox" class="hide_print" name="hide_print[]" value="Ratio_OD" <?php echo e(in_array('Ratio_OD', $print_eyeformFields) ? 'checked' : ''); ?>>CD Ratio
                                </td>
                                <td>
                                    <?php echo e($form_details->Ratio_OD); ?>

                                </td>
                                <td>
                                    <?php echo e($form_details->Ratio_OS); ?>

                                </td>
                            </tr>
                        <?php endif; ?>
                        <?php if(!$CheckField::IsFieldEmpty($form_details->Pachymetry_OD) && !$CheckField::IsFieldEmpty($form_details->Pachymetry_OS)): ?>
                            <tr>
                                <td>
                                    <input type="checkbox" class="hide_print" name="hide_print[]" value="Pachymetry_OD" <?php echo e(in_array('Pachymetry_OD', $print_eyeformFields) ? 'checked' : ''); ?>>Pachymetry
                                </td>
                                <td>
                                    <?php echo e($form_details->Pachymetry_OD); ?>

                                </td>
                                <td>
                                    <?php echo e($form_details->Pachymetry_OS); ?>

                                </td>
                            </tr>
                        <?php endif; ?>
                        <?php if(!$CheckField::IsFieldEmpty($form_details->CCT_OD) && !$CheckField::IsFieldEmpty($form_details->CCT_OS)): ?>
                            <tr>
                                <td>
                                    <input type="checkbox" class="hide_print" name="hide_print[]" value="CCT_OD" <?php echo e(in_array('CCT_OD', $print_eyeformFields) ? 'checked' : ''); ?>>CCT
                                </td>
                                <td>
                                    <?php echo e($form_details->CCT_OD); ?>

                                </td>
                                <td>
                                    <?php echo e($form_details->CCT_OS); ?>

                                </td>
                            </tr>
                        <?php endif; ?>
                        <?php $__currentLoopData = $form_details->eyeformmultipleentry()->where('field_name', 'diagno')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <?php if($loop->iteration == 1): ?>
                                    <input type="checkbox" class="hide_print" name="hide_print[]" value="diagno" <?php echo e(in_array('diagno', $print_eyeformFields) ? 'checked' : ''); ?>>Diagnosis
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php echo e($item->field_value_OD); ?>

                            </td>
                            <td>
                                <?php echo e($item->field_value_OS); ?>

                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php if(!$CheckField::IsFieldEmpty($form_details->Advice_OD) && !$CheckField::IsFieldEmpty($form_details->Advice_OS)): ?>
                            <tr>
                                <td>
                                    <input type="checkbox" class="hide_print" name="hide_print[]" value="Advice_OD" <?php echo e(in_array('Advice_OD', $print_eyeformFields) ? 'checked' : ''); ?>>Advice
                                </td>
                                <td>
                                    <?php echo e(nl2br($form_details->Advice_OD)); ?>

                                </td>
                                <td>
                                    <?php echo e(nl2br($form_details->Advice_OS)); ?>

                                </td>
                            </tr>
                        <?php endif; ?>
                        <?php if(!$CheckField::IsFieldEmpty($form_details->BloodInvestigation)): ?>
                            <tr>
                                <td>
                                    <input type="checkbox" class="hide_print" name="hide_print[]" value="BloodInvestigation" <?php echo e(in_array('BloodInvestigation', $print_eyeformFields) ? 'checked' : ''); ?>>Blood Investigation
                                </td>
                                <td colspan="2">
                                    <?php echo e(nl2br($form_details->BloodInvestigation)); ?>

                                </td>
                            </tr>
                        <?php endif; ?>
                        <?php if(!$CheckField::IsFieldEmpty($form_details->k1_od) && !$CheckField::IsFieldEmpty($form_details->k1_os)): ?>
                            <tr>
                                <td>
                                    <input type="checkbox" class="hide_print" name="hide_print[]" value="k1_od" <?php echo e(in_array('k1_od', $print_eyeformFields) ? 'checked' : ''); ?>>K1
                                </td>
                                <td>
                                    <?php echo e($form_details->k1_od); ?>

                                </td>
                                <td>
                                    <?php echo e($form_details->k1_os); ?>

                                </td>
                            </tr>
                        <?php endif; ?>
                        <?php if(!$CheckField::IsFieldEmpty($form_details->k2_od) && !$CheckField::IsFieldEmpty($form_details->k2_os)): ?>
                            <tr>
                                <td>
                                    <input type="checkbox" class="hide_print" name="hide_print[]" value="k2_od" <?php echo e(in_array('k2_od', $print_eyeformFields) ? 'checked' : ''); ?>>K2
                                </td>
                                <td>
                                    <?php echo e($form_details->k2_od); ?>

                                </td>
                                <td>
                                    <?php echo e($form_details->k2_os); ?>

                                </td>
                            </tr>
                        <?php endif; ?>
                        <?php if(!$CheckField::IsFieldEmpty($form_details->lenspower_od) && !$CheckField::IsFieldEmpty($form_details->lenspower_os)): ?>
                            <tr>
                                <td>
                                    <input type="checkbox" class="hide_print" name="hide_print[]" value="lenspower_od" <?php echo e(in_array('lenspower_od', $print_eyeformFields) ? 'checked' : ''); ?>>Lens Power
                                </td>
                                <td>
                                    <?php echo e($form_details->lenspower_od); ?>

                                </td>
                                <td>
                                    <?php echo e($form_details->lenspower_os); ?>

                                </td>
                            </tr>
                        <?php endif; ?>
						<?php if(!$CheckField::IsFieldEmpty($form_details->lens_type_od) && !$CheckField::IsFieldEmpty($form_details->lens_type_os)): ?>
                            <tr>
                                <td>
                                    <input type="checkbox" class="hide_print" name="hide_print[]" value="lens_type_od" <?php echo e(in_array('lens_type_od', $print_eyeformFields) ? 'checked' : ''); ?>>Type of Lens
                                </td>
                                <td>
                                    <?php echo e($form_details->lens_type_od); ?>

                                </td>
                                <td>
                                    <?php echo e($form_details->lens_type_os); ?>

                                </td>
                            </tr>
                        <?php endif; ?>
                        <?php if(!$CheckField::IsFieldEmpty($form_details->axial_length_OD) && !$CheckField::IsFieldEmpty($form_details->axial_length_OS)): ?>
                            <tr>
                                <td>
                                    <input type="checkbox" class="hide_print" name="hide_print[]" value="axial_length_OD" <?php echo e(in_array('axial_length_OD', $print_eyeformFields) ? 'checked' : ''); ?>>Axial Lenght
                                </td>
                                <td>
                                    <?php echo e($form_details->axial_length_OD); ?>

                                </td>
                                <td>
                                    <?php echo e($form_details->axial_length_OS); ?>

                                </td>
                            </tr>
                        <?php endif; ?>
                        <?php if(!$CheckField::IsFieldEmpty($form_details->KC_OD) && !$CheckField::IsFieldEmpty($form_details->KC_OS)): ?>
                            <tr>
                                <td>
                                    <input type="checkbox" class="hide_print" name="hide_print[]" value="KC_OD" <?php echo e(in_array('KC_OD', $print_eyeformFields) ? 'checked' : ''); ?>>KC
                                </td>
                                <td>
                                    <?php echo e($form_details->KC_OD); ?>

                                </td>
                                <td>
                                    <?php echo e($form_details->KC_OS); ?>

                                </td>
                            </tr>
                        <?php endif; ?>
                        <?php if(!$CheckField::IsFieldEmpty($form_details->colour_OD) && !$CheckField::IsFieldEmpty($form_details->colour_OS)): ?>
                            <tr>
                                <td>
                                    <input type="checkbox" class="hide_print" name="hide_print[]" value="colour_OD" <?php echo e(in_array('colour_OD', $print_eyeformFields) ? 'checked' : ''); ?>>colour  Vision
                                </td>
                                <td>
                                    <?php echo e($form_details->colour_OD); ?>

                                </td>
                                <td>
                                    <?php echo e($form_details->colour_OS); ?>

                                </td>
                            </tr>
                        <?php endif; ?>
                        <?php if(!$CheckField::IsFieldEmpty($form_details->schimerTest1_OD) && !$CheckField::IsFieldEmpty($form_details->schimerTest1_OS)): ?>
                            <tr>
                                <td>
                                    <input type="checkbox" class="hide_print" name="hide_print[]" value="schimerTest1_OD" <?php echo e(in_array('schimerTest1_OD', $print_eyeformFields) ? 'checked' : ''); ?>>Schimer Test 1
                                </td>
                                <td>
                                    <?php echo e($form_details->schimerTest1_OD); ?>

                                </td>
                                <td>
                                    <?php echo e($form_details->schimerTest1_OS); ?>

                                </td>
                            </tr>
                        <?php endif; ?>
                        <?php if(!$CheckField::IsFieldEmpty($form_details->schimerTest2_OD) && !$CheckField::IsFieldEmpty($form_details->schimerTest2_OS)): ?>
                            <tr>
                                <td>
                                    <input type="checkbox" class="hide_print" name="hide_print[]" value="schimerTest2_OD" <?php echo e(in_array('schimerTest2_OD', $print_eyeformFields) ? 'checked' : ''); ?>>Schimer Test 2
                                </td>
                                <td>
                                    <?php echo e($form_details->schimerTest2_OD); ?>

                                </td>
                                <td>
                                    <?php echo e($form_details->schimerTest2_OS); ?>

                                </td>
                            </tr>
                        <?php endif; ?>
                        <?php $__currentLoopData = $form_details->eyeformmultipleentry()->where('field_name', 'OCT')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <?php if($loop->iteration == 1): ?>
                                    <input type="checkbox" class="hide_print" name="hide_print[]" value="OCT" <?php echo e(in_array('OCT', $print_eyeformFields) ? 'checked' : ''); ?>>Optical Coherence tomography (OCT)
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php echo e($item->field_value_OD); ?>

                            </td>
                            <td>
                                <?php echo e($item->field_value_OS); ?>

                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $form_details->eyeformmultipleentry()->where('field_name', 'EOM')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <?php if($loop->iteration == 1): ?>
                                <input type="checkbox" class="hide_print" name="hide_print[]" value="EOM" <?php echo e(in_array('EOM', $print_eyeformFields) ? 'checked' : ''); ?>>Extra Ocular Movement (EOM)
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php echo e($item->field_value_OD); ?>

                            </td>
                            <td>
                                <?php echo e($item->field_value_OS); ?>

                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
              </div>  
				<?php if(!$CheckField::IsFieldEmpty($form_details->otherDetailsDiagnosis)): ?>
                <div class="row">
                        <div class="col-md-12">
                            <label class="control-label">Diagnosis :</label>   <?php echo nl2br($form_details->otherDetailsDiagnosis); ?> 
                        </div>
                    </div>
                <?php endif; ?>

				<?php  
					$otherDetailsAnteriorSegment = $form_details->eyeformmultipleentry()->where('field_name', 'otherDetailsAnteriorSegment')->get();
				 ?>
                <?php if(count($otherDetailsAnteriorSegment)): ?>
                <div class="row">
						<div class="col-md-12">
							<div class="table-responsive">
								<table class="table  table-bordered">
									<thead>
										<tr>
											<td >
												<input type="checkbox" class="hide_print" name="hide_print[]" value="otherDetailsAnteriorSegment" <?php echo e(in_array('otherDetailsAnteriorSegment', $print_eyeformFields) ? 'checked' : ''); ?>>Anterior Segment : 
											</td>
											<td >
												<strong>OD</strong>
											</td>
											<td >
												<strong>OS</strong>
											</td>
										</tr>
									</thead>
									<tbody>
										<?php $__currentLoopData = $otherDetailsAnteriorSegment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<tr>
												<td >
													
												</td>
												<td >
													<strong><?php echo e($item->field_value_OD); ?></strong>
												</td>
												<td >
													<strong><?php echo e($item->field_value_OS); ?></strong>
												</td>
											</tr>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</tbody>
								</table>
							</div>
						</div>

                       
                </div>
                <?php endif; ?>

				<?php  
					$otherDetailsPosteriorSegment = $form_details->eyeformmultipleentry()->where('field_name', 'otherDetailsPosteriorSegment')->get();
				 ?>
                <?php if(count($otherDetailsPosteriorSegment)): ?>
                <div class="row">
						<div class="col-md-12">
							<div class="table-responsive">
								<table class="table  table-bordered">
									<thead>
										<tr>
											<td >
												<input type="checkbox" class="hide_print" name="hide_print[]" value="otherDetailsPosteriorSegment" <?php echo e(in_array('otherDetailsPosteriorSegment', $print_eyeformFields) ? 'checked' : ''); ?>>Posterior Segment' : 
											</td>
											<td >
												<strong>OD</strong>
											</td>
											<td >
												<strong>OS</strong>
											</td>
										</tr>
									</thead>
									<tbody>
										<?php $__currentLoopData = $otherDetailsPosteriorSegment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<tr>
												<td >
													
												</td>
												<td >
													<strong><?php echo e($item->field_value_OD); ?></strong>
												</td>
												<td >
													<strong><?php echo e($item->field_value_OS); ?></strong>
												</td>
											</tr>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</tbody>
								</table>
							</div>
						</div>

                       
                </div>
                <?php endif; ?>

				<?php  
					$otherDetailsAdditionalInformation = $form_details->eyeformmultipleentry()->where('field_name', 'otherDetailsAdditionalInformation')->get();
				 ?>
                <?php if(count($otherDetailsAdditionalInformation)): ?>
                <div class="row">
						<div class="col-md-12">
							<div class="table-responsive">
								<table class="table  table-bordered">
									<tbody>
										<?php $__currentLoopData = $otherDetailsAdditionalInformation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<tr>
												<?php if($key == 0): ?>
												<td rowspan="<?php echo e(count($otherDetailsAdditionalInformation)); ?>">
													<input type="checkbox" class="hide_print" name="hide_print[]" value="otherDetailsAdditionalInformation" <?php echo e(in_array('otherDetailsAdditionalInformation', $print_eyeformFields) ? 'checked' : ''); ?>>Additional Information :
												</td>
												<?php endif; ?>
												<td >
													<strong><?php echo e($item->field_value_OD); ?></strong>
												</td>
											</tr>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</tbody>
								</table>
							</div>
						</div>

                       
                </div>
                <?php endif; ?>

				<?php  
					$otherDetailsAdvice = $form_details->eyeformmultipleentry()->where('field_name', 'otherDetailsAdvice')->get();
				 ?>
                <?php if(count($otherDetailsAdvice)): ?>
                <div class="row">
						<div class="col-md-12">
							<div class="table-responsive">
								<table class="table  table-bordered">
									<tbody>
										<?php $__currentLoopData = $otherDetailsAdvice; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<tr>
												<?php if($key == 0): ?>
												<td rowspan="<?php echo e(count($otherDetailsAdvice)); ?>">
													<input type="checkbox" class="hide_print" name="hide_print[]" value="otherDetailsAdvice" <?php echo e(in_array('otherDetailsAdvice', $print_eyeformFields) ? 'checked' : ''); ?>>Advice :
												</td>
												<?php endif; ?>
												<td >
													<strong><?php echo e($item->field_value_OD); ?></strong>
												</td>
											</tr>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</tbody>
								</table>
							</div>
						</div>

                       
                </div>
                <?php endif; ?>

				<?php  
					$surgery = $form_details->eyeformmultipleentry()->where('field_name', 'surgery')->get();
				 ?>
                <?php if(count($surgery)): ?>
                <div class="row">
						<div class="col-md-12">
							<div class="table-responsive">
								<table class="table  table-bordered">
									<tbody>
										<?php $__currentLoopData = $surgery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<tr>
												<?php if($key == 0): ?>
												<td rowspan="<?php echo e(count($otherDetailsAdvice)); ?>">
													<input type="checkbox" class="hide_print" name="hide_print[]" value="surgery" <?php echo e(in_array('surgery', $print_eyeformFields) ? 'checked' : ''); ?>>Surgery/Procedure :
												</td>
												<?php endif; ?>
												<td >
													<strong><?php echo e($item->field_value_OD); ?></strong>
												</td>
											</tr>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</tbody>
								</table>
							</div>
						</div>

                       
                </div>
                <?php endif; ?>

				 <?php if(count($form_details->uveiitis_bloodtests_data)): ?>
                <div class="row">
						<div class="col-md-12">
							<div class="table-responsive">
								<table class="table  table-bordered">
									<tbody>
										<tr>
												
												<td>
													<input type="checkbox" class="hide_print" name="hide_print[]" value="uveiitis_bloodtests_data" <?php echo e(in_array('uveiitis_bloodtests_data', $print_eyeformFields) ? 'checked' : ''); ?>>Blood Investigation
												</td>
												
												<td >
													
												</td>
											</tr>
										<?php  $test_type = "";  ?>
										<?php $__currentLoopData = $form_details->uveiitis_bloodtests_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<tr>
												
												<td>
													<?php if($item->test_type != $test_type): ?> 
														<?php echo e($item->test_type); ?> 
													<?php endif; ?>

													<?php  $test_type = $item->test_type;  ?>
												</td>
												
												<td >
													<strong><?php echo e($item->value); ?></strong>
												</td>
											</tr>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</tbody>
								</table>
							</div>
						</div>
                </div>
                <?php endif; ?>

				

               
                <?php if(!empty($casedata->appointment_dt) && !is_null($casedata->appointment_dt) && !isset($casedata->appointment_dt)): ?>
                    <div class="row">
                        <div class="col-md-12">
                            <label class="control-label">Followup Date :</label>   <?php echo e($casedata['appointment_dt']); ?> 
                        </div>
                    </div>
                <?php endif; ?>
                <?php if(!empty($casedata->appointment_timeslot) && !is_null($casedata->appointment_timeslot) && !isset($casedata->appointment_timeslot)): ?>
                    <div class="row">
                        <div class="col-md-12">
                            <label class="control-label">Followup Time :</label>   <?php echo e($casedata['appointment_timeslot']); ?> 
                        </div>
                    </div>
                <?php endif; ?>
               
                
                <div class="row clearfix">
                    <?php if(isset($casedata['Before_file']) && $casedata['Before_file'] != null): ?>
                        <div class="col-sm-12"> 
                            Before Image
                        </div>
                        <div class="col-sm-12"> 
                            <img src=<?php echo e(Storage::disk('local')->url($casedata['Before_file'])."?".filemtime(Storage::path($casedata['Before_file']))); ?> class="img-rounded" alt="Image Not found" width="100%" height="150" />
                        </div>
                    <?php endif; ?>                
                </div>

                <div class="row clearfix">
                    <?php if(isset($casedata['After_file']) && $casedata['After_file'] != null): ?>
                        <div class="col-sm-12"> 
                            After Image
                        </div>
                        <div class="col-sm-12"> 
                            <img src=<?php echo e(Storage::disk('local')->url($casedata['After_file'])."?".filemtime(Storage::path($casedata['After_file']))); ?> class="img-rounded" alt="Image Not found" width="100%" height="150" />
                        </div>
                    <?php endif; ?>
                </div>
                
<!--                ==================================================-->
<?php if($eyform_vision_pgp_details): ?>
    <?php if($eyform_vision_pgp_details->vision_pgp_dv_sph_r || $eyform_vision_pgp_details->vision_pgp_dv_cyl_r || $eyform_vision_pgp_details->vision_pgp_dv_axis_r || $eyform_vision_pgp_details->vision_pgp_dv_vision_r || $eyform_vision_pgp_details->vision_pgp_dv_sph_l || $eyform_vision_pgp_details->vision_pgp_dv_cyl_l || $eyform_vision_pgp_details->vision_pgp_dv_axis_l || $eyform_vision_pgp_details->vision_pgp_dv_vision_l || $eyform_vision_pgp_details->vision_pgp_nv_sph_r || $eyform_vision_pgp_details->vision_pgp_nv_cyl_r || $eyform_vision_pgp_details->vision_pgp_nv_axis_r || $eyform_vision_pgp_details->vision_pgp_nv_vision_r || $eyform_vision_pgp_details->vision_pgp_nv_sph_l || $eyform_vision_pgp_details->vision_pgp_nv_cyl_l || $eyform_vision_pgp_details->vision_pgp_nv_axis_l || $eyform_vision_pgp_details->vision_pgp_nv_vision_l): ?>
 <div > 
    <input type="checkbox" class="hide_print" name="hide_print[]" value="pgp" <?php echo e(in_array('pgp', $print_eyeformFields) ? 'checked' : ''); ?>>PGP
</div>
    <?php echo $__env->make('EyeForm.view_templates.eyform_vision_pgp_details', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php endif; ?>
<?php endif; ?>

<?php if($glass_prescription): ?>
    <?php if($glass_prescription->r_dv_sph || $glass_prescription->r_dv_cyl || 
	$glass_prescription->r_dv_axi || $glass_prescription->r_dv_vision || 
	$glass_prescription->l_dv_sph || $glass_prescription->l_dv_cyl || 
	$glass_prescription->l_dv_axi || $glass_prescription->l_dv_vision || 

	$glass_prescription->r_nv_sph || $glass_prescription->r_nv_cyl || 
	$glass_prescription->r_nv_axi || $glass_prescription->r_nv_vision || 
	$glass_prescription->l_nv_sph || $glass_prescription->l_nv_cyl || 
	$glass_prescription->l_nv_axi || $glass_prescription->l_nv_vision): ?>
 <div > 
    <input type="checkbox" class="hide_print" name="hide_print[]" value="refraction1" <?php echo e(in_array('refraction1', $print_eyeformFields) ? 'checked' : ''); ?>>Glass Prescription
                        </div>
    <?php echo $__env->make('EyeForm.view_templates.eyform_refraction_retina_scopy_details', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php endif; ?>
    <?php endif; ?>



<!--                ==================================================-->
 <?php if($form_details->sph_r_undi || $form_details->cyl_r_undi || $form_details->Axis_r_undi || $form_details->vision_r_sa || $form_details->Add_r_sa || $form_details->Nvision_r_sa || $form_details->sph_l_undi || $form_details->cyl_l_undi || $form_details->Axis_l_undi || $form_details->vision_l_sa || $form_details->Add_l_sa || $form_details->Nvision_l_sa || $form_details->sph_r_di || $form_details->cyl_r_di || $form_details->Axis_r_di || $form_details->vision_r_pga || $form_details->Add_r_pga || $form_details->Nvision_r_pga || $form_details->sph_l_di || $form_details->cyl_l_di || $form_details->Axis_l_di || $form_details->vision_l_pga || $form_details->Add_l_pga || $form_details->Nvision_l_pga ||
 
 $form_details->sph_r_undi_sub || $form_details->cyl_r_undi_sub || $form_details->Axis_r_undi_sub || $form_details->sph_l_undi_sub || $form_details->cyl_l_undi_sub || $form_details->Axis_l_undi_sub || $form_details->sph_r_di_sub || $form_details->cyl_r_di_sub || $form_details->Axis_r_di_sub || $form_details->sph_l_di_sub || $form_details->cyl_l_di_sub || $form_details->Axis_l_di_sub
 
 ): ?>             
                <div class="col-md-12">
					<label><input type="checkbox" class="hide_print" name="hide_print[]" value="refraction2" <?php echo e(in_array('refraction2', $print_eyeformFields) ? 'checked' : ''); ?>>Refraction : </label>
                    <div class="table-responsive">
                        <table class="table table-bordered">
						
                            <thead>
                                <tr>
                                    <th>&nbsp;</th>
                                    <th colspan="3" class="text-center">Right</th>
                                    <th colspan="3" class="text-center">Left</th>
                                </tr>
                                <tr>
                                    <th>&nbsp;</th>
                                    <th>SPH</th>
                                    <th>CYL</th>
                                    <th>Axis</th>

                                    <th>SPH</th>
                                    <th>CYL</th>
                                    <th>Axis</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>AR Undilated</td>
                                    <td>
                                        <?php echo e($form_details->sph_r_undi); ?>

                                    </td>
                                    <td>
                                        <?php echo e($form_details->cyl_r_undi); ?>

                                    </td>
                                    <td>
                                        <?php echo e($form_details->Axis_r_undi); ?>

                                    </td>

                                    <td>
                                        <?php echo e($form_details->sph_l_undi); ?>

                                    </td>
                                    <td>
                                        <?php echo e($form_details->cyl_l_undi); ?>

                                    </td>
                                    <td>
                                        <?php echo e($form_details->Axis_l_undi); ?>

                                    </td>
                                </tr>
								<tr>
                                    <td>Subjective Undilated</td>
                                    <td>
                                        <?php echo e($form_details->sph_r_undi_sub); ?>

                                    </td>
                                    <td>
                                        <?php echo e($form_details->cyl_r_undi_sub); ?>

                                    </td>
                                    <td>
                                        <?php echo e($form_details->Axis_r_undi_sub); ?>

                                    </td>

                                    <td>
                                        <?php echo e($form_details->sph_l_undi_sub); ?>

                                    </td>
                                    <td>
                                        <?php echo e($form_details->cyl_l_undi_sub); ?>

                                    </td>
                                    <td>
                                        <?php echo e($form_details->Axis_l_undi_sub); ?>

                                    </td>
                                </tr>
                                <tr>
                                    <td>AR Dilated</td>
                                    <td>
                                        <?php echo e($form_details->sph_r_di); ?>

                                    </td>
                                    <td>
                                        <?php echo e($form_details->cyl_r_di); ?>

                                    </td>
                                    <td>
                                        <?php echo e($form_details->Axis_r_di); ?>

                                    </td>

                                    <td>
                                        <?php echo e($form_details->sph_l_di); ?>

                                    </td>
                                    <td>
                                        <?php echo e($form_details->cyl_l_di); ?>

                                    </td>
                                    <td>
                                        <?php echo e($form_details->Axis_l_di); ?>

                                    </td>
                                </tr>
                                <tr>
                                    <td>Subjective Dilated</td>
                                    <td>
                                        <?php echo e($form_details->sph_r_di_sub); ?>

                                    </td>
                                    <td>
                                        <?php echo e($form_details->cyl_r_di_sub); ?>

                                    </td>
                                    <td>
                                        <?php echo e($form_details->Axis_r_di_sub); ?>

                                    </td>

                                    <td>
                                        <?php echo e($form_details->sph_l_di_sub); ?>

                                    </td>
                                    <td>
                                        <?php echo e($form_details->cyl_l_di_sub); ?>

                                    </td>
                                    <td>
                                        <?php echo e($form_details->Axis_l_di_sub); ?>

                                    </td>
                                </tr>
                            </tbody>

                        </table>
                    </div>
                </div>
<?php endif; ?>


<!-- =========================================== Start A scan ==================================================== -->
<?php if(count($multiple_entries_data_arr) > 0 && 
($multiple_entries_data_arr['flat_k']['field_value_OD'] != "" && $multiple_entries_data_arr['flat_k']['field_value_OS'] != "") || ($multiple_entries_data_arr['flat_axis']['field_value_OD'] != "" && $multiple_entries_data_arr['flat_axis']['field_value_OS'] != "") || ($multiple_entries_data_arr['stap_k']['field_value_OD'] != "" && $multiple_entries_data_arr['stap_k']['field_value_OS'] != "") || ($multiple_entries_data_arr['stap_axis']['field_value_OD'] != "" && $multiple_entries_data_arr['stap_axis']['field_value_OS'] != "") || ($multiple_entries_data_arr['axial_length']['field_value_OD'] != "" && $multiple_entries_data_arr['axial_length']['field_value_OS'] != "") || ($multiple_entries_data_arr['optical_acd']['field_value_OD'] != "" && $multiple_entries_data_arr['optical_acd']['field_value_OS'] != "") || 
($multiple_entries_data_arr['target_refraction']['field_value_OD'] != "" && $multiple_entries_data_arr['target_refraction']['field_value_OS'] != "") ||
($multiple_entries_data_arr['lens_thickness']['field_value_OD'] != "" && $multiple_entries_data_arr['lens_thickness']['field_value_OS'] != "") ||
($multiple_entries_data_arr['wtw']['field_value_OD'] != "" && $multiple_entries_data_arr['wtw']['field_value_OS'] != "") ||
($multiple_entries_data_arr['kc_formula_use']['field_value_OD'] != "" && $multiple_entries_data_arr['kc_formula_use']['field_value_OS'] != "") ||
($multiple_entries_data_arr['type_of_lens']['field_value_OD'] != "" && $multiple_entries_data_arr['type_of_lens']['field_value_OS'] != "") ||
($multiple_entries_data_arr['se']['field_value_OD'] != "" && $multiple_entries_data_arr['se']['field_value_OS'] != "") ||
($multiple_entries_data_arr['iol_cilinder']['field_value_OD'] != "" && $multiple_entries_data_arr['iol_cilinder']['field_value_OS'] != "")): ?>

<div class="col-md-12">
	<label><input type="checkbox" class="hide_print" name="hide_print[]" value="a_scan" <?php echo e(in_array('a_scan', $print_eyeformFields) ? 'checked' : ''); ?>>A Scan: </label>
	<div class="table-responsive">
		<table class="table table-bordered">
			<thead>
				<tr>
					<td style="width:33%">
						 
					</td>
					<td >
						<strong>OD</strong>
					</td>
					<td >
						<strong>OS</strong>
					</td>
				</tr>
			</thead>
			<tbody>
				<?php if($multiple_entries_data_arr['flat_k']['field_value_OD'] != "" && $multiple_entries_data_arr['flat_k']['field_value_OS'] != ""): ?>
				<tr>
					<td><input type="checkbox" class="hide_print" name="hide_print[]" value="flat_k" <?php echo e(in_array('flat_k', $print_eyeformFields) ? 'checked' : ''); ?>>Flat K</td>
					<td><?php echo e($multiple_entries_data_arr['flat_k']['field_value_OD']); ?></td>
					<td><?php echo e($multiple_entries_data_arr['flat_k']['field_value_OS']); ?></td>
				</tr>
				<?php endif; ?>

				<?php if($multiple_entries_data_arr['flat_axis']['field_value_OD'] != "" && $multiple_entries_data_arr['flat_axis']['field_value_OS'] != ""): ?>
				<tr>
					<td><input type="checkbox" class="hide_print" name="hide_print[]" value="flat_axis" <?php echo e(in_array('flat_axis', $print_eyeformFields) ? 'checked' : ''); ?>>Flat Axis</td>
					<td><?php echo e($multiple_entries_data_arr['flat_axis']['field_value_OD']); ?></td>
					<td><?php echo e($multiple_entries_data_arr['flat_axis']['field_value_OS']); ?></td>
				</tr>
				<?php endif; ?>

				<?php if($multiple_entries_data_arr['stap_k']['field_value_OD'] != "" && $multiple_entries_data_arr['stap_k']['field_value_OS'] != ""): ?>
				<tr>
					<td><input type="checkbox" class="hide_print" name="hide_print[]" value="stap_k" <?php echo e(in_array('stap_k', $print_eyeformFields) ? 'checked' : ''); ?>>Stap K</td>
					<td><?php echo e($multiple_entries_data_arr['stap_k']['field_value_OD']); ?></td>
					<td><?php echo e($multiple_entries_data_arr['stap_k']['field_value_OS']); ?></td>
				</tr>
				<?php endif; ?>

				<?php if($multiple_entries_data_arr['stap_axis']['field_value_OD'] != "" && $multiple_entries_data_arr['stap_axis']['field_value_OS'] != ""): ?>
				<tr>
					<td><input type="checkbox" class="hide_print" name="hide_print[]" value="stap_axis" <?php echo e(in_array('stap_axis', $print_eyeformFields) ? 'checked' : ''); ?>>Stap Axis</td>
					<td><?php echo e($multiple_entries_data_arr['stap_axis']['field_value_OD']); ?></td>
					<td><?php echo e($multiple_entries_data_arr['stap_axis']['field_value_OS']); ?></td>
				</tr>
				<?php endif; ?>

				<?php if($multiple_entries_data_arr['axial_length']['field_value_OD'] != "" && $multiple_entries_data_arr['axial_length']['field_value_OS'] != ""): ?>
				<tr>
					<td><input type="checkbox" class="hide_print" name="hide_print[]" value="axial_length" <?php echo e(in_array('axial_length', $print_eyeformFields) ? 'checked' : ''); ?>>Axial Length</td>
					<td><?php echo e($multiple_entries_data_arr['axial_length']['field_value_OD']); ?></td>
					<td><?php echo e($multiple_entries_data_arr['axial_length']['field_value_OS']); ?></td>
				</tr>
				<?php endif; ?>

				<?php if($multiple_entries_data_arr['optical_acd']['field_value_OD'] != "" && $multiple_entries_data_arr['optical_acd']['field_value_OS'] != ""): ?>
				<tr>
					<td><input type="checkbox" class="hide_print" name="hide_print[]" value="optical_acd" <?php echo e(in_array('optical_acd', $print_eyeformFields) ? 'checked' : ''); ?>>Optical ACD</td>
					<td><?php echo e($multiple_entries_data_arr['optical_acd']['field_value_OD']); ?></td>
					<td><?php echo e($multiple_entries_data_arr['optical_acd']['field_value_OS']); ?></td>
				</tr>
				<?php endif; ?>

				<?php if($multiple_entries_data_arr['target_refraction']['field_value_OD'] != "" && $multiple_entries_data_arr['target_refraction']['field_value_OS'] != ""): ?>
				<tr>
					<td><input type="checkbox" class="hide_print" name="hide_print[]" value="target_refraction" <?php echo e(in_array('target_refraction', $print_eyeformFields) ? 'checked' : ''); ?>>Target Refraction</td>
					<td><?php echo e($multiple_entries_data_arr['target_refraction']['field_value_OD']); ?></td>
					<td><?php echo e($multiple_entries_data_arr['target_refraction']['field_value_OS']); ?></td>
				</tr>
				<?php endif; ?>

				<?php if($multiple_entries_data_arr['lens_thickness']['field_value_OD'] != "" && $multiple_entries_data_arr['lens_thickness']['field_value_OS'] != ""): ?>
				<tr>
					<td><input type="checkbox" class="hide_print" name="hide_print[]" value="lens_thickness" <?php echo e(in_array('lens_thickness', $print_eyeformFields) ? 'checked' : ''); ?>>Lens Thickness</td>
					<td><?php echo e($multiple_entries_data_arr['lens_thickness']['field_value_OD']); ?></td>
					<td><?php echo e($multiple_entries_data_arr['lens_thickness']['field_value_OS']); ?></td>
				</tr>
				<?php endif; ?>

				<?php if($multiple_entries_data_arr['wtw']['field_value_OD'] != "" && $multiple_entries_data_arr['wtw']['field_value_OS'] != ""): ?>
				<tr>
					<td><input type="checkbox" class="hide_print" name="hide_print[]" value="wtw" <?php echo e(in_array('wtw', $print_eyeformFields) ? 'checked' : ''); ?>>WTW</td>
					<td><?php echo e($multiple_entries_data_arr['wtw']['field_value_OD']); ?></td>
					<td><?php echo e($multiple_entries_data_arr['wtw']['field_value_OS']); ?></td>
				</tr>
				<?php endif; ?>

				<?php if($multiple_entries_data_arr['kc_formula_use']['field_value_OD'] != "" && $multiple_entries_data_arr['kc_formula_use']['field_value_OS'] != ""): ?>
				<tr>
					<td><input type="checkbox" class="hide_print" name="hide_print[]" value="kc_formula_use" <?php echo e(in_array('kc_formula_use', $print_eyeformFields) ? 'checked' : ''); ?>>KC/Formula Use</td>
					<td><?php echo e($multiple_entries_data_arr['kc_formula_use']['field_value_OD']); ?></td>
					<td><?php echo e($multiple_entries_data_arr['kc_formula_use']['field_value_OS']); ?></td>
				</tr>
				<?php endif; ?>

				<?php if($multiple_entries_data_arr['type_of_lens']['field_value_OD'] != "" && $multiple_entries_data_arr['type_of_lens']['field_value_OS'] != ""): ?>
				<tr>
					<td><input type="checkbox" class="hide_print" name="hide_print[]" value="type_of_lens" <?php echo e(in_array('type_of_lens', $print_eyeformFields) ? 'checked' : ''); ?>>Type of Lens</td>
					<td><?php echo e($multiple_entries_data_arr['type_of_lens']['field_value_OD']); ?></td>
					<td><?php echo e($multiple_entries_data_arr['type_of_lens']['field_value_OS']); ?></td>
				</tr>
				<?php endif; ?>

				<?php if($multiple_entries_data_arr['se']['field_value_OD'] != "" && $multiple_entries_data_arr['se']['field_value_OS'] != ""): ?>
				<tr>
					<td><input type="checkbox" class="hide_print" name="hide_print[]" value="se" <?php echo e(in_array('se', $print_eyeformFields) ? 'checked' : ''); ?>>Power of Lens - Se</td>
					<td><?php echo e($multiple_entries_data_arr['se']['field_value_OD']); ?></td>
					<td><?php echo e($multiple_entries_data_arr['se']['field_value_OS']); ?></td>
				</tr>
				<?php endif; ?>

				<?php if($multiple_entries_data_arr['iol_cilinder']['field_value_OD'] != "" && $multiple_entries_data_arr['iol_cilinder']['field_value_OS'] != ""): ?>
				<tr>
					<td><input type="checkbox" class="hide_print" name="hide_print[]" value="iol_cilinder" <?php echo e(in_array('iol_cilinder', $print_eyeformFields) ? 'checked' : ''); ?>>Power of Lens - IOL Cilinder</td>
					<td><?php echo e($multiple_entries_data_arr['iol_cilinder']['field_value_OD']); ?></td>
					<td><?php echo e($multiple_entries_data_arr['iol_cilinder']['field_value_OS']); ?></td>
				</tr>
				<?php endif; ?>

			</tbody>
		</table>
	</div>
</div>

<?php endif; ?>
<!-- =========================================== End A scan======================================================= -->
                <div class="col-md-12">
                  <div class="table-responsive">    
                        <table width="100%">
                            <tr>
                                <td class="col-md-2">&nbsp;</td>
                                <td class="col-md-5" colspan="4" >
                                    <?php if(!empty($form_details->retino_scopy_OD) && !is_null($form_details->retino_scopy_OD)): ?>
                                        <p>&nbsp;</p>
                                        <center id="wPaint-retino_scopy_OD"> 
                                                <img src=<?php echo e(Storage::disk('local')->url($form_details->retino_scopy_OD)."?".filemtime(Storage::path($form_details->retino_scopy_OD))); ?> class="img-rounded" alt="Image Not found" width="150" height="150" />
                                        </center>
                                    <?php endif; ?>
                                </td>
                                <td class="col-md-5" colspan="4" >
                                    <?php if(!empty($form_details->retino_scopy_OS) && !is_null($form_details->retino_scopy_OS)): ?>                        
                                        <p>&nbsp;</p>
                                        <center id="wPaint-retino_scopy_OS"> 
                                                <img src=<?php echo e(Storage::disk('local')->url($form_details->retino_scopy_OS)."?".filemtime(Storage::path($form_details->retino_scopy_OS))); ?> class="img-rounded" alt="Image Not found" width="150" height="150" />  
                                        </center>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        </table>
                    </div>
                </div>
                <br>
                <br>
                <br>

                <div class="col-md-12">
                    <ul class="list-unstyled">
                        <li class="">Please bring this paper on every visit</li>
                        <li class=""> Please follow the time </li>
                        <li class=""> Please inform allergy immediately </li>
                    </ul>
                </div>
          
                <div class="col-md-12">
                <div class="row">

                              <?php if(count($form_details->newBloodtestdata) > 0): ?>
                              <?php $__currentLoopData = $form_details->newBloodtestdata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$bloodData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-4">
                                <label for="preoperative_chk"><b><?php echo e($key); ?></b></label>
                                <ul class="list-group1">
                                <?php $__currentLoopData = $bloodData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pre_operative_bloodtests_row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="list-group-item1" style=""><?php echo e($pre_operative_bloodtests_row->value); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                                 
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                             <?php endif; ?>
                    
                </div> 
				</div>
                <div class="row clearfix">
                  <div class="col-md-4 col-md-offset-4">
                  <div class="form-group">
                  <a class="btn btn-default btn-lg" href="<?php echo e(url('/case_masters')); ?>"><i class="glyphicon glyphicon-chevron-left"></i> Back</a> &nbsp;   
                  <button type="submit" class="btn btn-default btn-lg"> Edit </button>&nbsp;
                  <a class="btn btn-default btn-lg" href="<?php echo e(url('/PrintMedicalDetails/').'/'.$casedata['id']); ?>" target="_blank"><i class="glyphicon glyphicon-chevron-left"></i>Print</a>
                  </div>
                  </div>
                </div>

                </div>
                </div>
                </div>
                </div>
                </div>
                </div>
                </div>
                </form>
                </div>
                </div>
                </div>
             </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/js/select2.min.js"></script>
<script type="text/javascript">
    $(document).ready(function(){
      $('#medicine_id').select2();  
      $('.datepicker').datepicker({
            format: "dd/M/yyyy",
            weekStart: 1,
            clearBtn: true,
            daysOfWeekHighlighted: "0,6",
            autoclose: true,
        }); 
			

		$('.hide_print').on('click', function() {
			//alert(this.value);
			
			var url="<?php echo e(url('manage-print-display')); ?>";

			if($(this).is(':checked')) {
				var action = "add";
			} else {
				var action = "remove";
			}

			$.ajax({
				url:url,
				method:'post',
				data:{form_type: 'eyeform', value: this.value, action : action},
				success:function(data)
				{

				}
			});
			
			/*
			var test_type = $(this).data('type');
			var test = $(this).val();
			var is_checked = $(this).is(':checked') ? 1 : 0;

			console.log(test +' : '+ is_checked);

			var caseid=$("#caseid").val();
			var case_number=$("#case_number").val();

			var url="<?php echo e(url('manage-bloodinvestigation')); ?>";

			$.ajax({
				url:url,
				method:'post',
				data:{form_type: 'eyeform', test_type:test_type, test:test, is_checked:is_checked, caseid:caseid,case_number:case_number},
				success:function(data)
				{

				}
			});
			*/
		});
		

    });


</script>
 
<?php $__env->stopSection(); ?>
  
<?php echo $__env->make('adminlayouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>