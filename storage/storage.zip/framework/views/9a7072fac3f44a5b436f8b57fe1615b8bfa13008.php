

<span class="dropdown-container">
<div id="ConjAndLids" class="ContainerToAppend">
<div class="col-md-12">
<div class="col-md-2">
<div class="form-group labelgrp">
<label>Lids</label>
</div>
<input type="hidden" id="ConjAndLids[]" name="ConjAndLids[]" class="hiddenCounter" value="1" />   
</div>

<div class="col-md-3">
<?php echo e(Form::select('Lids_OD[]', array(' '=>'-Select-') + $form_dropdowns->where('fieldName', 'LIDS OD')->pluck('ddText','ddText')->toArray(), array_key_exists('LIDS OD', $defaultValues)?$defaultValues['LIDS OD']:null, array('class'=> 'form-control select2','data-live-search'=>'true'))); ?>

</div>

<div class="col-md-3">
<?php echo e(Form::select('Lids_OS[]', array(' '=>'-Select-') + $form_dropdowns->where('fieldName', 'LIDS OS')->pluck('ddText','ddText')->toArray(), array_key_exists('LIDS OS', $defaultValues)?$defaultValues['LIDS OS']:null, array('class'=> 'form-control select2','data-live-search'=>'true'))); ?>

</div>

<div class="col-md-4">
<button type="button" name="add" id='lidsbtn' class="btn btn-success  set-dropdown-options"  data-field_name="LIDS OD" data-form_name="EyeForm" >Set Option </button>
<button type='button' class="btn btn-primary" id='lidsbtnsave'>Save Option</button>

<button id="ConjAndLids" class="btn btn-default addmore" data-templateDiv="ConjAndLidsTemplate">Add</button>
</div>
</div>

</div> 
<div id='LidsTextBoxesGroup' class="col-md-12">

</div>

<!-- ================================================================================= -->

<!-- set-dropdown-options -->
<!-- <span class="dropdown-container"> -->
<div class='dropdown-options-initial-div' class="col-md-12" style="display:none;">
<?php  
$dropdown_options_field_name = 'LIDS OD';
$dropdown_options_form_name = 'EyeForm';
 ?>

</div>
</span>
<!-- ================================================================================= -->
<div class="dbMultiEntryContainer">
<?php $__currentLoopData = $form_details->eyeformmultipleentry()->where('field_name', 'Lids')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="col-md-12">
<div class="col-md-2">
</div>
<div class="col-md-3">
<input type="text" class="form-control" readonly value="<?php echo e($item->field_value_OD); ?>">
</div>
<div class="col-md-3">
<input type="text" class="form-control" readonly value="<?php echo e($item->field_value_OS); ?>">
</div>
<div class="col-md-2">
<button class="removeDbItem btn btn-default" data-deleteid="<?php echo e($item->id); ?>">Remove</button>
</div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<span class="dropdown-container">
<div id="OrbitSacsEyeMotility" class="ContainerToAppend">
<div class="col-md-12">
<div class="col-md-2">
<div class="form-group labelgrp">
<label> Orbit</label>
</div>
<input type="hidden" id="Lids[]" name="Lids[]" class="hiddenCounter" value="1" />   
</div>
<div class="col-md-3">
<?php echo e(Form::select('OrbitSacsEyeMotility_OD[]', array(' '=>'-Select-') + $form_dropdowns->where('fieldName', 'OrbitSacsEyeMotility OD')->pluck('ddText','ddText')->toArray(), array_key_exists('OrbitSacsEyeMotility OD', $defaultValues)?$defaultValues['OrbitSacsEyeMotility OD']:null, array('class'=> 'form-control select2','data-live-search'=>'true'))); ?>

</div>
<div class="col-md-3">
<?php echo e(Form::select('OrbitSacsEyeMotility_OS[]', array(' '=>'-Select-') + $form_dropdowns->where('fieldName', 'OrbitSacsEyeMotility OS')->pluck('ddText','ddText')->toArray(), array_key_exists('OrbitSacsEyeMotility OS', $defaultValues)?$defaultValues['OrbitSacsEyeMotility OS']:null, array('class'=> 'form-control select2','data-live-search'=>'true'))); ?>

</div>
<div class="col-md-4">
<button type="button" name="add" id="orbitbtn" class="btn btn-success  set-dropdown-options"  data-field_name="OrbitSacsEyeMotility OD" data-form_name="EyeForm" >Set Option </button>
<button type="button" class="btn btn-primary" id="orbitbtnsave">Save Option</button>
<button id="Lids" class="btn btn-default addmore" data-templateDiv="LidsTemplate">Add</button>
</div>
</div>

</div>
<div id='OrbitTextBoxesGroup' class="col-md-12">

</div>

<!-- ================================================================================= -->

<!-- set-dropdown-options -->
<!-- <span class="dropdown-container"> -->
<div class='dropdown-options-initial-div' class="col-md-12" style="display:none;">
<?php  
$dropdown_options_field_name = 'OrbitSacsEyeMotility OD';
$dropdown_options_form_name = 'EyeForm';
 ?>

</div>
</span>
<!-- ================================================================================= -->
<div class="dbMultiEntryContainer">
<?php $__currentLoopData = $form_details->eyeformmultipleentry()->where('field_name', 'OrbitSacsEyeMotility')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="col-md-12">
<div class="col-md-2">
</div>
<div class="col-md-3">
<input type="text" class="form-control" readonly value="<?php echo e($item->field_value_OD); ?>">
</div>
<div class="col-md-3">
<input type="text" class="form-control" readonly value="<?php echo e($item->field_value_OS); ?>">
</div>
<div class="col-md-2">
<button class="removeDbItem btn btn-default" data-deleteid="<?php echo e($item->id); ?>">Remove</button>
</div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<span class="dropdown-container">
<div id="AC" class="ContainerToAppend">
<div class="col-md-12">
<div class="col-md-2">
<div class="form-group labelgrp">
<label>Conj</label>
</div>
<input type="hidden" id="AC[]" name="AC[]" class="hiddenCounter" value="1" />   
</div>
<div class="col-md-3">
<?php echo e(Form::select('ConjAndLids_OD[]', array(' '=>'-Select-') + $form_dropdowns->where('fieldName', 'Conj And Lids OD')->pluck('ddText','ddText')->toArray(), array_key_exists('Conj And Lids OD', $defaultValues)?$defaultValues['Conj And Lids OD']:null, array('class'=> 'form-control select2','data-live-search'=>'true'))); ?>

</div>
<div class="col-md-3">
<?php echo e(Form::select('ConjAndLids_OS[]', array(' '=>'-Select-') + $form_dropdowns->where('fieldName', 'Conj And Lids OS')->pluck('ddText','ddText')->toArray(), array_key_exists('Conj And Lids OS', $defaultValues)?$defaultValues['Conj And Lids OS']:null, array('class'=> 'form-control select2','data-live-search'=>'true'))); ?>

</div>
<div class="col-md-4">
<button type="button" name="add" id="conjbtn" class="btn btn-success  set-dropdown-options"  data-field_name="Conj And Lids OS" data-form_name="EyeForm" >Set Option </button>
<button type='button' class="btn btn-primary" id='conjbtnsave'>Save Option</button>
<button id="AC" class="btn btn-default addmore" data-templateDiv="ACTemplate">Add</button>
</div>
</div>

</div>
<div id='ConjTextBoxesGroup' class="col-md-12">

</div>

<!-- ================================================================================= -->

<!-- set-dropdown-options -->
<!-- <span class="dropdown-container"> -->
<div class='dropdown-options-initial-div' class="col-md-12" style="display:none;">
<?php  
$dropdown_options_field_name = 'Conj And Lids OS';
$dropdown_options_form_name = 'EyeForm';
 ?>

</div>
</span>
<!-- ================================================================================= -->
<div class="dbMultiEntryContainer">
<?php $__currentLoopData = $form_details->eyeformmultipleentry()->where('field_name', 'ConjAndLids')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="col-md-12">
<div class="col-md-2">
</div>
<div class="col-md-3">
<input type="text" class="form-control" readonly value="<?php echo e($item->field_value_OD); ?>">
</div>
<div class="col-md-3">
<input type="text" class="form-control" readonly value="<?php echo e($item->field_value_OS); ?>">
</div>
<div class="col-md-2">
<button class="removeDbItem btn btn-default" data-deleteid="<?php echo e($item->id); ?>">Remove</button>
</div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<span class="dropdown-container">
<div id="IRIS" class="ContainerToAppend">
<div class="col-md-12">
<div class="col-md-2">
<div class="form-group labelgrp">
<label>Cornea</label>
</div>
<input type="hidden" id="IRIS[]" name="IRIS[]" class="hiddenCounter" value="1" />   
</div>

<div class="col-md-3">
<?php echo e(Form::select('cornia_od[]', array(' '=>'-Select-') + $form_dropdowns->where('fieldName', 'Cornea OD')->pluck('ddText','ddText')->toArray(), array_key_exists('Cornea OD', $defaultValues)?$defaultValues['Cornea OD']:null, array('class'=> 'form-control select2','data-live-search'=>'true'))); ?>

</div>

<div class="col-md-3">
<?php echo e(Form::select('cornia_os[]', array(' '=>'-Select-') + $form_dropdowns->where('fieldName', 'Cornea OS')->pluck('ddText','ddText')->toArray(), array_key_exists('Cornea OS', $defaultValues)?$defaultValues['Cornea OS']:null, array('class'=> 'form-control select2','data-live-search'=>'true'))); ?>

</div>

<div class="col-md-4">
<button type="button" name="add" id="corneabtn" class="btn btn-success  set-dropdown-options"  data-field_name="Cornea OD" data-form_name="EyeForm" >Set Option </button>
<button type='button' class="btn btn-primary" id='corneabtnsave'>Save Option</button>
<button id="IRIS" class="btn btn-default addmore" data-templateDiv="IRISTemplate">Add</button>
</div>
</div>

</div>
<div id='CorneaTextBoxesGroup' class="col-md-12">

</div>

<!-- ================================================================================= -->

<!-- set-dropdown-options -->
<!-- <span class="dropdown-container"> -->
<div class='dropdown-options-initial-div' class="col-md-12" style="display:none;">
<?php  
$dropdown_options_field_name = 'Cornea OD';
$dropdown_options_form_name = 'EyeForm';
 ?>

</div>
</span>
<!-- ================================================================================= -->
<div class="dbMultiEntryContainer">
<?php $__currentLoopData = $form_details->eyeformmultipleentry()->where('field_name', 'cornia')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="col-md-12">
<div class="col-md-2">
</div>
<div class="col-md-3">
<input type="text" class="form-control" readonly value="<?php echo e($item->field_value_OD); ?>">
</div>
<div class="col-md-3">
<input type="text" class="form-control" readonly value="<?php echo e($item->field_value_OS); ?>">
</div>
<div class="col-md-2">
<button class="removeDbItem btn btn-default" data-deleteid="<?php echo e($item->id); ?>">Remove</button>
</div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<div class="col-md-12">
<div class="col-md-2">

</div>

<div class="col-md-5">

<div class="col-md-6">
<div class="example1" data-example="OdImg1">
<div class="board" id="OdImg1_canvas"></div>
</div>
<input type="hidden" name="OdImg1" id="OdImg1"/>
</div>

<div class="col-md-6">
<?php if(!empty($form_details->OdImg1) && !is_null($form_details->OdImg1)): ?>   
<button type="button" value="OdImg1" class="ImageDelete pull-right" >Delete</button>
<p>&nbsp;</p>
<center id="wPaint-OdImg1"> 
<img src=<?php echo e(Storage::disk('local')->url($form_details->OdImg1)."?".filemtime(Storage::path($form_details->OdImg1))); ?> class="img-rounded" alt="Image Not found" width="100%" height="100%" />
</center>
<?php endif; ?>
</div>
</div>

<div class="col-md-5">
<div class="col-md-6">
<div class="example1" data-example1="OsImg1">
<div class="board" id="OsImg1_canvas">
</div>
</div>
<input type="hidden" name="OsImg1" id="OsImg1"/>
</div>
<div class="col-md-6">
<?php if(!empty($form_details->OsImg1) && !is_null($form_details->OsImg1)): ?>
<button type="button" value="OsImg1" class="ImageDelete pull-right" >Delete</button>
<p>&nbsp;</p>
<center id="wPaint-OsImg1"> 
<img src=<?php echo e(Storage::disk('local')->url($form_details->OsImg1)."?".filemtime(Storage::path($form_details->OsImg1))); ?> class="img-rounded" alt="Image Not found" width="100%" height="100%" />  
</center>
<?php endif; ?>
</div>
</div>
</div>

<span class="dropdown-container">
<div id="sac" class="ContainerToAppend">
<div class="col-md-12">
<div class="col-md-2">
<div class="form-group labelgrp">
<label>AC</label>
</div>
<input type="hidden" id="sac[]" name="sac[]" class="hiddenCounter" value="1" />   
</div>

<div class="col-md-3">
<?php echo e(Form::select('AC_OD[]', array(' '=>'-Select-') + $form_dropdowns->where('fieldName', 'AC OD')->pluck('ddText','ddText')->toArray(), array_key_exists('AC OD', $defaultValues)?$defaultValues['AC OD']:null, array('class'=> 'form-control select2','data-live-search'=>'true'))); ?>

</div>

<div class="col-md-3">
<?php echo e(Form::select('AC_OS[]', array(' '=>'-Select-') + $form_dropdowns->where('fieldName', 'AC OS')->pluck('ddText','ddText')->toArray(), array_key_exists('AC OS', $defaultValues)?$defaultValues['AC OS']:null, array('class'=> 'form-control select2','data-live-search'=>'true'))); ?>

</div>

<div class="col-md-4">
<button type="button" name="add" id="ac1abtn" class="btn btn-success  set-dropdown-options"  data-field_name="AC OD" data-form_name="EyeForm" >Set Option </button>
<button type='button' class="btn btn-primary" id='ac1btnsave'>Save Option</button>
<button id="sac" class="btn btn-default addmore" data-templateDiv="sacTemplate">Add</button>
</div>

</div>

</div>
<div id='AC1TextBoxesGroup' class="col-md-12">

</div>

<!-- ================================================================================= -->

<!-- set-dropdown-options -->
<!-- <span class="dropdown-container"> -->
<div class='dropdown-options-initial-div' class="col-md-12" style="display:none;">
<?php  
$dropdown_options_field_name = 'AC OD';
$dropdown_options_form_name = 'EyeForm';
 ?>

</div>
</span>
<!-- ================================================================================= -->
<div class="dbMultiEntryContainer">
<?php $__currentLoopData = $form_details->eyeformmultipleentry()->where('field_name', 'AC')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="col-md-12">
<div class="col-md-2">
</div>
<div class="col-md-3">
<input type="text" class="form-control" readonly value="<?php echo e($item->field_value_OD); ?>">
</div>
<div class="col-md-3">
<input type="text" class="form-control" readonly value="<?php echo e($item->field_value_OS); ?>">
</div>
<div class="col-md-2">
<button class="removeDbItem btn btn-default" data-deleteid="<?php echo e($item->id); ?>">Remove</button>
</div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<span class="dropdown-container">
<div id="Retina" class="ContainerToAppend">
<div class="col-md-12">
<div class="col-md-2">
<div class="form-group labelgrp">
<label>Iris</label>
</div>
<input type="hidden" id="Retina[]" name="Retina[]" class="hiddenCounter" value="1" />   
</div>
<div class="col-md-3">
<?php echo e(Form::select('IRIS_OD[]', array(' '=>'-Select-') + $form_dropdowns->where('fieldName', 'IRIS OD')->pluck('ddText','ddText')->toArray(), array_key_exists('IRIS OD', $defaultValues)?$defaultValues['IRIS OD']:null, array('class'=> 'form-control select2','data-live-search'=>'true'))); ?>

</div>
<div class="col-md-3">
<?php echo e(Form::select('IRIS_OS[]', array(' '=>'-Select-') + $form_dropdowns->where('fieldName', 'IRIS OS')->pluck('ddText','ddText')->toArray(), array_key_exists('IRIS OS', $defaultValues)?$defaultValues['IRIS OS']:null, array('class'=> 'form-control select2','data-live-search'=>'true'))); ?>

</div>
<div class="col-md-4">
<button type="button" name="add" id="irisbtn" class="btn btn-success  set-dropdown-options"  data-field_name="IRIS OD" data-form_name="EyeForm" >Set Option </button>
<button type='button' class="btn btn-primary" id='irisbtnsave'>Save Option</button>
<button id="Retina" class="btn btn-default addmore" data-templateDiv="RetinaTemplate">Add</button>
</div>
</div>

</div>
<div id='IrisTextBoxesGroup' class="col-md-12">

</div>

<!-- ================================================================================= -->

<!-- set-dropdown-options -->
<!-- <span class="dropdown-container"> -->
<div class='dropdown-options-initial-div' class="col-md-12" style="display:none;">
<?php  
$dropdown_options_field_name = 'IRIS OD';
$dropdown_options_form_name = 'EyeForm';
 ?>

</div>
</span>
<!-- ================================================================================= -->
<div class="dbMultiEntryContainer">
<?php $__currentLoopData = $form_details->eyeformmultipleentry()->where('field_name', 'IRIS')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="col-md-12">
<div class="col-md-2">
</div>
<div class="col-md-3">
<input type="text" class="form-control" readonly value="<?php echo e($item->field_value_OD); ?>">
</div>
<div class="col-md-3">
<input type="text" class="form-control" readonly value="<?php echo e($item->field_value_OS); ?>">
</div>
<div class="col-md-2">
<button class="removeDbItem btn btn-default" data-deleteid="<?php echo e($item->id); ?>">Remove</button>
</div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<span class="dropdown-container">
<div id="Macula" class="ContainerToAppend">
<div class="col-md-12">
<div class="col-md-2">
<div class="form-group labelgrp">
<label>Pupil</label>
</div>
<input type="hidden" id="Macula[]" name="Macula[]" class="hiddenCounter" value="1" /> 
</div>
<div class="col-md-3">
<?php echo e(Form::select('pupilIrisac_OD[]', array(' '=>'-Select-') + $form_dropdowns->where('fieldName', 'pupilIrisac OD')->pluck('ddText','ddText')->toArray(), array_key_exists('pupilIrisac OD', $defaultValues)?$defaultValues['pupilIrisac OD']:null, array('class'=> 'form-control select2','data-live-search'=>'true'))); ?>

</div>
<div class="col-md-3">
<?php echo e(Form::select('pupilIrisac_OS[]', array(' '=>'-Select-') + $form_dropdowns->where('fieldName', 'pupilIrisac OS')->pluck('ddText','ddText')->toArray(), array_key_exists('pupilIrisac OS', $defaultValues)?$defaultValues['pupilIrisac OS']:null, array('class'=> 'form-control select2','data-live-search'=>'true'))); ?>

</div>
<div class="col-md-4">
<button type="button" name="add" id="pupilbtn" class="btn btn-success  set-dropdown-options"  data-field_name="pupilIrisac OD" data-form_name="EyeForm" >Set Option </button>
<button type='button' class="btn btn-primary" id='pupilbtnsave'>Save Option</button>
<button id="Macula" class="btn btn-default addmore" data-templateDiv="MaculaTemplate">Add</button>
</div>
</div>

</div>
<div id='PupilTextBoxesGroup' class="col-md-12">

</div>

<!-- ================================================================================= -->

<!-- set-dropdown-options -->
<!-- <span class="dropdown-container"> -->
<div class='dropdown-options-initial-div' class="col-md-12" style="display:none;">
<?php  
$dropdown_options_field_name = 'pupilIrisac OD';
$dropdown_options_form_name = 'EyeForm';
 ?>

</div>
</span>
<!-- ================================================================================= -->
<div class="dbMultiEntryContainer">
<?php $__currentLoopData = $form_details->eyeformmultipleentry()->where('field_name', 'pupilIrisac')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="col-md-12">
<div class="col-md-2">
</div>
<div class="col-md-3">
<input type="text" class="form-control" readonly value="<?php echo e($item->field_value_OD); ?>">
</div>
<div class="col-md-3">
<input type="text" class="form-control" readonly value="<?php echo e($item->field_value_OS); ?>">
</div>
<div class="col-md-2">
<button class="removeDbItem btn btn-default" data-deleteid="<?php echo e($item->id); ?>">Remove</button>
</div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<span class="dropdown-container">
<div id="ONH" class="ContainerToAppend">
<div class="col-md-12">
<div class="col-md-2">
<div class="form-group labelgrp">
<label>Lens</label>
</div>
<input type="hidden" id="ONH[]" name="ONH[]" class="hiddenCounter" value="1" />   
</div>
<div class="col-md-3">
<?php echo e(Form::select('lens_od[]', array('Select '=>'-Select-') + $form_dropdowns->where('fieldName', 'lens OD')->pluck('ddText','ddText')->toArray(), array_key_exists('lens OD', $defaultValues)?$defaultValues['lens OD']:null, array('class'=> 'form-control select2','data-live-search'=>'true'))); ?>

</div>
<div class="col-md-3">
<?php echo e(Form::select('lense_os[]', array(' '=>'-Select-') + $form_dropdowns->where('fieldName', 'lens OS')->pluck('ddText','ddText')->toArray(), array_key_exists('lens OS', $defaultValues)?$defaultValues['lens OS']:null, array('class'=> 'form-control select2','data-live-search'=>'true'))); ?>

</div>
<div class="col-md-4">
<button type="button" name="add" id="lensbtn" class="btn btn-success  set-dropdown-options"  data-field_name="lens OD" data-form_name="EyeForm" >Set Option </button>
<button type='button' class="btn btn-primary" id='lensbtnsave'>Save Option</button>
<button id="ONH" class="btn btn-default addmore" data-templateDiv="ONHTemplate">Add</button>
</div>
</div>

</div>
<div id='LensTextBoxesGroup' class="col-md-12">

</div>

<!-- ================================================================================= -->

<!-- set-dropdown-options -->
<!-- <span class="dropdown-container"> -->
<div class='dropdown-options-initial-div' class="col-md-12" style="display:none;">
<?php  
$dropdown_options_field_name = 'lens OD';
$dropdown_options_form_name = 'EyeForm';
 ?>

</div>
</span>
<!-- ================================================================================= -->
<div class="dbMultiEntryContainer">
<?php $__currentLoopData = $form_details->eyeformmultipleentry()->where('field_name', 'lens')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="col-md-12">
<div class="col-md-2">
</div>
<div class="col-md-3">
<input type="text" class="form-control" readonly value="<?php echo e($item->field_value_OD); ?>">
</div>
<div class="col-md-3">
<input type="text" class="form-control" readonly value="<?php echo e($item->field_value_OS); ?>">
</div>
<div class="col-md-2">
<button class="removeDbItem btn btn-default" data-deleteid="<?php echo e($item->id); ?>">Remove</button>
</div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<div class="col-md-12">
<div class="col-md-2">
<div class="form-group labelgrp">
<label>Fundus</label>
</div>
</div>
<div class="col-md-5">
<div class="col-md-6">
<div class="example1" data-example="OdImg2">
<div class="board" id="OdImg2_canvas" ></div>
</div>
<input type="hidden" name="OdImg2" id="OdImg2"/>
</div>
<div class="col-md-6">
<?php if(!empty($form_details->OdImg2) && !is_null($form_details->OdImg2)): ?>
<button type="button" value="OdImg2" class="ImageDelete pull-right" >Delete</button>
<p>&nbsp;</p>
<center id="wPaint-OdImg2"> 
<img src=<?php echo e(Storage::disk('local')->url($form_details->OdImg2)."?".filemtime(Storage::path($form_details->OdImg2))); ?> class="img-rounded" alt="Image Not found" width="100%" height="100%" />  
</center>
<?php endif; ?>
</div>
</div>

<div class="col-md-5">
<div class="col-md-6">
<div class="example1" data-example="OsImg2">
<div class="board" id="OsImg2_canvas"></div>
</div>
<input type="hidden" name="OsImg2" id="OsImg2"/>
</div>
<div class="col-md-6">
<?php if(!empty($form_details->OsImg2) && !is_null($form_details->OsImg2)): ?>
<button type="button" value="OsImg2" class="ImageDelete pull-right" >Delete</button>
<p>&nbsp;</p>
<center id="wPaint-OsImg2"> 
<img src=<?php echo e(Storage::disk('local')->url($form_details->OsImg2)."?".filemtime(Storage::path($form_details->OsImg2))); ?> class="img-rounded" alt="Image Not found" width="100%" height="100%" />  
</center>
<?php endif; ?>
</div>
</div>
</div>

<span class="dropdown-container">
<div id="OrbitSacsEyeMotility1" class="ContainerToAppend">
<div class="col-md-12">
<div class="col-md-2">
<div class="form-group labelgrp">
<label>Vitreins</label>
<input type="hidden" id="OrbitSacsEyeMotility[]" name="OrbitSacsEyeMotility[]" class="hiddenCounter" value="1" /> 
</div>  
</div>
<div class="col-md-3">
<?php echo e(Form::select('vitreoretinal_OD[]', array(' '=>'-Select-') + $form_dropdowns->where('fieldName', 'vitreoretinal OD')->pluck('ddText','ddText')->toArray(), array_key_exists('vitreoretinal OD', $defaultValues)?$defaultValues['vitreoretinal OD']:null, array('class'=> 'form-control select2','data-live-search'=>'true'))); ?>

</div>
<div class="col-md-3">
<?php echo e(Form::select('vitreoretinal_OS[]', array(' '=>'-Select-') + $form_dropdowns->where('fieldName', 'vitreoretinal OS')->pluck('ddText','ddText')->toArray(), array_key_exists('vitreoretinal OS', $defaultValues)?$defaultValues['vitreoretinal OS']:null, array('class'=> 'form-control select2','data-live-search'=>'true'))); ?>

</div>
<div class="col-md-4">
<button type="button" name="add" id="vitreobtn" class="btn btn-success  set-dropdown-options"  data-field_name="vitreoretinal OD" data-form_name="EyeForm" >Set Option </button>
<button type='button' class="btn btn-primary" id='vitreobtnsave'>Save Option</button>
<button id="OrbitSacsEyeMotility" class="btn btn-default addmore" data-templateDiv="OrbitSacsEyeMotilityTemplate">Add</button>
</div>
</div>

</div>
<div id='VitreoTextBoxesGroup' class="col-md-12">

</div>

<!-- ================================================================================= -->

<!-- set-dropdown-options -->
<!-- <span class="dropdown-container"> -->
<div class='dropdown-options-initial-div' class="col-md-12" style="display:none;">
<?php  
$dropdown_options_field_name = 'vitreoretinal OD';
$dropdown_options_form_name = 'EyeForm';
 ?>

</div>
</span>
<!-- ================================================================================= -->
<div class="dbMultiEntryContainer">
<?php $__currentLoopData = $form_details->eyeformmultipleentry()->where('field_name', 'vitreoretinal')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="col-md-12">
<div class="col-md-2">
</div>
<div class="col-md-3">
<input type="text" class="form-control" readonly value="<?php echo e($item->field_value_OD); ?>">
</div>
<div class="col-md-3">
<input type="text" class="form-control" readonly value="<?php echo e($item->field_value_OS); ?>">
</div>
<div class="col-md-2">
<button class="removeDbItem btn btn-default" data-deleteid="<?php echo e($item->id); ?>">Remove</button>
</div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<span class="dropdown-container">
<div id="cornia" class="ContainerToAppend">
<div class="col-md-12">
<div class="col-md-2">
<div class="form-group labelgrp">
<label>Retina</label>
</div>
<input type="hidden" id="cornia[]" name="cornia[]" class="hiddenCounter" value="1" />  
</div>
<div class="col-md-3">
<?php echo e(Form::select('Retina_OD[]', array(' '=>'-Select-') + $form_dropdowns->where('fieldName', 'Retina OD')->pluck('ddText','ddText')->toArray(), array_key_exists('Retina OD', $defaultValues)?$defaultValues['Retina OD']:null, array('class'=> 'form-control select2','data-live-search'=>'true'))); ?>

</div>
<div class="col-md-3">
<?php echo e(Form::select('Retina_OS[]', array(' '=>'-Select-') + $form_dropdowns->where('fieldName', 'Retina OS')->pluck('ddText','ddText')->toArray(), array_key_exists('Retina OS', $defaultValues)?$defaultValues['Retina OS']:null, array('class'=> 'form-control select2','data-live-search'=>'true'))); ?>

</div>
<div class="col-md-4">
<button type="button" name="add" id="retinabtn" class="btn btn-success  set-dropdown-options"  data-field_name="Retina OD" data-form_name="EyeForm" >Set Option </button>
<button type='button' class="btn btn-primary" id='retinabtnsave'>Save Option</button>
<button id="cornia" class="btn btn-default addmore" data-templateDiv="corniaTemplate">Add</button>
</div>
</div>

</div>
<div id='RetinaTextBoxesGroup' class="col-md-12">

</div>

<!-- ================================================================================= -->

<!-- set-dropdown-options -->
<!-- <span class="dropdown-container"> -->
<div class='dropdown-options-initial-div' class="col-md-12" style="display:none;">
<?php  
$dropdown_options_field_name = 'Retina OD';
$dropdown_options_form_name = 'EyeForm';
 ?>

</div>
</span>
<!-- ================================================================================= -->
<div class="dbMultiEntryContainer">
<?php $__currentLoopData = $form_details->eyeformmultipleentry()->where('field_name', 'Retina')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="col-md-12">
<div class="col-md-2">
</div>
<div class="col-md-3">
<input type="text" class="form-control" readonly value="<?php echo e($item->field_value_OD); ?>">
</div>
<div class="col-md-3">
<input type="text" class="form-control" readonly value="<?php echo e($item->field_value_OS); ?>">
</div>
<div class="col-md-2">
<button class="removeDbItem btn btn-default" data-deleteid="<?php echo e($item->id); ?>">Remove</button>
</div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<span class="dropdown-container">
<div id="pupilIrisac" class="ContainerToAppend">
<div class="col-md-12">
<div class="col-md-2">
<div class="form-group labelgrp">
<label>ONH</label>
</div>
<input type="hidden" id="pupilIrisac[]" name="pupilIrisac[]" class="hiddenCounter" value="1" />
</div>
<div class="col-md-3">
<?php echo e(Form::select('ONH_OD[]', array(' '=>'-Select-') + $form_dropdowns->where('fieldName', 'ONH OD')->pluck('ddText','ddText')->toArray(), array_key_exists('ONH OD', $defaultValues)?$defaultValues['ONH OD']:null, array('class'=> 'form-control select2','data-live-search'=>'true'))); ?>

</div>
<div class="col-md-3">
<?php echo e(Form::select('ONH_OS[]', array(' '=>'-Select-') + $form_dropdowns->where('fieldName', 'ONH OS')->pluck('ddText','ddText')->toArray(), array_key_exists('ONH OS', $defaultValues)?$defaultValues['ONH OS']:null, array('class'=> 'form-control select2','data-live-search'=>'true'))); ?>

</div>
<div class="col-md-4">
<button type="button" name="add" id="onhbtn" class="btn btn-success  set-dropdown-options"  data-field_name="ONH OD" data-form_name="EyeForm" >Set Option </button>
<button type='button' class="btn btn-primary" id='onhbtnsave'>Save Option</button>
<button id="pupilIrisac" class="btn btn-default addmore" data-templateDiv="pupilIrisacTemplate">Add</button>
</div>
</div>

</div>
<div id='ONHTextBoxesGroup' class="col-md-12">

</div>

<!-- ================================================================================= -->

<!-- set-dropdown-options -->
<!-- <span class="dropdown-container"> -->
<div class='dropdown-options-initial-div' class="col-md-12" style="display:none;">
<?php  
$dropdown_options_field_name = 'ONH OD';
$dropdown_options_form_name = 'EyeForm';
 ?>

</div>
</span>
<!-- ================================================================================= -->
<div class="dbMultiEntryContainer">
<?php $__currentLoopData = $form_details->eyeformmultipleentry()->where('field_name', 'ONH')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="col-md-12">
<div class="col-md-2">
</div>
<div class="col-md-3">
<input type="text" class="form-control" readonly value="<?php echo e($item->field_value_OD); ?>">
</div>
<div class="col-md-3">
<input type="text" class="form-control" readonly value="<?php echo e($item->field_value_OS); ?>">
</div>
<div class="col-md-2">
<button class="removeDbItem btn btn-default" data-deleteid="<?php echo e($item->id); ?>">Remove</button>
</div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<span class="dropdown-container">
<div id="lens" class="ContainerToAppend">
<div class="col-md-12">
<div class="col-md-2">
<div class="form-group labelgrp">
<label>Macula</label>
</div>
<input type="hidden" id="lens[]" name="lens[]" class="hiddenCounter" value="1" />  
</div>
<div class="col-md-3">
<?php echo e(Form::select('Macula_OD[]', array(' '=>'-Select-') + $form_dropdowns->where('fieldName', 'Macula OD')->pluck('ddText','ddText')->toArray(), array_key_exists('Macula OD', $defaultValues)?$defaultValues['Macula OD']:null, array('class'=> 'form-control select2','data-live-search'=>'true'))); ?>

</div>
<div class="col-md-3">
<?php echo e(Form::select('Macula_OS[]', array(' '=>'-Select-') + $form_dropdowns->where('fieldName', 'Macula OS')->pluck('ddText','ddText')->toArray(), array_key_exists('Macula OS', $defaultValues)?$defaultValues['Macula OS']:null, array('class'=> 'form-control select2','data-live-search'=>'true'))); ?>

</div>
<div class="col-md-4">
<button type="button" name="add" id="maculabtn" class="btn btn-success  set-dropdown-options"  data-field_name="Macula OD" data-form_name="EyeForm" >Set Option </button>
<button type='button' class="btn btn-primary" id='maculabtnsave'>Save Option</button>
<button id="lens" class="btn btn-default addmore" data-templateDiv="lensTemplate">Add</button>
</div>
</div>

</div>
<div id='MaculaTextBoxesGroup' class="col-md-12">

</div>

<!-- ================================================================================= -->

<!-- set-dropdown-options -->
<!-- <span class="dropdown-container"> -->
<div class='dropdown-options-initial-div' class="col-md-12" style="display:none;">
<?php  
$dropdown_options_field_name = 'Macula OD';
$dropdown_options_form_name = 'EyeForm';
 ?>

</div>
</span>
<!-- ================================================================================= -->
<div class="dbMultiEntryContainer">
<?php $__currentLoopData = $form_details->eyeformmultipleentry()->where('field_name', 'Macula')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="col-md-12">
<div class="col-md-2">
</div>
<div class="col-md-3">
<input type="text" class="form-control" readonly value="<?php echo e($item->field_value_OD); ?>">
</div>
<div class="col-md-3">
<input type="text" class="form-control" readonly value="<?php echo e($item->field_value_OS); ?>">
</div>
<div class="col-md-2">
<button class="removeDbItem btn btn-default" data-deleteid="<?php echo e($item->id); ?>">Remove</button>
</div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<span class="dropdown-container">
<div id="vitreoretinal" class="ContainerToAppend">
<div class="col-md-12">
<div class="col-md-2">
<div class="form-group labelgrp">
<label>Sac</label>
<input type="hidden" id="vitreoretinal[]" name="vitreoretinal[]" class="hiddenCounter" value="1" />
</div>
</div>
<div class="col-md-3">
<?php echo e(Form::select('sac_OD[]', array(' '=>'-Select-') + $form_dropdowns->where('fieldName', 'sac OD')->pluck('ddText','ddText')->toArray(), array_key_exists('sac OD', $defaultValues)?$defaultValues['sac OD']:null, array('class'=> 'form-control select2','data-live-search'=>'true'))); ?>

</div>
<div class="col-md-3">
<?php echo e(Form::select('sac_OS[]', array(' '=>'-Select-') + $form_dropdowns->where('fieldName', 'sac OS')->pluck('ddText','ddText')->toArray(), array_key_exists('sac OS', $defaultValues)?$defaultValues['sac OS']:null, array('class'=> 'form-control select2','data-live-search'=>'true'))); ?>

</div>
<div class="col-md-4">
<button type="button" name="add" id="sacbtn" class="btn btn-success  set-dropdown-options"  data-field_name="sac OD" data-form_name="EyeForm" >Set Option </button>
<button type='button' class="btn btn-primary waves-effect"  id='sacbtnsave'>Save Option</button>
<button id="vitreoretinal" class="btn btn-default addmore" data-templateDiv="vitreoretinalTemplate">Add</button>
</div>
</div>

</div>
<div id='SacTextBoxesGroup' class="col-md-12">

</div>

<!-- ================================================================================= -->

<!-- set-dropdown-options -->
<!-- <span class="dropdown-container"> -->
<div class='dropdown-options-initial-div' class="col-md-12" style="display:none;">
<?php  
$dropdown_options_field_name = 'sac OD';
$dropdown_options_form_name = 'EyeForm';
 ?>

</div>
</span>
<!-- ================================================================================= -->

<div class="dbMultiEntryContainer">
<?php $__currentLoopData = $form_details->eyeformmultipleentry()->where('field_name', 'sac')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="col-md-12">
<div class="col-md-2">
</div>
<div class="col-md-3">
<input type="text" class="form-control" readonly value="<?php echo e($item->field_value_OD); ?>"/>
</div>
<div class="col-md-3">
<input type="text" class="form-control" readonly value="<?php echo e($item->field_value_OS); ?>"/>
</div>
<div class="col-md-2">
<button class="removeDbItem btn btn-default" data-deleteid="<?php echo e($item->id); ?>">Remove</button>
</div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<div class="col-md-12 custom-item-parent-div">
<div class="row custom-item">
<div class="col-md-4">
<select class="custom-item-dropdown form-control select2">
<option value="">Select Option</option>

<option value="Lids" data-title="Lids" data-od="1" data-os="1">Lids</option>
<option value="Orbit" data-title="Orbit" data-od="1" data-os="1">Orbit</option>

<option value="ConjAndLids" data-title="Conj" data-od="1" data-os="1">Conj</option>
<option value="cornia" data-title="Cornea" data-od="1" data-os="1">Cornea</option>

<option value="AC" data-title="AC" data-od="1" data-os="1">AC</option>
<option value="IRIS" data-title="Iris" data-od="1" data-os="1">Iris</option>

<option value="pupilIrisac" data-title="Pupil" data-od="1" data-os="1">Pupil</option>
<option value="lens" data-title="Lens" data-od="1" data-os="1">Lens</option>

<option value="vitreoretinal" data-title="Vitreins" data-od="1" data-os="1">Vitreins</option>
<option value="Retina" data-title="Retina" data-od="1" data-os="1">Retina</option>

<option value="ONH" data-title="ONH" data-od="1" data-os="1">ONH</option>
<option value="Macula" data-title="Macula" data-od="1" data-os="1">Macula</option>


<option value="sac" data-title="Sac" data-od="1" data-os="1">Sac</option>
</select>
</div>
<div class="col-md-3">

</div>
<div class="col-md-3">

</div>
<div class="col-md-2">
<span class="add-custom-item btn btn-default">Add</span>
</div>
</div>
<div class="custom-item-container">

</div>
</div>                                
<div class="col-md-12">
<div class="col-md-6 col-md-offset-4">
<div class="form-group">
<button type="submit" formaction="<?php echo e(url('/patientDetails/SaveEyeExamination')); ?>" type="submit" name="submit" class="btn btn-primary btn-lg" value="submit">Submit</button>
<button type="submit" formaction="<?php echo e(url('/patientDetails/SaveEyeExamination1')); ?>" name="submit" class="btn btn-primary btn-lg" value="submit">Submit & View
</button>                                       
</div>
</div>
</div>

