<?php $__env->startSection('style'); ?>
<style>
    @media  screen and (max-width: 767px) {
        .select2 {
            width: 100% !important;
        }
    }
    .ui-autocomplete-loading {
        background: white url("<?php echo e(asset('images/ui-anim_basic_16x16.gif')); ?>") right center no-repeat;
    }

    .canvas{
        position:relative; width:150px; height:200px; background-color:#7a7a7a; margin:70px auto 20px auto;
    }

</style>
<link href="<?php echo e(url('/')); ?>/select2/css/select2.min.css" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
<div class="list-group list-group-horizontal">
        <?php $__empty_1 = true; $__currentLoopData = $DateWiseRecordLst; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $VisitListDateWise): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php if($case_master['id'] == $VisitListDateWise['id']): ?>
                    <a href="<?php echo e(url('/eyeOperationRecord').'/'.$VisitListDateWise['id'].'/edit'); ?>" class="list-group-item active"><?php echo e(Carbon\Carbon::parse($VisitListDateWise['created_at'])->format('d-M-Y')); ?></a> <span> &nbsp;</span>    
                <?php else: ?>
                    <a href="<?php echo e(url('/eyeOperationRecord').'/'.$VisitListDateWise['id'].'/edit'); ?>" class="list-group-item"><?php echo e(Carbon\Carbon::parse($VisitListDateWise['created_at'])->format('d-M-Y')); ?></a> <span> &nbsp;</span>
                <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

</div>
<div class="container-fluid">
<div class="row clearfix">
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
<div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <?php echo $__env->make('shared.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                          <?php if(Session::has('flash_message')): ?>
                          <div class="alert alert-success">
                          <?php echo e(Session::get('flash_message')); ?>

                          </div>
                          <?php endif; ?>


       

<div class="card">
<div class="header bg-pink">
<h2> Operation Record </h2>
</div>
     
<div class="body">
<div class="row clearfix ">

 <form action="<?php echo e(url('/eyeOperationRecord'.( isset($case_master) ? "/" . $case_master['id'] : ""))); ?>" method="POST" class="form-horizontal" enctype = 'multipart/form-data' id="eyeOperationRecord" >
  <?php echo e(csrf_field()); ?>


 <?php if(isset($case_master)): ?>
   <input type="hidden" name="_method" value="PATCH">
<?php endif; ?>

<input type="hidden" id="case_id" name="case_id" value="<?php echo e(isset($case_master['id']) ? $case_master['id'] : ''); ?>" >

                          <div class="col-md-12">
                            <div class="col-md-4">
                              <div class="col-md-3">
                              <div class="form-group labelgrp">
                              <label for="case_number" class="control-label">Case Number</label>
                              </div>
                              </div>

                              <div class="col-md-9">
                              <div class="form-group">
                              <div class="form-line">
                              <input type="text" name="case_number" id="case_number" class="form-control" readonly='readonly' value="<?php echo e(isset($case_master['case_number']) ? $case_master['case_number'] : ''); ?>">                          
                              </div>
                              </div>
                              </div>   
                            </div>
                            <div class="col-md-4">
                              <div class="col-md-2">
                              <div class="form-group labelgrp">
                              <?php echo e(Form::label('IPD_no','IPD no.')); ?> 
                              </div>
                              </div>


                              <div class="col-md-10">
                              <div class="form-group">
                              <div class="form-line">
                              <?php echo e(Form::text('IPD_no', Request::old('IPD_no',$case_master['IPD_no']), array('class' => 'form-control'))); ?>                           
                              </div>
                              </div>
                              </div>                              
                            </div>

                            <div class="col-md-4">

                              <div class="col-md-2">
                              <div class="form-group labelgrp">
                              <?php echo e(Form::label('uhid','UHID No:')); ?> 
                              </div>
                              </div>


                              <div class="col-md-10">
                              <div class="form-group">
                              <div class="form-line">
                              <?php echo e(Form::text('uhid', Request::old('uhid',$case_master['uhid_no']), array('class' => 'form-control ', 'autocomplete'=>'off'))); ?>                      
                              </div>
                              </div>
                              </div>                              
                            </div>
                          </div>
                          <div class="col-md-12">
                            <div class="col-md-6">
                              <div class="col-md-2">
                              <div class="form-group labelgrp">
                              <label for="patient_name" class="control-label">Name Of Patient</label>
                              </div>
                              </div>


                              <div class="col-md-10">
                              <div class="form-group">
                              <div class="form-line">
                              <input type="text" name="patient_name" id="patient_name" class="form-control" readonly='readonly' value="<?php echo e(isset($case_master['patient_name']) ? $case_master['patient_name'] : ''); ?>">                          
                              </div>
                              </div>
                              </div>
                            </div>
                            <div class="col-md-6">
                                <div class="col-md-6">
                                  <div class="col-md-2">
                                  <div class="form-group labelgrp">
                                      <label for="patient_name" class="control-label">Age</label>
                                  </div>
                                  </div>

                                  <div class="col-md-10">
                                      <div class="form-group">
                                          <div class="form-line">
                                              <input type="text" name="patient_name" id="patient_name" class="form-control" readonly='readonly' value="<?php echo e(isset($case_master['patient_age']) ? $case_master['patient_age'] : ''); ?>">                          
                                          </div>
                                      </div>
                                  </div>
                                </div> 
                                <div class="col-md-6">
                                  <div class="col-md-3">
                                  <div class="form-group labelgrp">
                                      <label for="patient_name" class="control-label">Gender</label>
                                  </div>
                                  </div>

                                  <div class="col-md-9">
                                      <div class="form-group">
                                          <div class="form-line">
                                              <input type="text" name="patient_name" id="patient_name" class="form-control" readonly='readonly' value="<?php echo e(isset($case_master['male_female']) ? $case_master['male_female'] : ''); ?>">                          
                                          </div>
                                      </div>
                                  </div>
                                </div>                                                              
                            </div>
                          </div>
                          <div classs="col-md-12">
                              <span class="dropdown-container">
                              <div id="surgery_history" class="ContainerToAppend">
                                <div class="col-md-12">
                                  <div class="col-md-8">
                                    <div class="col-md-3">
                                      <div class="form-group labelgrp">
                                        <label class="">Surgery/Procedure</label> 
                                      </div>
                                      <input type="hidden" id="surgeryHistory[]" name="surgeryHistory[]" class="hiddenCounter" value="1" />  
                                    </div>

                                    <div class="col-md-3">
                                      <?php echo e(Form::select('Surgery[]', array(' '=>'-Select-') + $form_dropdownsEye->where('fieldName', 'surgery_history')->pluck('ddText','ddText')->toArray(), array_key_exists('surgery_history', $defaultValues)?$defaultValues['surgery_history']:null, array('class'=> 'form-control select2','data-live-search'=>'true'))); ?>

                                    </div>

                                    <div class="col-md-6">
                                      <button type="button" name="add" id='surgerysetbtn' class="btn btn-success set-dropdown-options" data-field_name="Systemic History OD" data-form_name="commanForm">Set Option </button>

                                      <button type='button' class="btn btn-primary" id='surgerybtnsave'>Save Option</button>

                                      <button id="addSystemicHistory" class="btn btn-default addmore" data-templateDiv="surgerytemplate">Add</button>
                                    </div>
                                  </div>
                                  <div class="col-md-4"> 
                                    <div class="col-md-6">
                                    <div class="form-group labelgrp">
                                    <?php echo e(Form::label('admission_date_time','Admission Date & Time')); ?> 
                                    </div>
                                    </div>


                                    <div class="col-md-6">
                                    <div class="form-group">
                                    <div class="form-line">
                                    <?php echo e(Form::text('admission_date_time', Request::old('admission_date_time',$case_master['admission_date_time']), array('class' => 'form-control datetimepicker', 'autocomplete'=>'off'))); ?>                      
                                    </div>
                                    </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                              <div id='surgeryTextBoxesGroup' class="col-md-12">

                              </div>
                               <div class="dbMultiEntryContainer">
                                 <?php $__currentLoopData = $surgeryDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-12">
                                        <div class="col-md-2">
                                        </div>
                                        <div class="col-md-4">
                                        <input type="text" class="form-control" readonly value="<?php echo e($item->text); ?>">
                                        </div>
                                        <div class="col-md-2">
                                        <button class="removeDbItemSurgery btn btn-default" data-deleteid="<?php echo e($item->id); ?>" data-type="surgery_history">Remove</button>
                                        </div>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                              </span> 
                              <div id="templateContainner" style="display:none">
                                <div id="surgerytemplate">
                                    <div class="col-md-12">
                                            <div class="col-md-2">
                                                <input type="hidden" id="surgeryHistory[]" name="surgeryHistory[]" class="hiddenCounter" value="" />
                                            </div>
                                            <div class="col-md-4">
                                                <?php echo e(Form::select('Surgery[]', array(' '=>'-Select-') + $form_dropdownsEye->where('fieldName', 'surgery_history')->pluck('ddText','ddText')->toArray(), array_key_exists('surgery_history', $defaultValues)?$defaultValues['surgery_history']:null, array('class'=> 'form-control Dyselect2','data-live-search'=>'true'))); ?>

                                
                                            </div>
                                           
                                            <div class="col-md-2">
                                                <button class="removeItem btn btn-default" data-loading-text="<i class='fa fa-spinner fa-spin '></i> Processing..">Remove</button>
                                            </div>
                                    </div>
                                </div>  
                              </div>     
                            </div>


                            <script>

                          $(document).ready(function(){
                            var surgerycnt = 1;
                            $("#surgerysetbtn").click(function () {

                            if(surgerycnt>10){
                            swal("Only 10 Options Values are allow!");
                            return false;
                            }

                            var newTextBoxDiv='<div class="col-md-3" id="TextBoxDiv'+surgerycnt+'"><div class="input-group"><div class="form-line"><input class="form-control"  type="hidden"  name="fieldName1" value="surgery_history"><input class="form-control"  type="text" id="optionsval'+surgerycnt+'" placeholder="value'+surgerycnt+'" name="optionsval[]"></div><span class="input-group-addon systemichistoryremoveButton" type="button" id="systemichistoryremoveButton" ><i class="fa fa-times" aria-hidden="true"></i></span></div></div>'

                            $("#surgeryTextBoxesGroup").append(newTextBoxDiv);
                            surgerycnt++;
                            });

                            $(document).on('click', '.systemichistoryremoveButton', function(e) {
                          surgerycnt--;
                          var target = $("#surgeryTextBoxesGroup").find("#TextBoxDiv" +surgerycnt);
                          $(target).remove();
                          });

                          $("#surgerybtnsave").click(function () {
                                 
                                  var content=$("#surgeryTextBoxesGroup").val();
                                  if (isEmpty($('#surgeryTextBoxesGroup'))) 
                                  {
                                      swal({
                                      title: "Please Add Some Option by clicking on",
                                      text: "<button style=\"border-radius: 4px !important;\" type='button' class='btn btn-success'>Set Option</button>",
                                      html: true
                                      });
                                  }
                                 else 
                              {
                           var data=$("#eyeOperationRecord").serialize();
                                  event.preventDefault();
                                  $.ajax({
                                      url:'<?php echo e(route("dynamic-field.insert")); ?>',
                                      method:'post',
                                      data:data,
                                      success:function(data)
                                      {
                                       swal({title: "Option For Surgery is saved", text: "Added Successfully!", type: "success"},
                                       function(){ 
                                        location.reload();
                                        }
                                      );
                                      }
                                  })
                              }

                              });
                          });
                          </script>




                           <div class="col-md-12">
                              <div class="col-md-2">
                              <div class="form-group labelgrp">
                              <?php echo e(Form::label('surgery_date_time','Surgery Date & Time')); ?> 
                              </div>
                              </div>


                              <div class="col-md-4">
                              <div class="form-group">
                              <div class="form-line">
                              <?php echo e(Form::text('surgery_date_time', Request::old('surgery_date_time',$case_master['surgery_date_time']), array('class' => 'form-control datetimepicker', 'autocomplete'=>'off'))); ?>                           
                              </div>
                              </div>
                              </div>

                              <div class="col-md-2">
                              <div class="form-group labelgrp">
                              <?php echo e(Form::label('discharge_date_time','Discharge Date & Time ')); ?>

                              </div>
                              </div>


                              <div class="col-md-4">
                              <div class="form-group">
                              <div class="form-line">
                              <?php echo e(Form::text('discharge_date_time', Request::old('discharge_date_time',$case_master['discharge_date_time']), array('class' => 'form-control datetimepicker'))); ?>                           
                              </div>
                              </div>
                              </div>
                          </div>

                            <div class="col-md-12">
                              <div class="col-md-5">
                                <div class="col-md-3">
                                <div class="form-group labelgrp">
                                <?php echo e(Form::label('doctor_in_charge','Doctor-In-Charge')); ?> 
                                </div>
                                </div>


                                <div class="col-md-9">
                                <div class="form-group">
                                <div class="form-line">
                                <?php echo e(Form::select('Surgeon', array(''=>'Please select') + $doctorlist->toArray(), Request::old('Surgeon',$eyeOperationRecord->Surgeon), array('class' => 'form-control select2',  'id'=>'Surgeon','data-live-search'=>'true'))); ?>                          
                                </div>
                                </div>
                                </div>
                            </div>

<!-- ==================================================================================================================================== -->
                        <div classs="col-md-6">
                            <span class="dropdown-container">
                            <div id="classes_history" class="ContainerToAppend">
                              <div class="col-md-7">
                               
                                  <div class="col-md-1">
                                    <div class="form-group labelgrp">
                                      <label class="">Classes</label> 
                                    </div>
                                    <input type="hidden" id="classesHistory[]" name="classesHistory[]" class="hiddenCounter" value="1" />  
                                  </div>

                                  <div class="col-md-4">

                                    <?php echo e(Form::select('classes[]', array(' '=>'-Select-') + $form_dropdownsEye->where('fieldName', 'classes_history')->pluck('ddText','ddText')->toArray(), array_key_exists('classes_history', $defaultValues)?$defaultValues['classes_history']:null, array('class'=> 'form-control select2','data-live-search'=>'true'))); ?>

                                  </div>

                                  <div class="col-md-7">
                                    <button type="button" name="add" id='classsetbtn' class="btn btn-success set-dropdown-options" data-field_name="Systemic History OD" data-form_name="commanForm">Set Option </button>

                                    <button type='button' class="btn btn-primary" id='classbtnsave'>Save Option</button>

                                    <button id="addSystemicHistory" class="btn btn-default addmore" data-templateDiv="classesTemplate">Add</button>
                                  </div>
                               
                                <div class="col-md-3">        </div>
                              </div>
                            </div>
                            <div id='classTextBoxesGroup' class="col-md-12">

                            </div>
                             <div class="dbMultiEntryContainer">
                             <?php if(isset($newDischargeData['classes'])) { ?>
                               <?php $__currentLoopData = $newDischargeData['classes']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <div class="col-md-12">
                                      <div class="col-md-6">
                                      </div>
                                      <div class="col-md-4">
                                      <input type="text" class="form-control" readonly value="<?php echo e($item->field_value); ?>">
                                      </div>
                                      <div class="col-md-2">
                                      <button class="removeDbItem btn btn-default" data-deleteid="<?php echo e($item->id); ?>" data-type="classes_history">Remove</button>
                                      </div>
                                  </div>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                             <?php } ?>
                              </div>
                            </span> 
                            <div id="templateContainner" style="display: none">
                              <div id="classesTemplate">
                                  <div class="col-md-12">
                                          <div class="col-md-6">
                                              <input type="hidden" id="classesHistory[]" name="classesHistory[]" class="hiddenCounter" value="" />
                                          </div>
                                          <div class="col-md-4">

                                              <?php echo e(Form::select('classes[]', array(' '=>'-Select-') + $form_dropdownsEye->where('fieldName', 'classes_history')->pluck('ddText','ddText')->toArray(), array_key_exists('classes_history', $defaultValues)?$defaultValues['classes_history']:null, array('class'=> 'form-control Dyselect2','data-live-search'=>'true'))); ?>

                              
                                          </div>
                                         
                                          <div class="col-md-2">
                                              <button class="removeItem btn btn-default" data-loading-text="<i class='fa fa-spinner fa-spin '></i> Processing..">Remove1</button>
                                          </div>
                                  </div>
                              </div>  
                            </div>     
                          </div>
                        </div>

                          <script>

                        $(document).ready(function(){
                          var classcnt = 1;
                          $("#classsetbtn").click(function () {

                          if(classcnt>10){
                          swal("Only 10 Options Values are allow!");
                          return false;
                          }

                          var newTextBoxDiv='<div class="col-md-3" id="TextBoxDiv'+classcnt+'"><div class="input-group"><div class="form-line"><input class="form-control"  type="hidden"  name="fieldName1" value="classes_history"><input class="form-control"  type="text" id="optionsval'+classcnt+'" placeholder="value'+classcnt+'" name="optionsval[]"></div><span class="input-group-addon systemichistoryremoveButton" type="button" id="systemichistoryremoveButton" ><i class="fa fa-times" aria-hidden="true"></i></span></div></div>'

                          $("#classTextBoxesGroup").append(newTextBoxDiv);
                          classcnt++;
                          });

                          $(document).on('click', '.systemichistoryremoveButton', function(e) {
                        classcnt--;
                        var target = $("#classTextBoxesGroup").find("#TextBoxDiv" +classcnt);
                        $(target).remove();
                        });

                        $("#classbtnsave").click(function () {
                               
                                var content=$("#classTextBoxesGroup").val();
                                if (isEmpty($('#classTextBoxesGroup'))) 
                                {
                                    swal({
                                    title: "Please Add Some Option by clicking on",
                                    text: "<button style=\"border-radius: 4px !important;\" type='button' class='btn btn-success'>Set Option</button>",
                                    html: true
                                    });
                                }
                               else 
                            {
                         var data=$("#eyeOperationRecord").serialize();
                                event.preventDefault();
                                $.ajax({
                                    url:'<?php echo e(route("dynamic-field.insert")); ?>',
                                    method:'post',
                                    data:data,
                                    success:function(data)
                                    {
                                     swal({title: "Option For Diagnosis", text: "Added Successfully!", type: "success"},
                                     function(){ 
                                      location.reload();
                                      }
                                    );
                                    }
                                })
                            }

                            });
                        });
                        </script>
<!-- =============================================================================================================================== -->
                          
                           
                           <div class="col-md-12">
                              <div class="col-md-2">
                              <div class="form-group labelgrp">
                              <?php echo e(Form::label('referred_by','Referred By')); ?> 
                              </div>
                              </div>


                              <div class="col-md-4">
                              <div class="form-group">
                              <div class="form-line">
                              <?php echo e(Form::text('referedby', Request::old('referedby',$case_master['referedby']), array('class' => 'form-control'))); ?>                           
                              </div>
                              </div>
                              </div>

                              <div class="col-md-2">
                              <div class="form-group labelgrp">
                              <?php echo e(Form::label('discharge_sts','Discharge Status')); ?> 
                              </div>
                              </div>


                              <div class="col-md-4">
                              <div class="form-group">
                              <div class="form-line">
                              <?php echo e(Form::text('discharge_sts', Request::old('discharge_sts',$case_master['discharge_sts']), array('class' => 'form-control'))); ?>                           
                              </div>
                              </div>
                              </div>
                          </div>
<!-- ==================================================================================================================================== -->
<div classs="col-md-12">
    <span class="dropdown-container">
    <div id="diagnosis_history" class="ContainerToAppend">
      <div class="col-md-12">
       
          <div class="col-md-2">
            <div class="form-group labelgrp">
              <label class="">Diagnosis</label> 
            </div>
            <input type="hidden" id="diagnosisHistory[]" name="diagnosisHistory[]" class="hiddenCounter" value="1" />  
          </div>

          <div class="col-md-5">
            <?php echo e(Form::select('diagnosis[]', array(' '=>'-Select-') + $form_dropdownsEye->where('fieldName', 'diagnosis_history')->pluck('ddText','ddText')->toArray(), array_key_exists('diagnosis_history', $defaultValues)?$defaultValues['diagnosis_history']:null, array('class'=> 'form-control select2','data-live-search'=>'true'))); ?>

          </div>

          <div class="col-md-5">
            <button type="button" name="add" id='diagnosissetbtn' class="btn btn-success set-dropdown-options" data-field_name="Systemic History OD" data-form_name="commanForm">Set Option </button>

            <button type='button' class="btn btn-primary" id='diagnosisbtnsave'>Save Option</button>

            <button id="addSystemicHistory" class="btn btn-default addmore" data-templateDiv="diagnosistemplate">Add</button>
          </div>
       
        <div class="col-md-3">        </div>
      </div>
    </div>
    <div id='diagnosisTextBoxesGroup' class="col-md-12">

    </div>
     <div class="dbMultiEntryContainer">
     <?php if(isset($newDischargeData['diagnosis'])) { ?>
       <?php $__currentLoopData = $newDischargeData['diagnosis']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="col-md-12">
              <div class="col-md-2">
              </div>
              <div class="col-md-8">
              <input type="text" class="form-control" readonly value="<?php echo e($item->field_value); ?>">
              </div>
              <div class="col-md-2">
              <button class="removeDbItem btn btn-default" data-deleteid="<?php echo e($item->id); ?>" data-type="diagnosis_history">Remove</button>
              </div>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     <?php } ?>
      </div>
    </span> 
    <div id="templateContainner" style="display:none">
      <div id="diagnosistemplate">
          <div class="col-md-12">
                  <div class="col-md-2">
                      <input type="hidden" id="diagnosisHistory[]" name="diagnosisHistory[]" class="hiddenCounter" value="" />
                  </div>
                  <div class="col-md-6">
                      <?php echo e(Form::select('diagnosis[]', array(' '=>'-Select-') + $form_dropdownsEye->where('fieldName', 'diagnosis_history')->pluck('ddText','ddText')->toArray(), array_key_exists('diagnosis_history', $defaultValues)?$defaultValues['diagnosis_history']:null, array('class'=> 'form-control Dyselect2','data-live-search'=>'true'))); ?>

      
                  </div>
                 
                  <div class="col-md-2">
                      <button class="removeItem btn btn-default" data-loading-text="<i class='fa fa-spinner fa-spin '></i> Processing..">Remove</button>
                  </div>
          </div>
      </div>  
    </div>     
  </div>


  <script>

$(document).ready(function(){
  var diagnosiscnt = 1;
  $("#diagnosissetbtn").click(function () {

  if(diagnosiscnt>10){
  swal("Only 10 Options Values are allow!");
  return false;
  }

  var newTextBoxDiv='<div class="col-md-3" id="TextBoxDiv'+diagnosiscnt+'"><div class="input-group"><div class="form-line"><input class="form-control"  type="hidden"  name="fieldName1" value="diagnosis_history"><input class="form-control"  type="text" id="optionsval'+diagnosiscnt+'" placeholder="value'+diagnosiscnt+'" name="optionsval[]"></div><span class="input-group-addon systemichistoryremoveButton" type="button" id="systemichistoryremoveButton" ><i class="fa fa-times" aria-hidden="true"></i></span></div></div>'

  $("#diagnosisTextBoxesGroup").append(newTextBoxDiv);
  diagnosiscnt++;
  });

  $(document).on('click', '.systemichistoryremoveButton', function(e) {
diagnosiscnt--;
var target = $("#diagnosisTextBoxesGroup").find("#TextBoxDiv" +diagnosiscnt);
$(target).remove();
});

$("#diagnosisbtnsave").click(function () {
       
        var content=$("#diagnosisTextBoxesGroup").val();
        if (isEmpty($('#diagnosisTextBoxesGroup'))) 
        {
            swal({
            title: "Please Add Some Option by clicking on",
            text: "<button style=\"border-radius: 4px !important;\" type='button' class='btn btn-success'>Set Option</button>",
            html: true
            });
        }
       else 
    {
 var data=$("#discharge_form").serialize();
        event.preventDefault();
        $.ajax({
            url:'<?php echo e(route("dynamic-field.insert")); ?>',
            method:'post',
            data:data,
            success:function(data)
            {
             swal({title: "Option For Diagnosis", text: "Added Successfully!", type: "success"},
             function(){ 
              location.reload();
              }
            );
            }
        })
    }

    });
});
</script>
<!-- =============================================================================================================================== -->
<!-- ================================================================================= -->
<div id="anaesthetistSurgeon" class="ContainerToAppend dropdown-container">
  <div class="col-md-12 ">
    <div class="col-md-2 ">
      <div class="form-group labelgrp">
        <?php echo e(Form::label('anaesthetistSurgeon','Anaesthetist Surgon')); ?> 
      </div>
    </div>

    <div class="col-md-6">
      <select class="form-control select2" data-live-search='true' name="anaesthetistSurgeon">
        <option>--Select--</option>
        <?php 
        //echo "<pre> =============";print_r($newDischargeData);exit;

        foreach ($form_dropdownsEye->where('fieldName', 'anaesthetistSurgeon')->pluck('ddText','ddText')->toArray() as $key => $value) { ?>
            <option value="<?php echo e($key); ?>" <?php if(isset($newDischargeData['anaesthetistSurgeon'][0]) && $newDischargeData['anaesthetistSurgeon'][0]->field_value == $value) { echo "selected";} ?>><?php echo e($value); ?></option>
        <?php } ?>
        
       </select>
    
    </div> 
    <div class="col-md-4">
      <button type="button" name="add" id='anaesthetistSurgeonbtn' class="btn btn-success  set-dropdown-options"  data-field_name="anaesthetistSurgeon" data-form_name="EyeForm" >Set Option </button>
      <button type='button' class="btn btn-primary" id='anaesthetistSurgeonbtnsave'>Save Option</button>
    </div>
  </div>
  <div id='anaesthetistSurgeonTextBoxesGroup' class="col-md-12">

  </div> 



  <!-- set-dropdown-options -->
  
  <div class='dropdown-options-initial-div' class="col-md-12" style="display:none;">
    <?php  
    $dropdown_options_field_name = 'anaesthetistSurgeon';
    $dropdown_options_form_name = 'EyeForm';
     ?>
  </div>
</div>

<script type="text/javascript">
  var anaesthetistSurgeoncnt = 1;
  $("#anaesthetistSurgeonbtn").click(function () {

    if(anaesthetistSurgeoncnt>10){
      swal("Only 10 Options Values are allow!");
      return false;
    }

    var newTextBoxDiv='<div class="col-md-3" id="TextBoxDiv'+anaesthetistSurgeoncnt+'"><div class="input-group"><div class="form-line"><input class="form-control"  type="hidden"  name="fieldName1" value="anaesthetistSurgeon"><input class="form-control"  type="hidden"  name="fieldName2" value="anaesthetistSurgeon"><input class="form-control"  type="text" id="optionsval'+anaesthetistSurgeoncnt+'" placeholder="value'+anaesthetistSurgeoncnt+'" name="optionsval[]"></div><span class="input-group-addon anaesthetistSurgeonremoveButton" type="button" id="anaesthetistSurgeonremoveButton" ><i class="fa fa-times" aria-hidden="true"></i></span></div></div>'

    $("#anaesthetistSurgeonTextBoxesGroup").append(newTextBoxDiv);
    anaesthetistSurgeoncnt++;
  });

  $(document).on('click', '.anaesthetistSurgeonremoveButton', function(e) {
    anaesthetistSurgeoncnt--;
    var target = $("#anaesthetistSurgeonTextBoxesGroup").find("#TextBoxDiv" +anaesthetistSurgeoncnt);
    $(target).remove();
  });

  // ANTERIOR SEGMENT Add Option//
  $("#anaesthetistSurgeonbtnsave").click(function () {
    var content=$("#anaesthetistSurgeonTextBoxesGroup").val();
    if (isEmpty($('#anaesthetistSurgeonTextBoxesGroup'))) {
      swal({
        title: "Please Add Some Option by clicking on",
        text: "<button style=\"border-radius: 4px !important;\" type='button' class='btn btn-success'>Set Option</button>",
        html: true
      });
    } else {
      var data=$("#discharge_form").serialize();
      event.preventDefault();
      $.ajax({
        url:'<?php echo e(route("dynamic-field.insert")); ?>',
        method:'post',
        data:data,
        success:function(data) {
          swal({title: "Option For Anaesthetist Surgeon", text: "Added Successfully!", type: "success"},
            function() { 
              location.reload();
            }
          );
        }
      })
    }

  });

</script>
<!-- ================================================================================= -->  

<!-- ================================================================================= -->

<!-- ================================================================================= -->
<div id="anesthesia" class="ContainerToAppend dropdown-container">
  <div class="col-md-12 ">
    <div class="col-md-2 ">
      <div class="form-group labelgrp">
        <?php echo e(Form::label('anesthesia','Anesthesia')); ?> 
      </div>
    </div>

    <div class="col-md-6">
      <select class="form-control select2" data-live-search='true' name="anesthesia">
        <option>--Select--</option>
        <?php 
        //echo "<pre> =============";print_r($form_dropdownsEye->where('fieldName', 'anaesthetistSurgeon')->pluck('ddText','ddText')->toArray());exit;

        foreach ($form_dropdownsEye->where('fieldName', 'anesthesia')->pluck('ddText','ddText')->toArray() as $key => $value) { ?>
            <option value="<?php echo e($key); ?>" <?php if(isset($newDischargeData['anesthesia'][0]) && $newDischargeData['anesthesia'][0]->field_value == $value) { echo "selected";} ?>><?php echo e($value); ?></option>
        <?php } ?>
        
       </select>

    </div> 
    <div class="col-md-4">
      <button type="button" name="add" id='anesthesiabtn' class="btn btn-success  set-dropdown-options"  data-field_name="anesthesia" data-form_name="EyeForm" >Set Option </button>
      <button type='button' class="btn btn-primary" id='anesthesiabtnsave'>Save Option</button>
    </div>
  </div>
  <div id='anesthesiaTextBoxesGroup' class="col-md-12">

  </div> 



  <!-- set-dropdown-options -->
  
  <div class='dropdown-options-initial-div' class="col-md-12" style="display:none;">
    <?php  
    $dropdown_options_field_name = 'anesthesia';
    $dropdown_options_form_name = 'EyeForm';
     ?>
  </div>
</div>

<script type="text/javascript">
  var anesthesiacnt = 1;
  $("#anesthesiabtn").click(function () {

    if(anesthesiacnt>10){
      swal("Only 10 Options Values are allow!");
      return false;
    }

    var newTextBoxDiv='<div class="col-md-3" id="TextBoxDiv'+anesthesiacnt+'"><div class="input-group"><div class="form-line"><input class="form-control"  type="hidden"  name="fieldName1" value="anesthesia"><input class="form-control"  type="hidden"  name="fieldName2" value="anesthesia"><input class="form-control"  type="text" id="optionsval'+anesthesiacnt+'" placeholder="value'+anesthesiacnt+'" name="optionsval[]"></div><span class="input-group-addon anesthesiaremoveButton" type="button" id="anesthesiaremoveButton" ><i class="fa fa-times" aria-hidden="true"></i></span></div></div>'

    $("#anesthesiaTextBoxesGroup").append(newTextBoxDiv);
    anesthesiacnt++;
  });

  $(document).on('click', '.anesthesiaremoveButton', function(e) {
    anesthesiacnt--;
    var target = $("#anesthesiaTextBoxesGroup").find("#TextBoxDiv" +anesthesiacnt);
    $(target).remove();
  });

  // ANTERIOR SEGMENT Add Option//
  $("#anesthesiabtnsave").click(function () {
    var content=$("#anesthesiaTextBoxesGroup").val();
    if (isEmpty($('#anesthesiaTextBoxesGroup'))) {
      swal({
        title: "Please Add Some Option by clicking on",
        text: "<button style=\"border-radius: 4px !important;\" type='button' class='btn btn-success'>Set Option</button>",
        html: true
      });
    } else {
      var data=$("#discharge_form").serialize();
      event.preventDefault();
      $.ajax({
        url:'<?php echo e(route("dynamic-field.insert")); ?>',
        method:'post',
        data:data,
        success:function(data) {
          swal({title: "Option For Anesthesia", text: "Added Successfully!", type: "success"},
            function() { 
              location.reload();
            }
          );
        }
      })
    }

  });

</script>



<!-- ================================================================================= --> 
<!-- 
                           <div class="col-md-12">
                              <div class="col-md-2">
                              <div class="form-group labelgrp">
                              <label for="diagnosis" class="control-label">Diagnosis</label>
                              </div>
                              </div>


                              <div class="col-md-4">
                              <div class="form-group">
                              <div class="form-line">
                              <?php echo e(Form::text('diagnosis', Request::old('diagnosis',$case_master['diagnosis']), array('class' => 'form-control'))); ?>                          
                              </div>
                              </div>
                              </div>
                              <div class="col-md-2">
                              <div class="form-group labelgrp">
                              <label for="upload_image" class="control-label">Image</label>
                              </div>
                              </div>


                              <div class="col-md-4">
                              <div class="form-group">
                              <div class="form-line">
                              <input type="file" name="upload_image" id="upload_image" class="form-control" >                         
                              </div>
                              </div>
                              </div>

                          </div> -->
                         
                        
                             
                 

                  <div class="row clearfix">
                                <div class="col-md-8 col-md-offset-2">
                                <div class="form-group">
                                 <button type="submit" name="submit" class="btn btn-success btn-lg" value="submit" >
                        <i class="fa fa-plus"></i> Submit
                    </button>
                    <a class="btn btn-default btn-lg" href="<?php echo e(url('/eyeOperationRecord')); ?>"><i class="glyphicon glyphicon-chevron-left"></i> Back</a>
                    
                    <a class="btn btn-default btn-lg" href="<?php echo e(url('/PatientMedicalDetails').'/'.$case_master->id); ?>"><i class="glyphicon glyphicon-chevron-left"></i> Patient Details</a>

                    <a  class="btn btn-default btn-lg" href="<?php echo e(url('/eyeOperationRecord/print').'/'.$case_master->id); ?>" target="_blank">
                        <i class="fa fa-print" aria-hidden="true"></i>Print
                    </a>
                    <a  class="btn btn-default btn-lg" href="<?php echo e(url('/eyeOperationRecord/view').'/'.$case_master->id); ?>" >
                        <i class="fa fa-print" aria-hidden="true"></i>View
                    </a>

                                      
                                </div>
                                </div>
                               
                            </div>
                            </form>   
                             </div>        
                </div>
           
            </div>
        </div>
</div>
</div>
</div>
</div>
</div>

        <?php $__env->stopSection(); ?>
  

  <?php $__env->startSection('scripts'); ?>
<!--<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/js/select2.min.js"></script>-->
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.9.0/moment.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/2.2.7/fullcalendar.min.js"></script>
<!-- <script src="<?php echo e(url('/')); ?>/assets/plugins/bootstrap-select/js/bootstrap-select.js"></script> -->
<script src="<?php echo e(url('/')); ?>/select2/js/select2.min.js"></script>
 <script type="text/javascript">
   $(document).ready(function() {

   });

   $(".removeDbItemSurgery").click(function(e) {
      var ClickedButton = $(this);
      var containerDiv = $(this).closest('div.form-group.row');

      //var delete_type = ClickedButton.data('type');
     // var url='<?php echo e(url("insurancedeletesurgery")); ?>/'+ $(ClickedButton).data('deleteid');
      //alert(url);
      swal({
        title: "Are you sure?",
        text: "This Will Remove !",
        type: "warning",
        showCancelButton: true,
        confirmButtonColor: "#DD6B55",
        confirmButtonText: "Yes, delete it!",
        closeOnConfirm: false
      }, function () {
          
        $.ajax({ url: '<?php echo e(route("insurancedeletesurgery")); ?>',
          method:'POST',
          data: {
            _token :$("input[name='_token'][type='hidden']").val(),
            id : $(ClickedButton).data('deleteid'),
          }
        })
        .success(function() {
          $(containerDiv).remove();
          $(ClickedButton).button('reset');

          swal({title: "Deleted", text: "Successfully!!!", type: "success"},
            function(){ 
              location.reload();
            }
          );
        }).error(function(){
        $(ClickedButton).button('reset');
        });

         location.reload();
      });
      e.preventDefault();

        });        

   $(".removeDbItem").click(function(e) {
      var ClickedButton = $(this);
      var containerDiv = $(this).closest('div.form-group.row');

      swal({
        title: "Are you sure?",
        text: "This Will Remove !",
        type: "warning",
        showCancelButton: true,
        confirmButtonColor: "#DD6B55",
        confirmButtonText: "Yes, delete it!",
        closeOnConfirm: false
      }, function () {
          
        $.ajax({ url: '<?php echo e(url("dischargedeleteField")); ?>',
          method:'POST',
          data: {
            _token :$("input[name='_token'][type='hidden']").val(),
            id : $(ClickedButton).data('deleteid'),
          }
        })
        .success(function() {
          $(containerDiv).remove();
          $(ClickedButton).button('reset');

          swal({title: "Deleted", text: "Successfully!!!", type: "success"},
            function(){ 
              location.reload();
            }
          );
        }).error(function(){
        $(ClickedButton).button('reset');
        });

         location.reload();
      });
      e.preventDefault();

        });        


   $(".select2").select2();
    function isEmpty( el ){
      return !$.trim(el.html())
    }
  $('.addmore').click(function(e) {
    e.preventDefault();
    var template = $("#"+$(this).data('templatediv')).clone();
    
    $(template).find('.hiddenCounter').val(($(this).closest('div.ContainerToAppend').find('div.form-group.row').length + 1));
   // alert("template"+$(this).data('templatediv'))
    $(this).closest('div.ContainerToAppend').append($(template).html());
    $(this).closest('div.ContainerToAppend').find('.Dyselect2').select2({width: '100%'});
    
  });    
 </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlayouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>