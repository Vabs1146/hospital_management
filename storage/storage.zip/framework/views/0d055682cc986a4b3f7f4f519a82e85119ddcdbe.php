
<?php $__env->startSection('style'); ?>
<?php $CheckField = app('App\Http\Controllers\EyeFormController'); ?>
<style>
    @media  screen and (max-width: 767px) {
        .select2 {
            width: 100% !important;
        }
    }
    .ui-autocomplete-loading {
        background: white url("<?php echo e(asset('images/ui-anim_basic_16x16.gif')); ?>") right center no-repeat;
    }
</style>
<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/css/select2.min.css" rel="stylesheet" />
<!-- Styles -->
<link rel="stylesheet" href="<?php echo e(asset('JqueryUI/jquery-ui.css')); ?>">
 
 
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="container-fluid">
<div class="row clearfix">
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
      
<div class="card">

<div class="header bg-pink">
<h2>
View Eye Report 
</h2>
</div>
    <div class="body">
     <div class="row clearfix">
         <div class="col-xs-12 ol-sm-12 col-md-12 col-lg-12">
             <div class="panel-group" id="accordion_9" role="tablist" aria-multiselectable="true">
                 <div class="panel panel-col-pink">
                    <div class="panel-heading" role="tab" id="headingOne_9">
                        <h4 class="panel-title">
                            <a role="button" data-toggle="collapse" data-parent="#accordion_9" href="#collapseOne_1" aria-expanded="true" aria-controls="collapseOne_9">
                              <span> Case Number : <b><?php echo e($casedata['case_number']); ?> </b> Patient Name : <b>
        <?php echo e($casedata['patient_name']); ?> </b> </span>
                            </a>
                        </h4>
                    </div>

<div id="collapseOne_9" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingOne_9">
 <?php echo e(Form::hidden('case_id', Request::old('case_id',$casedata['id']), array('class'=> 'form-control'))); ?>


<div class="panel-body">
<div class="row clearfix">
  <div class="row">
  <?php $__currentLoopData = $report_image; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rptImg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if(isset($rptImg) && $rptImg != null && isset($rptImg->filePath)): ?>
      <div class="col-md-4">
        <div class="thumbnail">
          <a href="<?php echo e(url('/printEyeReportFiles') . '/' . $rptImg->id); ?>" target="_blank">
            <img src="<?php echo e(Storage::disk('local')->url($rptImg->filePath)); ?>" alt="Lights" style="width:100%">
            <div class="caption">
              <p>&nbsp;</p>
            </div>
          </a>
        </div>
      </div>
    
    <?php endif; ?>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

     

<!---------------------medial--------------------------------->
    <div class="panel-body" >
    <div class="container-fluid">
    
          <ul class="list-inline">
  <li class="list-inline-item">
      <a class="btn btn-default btn-lg" href="<?php echo e(url('/AddEditEyeDetails') . '/'. $casedata['id']); ?>"><i class="glyphicon glyphicon-chevron-left"></i> Back </a>
  </li>
  <li class="list-inline-item">
      <a class="btn btn-default btn-lg" href="<?php echo e(url('/case_masters')); ?>"><i class="glyphicon glyphicon-chevron-left"></i> Back Patient list</a>
  </li>
  <li class="list-inline-item">
      <a class="btn btn-default btn-lg" href="<?php echo e(url('/AddEdit/prescription/').'/'. $casedata['id']); ?>">
          <i class="glyphicon glyphicon-chevron-left"></i> Add Prescription 
      </a>
  </li>
  <li class="list-inline-item">
      <a class="btn btn-default btn-lg" href="<?php echo e(url('/report_files/').'/'.$casedata['id'].'/edit'); ?>">
          <i class="glyphicon glyphicon-chevron-left"></i> Add Report 
      </a>
  </li>
  <li class="list-inline-item">
      <a class="btn btn-default btn-lg" href="<?php echo e(url('/insuranceBill/').'/'.$casedata['id'].'/edit'); ?>">
          <i class="glyphicon glyphicon-chevron-left"></i> Insurance Bill 
      </a>
  </li>
  <li class="list-inline-item">
      <a class="btn btn-default btn-lg" href="<?php echo e(url('/eyeOperationRecord/').'/'.$casedata['id'].'/edit'); ?>">
          <i class="glyphicon glyphicon-chevron-left"></i> Eye Operation Record 
      </a>
  </li>
  <li class="list-inline-item">
      <a class="btn btn-default btn-lg" href="<?php echo e(url('/discharge/').'/'.$casedata['id'].'/1/edit'); ?>">
          <i class="glyphicon glyphicon-chevron-left"></i> Discharge 
      </a>                    
  </li>
</ul>

<ul class="list-inline">
  <li class="list-inline-item">
      <a class="btn btn-default btn-lg" href="<?php echo e(url('/eyeoperation/').'/'.$casedata['id'].'/edit'); ?>">
          <i class="glyphicon glyphicon-chevron-left"></i> Operation Details 
      </a>                    
  </li>
  <li class="list-inline-item">
      <a class="btn btn-default btn-lg" href="<?php echo e(url('/eyeOperationRecord/view').'/'.$casedata['id']); ?>">
          <i class="glyphicon glyphicon-chevron-left"></i> Operation record View 
      </a>                                           
  </li>
  <li class="list-inline-item">
      <a class="btn btn-default btn-lg" href="<?php echo e(url('/eyeOperationRecord/print').'/'.$casedata['id']); ?>" target="_blank">
          <i class="fa fa-print" aria-hidden="true"></i>Operation record Print
      </a>                                           
  </li>
  <li class="list-inline-item">
      <a class="btn btn-default btn-lg" href="<?php echo e(url('/glassPrescription/').'/'.$casedata['id'].'/edit'); ?>">
          <i class="glyphicon glyphicon-chevron-left"></i> Glass Prescription 
      </a>                                           
  </li>
</ul>
            
           

        
     </div>
 </div>


</div>
</div>
</div>
</div>




</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>



<?php $__env->stopSection(); ?>


<?php echo $__env->make('adminlayouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>