<?php $__env->startSection('style'); ?>
<?php $CheckField = app('App\Http\Controllers\EyeFormController'); ?>
<style>
    @media  screen and (max-width: 767px) {
        .select2 {
            width: 100% !important;
        }
    }
    .ui-autocomplete-loading {
        background: white url("<?php echo e(asset('images/ui-anim_basic_16x16.gif')); ?>") right center no-repeat;
    }
</style>
<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/css/select2.min.css" rel="stylesheet" />
<!-- Styles -->
<link rel="stylesheet" href="<?php echo e(asset('JqueryUI/jquery-ui.css')); ?>">
 
 
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="container-fluid">
<div class="row clearfix">
  <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
         
<div class="card">

            <?php echo e(csrf_field()); ?>

<div class="header bg-pink">
<h2>
Eye Operation View
</h2>
</div>
    <div class="body">
     <div class="row clearfix">
         <div class="col-xs-12 ol-sm-12 col-md-12 col-lg-12">
             <div class="panel-group" id="accordion_9" role="tablist" aria-multiselectable="true">
                 <div class="panel panel-col-pink">
                    <div class="panel-heading" role="tab" id="headingOne_9">
                        <h4 class="panel-title">
                            <a role="button" data-toggle="collapse" data-parent="#accordion_9" href="#collapseOne_9" aria-expanded="true" aria-controls="collapseOne_9">
                            Eye Operation | Case Number : <?php echo e($case_master['case_number']); ?>  | <?php echo e('Time :' . $case_master['visit_time']); ?>

                            </a>
                        </h4>
                    </div>

<div id="collapseOne_9" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingOne_9">

<div class="panel-body">
    <div class="row clearfix">
      <div class="col-md-12">
        <div class="form-group">
        <img src=<?php echo e(Storage::disk('local')->url($logoUrl)); ?> class="img-rounded" alt="letter head top" width="100%" height="150" />
        </div>
      </div>
      <div class="panel-body" >
    <div class="container-fluid">
           <div class="row">
           <div class="col-md-12">
            <label for="Patient_name" class="control-label">Patient Name :</label> 
            <?php echo e($case_master['patient_name']); ?>

            </div>
            </div>
            
            <div class="row">
            
            <div class="col-md-4">
            <label for="Patient_age" class="control-label">Age :</label>
            <?php echo e($case_master['patient_age']); ?>

            </div>

            <div class="col-md-4">
            <label for="Patient_sex" class="control-label">Sex :</label>
            <?php echo e($case_master['male_female']); ?>

            </div>

            <div class="col-md-4">
            <label for="Patient_IPDno" class="control-label">IPD no :</label>
            <?php echo e($eyeOperationRecord->IPD_no); ?>

            </div>
          
        </div>

            <div class="row">
            <div class="col-md-12">
            <label for="Patient_address" class="control-label">Address :</label>
            <?php echo e($case_master['patient_address']); ?> 
            </div>
           </div>

            <div class="row">
            <div class="col-md-12">
            <label for="Addmission_dt" class="control-label">Date Of Addmission :</label>
            <?php echo e($discharge->date_admission); ?>

            </div>
            </div>

            <div class="row">
            <div class="col-md-12">
            <label for="Surgery_dt" class="control-label">Date Of Surgery :</label>
            <?php echo e($discharge->date_surgery); ?>

            </div>
            </div>

            <div class="row">
            <div class="col-md-12">
            <label for="Diagnosis" class="control-label">Diagnosis :</label>
            <?php echo e($discharge->diagnosis); ?>

            </div>
            </div>

            <div class="row">
            <div class="col-md-12">
            <label for="surgery" class="control-label">Surgery :</label> 
            <?php echo e($discharge->surgery); ?>

            </div>
            </div>

            <div class="row">
            
            <div class="col-md-4">
            <label for="BriefHistory" class="control-label">Brief History :</label>   <?php echo e($discharge->brief_history); ?>

            </div>

            <div class="col-md-4">
            <label for="TreatmentAdvised" class="control-label">Treatment Advised :</label>   <?php echo e($discharge->treatment_advised); ?>

            </div>
                
         </div>

            <div class="row">
            <div class="col-md-12">
            <label for="Investigation" class="control-label">Investigation :</label>   <?php echo e($discharge->investigation); ?>

            </div>
            </div>

            <div class="row">
            <div class="col-md-12">
            <label for="BriefHistory" class="control-label"> Followup :</label>
            <?php echo e($discharge->followup); ?>  
            </div>
            </div>

            <div class="row">
            <div class="col-md-12">
            <label for="BriefHistory" class="control-label"> Date : </label> <?php echo e(\Carbon\Carbon::now()->format('d/M/Y')); ?>

           
            </div> 
            </div>     
           

            
           
            <br/>
            
            <div class="col-md-12">
                <div class="col-md-6">
                    _______________________
                </div>
                <div class="col-md-6 pull-right">
                    _______________________
                </div>
                <div class="col-md-6">
                    Signature
                </div>
                <div class="col-md-6 pull-right">
                    Signature
                </div>
                <div class="col-md-6">
                    <?php echo e($case_master['patient_name']); ?>

                </div>
                <div class="col-md-6 pull-right">
                    <?php echo e(config('app.name', 'Dr')); ?>

                </div>
            </div>

     </div>





<!-----------button----------------------->    
<div class="row clearfix">
<div class="col-md-4 col-md-offset-4">
<div class="form-group">
    <a class="btn btn-info btn-lg" href="<?php echo e(url('/eyeOperationRecord/print').'/'.$case_master->id); ?>" target="_blank">
    <i class="fa fa-print" aria-hidden="true"></i>Print</a>
    <a class="btn btn-info btn-lg" href="<?php echo e(url('/PatientMedicalDetails').'/'.$case_master->id); ?>"><i class="glyphicon glyphicon-chevron-left"></i> Patient Details</a>
</div>
</div>
</div>
 <!----------end-button----------------------->  

</div>
</div>
</div>
</div>
<!-- </form> -->
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/js/select2.min.js"></script>
<script type="text/javascript">
    $(document).ready(function(){
      $('#medicine_id').select2();  
      $('.datepicker').datepicker({
            format: "dd/M/yyyy",
            weekStart: 1,
            clearBtn: true,
            daysOfWeekHighlighted: "0,6",
            autoclose: true,
        });    
    });
</script>
 
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlayouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>