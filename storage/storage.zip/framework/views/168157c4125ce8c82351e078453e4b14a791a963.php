<?php $__env->startSection('content'); ?>
<div class="container-fluid">
<div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                   <div class="card-body">
                               <div class="user-list">
                                    
                                   <a href="<?php echo e(route('gallery')); ?>" class="btn btn-info btn-lg float-right">Add gallery</a>
                               </div>
                           </div>
                           <br>
                    <div class="card">

                        <form>
                         <div class="header bg-pink">
                            <h2>
                               Gallery List
                            </h2>
                          
                        </div>
                         <div class="form-group">
                          <?php echo $__env->make('shared.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                          <?php if(Session::has('flash_message')): ?>
                          <div class="alert alert-success">
                          <?php echo e(Session::get('flash_message')); ?>

                          </div>
                          <?php endif; ?>
                         </div>
                        <div class="body">
                              <div class="table-responsive">
                                    <table class="table table-bordered table-striped table-hover js-basic-example dataTable" id="zero_config" name="sectiontable">
                                        <thead>
                                            <tr>
                                                <th>Gallery Name</th>
                                                <th>Gallery Image</th>
                                               
                                                <th>Delete</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $gallery_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $galleryname): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                          <tr>
                                          <td><a href="<?php echo e(route('showsubimage',$galleryname->main_id)); ?>"><?php echo e($galleryname->gallery_name); ?></a></td>
                                              
                                                   <td>
                                                    <img src="<?php echo e(url('/')); ?>/gallery_image/<?php echo e($galleryname->filenames1); ?>" style="width: 200px;height: 100px;" alt="">
                                                </td>
                                              
                                              <td>
                                                  <a href="<?php echo e(route('deleteGallery',$galleryname->main_id)); ?>" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this item?');">Delete</a>
                                              </td>
                                          </tr>
                                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </tbody>
                                       
                                    </table>
                                </div> 
                          
                        </div>
                        
                       
                        </div>
                </div>
            </div>


</div>


 <?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
 <script src="<?php echo e(url('/')); ?>/select2/js/select2.min.js"></script>
 <script type="text/javascript">

  
   $(document).ready(function(){
    
            sectiontable = $('#zero_config').dataTable({
               "ordering": false,
               stateSave: true
              
            });

           
         
          });
 </script>


<script src="<?php echo e(url('/')); ?>/assets/plugins/bootstrap-select/js/bootstrap-select.js"></script>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('adminlayouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>