<?php $__env->startSection('content'); ?>
<?php $__env->startSection('content'); ?>
<?php  $permissions = session('permissions'); 
//echo "====1111111===>>> <pre>"; print_r($permissions); exit;

//echo "====1111111===>>> <pre>"; print_r(AUTH::user()); exit;
 ?>
<div class="container-fluid">
    <div class="row clearfix">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <?php echo $__env->make('shared.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php if(Session::has('flash_message')): ?>
            <div class="alert alert-success">
                <?php echo e(Session::get('flash_message')); ?>

            </div>
            <?php endif; ?>
            <div class="card">
                <form action="<?php echo e(url('/settings')); ?>" method="POST" class="form-horizontal" enctype="multipart/form-data">
                    <?php echo e(csrf_field()); ?>


                    <?php if(isset($model)): ?>
                    <input type="hidden" name="_method" value="PATCH">
                    <?php endif; ?>
                    <div class="header bg-pink">
                        <h2>Add/Modify Settings</h2>
                    </div>


                    <div class="body">
                        <div class="row clearfix ">                            
                                <div class="col-md-4">
                                    <div class="form-group labelgrp">
                                        <label class="form-control">Hospital Name :</label>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <div class="form-line">
                                            <input type="text" name="hospital_name" id="hospital_name" class="form-control" value="<?php echo e($all_settings['hospital_name']->value); ?>">
                                        </div>
                                    </div>
                                </div>
								<?php if($permissions['settings']->edit_permission || AUTH::user()->role == 1): ?>
								<div class="col-md-2">
                                    <div class="form-group labelgrp">
                                        <input type="submit" name="update_hospital_name" value="Update">
                                    </div>
                                </div>
								<?php endif; ?>
                            </div>



                        <div class="row clearfix ">                            
                                <div class="col-md-4">
                                    <div class="form-group labelgrp">
                                        <label class="form-control">Hospital Logo :</label>
                                    </div>
                                </div>

                                <div class="col-md-<?php echo e(($all_settings['hospital_logo']->value != "") ? '4' : '6'); ?>">
                                    <div class="form-group">
                                        <div class="form-line">
                                            <input type="file" name="hospital_logo" id="hospital_logo" class="form-control">
                                        </div>
                                    </div>
									
                                </div>
								<?php if($all_settings['hospital_logo']->value != ""): ?>
									<div class="col-md-2">
									<a target="_blank" href="<?php echo e(url('/')); ?>/uploads/images/<?php echo e($all_settings['hospital_logo']->value); ?>"><img style="width: 100px;" src="<?php echo e(url('/')); ?>/uploads/images/<?php echo e($all_settings['hospital_logo']->value); ?>"></a>
									</div>
								<?php endif; ?>
								<?php if($permissions['settings']->edit_permission || AUTH::user()->role == 1): ?>
								<div class="col-md-2">
                                    <div class="form-group labelgrp">
                                        <input type="submit" name="update_hospital_logo" value="Update">
                                    </div>
                                </div>
								<?php endif; ?>
                            </div>

							<div class="row clearfix ">                            
                                <div class="col-md-4">
                                    <div class="form-group labelgrp">
                                        <label class="form-control">Doctor Name :</label>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <div class="form-line">
                                            <input type="text" name="doctor_name" id="doctor_name" class="form-control" value="<?php echo e($all_settings['doctor_name']->value); ?>">
                                        </div>
                                    </div>
                                </div>
								<?php if($permissions['settings']->edit_permission || AUTH::user()->role == 1): ?>
								<div class="col-md-2">
                                    <div class="form-group labelgrp">
                                        <input type="submit" name="update_doctor_name" value="Update">
                                    </div>
                                </div>
								<?php endif; ?>
                            </div>

							<div class="row clearfix ">                            
                                <div class="col-md-4">
                                    <div class="form-group labelgrp">
                                        <label class="form-control">UHID Prefix :</label>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <div class="form-line">
                                            <input type="text" name="uhid_prefix" id="uhid_prefix" class="form-control" value="<?php echo e($all_settings['uhid_prefix']->value); ?>">
                                        </div>
                                    </div>
                                </div>
								<?php if($permissions['settings']->edit_permission || AUTH::user()->role == 1): ?>
								<div class="col-md-2">
                                    <div class="form-group labelgrp">
                                        <input type="submit" name="update_uhid_prefix" value="Update">
                                    </div>
                                </div>
								<?php endif; ?>
                            </div>

							<div class="row clearfix ">                            
                                <div class="col-md-4">
                                    <div class="form-group labelgrp">
                                        <label class="form-control">Bill Number :</label>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <div class="form-line">
                                            <input type="text" name="bill_number" id="bill_number" class="form-control" value="<?php echo e($all_settings['bill_number']->value); ?>">
                                        </div>
                                    </div>
                                </div>
								<?php if($permissions['settings']->edit_permission || AUTH::user()->role == 1): ?>
								<div class="col-md-2">
                                    <div class="form-group labelgrp">
                                        <input type="submit" name="update_bill_number" value="Update">
                                    </div>
                                </div>
								<?php endif; ?>
                            </div>


                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlayouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>