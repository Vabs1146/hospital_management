<!DOCTYPE HTML>
<!--
	Justice by gettemplates.co
	Twitter: http://twitter.com/gettemplateco
	URL: http://gettemplates.co
-->
<html>

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	
	<title><?php echo e(config('app.name', 'Dr')); ?></title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="description" content="<?php echo e(config('app.name', 'Dr')); ?>">
	<meta name="keywords" content="<?php echo e(config('app.name', 'Dr')); ?>">

	<link href="https://fonts.googleapis.com/css?family=Crimson+Text:400,400i|Roboto+Mono" rel="stylesheet">

	<link rel="stylesheet" href="<?php echo e(asset('css/components.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('css/responsee.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('owl-carousel/owl.carousel.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('owl-carousel/owl.theme.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('css/template-style.css')); ?>">


	<!-- Modernizr JS -->
	<script src="<?php echo e(url('/')); ?>/assets/js/jquery-1.8.3.min.js"></script>
	<script src="<?php echo e(url('/')); ?>/assets/js/jquery-ui.min.js"></script>
	<script src="<?php echo e(url('/')); ?>/assets/js/modernizr.js"></script>
	<script src="<?php echo e(url('/')); ?>/assets/js/responsee.js"></script>
	
	<!-- FOR IE9 below -->
	<!--[if lt IE 9]>
	<script src="js/respond.min.js"></script>
	<![endif]-->
	<?php echo $__env->yieldContent('pageheader'); ?>

</head>

<body class="size-1140">
	<!-- HEADER -->
	<?php if(empty($hideMenu)): ?>
		<header role="banner">
		    <marquee behavior="scroll" direction="left" onMouseOver="this.stop();" onMouseOut="this.start();"> <?php echo e($bodyOne->name); ?>  <?php echo e($bodyOne->description); ?> </marquee>
			<!-- Top Navigation -->
			<nav class="background-white background-primary-hightlight">
				<div class="line">
					<div class="s-12 l-2">
						<a href="/" class="logo">
							<img src="<?php echo e($siteLogo); ?>" alt="">
						</a>
					</div>
					<div class="top-nav s-12 l-10">
						<p class="nav-text"></p>
						<ul class="right chevron">
							<li>
								<a href="/">Home</a>
							</li>
							<?php $subCnt = 0; $sub_SubCnt = 0; $subHref = ""; $sub_SubHref = ""; ?> 
							<?php $__currentLoopData = $menulst; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mLst): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
							<?php if(is_null($mLst->parentId)): ?>
							<li>
								<?php 
									$subHref = '/pages/'.$mLst->name;
									if(($menulst->where('parentId', $mLst->id)->count()) > 0){
										$subHref = "#";
									}
								 ?>
								<a href="<?php echo e($subHref); ?>"><?php echo e($mLst->name); ?></a>
								<?php $__currentLoopData = $menulst; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subMlst): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
									<?php if(intval($subMlst->parentId) == intval($mLst->id)): ?>
										<?php 
											$subCnt++; 
											$subHref = "#";
											if($subCnt == 1){
												echo "<ul>";
											}
										?>
									<li>
										<?php 
											$sub_SubHref = '/pages/'.$subMlst->name;
											if(($menulst->where('parentId', $subMlst->id)->count()) > 0){
												$sub_SubHref = "#";
											}
										 ?>
										<a href="<?php echo e($sub_SubHref); ?>"><?php echo e($subMlst->name); ?></a>
										<?php $__currentLoopData = $menulst; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub_subMlst): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
											<?php if($sub_subMlst->parentId == $subMlst->id): ?>
													<?php 
														$sub_SubCnt++; 
														if($sub_SubCnt == 1){
															echo "<ul>";
														}
													?>
												<li>
													<a href="<?php echo e('/pages/'.$sub_subMlst->name); ?>"><?php echo e($sub_subMlst->name); ?></a>
												</li>
											<?php endif; ?> 
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										<?php 
											if($sub_SubCnt > 0){
												echo "</ul>";
											}
											$sub_SubCnt = 0; 
										?>
									</li>
								<?php endif; ?> 
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								<?php 
									if($subCnt > 0){
										echo "</ul>";
									}
									$subCnt = 0; 
								?>
							</li>
							<?php endif; ?> 
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							<li>
								<a href="/Gallery">Gallery</a>
							</li>
							<li>
								<a href="<?php echo e(url('/appointment/')); ?>">Appointment</a>
							</li>
							<li>
								<a href="/AddRating">Feedback</a>
							</li>
						</ul>
					</div>
				</div>
			</nav>
		</header>
	<?php endif; ?>
	<!-- MAIN -->
	<main role="main">
		<?php echo $__env->yieldContent('pagebody'); ?>
	</main>


	<!-- FOOTER -->
	<footer>
		<!-- Social -->
		<div class="background-primary padding text-center">
			<a href="<?php echo e(config('app.facebook', '')); ?>">
				<i class="icon-facebook_circle icon2x text-white"></i>
			</a>
			<a href="<?php echo e(config('app.twitter', '')); ?>">
				<i class="icon-twitter_circle icon2x text-white"></i>
			</a>
			<a href="<?php echo e(config('app.google', '')); ?>">
				<i class="icon-google_plus_circle icon2x text-white"></i>
			</a>
			
		</div>

		<!-- Main Footer -->
		<section class="section background-dark">
			<div class="line">
				<div class="margin">
					<?php echo $footerText->html_text; ?>

				</div>
			</div>
		</section>
		<hr class="break margin-top-bottom-0" style="border-color: rgba(0, 38, 51, 0.80);">

	</footer>


	<!-- jQuery -->
	<script src="<?php echo e(asset('owl-carousel/owl.carousel.js')); ?> "></script>
	<script src="<?php echo e(url('/')); ?>/assets/js/template-scripts.js"></script>
	<!-- jQuery Easing -->

	<script src="<?php echo e(url('/')); ?>/assets/js/template-scripts.js"></script>
	<!-- Bootstrap -->
		<script src="<?php echo e(url('/')); ?>/assets/js/main.js"></script>
	<script src="<?php echo e(url('/')); ?>/assets/js/bootstrap-datepicker.min.js"></script>
	<?php echo $__env->yieldContent('footescripts'); ?>
</body>

</html>
