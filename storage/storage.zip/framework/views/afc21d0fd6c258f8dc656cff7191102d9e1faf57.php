<?php $__env->startSection('content'); ?>
<div class="container-fluid">
<div class="row clearfix">
  <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
    <?php if(Session::has('flash_message')): ?>
      <div class="alert alert-success">
      <?php echo e(Session::get('flash_message')); ?>

        </div>
        <?php endif; ?>
        </div>
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                         <div class="header bg-pink">
                            <h2> Payment Modes</h2>
                          </div>
                        
                        <div class="body">
                          <div class="row mb-2">
                              <div class="col-lg-12"> 
                              <div>
                              <a class="btn btn-success btn-lg" href="<?php echo e(route('payment-modes.create')); ?>"> Add New Payment Mode
                              </a>
                               </div>
                              </div>
                              </div>
                           <div class="table-responsive">
<table class="table table-bordered table-striped table-hover">
    <tr>
        <th>No</th>
        <th>Name</th>
        <th>Status</th>
        <th width="280px">Action</th>
    </tr>
    <?php $__currentLoopData = $payment_modes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment_modes_row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e(++$i); ?></td>
        <td><?php echo e($payment_modes_row->name); ?></td>
        <td><?php echo e($payment_modes_row->status); ?></td>
        <td>
            
            <a class="btn btn-primary" href="<?php echo e(route('payment-modes.edit',$payment_modes_row->id)); ?>">Edit</a> 
            
        </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
</div>
<?php echo e($payment_modes->render()); ?> 
                            </div>
                  
                    </div>
                </div>
            </div>


</div>



        <?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlayouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>