<?php $__env->startSection('content'); ?>
<?php  $permissions = session('permissions'); 
//echo "====1111111===>>> <pre>"; print_r($permissions); exit;

//echo "====1111111===>>> <pre>"; print_r(AUTH::user()); exit;
 ?>
<div class="container-fluid">
                <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                  <?php if(Session::has('flash_message')): ?>
                      <div class="alert alert-success">
                      <?php echo e(Session::get('flash_message')); ?>

                        </div>
                        <?php endif; ?>
                        <div class="card">
                         <div class="header bg-pink">
                            <h2>List of Members Contact Details</h2>
                        </div>
                         
                        <div class="body">
                                  <div class="table-responsive">
                                <table class="table table-hover table-bordered table-stripe" id="thegrid"  data-stripe-classes="[]">
                                    <thead>
                                      <tr>
                                          <th>Id</th>
                                          <th>Name</th>
                                          <th>Mobile</th>
                                          <th>Password</th>
                                           <?php if($permissions['users']->edit_permission || AUTH::user()->role == 1): ?>
                                         <th></th>
                                         <?php endif; ?>
                                          <?php if($permissions['users']->delete_permission || AUTH::user()->role == 1): ?>
                                          <th></th>    
                                          <?php endif; ?>
                                      </tr>
                                    </thead>
                                    <tbody>
                                    </tbody>
                                  </table>
                              </div>
                            
                            <div class="panel-footer"><input type="hidden" id="hdnCsrfToken" data-token="<?php echo e(csrf_token()); ?>"/>
                                <?php if($permissions['users']->add_permission || AUTH::user()->role == 1): ?>
                            <a href="<?php echo e(url('staff_users/create')); ?>" class="btn btn-lg btn-primary" role="button">Add User</a></div>
                            <?php endif; ?>
                        </div>                 
                    </div>
                </div>
            </div>


</div>

 <?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
    <script type="text/javascript">
        var theGrid = null;
        $(document).ready(function(){
            theGrid = $('#thegrid').DataTable({
                "processing": true,
                "serverSide": true,
                "ordering": true,
                "responsive": false,
                 "autoWidth": false,
                "ajax": "<?php echo e(url('staff_users/grid')); ?>",
                "columnDefs": [
                    {
                        "targets": 0,
                        "visible": false,
                        "searchable": false,
                        "class":"never"
                    },
                     <?php if($permissions['users']->edit_permission || AUTH::user()->role == 1): ?>
                    {
                        "render": function ( data, type, row ) {
                            return '<a href="<?php echo e(url('/staff_users')); ?>/'+row[0]+'/edit" class="btn btn-default">Update</a>';
                        },
                        "sortable": false,
                        "targets":4
                    },
                    <?php endif; ?>
                     <?php if($permissions['users']->delete_permission || AUTH::user()->role == 1): ?>
                       {
                        "render": function ( data, type, row ) {
                            return '<a href="#" onclick="return doDelete('+row[0]+')" class="btn btn-danger">Delete</a>';
                        },
                        "sortable": false,
                        "targets": 5
                    },
                    <?php endif; ?>
                ]
            });
        });
     
            function doDelete(id) {
            if(confirm('You really want to delete this record?')) {
               $.ajax({ url: '<?php echo e(url('/deleteuser/delete')); ?>/' + id, 
               type: 'DELETE',
               data: {_method: 'delete', _token :$("#hdnCsrfToken").data('token')}
               }).success(function() {
                theGrid.ajax.reload();
               });
            }
            return false;
        }
    </script>
<?php $__env->stopSection(); ?>
  
<?php echo $__env->make('adminlayouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>