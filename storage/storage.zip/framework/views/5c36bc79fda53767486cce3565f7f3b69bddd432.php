<div class="col-md-12">
	<div class="col-md-2">
		<div class="form-group labelgrp">
			<?php echo e(Form::label('CNS','General Complaints')); ?> 
		</div>
	</div>

	<div class="col-md-9">
		<div class="form-group">
			<div class="form-line">
				<?php echo e(Form::text('CNS', Request::old('CNS',$form_details->CNS), array('class' => 'form-control'))); ?>                           
			</div>
		</div>
	</div> 
</div>

<div class="col-md-12">
	<div class="col-md-2"> </div>
	<div class="col-md-5">
		<div class="form-group">
			<label>OD</label>
		</div>
	</div>

	<div class="col-md-5">
		<div class="form-group ">
			<label>OS</label>
		</div>
	</div>
</div>

<span class="dropdown-container">
	<div id="chiefComplaint" class="ContainerToAppend">
		<div class="col-md-12">
			<div class="col-md-2">
				<div class="form-group labelgrp">
					<label class="">Chief Complaint</label> 
				</div>
				<input type="hidden" id="ChiefComplaint[]" name="ChiefComplaint[]" class="hiddenCounter" value="1" />  
			</div>

			<div class="col-md-3">
				<?php echo e(Form::select('ChiefComplaint_OD[]', array(' '=>'-Select-') + $form_dropdowns->where('fieldName', 'Chief Complaint OD')->pluck('ddText','ddText')->toArray(), array_key_exists('Chief Complaint OD', $defaultValues)?$defaultValues['Chief Complaint OD']:null, array('class'=> 'form-control select2','data-live-search'=>'true'))); ?>

			</div>

			<div class="col-md-3">
				<?php echo e(Form::select('ChiefComplaint_OS[]', array(' '=>'-Select-') + $form_dropdowns->where('fieldName', 'Chief Complaint OS')->pluck('ddText','ddText')->toArray(), array_key_exists('Chief Complaint OS', $defaultValues)?$defaultValues['Chief Complaint OS']:null, array('class'=> 'form-control select2','data-live-search'=>'true'))); ?>

			</div>

			<div class="col-md-4">
				<button type="button" name="add" id='chiefcomplaintbtn' class="btn btn-success set-dropdown-options" data-field_name="Chief Complaint OD" data-form_name="EyeForm">Set Option </button>

				<button type='button' class="btn btn-primary" id='chiefcomplaintbtnsave'>Save Option</button>

				<button id="addChiefComplaint" class="btn btn-default addmore" data-templateDiv="ChiefComplaintTemplate">Add</button>
			</div>
		</div>

		<div class="col-md-12">
			<div class="col-md-2">
				<div class="form-group labelgrp">
					<label class="">Duration</label> 
				</div> 
			</div>

			<div class="col-md-3">
				<?php echo e(Form::text('ChiefComplaint_OD_duration[]', null, array('class'=> 'form-control', 'autocomplete'=>'off'))); ?>

			</div>

			<div class="col-md-3">
				<?php echo e(Form::text('ChiefComplaint_OS_duration[]', null, array('class'=> 'form-control', 'autocomplete'=>'off'))); ?>

			</div>

			<div class="col-md-4">
				
			</div>
		</div>

	</div>
	<div id='ChiefTextBoxesGroup' class="col-md-12">

	</div>
	<!-- ================================================================================= -->

	<!-- set-dropdown-options -->
	<!-- <span class="dropdown-container"> -->
	<div class='dropdown-options-initial-div' class="col-md-12" style="display:none;"> </div>
</span>
<!-- ================================================================================= -->    




<div class="dbMultiEntryContainer">
	<?php $__currentLoopData = $form_details->eyeformmultipleentry()->where('field_name', 'ChiefComplaint')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<div class="col-md-12">
		<div class="col-md-2"> </div>

		<div class="col-md-3">
			<input type="text" class="form-control" readonly value="<?php echo e($item->field_value_OD); ?>">
		</div>

		<div class="col-md-3">
			<input type="text" class="form-control" readonly value="<?php echo e($item->field_value_OS); ?>">
		</div>

		<div class="col-md-2">
			<button class="removeDbItem btn btn-default" data-deleteid="<?php echo e($item->id); ?>">Remove</button>
		</div>

		<div class="col-md-12">
			<div class="col-md-2"> </div>

			<div class="col-md-3">
				<input type="text" class="form-control" readonly value="<?php echo e($item->duration_od); ?>">
			</div>

			<div class="col-md-3">
				<input type="text" class="form-control" readonly value="<?php echo e($item->duration_os); ?>">
			</div>

			<div class="col-md-2">
				
			</div>
		</div>
	</div>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<span class="dropdown-container">
	<div id="OpthalHistory" class="ContainerToAppend">
		<div class="col-md-12">
			<div class="col-md-2">
				<div class="form-group labelgrp">
					<label>Ophthalmic History</label> 
				</div>
				<input type="hidden" id="OpthalHistory[]" name="OpthalHistory[]" class="hiddenCounter" value="1" />
			</div>  

			<div class="col-md-3">
				<?php echo e(Form::select('OpthalHistory_OD[]', array(' '=>'-Select-') + $form_dropdowns->where('fieldName', 'Opthal History OD')->pluck('ddText','ddText')->toArray(), array_key_exists('Opthal History OD', $defaultValues)?$defaultValues['Opthal History OD']:null, array('class'=> 'form-control select2','data-live-search'=>'true'))); ?>

			</div>

			<div class="col-md-3">
				<?php echo e(Form::select('OpthalHistory_OS[]', array(' '=>'-Select-') + $form_dropdowns->where('fieldName', 'Opthal History OS')->pluck('ddText','ddText')->toArray(), array_key_exists('Opthal History OS', $defaultValues)?$defaultValues['Opthal History OS']:null, array('class'=> 'form-control select2','data-live-search'=>'true'))); ?>

			</div>

			<div class="col-md-4">
				<button type="button" name="add" id='opthahistorybtn' class="btn btn-success set-dropdown-options"  data-field_name="Opthal History OS" data-form_name="EyeForm" >Set Option </button>
				<button type='button' class="btn btn-primary" id='opthahistorybtnsave'>Save Option</button>
				<button id="addOpthalHistory" class="btn btn-default addmore" data-templateDiv="OpthalHistoryTemplate">Add</button>
			</div>
		</div>

		<div class="col-md-12">
			<div class="col-md-2">
				<div class="form-group labelgrp">
					<label class="">Duration</label> 
				</div>
			</div>

			<div class="col-md-3">
				<?php echo e(Form::text('OpthalHistory_OD_duration[]', null, array('class'=> 'form-control', 'autocomplete'=>'off'))); ?>

			</div>

			<div class="col-md-3">
				<?php echo e(Form::text('OpthalHistory_OS_duration[]', null, array('class'=> 'form-control', 'autocomplete'=>'off'))); ?>

			</div>

			<div class="col-md-4">
				
			</div>
		</div>

	</div>
	<div id='OpthalTextBoxesGroup' class="col-md-12">

	</div>
	<!-- ================================================================================= -->

	<!-- set-dropdown-options -->
	<!-- <span class="dropdown-container"> -->
	<div class='dropdown-options-initial-div' class="col-md-12" style="display:none;"> </div>
</span>
<!-- ================================================================================= -->



<div class="dbMultiEntryContainer">
	<?php $__currentLoopData = $form_details->eyeformmultipleentry()->where('field_name', 'OpthalHistory')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<div class="col-md-12">
		<div class="col-md-2"> </div>

		<div class="col-md-3">
			<input type="text" class="form-control" readonly value="<?php echo e($item->field_value_OD); ?>">
		</div>

		<div class="col-md-3">
			<input type="text" class="form-control" readonly value="<?php echo e($item->field_value_OS); ?>">
		</div>

		<div class="col-md-2">
			<button class="removeDbItem btn btn-default" data-deleteid="<?php echo e($item->id); ?>">Remove</button>
		</div>

		<div class="col-md-12">
			<div class="col-md-2"> </div>

			<div class="col-md-3">
				<input type="text" class="form-control" readonly value="<?php echo e($item->duration_od); ?>">
			</div>

			<div class="col-md-3">
				<input type="text" class="form-control" readonly value="<?php echo e($item->duration_os); ?>">
			</div>

			<div class="col-md-2">
				
			</div>
		</div>
	</div>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<!-- ================================================================================= -->
<span class="dropdown-container">
	<div id="systemic_history" class="ContainerToAppend">
		<div class="col-md-12">
			<div class="col-md-2">
				<div class="form-group labelgrp">
					<label class="">Systemic History</label> 
				</div>
				<input type="hidden" id="systemicHistory[]" name="systemicHistory[]" class="hiddenCounter" value="1" />  
			</div>

			<div class="col-md-6">
				<?php echo e(Form::select('SystemicHistory_OD[]', array(' '=>'-Select-') + $form_dropdowns->where('fieldName', 'systemic_history')->pluck('ddText','ddText')->toArray(), array_key_exists('systemic_history', $defaultValues)?$defaultValues['systemic_history']:null, array('class'=> 'form-control select2','data-live-search'=>'true'))); ?>

			</div>

			<div class="col-md-4">
				<button type="button" name="add" id='systemichistorybtn' class="btn btn-success set-dropdown-options" data-field_name="systemic_history" data-form_name="EyeForm">Set Option </button>

				<button type='button' class="btn btn-primary" id='systemichistorybtnsave'>Save Option</button>

				<button id="addSystemicHistory" class="btn btn-default addmore" data-templateDiv="SystemicHistoryTemplate">Add</button>
			</div>
		</div>

		<div class="col-md-12">
			<div class="col-md-2">
				<div class="form-group labelgrp">
					<label class="">Duration</label> 
				</div>
			</div>

			<div class="col-md-6">
				<?php echo e(Form::text('SystemicHistory_OD_duration[]', null, array('class'=> 'form-control', 'autocomplete'=>'off'))); ?>

			</div>

			<div class="col-md-4">
				
			</div>
		</div>
	</div>
	<div id='SystemicHistoryTextBoxesGroup' class="col-md-12"> 	</div>

	<div class='dropdown-options-initial-div' class="col-md-12" style="display:none;"> </div>
</span>
<!-- ================================================================================= -->

<div class="dbMultiEntryContainer">
	<?php $__currentLoopData = $form_details->patients_systemic_history; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<div class="col-md-12">
		<div class="col-md-2"> </div>
		<div class="col-md-8">
			<input type="text" class="form-control" readonly value="<?php echo e($item->value); ?>">
		</div>
		<div class="col-md-2">
			<button class="removeDbItem btn btn-default" data-deleteid="<?php echo e($item->id); ?>" data-type="systemic_history">Remove</button>
		</div>

		<div class="col-md-12">
			<div class="col-md-2"> </div>

			<div class="col-md-8">
				<input type="text" class="form-control" readonly value="<?php echo e($item->duration); ?>">
			</div>

			<div class="col-md-2">
				
			</div>
		</div>
	</div>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<div class="col-md-12">
	<div class="col-md-2">
		<div class="form-group labelgrp">
			<label>Family History</label>
		</div>
	</div>

	<div class="col-md-9">
		<?php echo e(Form::textarea('familyHistory', Request::old('familyHistory',$form_details->familyHistory), array('class'=> 'form-control'))); ?>

	</div>
</div>

<div class="col-md-12">
	<div class="col-md-2">
		<div class="form-group labelgrp">
			<label>Birth History</label>
		</div>
	</div>

	<div class="col-md-9">
		<?php echo e(Form::textarea('birthHistory', Request::old('birthHistory',$form_details->birthHistory), array('class'=> 'form-control'))); ?>

	</div>
</div>
<div class="col-md-12 custom-item-parent-div">
	<div class="row custom-item">
		<div class="col-md-4">
			<select class="custom-item-dropdown form-control select2">
				<option value="">Select Option</option>
				<option value="ChiefComplaint" data-title="Chief Complaint" data-od="ChiefComplaint_OD[]" data-os="ChiefComplaint_OS[]">Chief Complaint</option>
				<option value="OpthalHistory" data-title="Ophthalmic History" data-od="OpthalHistory_OD[]" data-os="OpthalHistory_OS[]">Ophthalmic History</option>
				<option value="systemicHistory" data-title="Systemic History" data-od="SystemicHistory_OD[]">Systemic History</option>
			</select>
		</div>
		<div class="col-md-3"> </div>
		<div class="col-md-3"> </div>
		<div class="col-md-2">
			<span class="add-custom-item btn btn-default">Add</span>
		</div>
	</div>
	<div class="custom-item-container">

	</div>
</div>                                    
<div class="col-md-12">
	<div class="col-md-6 col-md-offset-4">
		<div class="form-group">
			<button type="submit" formaction="<?php echo e(url('/patientDetails/SaveEyeExamination')); ?>" type="submit" name="submit" class="btn btn-primary btn-lg" value="submit">Submit</button>
			<button type="submit" formaction="<?php echo e(url('/patientDetails/SaveEyeExamination1')); ?>" name="submitandview" class="btn btn-primary btn-lg" value="submitandview">Submit & View
			</button>
		</div>
	</div>
</div>

