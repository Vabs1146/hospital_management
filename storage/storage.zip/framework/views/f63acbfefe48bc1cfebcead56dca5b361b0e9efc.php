<?php $__env->startSection('content'); ?>
<div class="container-fluid">
<div class="row clearfix">
  <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
    <?php if(Session::has('flash_message')): ?>
      <div class="alert alert-success">
      <?php echo e(Session::get('flash_message')); ?>

        </div>
        <?php endif; ?>
        </div>
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                         <div class="header bg-pink">
                            <h2>Doctor Fees</h2>
                          </div>
                        
                        <div class="body">
                          <div class="row mb-2">
                              <div class="col-lg-12"> 
                              <div class="col-md-6">
                              <a class="btn btn-success btn-lg" href="<?php echo e(route('fees-details.create')); ?>"> Add New Doctor Fees
                              </a>
                               </div>
                              <div class="col-md-6">                               </div>
                              </div>
                              </div>
                           <div class="table-responsive">
<table class="table table-bordered table-striped table-hover">
    <tr>
        <th>No</th>
        <th>Doctor</th>
        <th>Details</th>
        <th>Amount</th>
        <th>Status</th>
        <th width="280px">Action</th>
    </tr>
    <?php $__currentLoopData = $fees_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fees_details_row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e(++$i); ?></td>
        <td><?php echo e($fees_details_row->doctor_id); ?></td>
        <td><?php echo e($fees_details_row->fees_details); ?></td>
        <td><?php echo e($fees_details_row->fees_amount); ?></td>
        <td><?php echo e($fees_details_row->status); ?></td>
        <td>
            
            <a class="btn btn-primary" href="<?php echo e(route('fees-details.edit',$fees_details_row->id)); ?>">Edit</a> 
            <?php echo e(Form::open(['method' => 'DELETE','route' => ['fees-details.destroy', $fees_details_row->id],'style'=>'display:inline'])); ?> 
                <?php echo e(Form::submit('Delete', ['class' => 'btn btn-danger'])); ?> 
            <?php echo e(Form::close()); ?>

        </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
</div>
<?php echo e($fees_details->render()); ?> 
                            </div>
                  
                    </div>
                </div>
            </div>


</div>



        <?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlayouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>