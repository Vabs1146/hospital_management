<?php $__env->startSection('content'); ?>
<div class="container-fluid">
<div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                   <?php if(Session::has('flash_message')): ?>
                    <div class="alert alert-success">
                        <?php echo e(Session::get('flash_message')); ?>

                    </div>
                    <?php endif; ?>
                    <div class="card">
                         <div class="header bg-pink">
                            <h2>
                                List of Members Contact Details
                            </h2>
                          
                        </div>
                        <div class="body">
                            <div class="table-responsive">
                                 <table class="table table-hover dataTable js-exportable" id="thegrid" data-stripe-classes="[]">

                                  <thead>
                                    <tr>
                                        <th>Id</th>
                                        <th>Name</th>
                                        <th>Relationship</th>
                                        <th>Mobile No</th>
                                        <th>Email Id</th>
                                        <th style="width:50px"></th>
                                    </tr>
                                  </thead>

                                  <tbody>
                                  </tbody>
                                </table>
                            </div>     
                        </div>
                        <div class="panel-footer">
                          <a href="<?php echo e(url('staff_member/create')); ?>" class="btn btn-lg btn-primary" role="button">Add User</a>
                        </div>              
                    </div>
                </div>
            </div>


</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script type="text/javascript">
        var theGrid = null;
        $(document).ready(function(){
            theGrid = $('#thegrid').DataTable({
                "processing": true,
                "serverSide": true,
                "ordering": true,
                "responsive": false,
                "autoWidth": false,
                "ajax": "<?php echo e(url('staff/grid')); ?>",
                "columnDefs": [
                    {
                        "targets": 0,
                        "visible": false,
                        "searchable": false,
                        "class":"never"
                    },
                    {
                        "render": function ( data, type, row ) {
                            return '<a href="<?php echo e(url('/staff_member')); ?>/'+row[0]+'/edit" class="btn btn-default">Update</a>';
                        },
                        "targets": 5
                    },
                ]
            });
        });
        function doDelete(id) {
            if(confirm('You really want to delete this record?')) {
               $.ajax({ url: '<?php echo e(url('/staff_users')); ?>/' + id, type: 'DELETE'}).success(function() {
                theGrid.ajax.reload();
               });
            }
            return false;
        }
    </script>
<?php $__env->stopSection(); ?>
  
<?php echo $__env->make('adminlayouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>