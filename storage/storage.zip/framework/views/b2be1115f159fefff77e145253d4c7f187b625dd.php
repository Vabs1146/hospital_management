<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Document</title>
    <link href="<?php echo e(asset('css/bootstrap.css')); ?>" rel="stylesheet">
    <style type="text/css">
        .invoice-title h2,
        .invoice-title h3 {
            display: inline-block;
        }
        
        .table > tbody > tr > .no-line {
            border-top: none;
        }
        
        .table > thead > tr > .no-line {
            border-bottom: none;
        }
        
        .table > tbody > tr > .thick-line {
            border-top: 2px solid;
        }
    </style>
</head>
<div class="container">
	<?php if(isset($header_footer_data[4]) && $header_footer_data[4] == "1" && $logoUrl != ""): ?>
    <div class="row">
        <div class="col-lg-12">
            <img src=<?php echo e(Storage::disk('local')->url($logoUrl)); ?> class="img-rounded" alt="letter head top" width="100%" height="100%" />
        </div>
    </div>
	<?php endif; ?>
    <div class="row">
        <div class="col-xs-12">
            <hr>
            <div class="row">
                <div class="col-xs-6">
                    <address>
                    <strong>Billed To:</strong>
                        <?php echo e($casedata['patient_name']); ?><br>
                      
                        <strong> Date:
                         <?php $__empty_1 = true; $__currentLoopData = $DateWiseRecordLst; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $VisitListDateWise): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
						 <?php if($case_master['id'] == $VisitListDateWise['id']): ?>
						 <?php echo e(Carbon\Carbon::parse($VisitListDateWise['created_at'])->format('d-M-Y')); ?><span> &nbsp;,</span>

						 <?php endif; ?>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</strong>    
                    </address>
                    </div>
                <div class="col-xs-6 text-right">
                    case no. :  <?php echo e($casedata['case_number']); ?>

                </div>
				<div class="col-xs-6 text-right">
                    Bill no. :  <?php echo e($casedata['bill_number']); ?>

                </div>
            </div>
        </div>
    </div>
    
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-body">
                    <div class="table-responsive">
                        <table class="table table-condensed">
                            <thead>
                            <tr>
                                <td >
                                    <strong>Sr no.</strong>
                                </td>
                                <td >
                                    &nbsp;
                                </td>
                                <td >
                                    <strong>Doctor</strong>
                                </td>
                                <td >
                                    <strong>Fees Details</strong>
                                </td>
                                <!-- <td >
                                   Payment Mode
                                </td> -->
                                <td  class="text-right"><strong>Totals</strong></td>                           
                                
                            </tr>
                            </thead>
                            <?php if(!empty($billdata) && count($billdata) > 0 ): ?>
                                <?php $cntInt = 1 ?>
                                <?php $__currentLoopData = $billdata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bdata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                    <tr>
                                        <td >
                                            <?php echo e($cntInt++); ?>

                                        </td>
                                        <td >
                                    &nbsp;
                                </td>
                                        <td> <?php echo e($doctor_array[$bdata->doctor_id]); ?> </td>
                                        <td> <?php echo e($fees_details_array[$bdata->bill_item]); ?> </td>
                                        
                                        <td class="text-right"> <?php echo e($bdata->bill_Amount); ?> </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                     <tr>
                                        
										<td  class="thick-line" > </td>
                                        <td class="thick-line" >&nbsp;</td>
                                        <td class="thick-line" >&nbsp;</td>
                                        <td class="thick-line text-right"> <label for="bill_Amount" class="control-label">Sub Total</label>  </td>
                                        
                                        <td class="thick-line text-right"> 
                                            <?php 
                                                $itemsum = 0; 
                                                $itemsum = $billdata->sum('bill_Amount');
                                                $itemsum = floatval($itemsum);
                                            ?>
                                            <?php echo e(round($itemsum,2)); ?>

                                              <?php
                                                
                                                $billamount = (isset($itemsum) && $itemsum > 0) ? ($itemsum += ($itemsum*(floatval($casedata['tax_percentage'])/100))) : $itemsum;

                                                $billamount = (isset($itemsum) && $itemsum > 0) ? floatval($itemsum - floatval($casedata['paidAmount'])) : 0;
												/*
                                                $f = new \NumberFormatter("en", \NumberFormatter::SPELLOUT);
                                                $exp = explode('.', $billamount);
                                                if(sizeof($exp)>1){

                                                }
                                                $billamountInWords = ucfirst($f->format($exp[0])) . ((sizeof($exp)>1)? (' and ' . ucfirst($f->format($exp[1]))) : '') . ' only.';
												*/
												$billamountInWords = "";
                                                /* $billamount = $billamount > 0 ? ($billamount += ($billamount*(floatval($casedata['tax_percentage'])/100))) : $billamount; */
                                            ?>
                                        </td>
                                    </tr>
                                    
									<?php if($casedata['bill_discount'] != "" && !empty($casedata['bill_discount'])): ?> 
										<tr>
											
											<td  class="no-line" > </td>
											<td  class="no-line">&nbsp;</td>
											<td  class="no-line">&nbsp;</td>
											<td  class="no-line text-right"><label class="control-label">Discount</label></td>
											<td  class="no-line  text-right"> <?php echo e(round((float) $casedata['bill_discount'], 2)); ?> </td>
										   
										</tr>
									<?php endif; ?>
                                    
                                    <tr>
                                       
										<td  class="no-line" > </td>
                                        <td  class="no-line">&nbsp;</td>
                                        <td  class="no-line">&nbsp;</td>
                                        <td  class="no-line text-right"><label class="control-label">Total Amount</label></td>
                                        <td  class="no-line  text-right"> <?php echo e(round($casedata['billAmount'], 2)); ?> </td>
                                       
                                    </tr>
									
                                    <tr>
                                        <td class="no-line text-right" colspan="4"><?php echo e($billamountInWords); ?></td>

                                    </tr>
                            <?php endif; ?>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>



	<?php if(!empty($payment_details) && count($payment_details) > 0 ): ?>

	<div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-body">
                    <div class="table-responsive">
                        <table class="table table-condensed">
                            <thead>
                            <tr>
                                <td >
                                    <strong>Sr no.</strong>
                                </td>
                               
                                <td >
                                    <strong>Payment Date</strong>
                                </td>
                                <td >
                                    <strong>Payment Mode</strong>
                                </td>
                                <td class="text-right">
                                   Payment Amount
                                </td>
                            </tr>
                            </thead>
                            
                                <?php $cntInt = 1 ?>
                                <?php $__currentLoopData = $payment_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment_details_row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                    <tr>
                                        <td >
                                            <?php echo e($cntInt++); ?>

                                        </td>
                                        
                                        <td> <?php echo e(date('d F, Y', strtotime($payment_details_row->payment_date))); ?> </td>
                                        <td> <?php echo e($payment_modes_array[$payment_details_row->payment_mode]); ?>    </td>
                                        
                                        <td class="text-right"> <?php echo e($payment_details_row->paid_Amount); ?>   </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                     <tr>
                                        
                                        <td class="thick-line" >&nbsp;</td>
                                        <td class="thick-line" >&nbsp;</td>
                                        <td class="thick-line text-right"> <label for="bill_Amount" class="control-label">Total Paid</label>  </td>
                                        
                                        <td class="thick-line text-right"> 
                                           Rs. <?php echo e($total_paid); ?>    
                                        </td>
                                    </tr>
                                    
                                    <tr>
                                        
                                        <td  class="no-line">&nbsp;</td>
                                        <td  class="no-line">&nbsp;</td>
                                        <td  class="no-line text-right"><label class="control-label">Balance</label></td>
                                        <td  class="no-line  text-right"> Rs. <?php echo e(round(($casedata['billAmount'] - $total_paid), 2)); ?>    </td>
                                       
                                    </tr>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

	<?php endif; ?>

 
    <div class="row">
            <div class="col-sm-6"></div>
            <div class="col-sm-6">
                <div class="pull-right">
                 <b><?php echo e(config('app.name', 'Dr')); ?></b>  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </div>
            </div>
        </div>
    

</div>
    <!-- jQuery -->
    <script src="<?php echo e(asset('js/jquery.min.js')); ?> "></script>
        <!-- Bootstrap -->
    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
    <script type="text/javascript">
        $(document).ready(function(){
            setTimeout(function () { window.print(); }, 500);
            window.onfocus = function () { setTimeout(function () { window.close(); }, 50); }
        });
    </script>
</body>

</html>