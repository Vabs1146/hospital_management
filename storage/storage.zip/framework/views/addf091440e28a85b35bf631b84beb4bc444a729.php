<?php $__env->startSection('pagebody'); ?>
      <!-- Main Carousel -->
      <section class="section background-dark">
        <div class="line">
          <div class="carousel-fade-transition owl-carousel carousel-main carousel-nav-white carousel-wide-arrows">
              <?php if(isset($imageGallery)): ?>
              <?php $__currentLoopData = $imageGallery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $imgGal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="item">
                  <div class="s-12 center">
                    <img src="<?php echo e(Storage::disk('local')->url($imgGal->imgUrl)); ?>" alt="">
                    <div class="carousel-content">
                      <div class="padding-2x">
                        <div class="s-12 m-12 l-8">
                          <p class="text-white text-s-size-20 text-m-size-40 text-l-size-60 margin-bottom-40 text-thin text-line-height-1">
                            <?php echo e($imgGal->Name); ?>

                          </p>
                          <p class="text-white text-size-16 margin-bottom-40">
                            <?php echo e($imgGal->Description); ?>

                          </p>  
                        </div>                  
                      </div>
                    </div>
                  </div>
                </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php endif; ?>
          </div>  
        </div>
      </section>
      
      <!-- Section 1 -->
      <section class="section background-white"> 
        <div class="line">
          <div class="margin">
              <?php echo $bodyOne; ?>

          </div>
        </div>
      </section>
      
      <!-- Section 2 -->
      <section class="section background-primary text-center">
        <div class="line">
          <div class="s-12 m-10 l-8 center">
            <h2 class="headline text-thin text-s-size-30"><?php echo e($bodyTwo->name); ?></h2>
            <p class="text-size-20"> <?php echo e($bodyTwo->description); ?> </p>
          </div>
        </div>  
      </section>
      
      <!-- Section 3 -->
      <section class="section background-white">
        <div class="full-width text-center">
          <div class="line">
              <?php echo $bodyTwo->html_text; ?>

          </div>  
        </div>  
      </section>
      <hr class="break margin-top-bottom-0">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footescripts'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make(env('layoutTemplate'), array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>