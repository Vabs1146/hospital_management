<?php $__env->startSection('style'); ?>
<style>
    @media  screen and (max-width: 767px) {
        .select2 {
            width: 100% !important;
        }
    }
    .ui-autocomplete-loading {
        background: white url("<?php echo e(asset('images/ui-anim_basic_16x16.gif')); ?>") right center no-repeat;
    }

    .canvas{
        position:relative; width:150px; height:200px; background-color:#7a7a7a; margin:70px auto 20px auto;
    }

</style>
<link href="<?php echo e(url('/')); ?>/select2/css/select2.min.css" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
<div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                  <?php echo $__env->make('shared.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 
                    <?php if(Session::has('flash_message')): ?>
                        <div class="alert alert-success">
                            <?php echo e(Session::get('flash_message')); ?>

                        </div>
                    <?php endif; ?>
                    <div class="card">
                        <form action="<?php echo e(url('/staff_member'.( isset($model) ? "/" . $model->id : ""))); ?>" method="POST" class="form-horizontal">
                        <?php echo e(csrf_field()); ?>


                        <?php if(isset($model)): ?>
                            <input type="hidden" name="_method" value="PATCH">
                        <?php endif; ?>
                         <div class="header bg-pink">
                            <h2>
                                 Add/Modify Members Contact
                            </h2>
                          
                        </div>
                        <div class="body">
                            <div class="row clearfix ">
                            <div class="col-md-12">
                              <input type="hidden" name="id" id="id" class="form-control" value="<?php echo e(isset($model['id']) ? $model['id'] : ''); ?>" readonly="readonly">
                              <div class="col-md-2">
                              <div class="form-group labelgrp">
                              <label for="staff_type_id" class="form-control">User Role :</label>
                              </div>
                              </div>

                              <div class="col-md-4">
                              <div class="form-group">
                              <?php echo e(Form::select('staff_type_id',array(''=>'Please select') + $staff_type_lst->toArray(),
                                Request::old('staff_type_id', $model['staff_type_id']), array('class' => 'form-control select2','data-live-search'=>'true'))); ?>                              
                              </div>
                              </div>

                               <div class="col-md-2">
                              <div class="form-group labelgrp">
                              <label for="Name" class="form-control">Name :</label>
                              </div>
                              </div>

                              <div class="col-md-4">
                              <div class="form-group">
                              <div class="form-line">
                              <input type="text" name="name" id="name" class="form-control" value="<?php echo e(isset($model['name']) ? $model['name'] : ''); ?>"> 
                              </div>
                              </div>
                              </div>
                              </div>


                            <div class="col-md-12">                           
                             <div class="col-md-2">
                              <div class="form-group labelgrp">
                              <label for="Description" class="form-control">Description :</label>
                              </div>
                              </div>

                              <div class="col-md-4">
                              <div class="form-group">
                              <div class="form-line">
                              <input type="text" name="description" id="description" class="form-control" value="<?php echo e(isset($model['description']) ? $model['description'] : ''); ?>">
                              </div>
                              </div>
                              </div>
                              <div class="col-md-2">
                              <div class="form-group labelgrp">
                              <label for="ed_degree" class="form-control">Ed Degree :</label>
                              </div>
                              </div>

                              <div class="col-md-4">
                              <div class="form-group">
                              <div class="form-line">
                              <input type="text" name="ed_degree" id="ed_degree" class="form-control" value="<?php echo e(isset($model['ed_degree']) ? $model['ed_degree'] : ''); ?>">
                              </div>
                              </div>
                              </div>
                            </div>  


                            <div class="col-md-12">                           
                             <div class="col-md-2">
                              <div class="form-group labelgrp">
                              <label for="Description" class="form-control">Mobile No :</label>
                              </div>
                              </div>

                              <div class="col-md-4">
                              <div class="form-group">
                              <div class="form-line">
                              <input type="text" name="mobile_no" id="mobile_no" class="form-control" value="<?php echo e(isset($model['mobile_no']) ? $model['mobile_no'] : ''); ?>">
                              </div>
                              </div>
                              </div>
                              <div class="col-md-2">
                              <div class="form-group labelgrp">
                              <label for="ed_degree" class="form-control">Email Id :</label>
                              </div>
                              </div>

                              <div class="col-md-4">
                              <div class="form-group">
                              <div class="form-line">
                              <input type="text" name="email_id" id="email_id" class="form-control" value="<?php echo e(isset($model['email_id']) ? $model['email_id'] : ''); ?>">
                              </div>
                              </div>
                              </div>
                            </div>  


                             <div class="col-md-12">                           
                             <div class="col-md-2">
                              <div class="form-group labelgrp">
                              <label for="Description" class="form-control">Address :</label>
                              </div>
                              </div>

                              <div class="col-md-4">
                              <div class="form-group">
                              <div class="form-line">
                             <input type="text" name="address" id="address" class="form-control" value="<?php echo e(isset($model['address']) ? $model['address'] : ''); ?>">
                              </div>
                              </div>
                              </div>
                              <div class="col-md-2">
                              <div class="form-group labelgrp">
                              <label for="ed_degree" class="form-control">Is Active :</label>
                              </div>
                              </div>

                              <div class="col-md-4">
                              <div class="form-group">
                                <input type="checkbox" id="remember_me_3" <?php echo e(( !isset($model) || is_null($model['is_active']) || $model['is_active'] == 0 )?"":"checked"); ?>  value="<?php echo e(isset($model['is_active']) ? $model['is_active'] : '0'); ?>" class="filled-in" name="is_active">
                                <label for="remember_me_3"></label>
                               
                              </div>
                              </div>
                            </div>   

                            <div class="col-md-12">                           
                             <div class="col-md-2">
                              <div class="form-group labelgrp">
                              <label for="Description" class="form-control">Created At :</label>
                              </div>
                              </div>

                              <div class="col-md-4">
                              <div class="form-group">
                              <div class="form-line">
                              <input type="date" name="created_at" id="created_at" class="form-control" value="<?php echo e(isset($model['created_at']) ? $model['created_at'] : ''); ?>">
                              </div>
                              </div>
                              </div>
                              <div class="col-md-2">
                              <div class="form-group labelgrp">
                              <label for="ed_degree" class="form-control">Updated At :</label>
                              </div>
                              </div>

                              <div class="col-md-4">
                              <div class="form-group">
                              <div class="form-line">
                              <input type="date" name="updated_at" id="updated_at" class="form-control" value="<?php echo e(isset($model['updated_at']) ? $model['updated_at'] : ''); ?>">
                              </div>
                              </div>
                              </div>
                            </div>   

                            <div class="col-md-12">                           
                              <div class="col-md-4 col-md-offset-4">
                              <div class="form-group">
                              <button type="submit" class="btn btn-success btn-lg">
                        <i class="fa fa-plus"></i> Save
                    </button> 
                    <a class="btn btn-default btn-lg" href="<?php echo e(url('/staff_users')); ?>"><i class="glyphicon glyphicon-chevron-left"></i> Back</a>
                              </div>
                              </div>
                              
                            
                            </div>                  
                            <!-- End Of row -->
                            </div>                              
                            </div>
                          </form>
                        </div>
                        
                    </div>
                </div>
            </div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
 <script src="<?php echo e(url('/')); ?>/select2/js/select2.min.js"></script>
 <script type="text/javascript">
   $(document).ready(function() {
   });
   $(".select2").select2();
 </script>
<?php $__env->stopSection(); ?>  
<?php echo $__env->make('adminlayouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>