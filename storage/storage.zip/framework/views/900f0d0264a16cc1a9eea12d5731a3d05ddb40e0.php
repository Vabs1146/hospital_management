<?php $__env->startSection('style'); ?>
<?php $CheckField = app('App\Http\Controllers\EyeFormController'); ?>
<style>
    @media  screen and (max-width: 767px) {
        .select2 {
            width: 100% !important;
        }
    }
    .ui-autocomplete-loading {
        background: white url("<?php echo e(asset('images/ui-anim_basic_16x16.gif')); ?>") right center no-repeat;
    }
</style>
<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/css/select2.min.css" rel="stylesheet" />
<!-- Styles -->
<link rel="stylesheet" href="<?php echo e(asset('JqueryUI/jquery-ui.css')); ?>">
 
 
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="list-group list-group-horizontal">
        <?php $__currentLoopData = $casedata['DateWiseRecordLst']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $VisitListDateWise): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($casedata['id'] == $VisitListDateWise['id']): ?>
                <a href="<?php echo e(url('/ViewMedicalDetails').'/'.$VisitListDateWise['id']); ?>" class="list-group-item active"><?php echo e(Carbon\Carbon::parse($VisitListDateWise['created_at'])->format('d-M-Y')); ?></a> <span> &nbsp;</span>    
            <?php else: ?>
                <a href="<?php echo e(url('/ViewMedicalDetails').'/'.$VisitListDateWise['id']); ?>" class="list-group-item"><?php echo e(Carbon\Carbon::parse($VisitListDateWise['created_at'])->format('d-M-Y')); ?></a> <span> &nbsp;</span>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>

<div class="container-fluid">
<div class="row clearfix">
  <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
      <?php echo $__env->make('shared.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <?php if(Session::has('flash_message')): ?>
      <div class="alert alert-success">
     <?php echo e(Session::get('flash_message')); ?>

      </div>
      <?php endif; ?>
<div class="card">
<form action="<?php echo e(url('/PatientMedicalDetails').'/'.$casedata['id']); ?>" method="GET" class="form-horizontal">
<?php echo e(csrf_field()); ?>

<div class="header bg-pink">
<h2>
Patient Details
</h2>
</div>
    <div class="body">
     <div class="row clearfix">
         <div class="col-xs-12 ol-sm-12 col-md-12 col-lg-12">
             <div class="panel-group" id="accordion_9" role="tablist" aria-multiselectable="true">
                 <div class="panel panel-col-pink">
                    <div class="panel-heading" role="tab" id="headingOne_9">
                        <h4 class="panel-title">
                            <a role="button" data-toggle="collapse" data-parent="#accordion_9" href="#collapseOne_9" aria-expanded="true" aria-controls="collapseOne_9">
                             Case Number : <?php echo e($casedata['case_number']); ?> 
                            </a>
                        </h4>
                    </div>

<div id="collapseOne_9" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingOne_9">
<?php echo e(Form::hidden('case_id', Request::old('case_id',$casedata['id']), array('class'=> 'form-control'))); ?>

<div class="panel-body">
    <div class="row clearfix">
      <div class="col-md-12">
        <div class="form-group">
        <?php echo e(Form::hidden('case_number', Request::old('case_number', $casedata['case_number']), array('class'=> 'form-control', 'readonly'=>'readonly'))); ?>

        </div>
      </div>

<!---------------------medial--------------------------------->
    <div class="panel-body" >
    <div class="container-fluid">
     <div class="table-responsive">
    <table class="table  table-bordered">
        <tbody>
             <?php if(!$CheckField::IsFieldEmpty($patient_details->Complaints)): ?>
            <tr>
              <td> <label for="MensturationHistory" class="control-label">Presenting Complaints with duration :</label></td>
                <td>
                 <?php echo e(($patient_details->Complaints)); ?>

                 
                </td>
            </tr>
            <?php endif; ?>
            <?php if(!$CheckField::IsFieldEmpty($patient_details->History)): ?>
            <tr>
              <td> <label for="MensturationHistory" class="control-label">Past History</label></td>
                <td>
                 <?php echo e(($patient_details->History)); ?>

                </td>
            </tr>
            <?php endif; ?>
             <?php if(!$CheckField::IsFieldEmpty($patient_details->PastPersonalHistory)): ?>
            <tr>
              <td> <label for="MensturationHistory" class="control-label">Past Personal History </label></td>
                <td>
                 <?php echo e(($patient_details->PastPersonalHistory)); ?>

                </td>
            </tr>
            <?php endif; ?>
            <?php if(!$CheckField::IsFieldEmpty($patient_details->menarch)): ?>
            <tr>
              <td> <label for="MensturationHistory" class="control-label">Menarche </label></td>
                <td>
                 <?php echo e(($patient_details->menarch)); ?>

                </td>
            </tr>
            <?php endif; ?>
            <?php if(!$CheckField::IsFieldEmpty($patient_details->ObstetricMarriedSice)): ?>
            <tr>
              <td> <label for="MensturationHistory" class="control-label">Married Since </label></td>
                <td>
                 <?php echo e(($patient_details->ObstetricMarriedSice)); ?>

                </td>
            </tr>
            <?php endif; ?>
            <?php if(!$CheckField::IsFieldEmpty($patient_details->ObstetricCMP)): ?>
            <tr>
              <td> <label for="MensturationHistory" class="control-label">Year</label></td>
                <td>
                 <?php echo e(($patient_details->ObstetricCMP)); ?>

                </td>
            </tr>
            <?php endif; ?>
            <?php if(!$CheckField::IsFieldEmpty($patient_details->ObstetricG)): ?>
            <tr>
              <td> <label for="MensturationHistory" class="control-label">G </label></td>
                <td>
                 <?php echo e(($patient_details->ObstetricG)); ?>

                </td>
            </tr>
            <?php endif; ?>
            <?php if(!$CheckField::IsFieldEmpty($patient_details->ObstetricP)): ?>
            <tr>
              <td> <label for="MensturationHistory" class="control-label">P</label></td>
                <td>
                 <?php echo e(($patient_details->ObstetricP)); ?>

                </td>
            </tr>
            <?php endif; ?>
            <?php if(!$CheckField::IsFieldEmpty($patient_details->ObstetricL)): ?>
            <tr>
              <td> <label for="MensturationHistory" class="control-label">L </label></td>
                <td>
                 <?php echo e(($patient_details->ObstetricL)); ?>

                </td>
            </tr>
            <?php endif; ?>
            <?php if(!$CheckField::IsFieldEmpty($patient_details->ObstetricA)): ?>
            <tr>
              <td> <label for="MensturationHistory" class="control-label">A </label></td>
                <td>
                 <?php echo e(($patient_details->ObstetricA)); ?>

                </td>
            </tr>
            <?php endif; ?>
            <?php if(!$CheckField::IsFieldEmpty($patient_details->ObstetricD)): ?>
            <tr>
              <td> <label for="MensturationHistory" class="control-label">D </label></td>
                <td>
                 <?php echo e(($patient_details->ObstetricD)); ?>

                </td>
            </tr>
            <?php endif; ?>
            <?php if(!$CheckField::IsFieldEmpty($patient_details->ObstetricText)): ?>
            <tr>
              <td> <label for="MensturationHistory" class="control-label">Text </label></td>
                <td>
                 <?php echo e(($patient_details->ObstetricText)); ?>

                </td>
            </tr>
            <?php endif; ?>
            <?php if(!$CheckField::IsFieldEmpty($patient_details->presentPregnecyLMP)): ?>
            <tr>
              <td> <label for="MensturationHistory" class="control-label">LMP </label></td>
                <td>
                 <?php echo e(($patient_details->presentPregnecyLMP)); ?>

                </td>
            </tr>
            <?php endif; ?>
            <?php if(!$CheckField::IsFieldEmpty($patient_details->presentPregnencyEDD)): ?>
            <tr>
              <td> <label for="MensturationHistory" class="control-label">EDD </label></td>
                <td>
                 <?php echo e(($patient_details->presentPregnencyEDD)); ?>

                </td>
            </tr>
            <?php endif; ?>
            <?php if(!$CheckField::IsFieldEmpty($patient_details->presentPregnencyUSG)): ?>
            <tr>
              <td> <label for="MensturationHistory" class="control-label">Edd by USG </label></td>
                <td>
                 <?php echo e(($patient_details->presentPregnencyUSG)); ?>

                </td>
            </tr>
            <?php endif; ?>
            <?php if(!$CheckField::IsFieldEmpty($patient_details->Education)): ?>
            <tr>
              <td> <label for="MensturationHistory" class="control-label">Education </label></td>
                <td>
                 <?php echo e(($patient_details->Education)); ?>

                </td>
            </tr>
            <?php endif; ?>
           
            <?php if(!$CheckField::IsFieldEmpty($patient_details->GenExamBuild)): ?>
            <tr>
              <td> <label for="MensturationHistory" class="control-label">Build </label></td>
                <td>
                 <?php echo e(($patient_details->GenExamBuild)); ?>

                </td>
            </tr>
            <?php endif; ?>
             <?php if(!$CheckField::IsFieldEmpty($patient_details->GenExamHeight)): ?>
            <tr>
              <td> <label for="MensturationHistory" class="control-label">Height </label></td>
                <td>
                 <?php echo e($patient_details->GenExamHeight .' cm'); ?>

                </td>
            </tr>
            <?php endif; ?>
             <?php if(!$CheckField::IsFieldEmpty($patient_details->GenExamWeight)): ?>
            <tr>
              <td><label for="MensturationHistory" class="control-label">Weight </label></td>
                <td>
                  <?php echo e($patient_details->GenExamWeight.' kg'); ?>

                </td>
            </tr>
            <?php endif; ?>
         
             <?php if(!$CheckField::IsFieldEmpty($patient_details->BMI)): ?>
            <tr>
              <td><label for="MensturationHistory" class="control-label">BMI </label></td>
                <td>
                  <?php echo e($patient_details->BMI); ?>

                </td>
            </tr>
            <?php endif; ?>
              <?php if(!$CheckField::IsFieldEmpty($patient_details->Temp)): ?>
            <tr>
              <td><label for="MensturationHistory" class="control-label">Temp </label></td>
                <td>
                  <?php echo e($patient_details->Temp); ?>

                </td>
            </tr>
            <?php endif; ?>
             <?php if(!$CheckField::IsFieldEmpty($patient_details->AG)): ?>
            <tr>
              <td><label for="MensturationHistory" class="control-label">AG </label></td>
                <td>
                  <?php echo e($patient_details->AG); ?>

                </td>
            </tr>
            <?php endif; ?>
            <?php if(!$CheckField::IsFieldEmpty($patient_details->GenExamPulse)): ?>
            <tr>
              <td><label for="MensturationHistory" class="control-label">Pulse </label></td>
                <td>
                  <?php echo e($patient_details->GenExamPulse .' per min'); ?>

                </td>
            </tr>
            <?php endif; ?>
              <?php if(!$CheckField::IsFieldEmpty($patient_details->Temp)): ?>
            <tr>
              <td><label for="MensturationHistory" class="control-label">BP </label></td>
                <td>
                  <?php echo e($patient_details->GenExamBP . '/' . $patient_details->GenExamBP_lower . 'mmhg'); ?>

                </td>
            </tr>
            <?php endif; ?>
             <?php if(!$CheckField::IsFieldEmpty($patient_details->GenExamRR)): ?>
            <tr>
              <td><label for="MensturationHistory" class="control-label">RR </label></td>
                <td>
                  <?php echo e($patient_details->GenExamRR . ' per min'); ?>

                </td>
            </tr>
            <?php endif; ?>
             <?php if(!$CheckField::IsFieldEmpty($patient_details->GenExamPallor)): ?>
            <tr>
              <td><label for="MensturationHistory" class="control-label">Pallor </label></td>
                <td>
                  <?php echo e($patient_details->GenExamPallor); ?>

                </td>
            </tr>
            <?php endif; ?>
             <?php if(!$CheckField::IsFieldEmpty($patient_details->Cyanosis)): ?>
            <tr>
              <td><label for="MensturationHistory" class="control-label">Cyanosis </label></td>
                <td>
                  <?php echo e($patient_details->GenExamCyanosis); ?>

                </td>
            </tr>
            <?php endif; ?>
             <?php if(!$CheckField::IsFieldEmpty($patient_details->Icterus)): ?>
            <tr>
              <td><label for="MensturationHistory" class="control-label">Icterus </label></td>
                <td>
                  <?php echo e($patient_details->GenExamIcterus); ?>

                </td>
            </tr>
            <?php endif; ?>
             <?php if(!$CheckField::IsFieldEmpty($patient_details->Edema)): ?>
            <tr>
              <td><label for="MensturationHistory" class="control-label">Edema </label></td>
                <td>
                  <?php echo e($patient_details->GenExamEdema); ?>

                </td>
            </tr>
            <?php endif; ?>
             <?php if(!$CheckField::IsFieldEmpty($patient_details->GenExamSkin)): ?>
            <tr>
              <td><label for="MensturationHistory" class="control-label">Skin </label></td>
                <td>
                  <?php echo e($patient_details->GenExamSkin); ?>

                </td>
            </tr>
            <?php endif; ?>
             <?php if(!$CheckField::IsFieldEmpty($patient_details->SysExamCVS)): ?>
            <tr>
              <td><label for="MensturationHistory" class="control-label">CVS </label></td>
                <td>
                  <?php echo e($patient_details->SysExamCVS); ?>

                </td>
            </tr>
            <?php endif; ?>

            <?php if(!$CheckField::IsFieldEmpty($patient_details->SysExamRS)): ?>
            <tr>
              <td><label for="MensturationHistory" class="control-label">RS </label></td>
                <td>
                  <?php echo e($patient_details->SysExamRS); ?>

                </td>
            </tr>
            <?php endif; ?>
            <?php if(!$CheckField::IsFieldEmpty($patient_details->SysExamPA)): ?>
            <tr>
              <td><label for="MensturationHistory" class="control-label">PA </label></td>
                <td>
                  <?php echo e($patient_details->SysExamPA); ?>

                </td>
            </tr>
            <?php endif; ?>
            <?php if(!$CheckField::IsFieldEmpty($patient_details->SysExamLocalExam)): ?>
            <tr>
              <td><?php echo e(Form::label('SysExamLocalExam','Local/Examination')); ?> </td>
                <td>
                  <?php echo e($patient_details->SysExamLocalExam); ?>

                </td>
            </tr>
            <?php endif; ?>
            <?php if(!$CheckField::IsFieldEmpty($patient_details->ProvisionalDiagnosis)): ?>
            <tr>
              <td><?php echo e(Form::label('ProvisionalDiagnosis','Provisional Diagnosis')); ?></td>
                <td>
                  <?php echo e($patient_details->ProvisionalDiagnosis); ?>

                </td>
            </tr>
            <?php endif; ?>
            <?php if(!$CheckField::IsFieldEmpty($patient_details->InvestigationAdvice)): ?>
            <tr>
              <td><?php echo e(Form::label('InvestigationAdvice','Investigation Advice')); ?></td>
                <td>
                  <?php echo e($patient_details->InvestigationAdvice); ?>

                </td>
            </tr>
            <?php endif; ?>
            <?php if(!$CheckField::IsFieldEmpty($patient_details->TreatmentAdvice)): ?>
            <tr>
              <td><?php echo e(Form::label('TreatmentAdvice','Treatment Advice')); ?> </td>
                <td>
                  <?php echo e($patient_details->TreatmentAdvice); ?>

                </td>
            </tr>
            <?php endif; ?>
            <?php if(!$CheckField::IsFieldEmpty($patient_details->Remark)): ?>
            <tr>
              <td><?php echo e(Form::label('Remark','Remark')); ?> </td>
                <td>
                  <?php echo e($patient_details->Remark); ?>

                </td>
            </tr>
            <?php endif; ?>
            <?php if(!$CheckField::IsFieldEmpty($patient_details->Text)): ?>
            <tr>
              <td><?php echo e(Form::label('Text','Text')); ?> </td>
                <td>
                  <?php echo e($patient_details->Text); ?>

                </td>
            </tr>
            <?php endif; ?>
            <?php if(!$CheckField::IsFieldEmpty($casedata['appointment_dt'])): ?>
            <tr>
              <td><?php echo e(Form::label('followupDate','Follow-up Date')); ?> </td>
                <td>
                  <?php echo e($casedata['appointment_dt']); ?>

                </td>
            </tr>
            <?php endif; ?>
            <?php if(!$CheckField::IsFieldEmpty($casedata['appointment_timeslot'])): ?>
            <tr>
              <td><?php echo e(Form::label('FollowUpTimeSlot','Follow up Time Slot')); ?>  </td>
                <td>
                  <?php echo e($casedata['appointment_timeslot']); ?>

                </td>
            </tr>
            <?php endif; ?>

          

        </tbody>
    </table>
 </div>
</div>
</div>


</div>
</div>
</div>
</div>

<!------------------2-panel------------------------------->

<div class="panel panel-col-pink">
<div class="panel-heading" role="tab" id="headingOne_9">
    <h4 class="panel-title">
        <a role="button" data-toggle="collapse" data-parent="#accordion_8" href="#collapseOne_8" aria-expanded="true" aria-controls="collapseOne_8">
        Prescription
        </a>
    </h4>
</div>
<div id="collapseOne_8" class="panel-collapse collapse">
            <div class="container-fluid">
                <div class="panel-body">
                    <div class="table-responsive">
					

							
                            <table class="table table-condensed">
                                <thead>
                                    <tr>
                         <td><strong>Sr. No.</strong></td>
                         <td><strong>Medicine</strong></td>
						 <td><strong>Times a day</strong></td>
						<td><strong>Day</strong></td>
                         <td><strong>Quantity</strong></td>
                        
                         
                         
                </tr>
                                </thead>
                                <tbody>
                                    <!-- foreach ($order->lineItems as $line) or some such thing here -->
                                <?php $Sumtotal = 0; ?>
                                <?php $__currentLoopData = $casedata['prescriptions']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prescption): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
               <td>
                    <?php echo e($loop->iteration); ?>

                </td>   
                <td>
                    <?php echo e($prescption->Medical_store->medicine_name); ?>

                </td>
                
                <td>
					 <?php echo e($prescption->numberoftimes); ?>

                  
                </td>
                <td>
                  <?php echo e($prescption->medicine_Quntity); ?>  
                </td>
                <td>
					
					  <?php echo e($prescption->strength); ?>

                   
                </td>
                
                
            <tr>
                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                                </tbody>
                            </table>

                        </div>
                </div>
            </div>
        </div>  
</div>
<!-----------------end-2-panel------------------------------->
<!----------------3-panel------------------------------------>
<div class="panel panel-col-pink">
<div class="panel-heading" role="tab" id="headingOne_9">
    <div class="panel-heading">
        <h4 class="panel-title">
           <a data-toggle="collapse" data-parent="#accordion" href="#collapseNote">
            Note</a>
        </h4>
    </div>
    <div id="collapseNote" class="panel-collapse collapse in">
        <div class="container">
            <div class="panel-body">
                <ul class="list-unstyled">
                    <li class="">Please bring this paper on every visit</li>
                    <li class=""> Please follow the time </li>
                    <li class=""> Please inform allergy immediately </li>
                 </ul>
            </div>
        </div> 
    </div>
</div>
</div>
<br>
<!---------------end-3-panel------------------------------------>

<!-----------button----------------------->    
<div class="row clearfix">
<div class="col-md-4 col-md-offset-4">
<div class="form-group">
   <a class="btn btn-info btn-lg" href="<?php echo e(url('/case_masters')); ?>"><i class="glyphicon glyphicon-chevron-left"></i> Back</a>    
   <button type="submit" class="btn btn-info btn-lg"> Edit </button>
   <a class="btn btn-info btn-lg" href="<?php echo e(url('/PrintMedicalDetails/').'/'.$casedata['id']); ?>" target="_blank"><i class="glyphicon glyphicon-chevron-left"></i>Print</a>
</div>
</div>
</div>
 <!----------end-button----------------------->  

</div>
</div>
</div>
</div>
</form>
</div>
</div>
</div>
</div>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/js/select2.min.js"></script>
<script type="text/javascript">
    $(document).ready(function(){
      $('#medicine_id').select2();  
      $('.datepicker').datepicker({
            format: "dd/M/yyyy",
            weekStart: 1,
            clearBtn: true,
            daysOfWeekHighlighted: "0,6",
            autoclose: true,
        });
        
        $("#Tabseyehistory a[href='"+$("#field_type_id").val()+"']").tab('show');
        $('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
            var target = $(e.target).attr("href");
            $("#field_type_id").val(target);
            $("#memory_id").val('');
        });
        $("#TabContainerDiv a.memoryList").on('click',function(e){
            e.preventDefault();
            $("#memory_id").val($(this).data('id'));
            $("button[name='mem_delete']").addClass('hidden');
            $.get('/getMemoryDetials/'+$(this).data('id'),function(data){
                 $("input[name='title']").val(data.title);
                 $("input[name='memory_data']").val(data.data);
                 if(data.field_type_id = "1"){
                    $("input[name='complaint']").val(data.data);
                 }
                 if(data.field_type_id = "2"){
                    $("input[name='Diagnosis']").val(data.data);
                 }
                 if(data.field_type_id = "3"){
                    $("input[name='Treatment']").val(data.data);
                 }
                 $("button[name='mem_delete']").removeClass('hidden');
            });
           
        });    
    });
</script>

<!-- jQuery Easing -->
<script src="<?php echo e(asset('JqueryUI/jquery.js')); ?> ">
</script>

<script>    
     jq = $.noConflict(true);
</script>
<script src="<?php echo e(asset('JqueryUI/jquery-ui.js')); ?> ">
</script>
<script>
        var url = "<?php echo e(url('/caseHistoryAutocomplete')); ?>";
        jq(".autocompleteTxt").autocomplete({
            source: function(request, response) {
                $.ajax({
                    url: "<?php echo e(url('/caseHistoryAutocomplete')); ?>",
                    dataType: "json",
                    data: {
                        query: request.term,
                        PropertyName: jq(this.element).attr('name')//'Complaints' 
                    },
                    success: function(data) {
                        data = JSON.parse(JSON.stringify(data));
                        response(data);
                    }
                });
            }
        });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlayouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>