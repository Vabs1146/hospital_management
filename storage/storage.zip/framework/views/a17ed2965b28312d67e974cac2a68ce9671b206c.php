<?php $__env->startSection('style'); ?>
<link href="<?php echo e(url('/')); ?>/select2/css/select2.min.css" rel="stylesheet">

<style>
    @media  screen and (max-width: 767px) {
        .select2 {
            width: 100% !important;
        }
    }
   select2-container .select2-selection--single
  {
        height: 33px !important;
  }

</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
<div class="row clearfix">
       <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <?php echo $__env->make('shared.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                  <?php if(Session::has('flash_message')): ?>
                  <div class="alert alert-success">
                  <?php echo e(Session::get('flash_message')); ?>

                  </div>
                  <?php endif; ?>
          <div class="card">
          <form action="<?php echo e(url('/IPD/patientMedicine'.( empty($patientRegister->id) ? "/0" : ("/" . $patientRegister['id'])))); ?>" method="POST" class="form-horizontal" enctype = 'multipart/form-data' >
                <?php echo e(csrf_field()); ?>


                <?php if(!empty($patientRegister->id) | 1==1): ?>
                    <input type="hidden" name="_method" value="PATCH">
                <?php endif; ?>

        <input type="hidden" id="register_id" name="register_id" value="<?php echo e(isset($patientRegister->id) ? $patientRegister->id : ''); ?>" >
        <input type="hidden" id="id" name="id" value="<?php echo e(isset($patientMedicine->id) ? $patientMedicine->id : ''); ?>" >
          <div class="header bg-pink">
          <h2>Add/Edit bill</h2>
          </div>
              <div class="body">
                  <div class="row clearfix ">
                            <div class="col-md-12">
                              <div class="col-md-2">
                              <div class="form-group labelgrp">
                              <?php echo e(Form::label('name','Patient Name')); ?>

                              </div>
                              </div>

                              <div class="col-md-4">
                              <div class="form-group">
                              <div class="form-line">
                              <?php echo e(Form::text('name', Request::old('name',$patientRegister->name), array('class' => 'form-control readonly','readonly', 'autocomplete'=>'off'))); ?>

                              </div>
                              </div>
                              </div>
                            </div>
                            </div>    

                            <div class="row clearfix">
                            <div class="col-md-4 col-md-offset-4">
                            <div class="form-group">
                            <a class="btn btn-default btn-lg" href="<?php echo e(url('/IPD/patientMedicine')); ?>" ><i class="glyphicon glyphicon-print"></i> Back </a>&nbsp;
                            <a class="btn btn-default btn-lg" href="<?php echo e(url('/IPD/patientRegsiter')); ?>"><i class="glyphicon glyphicon-chevron-left"></i>Patient Register</a>
                            <?php if(!empty($patientMedicine->id) && $patientMedicine->id > 0): ?>
                             <a class="btn btn-default" href="<?php echo e(url('/IPD/patientMedicine/print/') ."/". $patientRegister->id); ?>" target="_blank" ><i class="glyphicon glyphicon-print"></i> Print </a>
                            <?php endif; ?>
                            </div>
                            </div> 
                            </div>

                            <div class="row">
                            <?php if(!empty($patientRegister->id) && $patientRegister->id > 0): ?>
                            <div class="col-md-12">
                            <div class="table-responsive">
                            <table class="table">
                            <tr>
                                <td>
                                    <label for="Medicine" class="control-label">Medicine</label>
                                    <?php echo e(Form::select('medicine_id', array(''=>'Please select') + $medicinelist->toArray(), Request::old('medicine_id'), array('class' => 'form-control select2', 'form-control2','required'))); ?> 
                                </td>
                                <td>
                                    <label class="control-label">Date of mgf.</label>
                                    <input type="text" name="date_of_mgf" id="date_of_mgf" class="form-control datepicker" value="<?php echo e(isset($date_of_mgf) ? $date_of_mgf : ''); ?>">
                                </td>
                                <td>
                                    <label for="date_of_exp" class="control-label">Date of Exp.</label>
                                    <input type="text" name="date_of_exp" id="date_of_exp" class="form-control datepicker" value="<?php echo e(isset($date_of_exp) ? $date_of_exp : ''); ?>">
                                </td>
                                <td>
                                    <label for="batch_no" class="control-label">Batch No</label>
                                    <input type="text" name="batch_no" id="batch_no" class="form-control" value="<?php echo e(isset($batch_no) ? $batch_no : ''); ?>"> 
                                </td>
                                <td>
                                    <label for="price" class="control-label">Price</label>
                                    <input type="text" name="price" id="price" class="form-control" value="<?php echo e(isset($price) ? $price : ''); ?>"> 
                                </td>
                                <td>
                                    <label for="quantity" class="control-label">Quantity</label>
                                    <input type="text" name="quantity" id="quantity" class="form-control" value="<?php echo e(isset($quantity) ? $quantity : ''); ?>"> 
                                </td>
                                <td>
                                    <label for="Total Price" class="control-label">Amount</label> 
                                    <span class="form-control" id="totalPrice">  </span> 
                                </td>
                                <td>
                                    <label for="Item_Add" class="control-label">&nbsp;</label>
                                    <button class="btn btn-success form-control" name="Item_Add" value="Item_Add" type="submit"> <i class="fa fa-plus"></i> Add</button>
                                </td>
                            </tr>
                            <?php if(null !== old('patientMedicine',$patientMedicine) && count(old('patientMedicine',$patientMedicine))> 0 ): ?>
                                <?php 
                                    $itemsum = 0;
                                ?>
                                <?php $__currentLoopData = old('patientMedicine',$patientMedicine); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pMedicine): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                    <tr>
                                        <td> <?php echo e($pMedicine->medical_store->medicine_name); ?> </td>
                                        <td> <?php echo e($pMedicine->date_of_mgf); ?> </td>
                                        <td> <?php echo e($pMedicine->date_of_exp); ?> </td>
                                        <td> <?php echo e($pMedicine->batch_no); ?> </td>
                                        <td> <?php echo e($pMedicine->price); ?> </td>
                                        <td> <?php echo e($pMedicine->quantity); ?> </td>
                                        <td> <?php echo e($pMedicine->price*$pMedicine->quantity); ?> </td>
                                        <td> <?php echo e(Form::button('Delete', array('class'=> 'btn btn-warning pull-right', 'Value' => $pMedicine->id, 'name' => 'delete_item', 'type'=>'submit', 'formnovalidate'))); ?> </td>
                                    </tr>
                                    <?php 
                                        $itemsum = $itemsum + ($pMedicine->price*$pMedicine->quantity);
                                     ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                     <tr>
                                        
                                        <td align="right" colspan="6"> 
                                            <label for="totalAmount" class="control-label">Total</label>  
                                        </td>
                                        <td> 
                                            <input type="number" name="totalAmount" id="totalAmount" class="form-control" value="<?php echo e($itemsum); ?>"  readonly="readonly"> 
                                        </td>
                                        <td>  </td>
                                    </tr>
                            <?php endif; ?>
                        </table>
                    </div>
                </div>
                <?php endif; ?>
                            </div>
                </div>
           </form>
            </div>
        </div>
</div>
</div>

 <?php $__env->stopSection(); ?>
 
<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(url('/')); ?>/select2/js/select2.min.js"></script>


<script type="text/javascript">
    $(document).ready(function(){
     $('.select2').select2();
      $("#price, #quantity").on('blur', function(){
        $("#totalPrice").text('');
          if($.isNumeric($.trim($("#price").val())) & $.isNumeric($.trim($("#quantity").val()))){
            $("#totalPrice").text($("#price").val() * $("#quantity").val());
          }
      });
     
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlayouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>