<?php $__env->startSection('style'); ?>
<link href="<?php echo e(url('/')); ?>/select2/css/select2.min.css" rel="stylesheet">
<style>
    @media  screen and (max-width: 767px) {
    .select2 {
    width: 100% !important;
    }
    }
    .ui-autocomplete-loading {
    background: white url("<?php echo e(asset('images/ui-anim_basic_16x16.gif')); ?>") right center no-repeat;
    }
    .star{
    color: red;
    }
</style>
<!-- Styles -->
<link rel="stylesheet" href="<?php echo e(asset('JqueryUI/jquery-ui.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row clearfix">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <?php echo $__env->make('shared.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php if(Session::has('flash_message')): ?>
            <div class="alert alert-success">
                <?php echo e(Session::get('flash_message')); ?>

            </div>
            <?php endif; ?>
            <div class="card">
                <form action="<?php echo e(url('/patientDetails/SaveKYC' )); ?>" method="POST" class="form-horizontal">
                    <?php echo e(csrf_field()); ?>

                    <div class="header bg-pink">
                        <h2>Patient Info</h2>
                    </div>
                    <div class="body">
                        <div class="row clearfix ">
                            <div class="col-md-12">
                                <div class="col-md-2">
                                    <div class="form-group labelgrp">
                                        <label for="case_number" class="form-control">Doctor <b class="star">*</b>:</label>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <?php echo e(Form::select('doctor_id', array(''=>'Please select') + $doctorlist->toArray(), Request::old('appDetails.doctor_id', $appDetails->doctor_id), array('class' => 'form-control select2', 'required'))); ?>

                                </div>
                                <div class="col-md-2">
                                    <div class="form-group labelgrp">
                                        <label for="case_number" class="form-control">Case Number :</label>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <div class="form-line">
                                            <?php echo e(Form::text('case_number', Request::old('case_number'), array('class' => 'form-control autocompleteTxt', 'placeholder'=>'Type Patient Name / mobile no / case number / UHID no','id'=>'case_number'))); ?>                           
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="col-md-2">
                                    <div class="form-group labelgrp">
                                        <label class="form-control">UHID no :</label>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <div class="form-line">
                                            <?php echo e(Form::text('uhid_no', Request::old('uhid_no'), array('class' => 'form-control'))); ?>                             
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div class="form-group labelgrp">
                                        <label class="form-control"> Visit Time :</label>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <div class="form-line">
                                            <?php echo e(Form::text('visit_time', $appDetails->appointment_timeslot, array('class' => 'form-control'))); ?>                            
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="col-md-2">
                                    <div class="form-group labelgrp">
                                        <label for="patient_name" class="form-control">Patient Name <b class="star">*</b>:</label>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <div class="form-line">
                                            <?php echo e(Form::text('patient_name', $appDetails->name, array('class' => 'form-control', 'required'))); ?>                            
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div class="form-group labelgrp">
                                        <label class="form-control"> Address <b class="star">*</b>:</label>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <div class="form-line">
                                            <?php echo e(Form::text('patient_address', Request::old('patient_address'), array('class' => 'form-control'))); ?>                            
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="col-md-2">
                                    <div class="form-group labelgrp">
                                        <label class="form-control">Email Id :</label>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <div class="form-line">
                                            <?php echo e(Form::text('patient_emailId', $appDetails->email, array('class' => 'form-control'))); ?>                             
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div class="form-group labelgrp">
                                        <label class="form-control"> Age :</label>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <div class="form-line">
                                            <?php echo e(Form::text('patient_age', Request::old('patient_age'), array('class' => 'form-control'))); ?>                            
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="col-md-2">
                                    <div class="form-group labelgrp">
                                        <label class="form-control"> Mobile No <b class="star">*</b>:</label>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <div class="form-line">
                                            <?php echo e(Form::text('patient_mobile', Request::old('patient_mobile', $appDetails->mobile_no), array('class' => 'form-control', 'required'))); ?>                           
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div class="form-group labelgrp">
                                        <label class="form-control">Gender <b class="star">*</b>:</label>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <div class="demo-radio-button" style="padding-top: 6px">
                                            <input type="radio" name="male_female" id="male_female" value="Male" required />
                                            <label for="male_female">Male</label>
                                            <input type="radio" name="male_female" id="male_female1" value="Female" required />
                                            <label for="male_female1">Female</label>
                                            <input type="hidden" name="appointment_Id" id="appointment_Id" value="<?php echo e($appDetails->id); ?>"   />
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="col-md-2">
                                    <div class="form-group labelgrp">
                                        <label for="referedby" class="form-control">Refered by</label>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <div class="form-line"> 
                                            <?php echo e(Form::text('referedby', Request::old('referedby'), array('class' => 'form-control'))); ?>  
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div class="form-group labelgrp">
                                        <label class="form-control">Blood Pressure :</label>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <div class="form-line">
                                            <?php echo e(Form::text('blood_pressure', $appDetails->blood_pressure, array('class' => 'form-control'))); ?>                             
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="col-md-2">
                                    <div class="form-group labelgrp">
                                        <label for="infection" class="form-control">Infection</label>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <div class="form-line"> 
                                            <?php echo e(Form::text('infection', Request::old('infection'), array('class' => 'form-control'))); ?>  
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div class="form-group labelgrp">
                                        <label class="form-control">Miscellaneous History :</label>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <div class="form-line">
                                            <?php echo e(Form::text('miscellaneous_history', $appDetails->miscellaneous_history, array('class' => 'form-control'))); ?>                             
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="col-md-2">
                                    <div class="form-group labelgrp">
                                        <label class="form-control">Patient Weight :</label>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <div class="form-line">
                                            <?php echo e(Form::text('patient_weight', Request::old('patient_weight'), array('class' => 'form-control'))); ?>                                    
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div class="form-group labelgrp">
                                        <label class="form-control">Patient Height :</label>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <div class="form-line">
                                            <?php echo e(Form::text('patient_height', Request::old('patient_height'), array('class' => 'form-control'))); ?>                                    
                                        </div>
                                    </div>
                                </div>
                            </div>
							
                        </div>
                        <div class="row clearfix">
                            <div class="col-md-8 col-md-offset-2" >
                                <button type="submit" name="submit" class="btn btn-success btn-lg" value="submit" ><i class="fa fa-plus"></i> Submit
                                </button>&nbsp;
                                <button type="submit" name="submitMsg" class="btn btn-success btn-lg" value="submitMsg" ><i class="fa fa-plus"></i> Submit & Msg.
                                </button>&nbsp;
                                <button type="submit" formtarget="_blank" formaction="<?php echo e(url('/patientDetails/SaveKYCWhatsapp')); ?>" name="submit" class="btn" value="submit" ><i class="fab fa-whatsapp-square fa-2x" style="color:green;"></i> </button>&nbsp;
                                <button type="submit" formaction="<?php echo e(url('/patientDetails/SaveEyeExamination2')); ?>" name="submit" class="btn btn-success btn-lg" value="submit" >Submit & Email</button>&nbsp;
                            </div>
                            <div class="col-md-8 col-md-offset-2" >
                                <a class="btn btn-default btn-lg" href="<?php echo e(url('/appointmentlist/0')); ?>"><i class="glyphicon glyphicon-chevron-left"></i> Back to Appointment</a>&nbsp;
                                <a class="btn btn-default btn-lg" href="<?php echo e(url('/case_masters')); ?>"><i class="glyphicon glyphicon-chevron-left"></i> Back to Patient List</a> 
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(url('/')); ?>/select2/js/select2.min.js"></script>
<script type="text/javascript">
    $(document).ready(function(){
         $('.select2').select2();
    
    });
</script>
<!-- jQuery Easing -->
<script src="<?php echo e(asset('JqueryUI/jquery.js')); ?> "></script>
<script>    
    jq = $.noConflict(true);
    //alert(jq);
</script>
<script src="<?php echo e(asset('JqueryUI/jquery-ui.js')); ?> "></script>
<script>
    var url = "<?php echo e(url('/GetCaseIdByPatientNameMobile')); ?>";
    jq(".autocompleteTxt").autocomplete({
        source: function(request, response) {
            $.ajax({
                url: "<?php echo e(url('/GetCaseIdByPatientNameMobile')); ?>",
                dataType: "json",
                data: {
                    query: request.term,
                    PropertyName: jq(this.element).attr('name'),//'Complaints' 
                    tableName: 'eyeform'
                },
                success: function(data) {
                    response(data);
                    
                }
            });
        },
        select: function(event, ui) {
            jq("#case_number").val(ui.item.value);
            $('input[name="patient_name"]').val(ui.item.patient_name);
            $('input[name="patient_mobile"]').val(ui.item.patient_mobile);
            $('input[name="patient_address"]').val(ui.item.patient_address);
            $('input[name="patient_emailId"]').val(ui.item.patient_emailId);
            $('input[name="patient_age"]').val(ui.item.patient_age);
            $('input[name="uhid_no"]').val(ui.item.uhid_no);
            $('input[name="patient_weight"]').val(ui.item.patient_weight);
            $('input[name="patient_height"]').val(ui.item.patient_height);
            $('input[name="blood_pressure"]').val(ui.item.blood_pressure);
            $('input[name="infection"]').val(ui.item.infection);
            $('input[name="miscellaneous_history"]').val(ui.item.miscellaneous_history);
            $('input[name="male_female"][value='+ ui.item.male_female +']').attr('checked', 'checked');
            $('input[name="doctor_fee"]').val(ui.item.billAmount);
            $('input[name="referedby"]').val(ui.item.referedby);
            $('input[name="payment_mode"]').val(ui.item.payment_mode);
            $("#doctor_id").append('<option value="'+ui.item.doctor_id+'" selected="">'+ui.item.doctor_name+'</option>');
            $("#doctor_id").selectpicker("refresh");
             
            return false; // Prevent the widget from inserting the value.
        }
    });
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('adminlayouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>