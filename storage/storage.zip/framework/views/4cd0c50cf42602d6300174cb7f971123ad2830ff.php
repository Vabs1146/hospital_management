<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="list-group list-group-horizontal">
        <?php $__empty_1 = true; $__currentLoopData = $model['DateWiseRecordLst']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $VisitListDateWise): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php if($model['case_master']['id'] == $VisitListDateWise['id']): ?>
                    <a href="<?php echo e(url('/report_files').'/'.$VisitListDateWise['id'].'/edit'); ?>" class="list-group-item active"><?php echo e(Carbon\Carbon::parse($VisitListDateWise['created_at'])->format('d-M-Y')); ?></a> <span> &nbsp;</span>    
                <?php else: ?>
                    <a href="<?php echo e(url('/report_files').'/'.$VisitListDateWise['id'].'/edit'); ?>" class="list-group-item"><?php echo e(Carbon\Carbon::parse($VisitListDateWise['created_at'])->format('d-M-Y')); ?></a> <span> &nbsp;</span>
                <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<div class="container-fluid">
<div class="row clearfix">
       <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
		     
                    <?php echo $__env->make('shared.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 
                    <?php if(Session::has('flash_message')): ?>
                        <div class="alert alert-success">
                            <?php echo e(Session::get('flash_message')); ?>

                        </div>
                    <?php endif; ?>

          <div class="card">
        
          <div class="header bg-pink">
          <h2>Add/Edit Report File </h2>
          </div>

<form action="<?php echo e(url('/report_files'.( isset($model) ? "/" . $model['case_master']['id'] : ""))); ?>" method="POST" class="form-horizontal" enctype = 'multipart/form-data' >
                <?php echo e(csrf_field()); ?>


                <?php if(isset($model)): ?>
                    <input type="hidden" name="_method" value="PATCH">
                <?php endif; ?>

              
                <input type="hidden" id="case_id" name="case_id" value="<?php echo e(isset($model['case_master']['id']) ? $model['case_master']['id'] : ''); ?>" >

         
              
              <div class="body">
                  <div class="row clearfix ">
                            <div class="col-md-12">
                              <div class="col-md-2">
                              <div class="form-group labelgrp">
                              <label class="form-control">Case Number :</label>
                              </div>
                              </div>


                              <div class="col-md-4">
                              <div class="form-group">
                              <div class="form-line">
                              <input type="text" name="case_number" id="case_number" class="form-control" readonly='readonly' value="<?php echo e(isset($model['case_master']['case_number']) ? $model['case_master']['case_number'] : ''); ?>">                            
                              </div>
                              </div>
                              </div>    


                              <div class="col-md-2">
                              <div class="form-group labelgrp">
                              <label class="form-control">Patient Name :</label>
                              </div>
                              </div>


                              <div class="col-md-4">
                              <div class="form-group">
                              <div class="form-line">
                              <input type="text" name="patient_name" id="patient_name" class="form-control"  readonly='readonly' value="<?php echo e(isset($model['case_master']['patient_name']) ? $model['case_master']['patient_name'] : ''); ?>">                            
                              </div>
                              </div>
                              </div>
                          </div>

                          <div class="col-md-12">
                              <div class="col-md-2">
                              <div class="form-group labelgrp">
                              <label class="form-control">Upload File :</label>
                              </div>
                              </div>


                              <div class="col-md-4">
                              <div class="form-group">
                              <div class="form-line">
                              <input type="file" name="uploaded_file" id="uploaded_file" class="form-control" value="<?php echo e(isset($model['uploaded_file']) ? $model['uploaded_file'] : ''); ?>">                            
                              </div>
                              </div>
                              </div>

                              <div class="col-md-2">
                              <div class="form-group labelgrp">
                              <label class="form-control"> Report Title :</label>
                              </div>
                              </div>


                              <div class="col-md-4">
                              <div class="form-group">
                              <div class="form-line">
                              <input type="text" name="report_title" id="report_title" class="form-control" value="<?php echo e(isset($model['report_title']) ? $model['report_title'] : ''); ?>">                           
                              </div>
                              </div>
                              </div>
                          </div>


                           <div class="col-md-12">
                              <div class="col-md-2">
                              <div class="form-group labelgrp">
                              <label class="form-control">Report Description :</label>
                              </div>
                              </div>


                              <div class="col-md-4">
                              <div class="form-group">
                              <div class="form-line">
                               <input type="text" name="report_description" id="report_description" class="form-control" value="<?php echo e(isset($model['report_description']) ? $model['report_description'] : ''); ?>">                             
                              </div>
                              </div>
                              </div>

                             
                          </div>

                            <div class="col-md-12">
                              <div class="col-md-2">
                              <div class="form-group labelgrp">
                              <label class="form-control"></label>
                              </div>
                              </div>


                               <div class="col-md-4">
                              <div class="form-group">
                              
                              <button type="submit" name="report_add" value="report_add" class="btn btn-success btn-lg">
                              <i class="fa fa-plus"></i> Add Report
                              </button>  


                              
                              </div>
                              </div>

                              
                          </div>
                           
                           <div class="col-md-12">
                              <div class="col-md-2">
                              <div class="form-group labelgrp">
                              <label class="form-control"> </label>
                              </div>
                              </div>


                              <div class="col-md-4">
                              <div class="form-group">
                              
                             <?php if(null !== old('Report_file',$model['Report_file']) && count(old('Report_file',$model['Report_file']))> 0 ): ?>
                    <div class="list-group">
                    <?php $__currentLoopData = old('Report_file',$model['Report_file']); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reportfile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                        
                            <div href="#" class="list-group-item clearfix">
                                <span>
                                    <?php echo e(Form::button('Delete', array('class'=> 'btn btn-warning pull-right', 'Value' => $reportfile->id, 'name' => 'report_delete', 'type'=>'submit'))); ?>

                                </span>
                                <div class="d-flex w-100 justify-content-between">
                                    <?php if(isset($reportfile->file_path) && $reportfile->file_path != null): ?>
                                       <h5 class="mb-1"> <a href="<?php echo e(Storage::disk('local')->url($reportfile->file_path)); ?>" class="" target="_blank"> ..Report document </a> </h5>
                                    <?php endif; ?>
                                </div>
                                <p class="mb-1">
                                   <?php echo e($reportfile->report_title); ?>

                                </p>
                                <p class="mb-1">
                                    <?php echo e($reportfile->report_description); ?>

                                </p>
                            </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php endif; ?>
                             
                          </div>
                              </div>

                              

                              
                          </div>
                         
                        
                                    
                  </div>    

                  <div class="row clearfix">
                                <div class="col-md-4 col-md-offset-2">
                                <div class="form-group">
                                <a class="btn btn-default btn-lg" href="<?php echo e(url('/report_files')); ?>"><i class="glyphicon glyphicon-chevron-left"></i> Back</a>
                    <a class="btn btn-default btn-lg" href="<?php echo e(url('/PatientMedicalDetails').'/'.$model['case_master']['id']); ?>"><i class="glyphicon glyphicon-chevron-left"></i> Back To Patient Details</a>


                                      
                                </div>
                                </div>
                               
                            </div>
                </div>
           </form>
            </div>
        </div>
</div>
</div>


        <?php $__env->stopSection(); ?>
  
<?php echo $__env->make('adminlayouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>