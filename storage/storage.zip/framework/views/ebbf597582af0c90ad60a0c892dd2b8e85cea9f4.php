
<?php $__env->startSection('style'); ?>
<style>
    @media  screen and (max-width: 767px) {
        .select2 {
            width: 100% !important;
        }
    }

    .ui-autocomplete-loading {
        background: white url("<?php echo e(asset('images/ui-anim_basic_16x16.gif')); ?>") right center no-repeat;
    }

    .canvas {
        position: relative;
        width: 150px;
        height: 200px;
        background-color: #7a7a7a;
        margin: 70px auto 20px auto;
    }
</style>
<link rel="stylesheet" href="<?php echo e(asset('JqueryUI/jquery-ui.css')); ?>">

<link rel="stylesheet" href="<?php echo e(asset('drawingboardJs/prism.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('drawingboardJs/website.css')); ?>">


<!-- in a production environment, just include the minified css. It contains the css of the board and the default controls (size, nav, colors): -->
<link rel="stylesheet" href="<?php echo e(asset('drawingboardJs/drawingboard.min.css')); ?>">

<style>
    /*
        * drawingboards styles: set the board dimensions you want with CSS
        */

    .board {
        margin: 0 auto;
        width: 100%;
        height: 100%;
    }

</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
<div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                  <?php echo $__env->make('shared.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <?php if(Session::has('flash_message')): ?>
                    <div class="alert alert-success">
                        <?php echo e(Session::get('flash_message')); ?>

                    </div>
                    <?php endif; ?>
                  <div class="card">
                <form action="<?php echo e(url('/dynamicForm/'.$form_master->id.'/'.$patientRegister->id. '/Opd' .'')); ?>" method="POST" class="form-horizontal" id="form_<?php echo e($patientRegister->id); ?>"
                enctype='multipart/form-data'>
                <?php echo e(csrf_field()); ?>

                         <div class="header bg-pink">
                            <h2>
                                Squint Evaluation
                            </h2>
                          
                        </div>
                        <?php echo e(Form::hidden('register_id', $patientRegister->id )); ?>

                        <div class="body">
                            <div class="row clearfix">
                              <div class="col-md-12">
                                <?php  $fieldName = "HeadPosture";  ?>
                                <?php echo e(Form::label('field_data_singular['.$field_name_id[$fieldName].']','Head Posture')); ?> 
                                <?php echo e(Form::text('field_data_singular['.$field_name_id[$fieldName].']', $form_field_values->where('form_field_code', $field_name_id[$fieldName])->isEmpty()?"":$form_field_values->where('form_field_code', $field_name_id[$fieldName])->first()->field_data, array('class'=> 'form-control'))); ?>

                              </div>
                              <div class="col-md-12">
                                <div class="table-responsive">
                              <table class="table">
                                  <tr>
                                      <th>Face Turn</th>
                                      <th>Right</th>
                                      <th>Left</th>
                                  </tr>
                                  <tr>
                            <th>Chin elevation or depression</th>
                            <td>
                                <?php  $fieldName = "FaceTurnChinLeft";  ?>
                                <?php echo e(Form::text('field_data_singular['.$field_name_id[$fieldName].']', $form_field_values->where('form_field_code', $field_name_id[$fieldName])->isEmpty()?"":$form_field_values->where('form_field_code', $field_name_id[$fieldName])->first()->field_data, array('class'=> 'form-control'))); ?>

                            </td>
                            <td>
                                <?php  $fieldName = "FaceTurnChinRight";  ?>
                                <?php echo e(Form::text('field_data_singular['.$field_name_id[$fieldName].']', $form_field_values->where('form_field_code', $field_name_id[$fieldName])->isEmpty()?"":$form_field_values->where('form_field_code', $field_name_id[$fieldName])->first()->field_data, array('class'=> 'form-control'))); ?>

                            </td>
                        </tr>
                        <tr>
                            <th>Head Tilt</th>
                            <td>
                                <?php  $fieldName = "FaceTurnHeadTiltLeft";  ?>
                                <?php echo e(Form::text('field_data_singular['.$field_name_id[$fieldName].']', $form_field_values->where('form_field_code', $field_name_id[$fieldName])->isEmpty()?"":$form_field_values->where('form_field_code', $field_name_id[$fieldName])->first()->field_data, array('class'=> 'form-control'))); ?>

                            </td>
                            <td>
                                <?php  $fieldName = "FaceTurnHeadTiltRight";  ?>
                                <?php echo e(Form::text('field_data_singular['.$field_name_id[$fieldName].']', $form_field_values->where('form_field_code', $field_name_id[$fieldName])->isEmpty()?"":$form_field_values->where('form_field_code', $field_name_id[$fieldName])->first()->field_data, array('class'=> 'form-control'))); ?>

                            </td>
                            </tr>
                            </table>
                            </div>
                          </div>
                            <div class="col-md-12">
                                <?php  $fieldName = "HirschbergTest";  ?>
                                <?php echo e(Form::label('field_data_singular['.$field_name_id[$fieldName].']','Hirschberg Test')); ?> 
                                <?php echo e(Form::text('field_data_singular['.$field_name_id[$fieldName].']', $form_field_values->where('form_field_code', $field_name_id[$fieldName])->isEmpty()?"":$form_field_values->where('form_field_code', $field_name_id[$fieldName])->first()->field_data, array('class'=> 'form-control'))); ?>

                              </div>
                              <div class="col-md-12">
                              <?php  $fieldName = "CoverTest";  ?>
                                <?php echo e(Form::label('field_data_singular['.$field_name_id[$fieldName].']','Cover Test')); ?> 
                                <?php echo e(Form::text('field_data_singular['.$field_name_id[$fieldName].']', $form_field_values->where('form_field_code', $field_name_id[$fieldName])->isEmpty()?"":$form_field_values->where('form_field_code', $field_name_id[$fieldName])->first()->field_data, array('class'=> 'form-control'))); ?>

                              </div>
                              <div class="col-md-12">
                                 <?php  $fieldName = "PrismBarCoverTestDistance";  ?>
                                  <?php echo e(Form::label('field_data_singular['.$field_name_id[$fieldName].']','Prism Bar Cover Test : Distance')); ?> 
                                  <?php echo e(Form::text('field_data_singular['.$field_name_id[$fieldName].']', $form_field_values->where('form_field_code', $field_name_id[$fieldName])->isEmpty()?"":$form_field_values->where('form_field_code', $field_name_id[$fieldName])->first()->field_data, array('class'=> 'form-control'))); ?>

                              </div>
                              <div class="col-md-12">
                             
                                <label> All Nine gazes</label>
                             
                              </div>

                              <div class="col-md-12">
                                <div class="table-responsive">
                               <table class="table table-responsive">
                                  <tr>
                                      <td>
                                          <?php  $fieldName = "NineGazes1";  ?>
                                          <?php echo e(Form::text('field_data_singular['.$field_name_id[$fieldName].']', $form_field_values->where('form_field_code', $field_name_id[$fieldName])->isEmpty()?"":$form_field_values->where('form_field_code', $field_name_id[$fieldName])->first()->field_data, array('class'=> 'form-control'))); ?>

                                      </td>
                                      <td>
                                          <?php  $fieldName = "NineGazes2";  ?>
                                          <?php echo e(Form::text('field_data_singular['.$field_name_id[$fieldName].']', $form_field_values->where('form_field_code', $field_name_id[$fieldName])->isEmpty()?"":$form_field_values->where('form_field_code', $field_name_id[$fieldName])->first()->field_data, array('class'=> 'form-control'))); ?>

                                      </td>
                                      <td>
                                          <?php  $fieldName = "NineGazes3";  ?>
                                          <?php echo e(Form::text('field_data_singular['.$field_name_id[$fieldName].']', $form_field_values->where('form_field_code', $field_name_id[$fieldName])->isEmpty()?"":$form_field_values->where('form_field_code', $field_name_id[$fieldName])->first()->field_data, array('class'=> 'form-control'))); ?>                            
                                      </td>
                                  </tr>
                                  <tr>
                                      <td>
                                          <?php  $fieldName = "NineGazes4";  ?>
                                          <?php echo e(Form::text('field_data_singular['.$field_name_id[$fieldName].']', $form_field_values->where('form_field_code', $field_name_id[$fieldName])->isEmpty()?"":$form_field_values->where('form_field_code', $field_name_id[$fieldName])->first()->field_data, array('class'=> 'form-control'))); ?>

                                      </td>
                                      <td>
                                          <?php  $fieldName = "NineGazes5";  ?>
                                          <?php echo e(Form::text('field_data_singular['.$field_name_id[$fieldName].']', $form_field_values->where('form_field_code', $field_name_id[$fieldName])->isEmpty()?"":$form_field_values->where('form_field_code', $field_name_id[$fieldName])->first()->field_data, array('class'=> 'form-control'))); ?>

                                      </td>
                                      <td>
                                          <?php  $fieldName = "NineGazes6";  ?>
                                          <?php echo e(Form::text('field_data_singular['.$field_name_id[$fieldName].']', $form_field_values->where('form_field_code', $field_name_id[$fieldName])->isEmpty()?"":$form_field_values->where('form_field_code', $field_name_id[$fieldName])->first()->field_data, array('class'=> 'form-control'))); ?>                            
                                      </td>
                                  </tr>
                                  <tr>
                                      <td>
                                          <?php  $fieldName = "NineGazes7";  ?>
                                          <?php echo e(Form::text('field_data_singular['.$field_name_id[$fieldName].']', $form_field_values->where('form_field_code', $field_name_id[$fieldName])->isEmpty()?"":$form_field_values->where('form_field_code', $field_name_id[$fieldName])->first()->field_data, array('class'=> 'form-control'))); ?>

                                      </td>
                                      <td>
                                          <?php  $fieldName = "NineGazes8";  ?>
                                          <?php echo e(Form::text('field_data_singular['.$field_name_id[$fieldName].']', $form_field_values->where('form_field_code', $field_name_id[$fieldName])->isEmpty()?"":$form_field_values->where('form_field_code', $field_name_id[$fieldName])->first()->field_data, array('class'=> 'form-control'))); ?>

                                      </td>
                                      <td>
                                          <?php  $fieldName = "NineGazes9";  ?>
                                          <?php echo e(Form::text('field_data_singular['.$field_name_id[$fieldName].']', $form_field_values->where('form_field_code', $field_name_id[$fieldName])->isEmpty()?"":$form_field_values->where('form_field_code', $field_name_id[$fieldName])->first()->field_data, array('class'=> 'form-control'))); ?>                            
                                      </td>
                                  </tr>
                              </table>
                              </div>
                              </div>
                              <div class="col-md-12">
                                <?php  $fieldName = "PrimaryDeviation";  ?>
                                <?php echo e(Form::label('field_data_singular['.$field_name_id[$fieldName].']','Primary Deviation')); ?> 
                                <?php echo e(Form::text('field_data_singular['.$field_name_id[$fieldName].']', $form_field_values->where('form_field_code', $field_name_id[$fieldName])->isEmpty()?"":$form_field_values->where('form_field_code', $field_name_id[$fieldName])->first()->field_data, array('class'=> 'form-control'))); ?>

                              </div>
                              <div class="col-md-12">
                              <?php  $fieldName = "SecondaryDeviation";  ?>
                              <?php echo e(Form::label('field_data_singular['.$field_name_id[$fieldName].']','Secondary Deviation')); ?> 
                              <?php echo e(Form::text('field_data_singular['.$field_name_id[$fieldName].']', $form_field_values->where('form_field_code', $field_name_id[$fieldName])->isEmpty()?"":$form_field_values->where('form_field_code', $field_name_id[$fieldName])->first()->field_data, array('class'=> 'form-control'))); ?>

                              </div>
                              <div class="col-md-12">
                              <?php  $fieldName = "OcularMotility";  ?>
                              <?php echo e(Form::label('field_data_singular['.$field_name_id[$fieldName].']','Ocular Motility')); ?> 
                              <?php echo e(Form::text('field_data_singular['.$field_name_id[$fieldName].']', $form_field_values->where('form_field_code', $field_name_id[$fieldName])->isEmpty()?"":$form_field_values->where('form_field_code', $field_name_id[$fieldName])->first()->field_data, array('class'=> 'form-control'))); ?>

                              </div>
                              <div class="col-md-12">
                                <?php  $fieldName = "WorthFourDotTest";  ?>
                              <?php echo e(Form::label('field_data_singular['.$field_name_id[$fieldName].']','Worth Four Dot Test')); ?> 
                              <?php echo e(Form::text('field_data_singular['.$field_name_id[$fieldName].']', $form_field_values->where('form_field_code', $field_name_id[$fieldName])->isEmpty()?"":$form_field_values->where('form_field_code', $field_name_id[$fieldName])->first()->field_data, array('class'=> 'form-control'))); ?>

                              </div>
                              <div class="col-md-12">
                              <?php  $fieldName = "Stereopsis";  ?>
                              <?php echo e(Form::label('field_data_singular['.$field_name_id[$fieldName].']','Stereopsis')); ?> 
                              <?php echo e(Form::text('field_data_singular['.$field_name_id[$fieldName].']', $form_field_values->where('form_field_code', $field_name_id[$fieldName])->isEmpty()?"":$form_field_values->where('form_field_code', $field_name_id[$fieldName])->first()->field_data, array('class'=> 'form-control'))); ?>

                              </div>
                              <div class="col-md-12">
                              <?php  $fieldName = "MaddoxRod";  ?>
                              <?php echo e(Form::label('field_data_singular['.$field_name_id[$fieldName].']','Maddox Rod')); ?> 
                              <?php echo e(Form::text('field_data_singular['.$field_name_id[$fieldName].']', $form_field_values->where('form_field_code', $field_name_id[$fieldName])->isEmpty()?"":$form_field_values->where('form_field_code', $field_name_id[$fieldName])->first()->field_data, array('class'=> 'form-control'))); ?>

                              </div>
                              <div class="col-md-12">
                                <div class="table">
                    <table class="table table-responsive">
                        <tr>
                            <td>
                                <?php  $fieldName = "DipopiaCharting1";  ?>
                                <?php echo e(Form::text('field_data_singular['.$field_name_id[$fieldName].']', $form_field_values->where('form_field_code', $field_name_id[$fieldName])->isEmpty()?"":$form_field_values->where('form_field_code', $field_name_id[$fieldName])->first()->field_data, array('class'=> 'form-control'))); ?>

                            </td>
                            <td>
                                <?php  $fieldName = "DipopiaCharting2";  ?>
                                <?php echo e(Form::text('field_data_singular['.$field_name_id[$fieldName].']', $form_field_values->where('form_field_code', $field_name_id[$fieldName])->isEmpty()?"":$form_field_values->where('form_field_code', $field_name_id[$fieldName])->first()->field_data, array('class'=> 'form-control'))); ?>

                            </td>
                            <td>
                                <?php  $fieldName = "DipopiaCharting3";  ?>
                                <?php echo e(Form::text('field_data_singular['.$field_name_id[$fieldName].']', $form_field_values->where('form_field_code', $field_name_id[$fieldName])->isEmpty()?"":$form_field_values->where('form_field_code', $field_name_id[$fieldName])->first()->field_data, array('class'=> 'form-control'))); ?>

                            </td>
                        </tr>
                        <tr>
                            <td>
                                <?php  $fieldName = "DipopiaCharting4";  ?>
                                <?php echo e(Form::text('field_data_singular['.$field_name_id[$fieldName].']', $form_field_values->where('form_field_code', $field_name_id[$fieldName])->isEmpty()?"":$form_field_values->where('form_field_code', $field_name_id[$fieldName])->first()->field_data, array('class'=> 'form-control'))); ?>

                            </td>
                            <td>
                                <?php  $fieldName = "DipopiaCharting5";  ?>
                                <?php echo e(Form::text('field_data_singular['.$field_name_id[$fieldName].']', $form_field_values->where('form_field_code', $field_name_id[$fieldName])->isEmpty()?"":$form_field_values->where('form_field_code', $field_name_id[$fieldName])->first()->field_data, array('class'=> 'form-control'))); ?>

                            </td>
                            <td>
                                <?php  $fieldName = "DipopiaCharting6";  ?>
                                <?php echo e(Form::text('field_data_singular['.$field_name_id[$fieldName].']', $form_field_values->where('form_field_code', $field_name_id[$fieldName])->isEmpty()?"":$form_field_values->where('form_field_code', $field_name_id[$fieldName])->first()->field_data, array('class'=> 'form-control'))); ?>

                            </td>
                        </tr>
                        <tr>
                            <td>
                                <?php  $fieldName = "DipopiaCharting7";  ?>
                                <?php echo e(Form::text('field_data_singular['.$field_name_id[$fieldName].']', $form_field_values->where('form_field_code', $field_name_id[$fieldName])->isEmpty()?"":$form_field_values->where('form_field_code', $field_name_id[$fieldName])->first()->field_data, array('class'=> 'form-control'))); ?>

                            </td>
                            <td>
                                <?php  $fieldName = "DipopiaCharting8";  ?>
                                <?php echo e(Form::text('field_data_singular['.$field_name_id[$fieldName].']', $form_field_values->where('form_field_code', $field_name_id[$fieldName])->isEmpty()?"":$form_field_values->where('form_field_code', $field_name_id[$fieldName])->first()->field_data, array('class'=> 'form-control'))); ?>

                            </td>
                            <td>
                                <?php  $fieldName = "DipopiaCharting9";  ?>
                                <?php echo e(Form::text('field_data_singular['.$field_name_id[$fieldName].']', $form_field_values->where('form_field_code', $field_name_id[$fieldName])->isEmpty()?"":$form_field_values->where('form_field_code', $field_name_id[$fieldName])->first()->field_data, array('class'=> 'form-control'))); ?>

                            </td>
                        </tr>
                    </table>
                </div>
                              </div>

                              </div>
                              
                             <div class="row clearfix">
                                <div class="col-md-4 col-md-offset-4">
                                <div class="form-group">
                                <input type="hidden" name="returnUrl" id="returnUrl" value="<?php echo e(url('/AddEditEyeDetails').'/'.$patientRegister->id); ?>" >
                                <button type="submit" name="submit" class="btn btn-success btn-lg" value="submit">
                                <i class="fa fa-plus"></i> Submit
                                </button>
                                <a class="btn btn-default btn-lg" href="<?php echo e(url('/AddEditEyeDetails').'/'.$patientRegister->id); ?>">
                                <i class="glyphicon glyphicon-chevron-left"></i> Back</a>
                                <a class="btn btn-default btn-lg" href="<?php echo e(url('/dynamicForm/view/').'/'.$form_master->id.'/'.$patientRegister->id); ?>">
                                <i class="glyphicon glyphicon-chevron-left"></i> view</a>
                                <a class="btn btn-default btn-lg" href="<?php echo e(url('/dynamicForm/print/').'/'.$form_master->id.'/'.$patientRegister->id); ?>"
                                target="_blank"><i class="glyphicon glyphicon-chevron-left"></i> print</a>
                                </div>
                                </div>  
                            </div>

                            
                        </div>
                       </form>
                    </div>
                </div>
            </div>


</div>

        <?php $__env->stopSection(); ?>
  
<?php echo $__env->make('adminlayouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>