
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
<div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                   <?php if(Session::has('flash_message')): ?>
                    <div class="alert alert-success">
                        <?php echo e(Session::get('flash_message')); ?>

                    </div>
                    <?php endif; ?>
                    <div class="card">
                         <div class="header bg-pink">
                            <h2>
                               List of Menus
                            </h2>
                          
                        </div>
                        <div class="body">
                            <div class="table-responsive">
                                 <table class="table table-hover table-bordered dataTable js-exportable" id="thegrid" data-stripe-classes="[]">
                                  <thead>
                                    <tr>
                                        <th>Id</th>
                                        <th>Name</th>
                                        <th>Description</th>
                                        
                                        <th>IsActive</th>
                                        
                                        <th style="width:50px"></th>
                                        <th style="width:50px"></th>
                                    </tr>
                                  </thead>

                                  <tbody>
                                  </tbody>
                                </table>
                            </div>     
                        </div>
                        <div class="panel-footer">
                          <a href="<?php echo e(url('menu_lists/create')); ?>" class="btn btn-primary btn-lg" role="button">Add menu</a>
                        </div>              
                    </div>
                </div>
            </div>


</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script type="text/javascript">
        var theGrid = null;
        $(document).ready(function(){
            theGrid = $('#thegrid').DataTable({
                "processing": true,
                "serverSide": true,
                "ordering": true,
                "responsive": false,
                "ajax": "<?php echo e(url('menu_lists/grid')); ?>",
                "columnDefs": [
                    {
                        "render": function ( data, type, row ) {
                            return '<a href="<?php echo e(url('/menu_lists')); ?>/'+row[0]+'">'+data+'</a>';
                        },
                        "targets": 0
                    },
                    {
                        "render": function ( data, type, row ) {
                            return '<a href="<?php echo e(url('/menu_lists')); ?>/'+row[0]+'/edit" class="btn btn-default">Update</a>';
                        },
                        "targets": 4                    },
                    {
                        "render": function ( data, type, row ) {
                            return '<a href="<?php echo e(url('/dynamic_text/1')); ?>/'+row[0]+'" class="btn btn-default">Page Data</a>';
                        },
                        "targets": 4+1
                    },
                ]
            });
        });
        function doDelete(id) {
            if(confirm('You really want to delete this record?')) {
               $.ajax({ url: '<?php echo e(url('/menu_lists')); ?>/' + id, type: 'DELETE'}).success(function() {
                theGrid.ajax.reload();
               });
            }
            return false;
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlayouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>