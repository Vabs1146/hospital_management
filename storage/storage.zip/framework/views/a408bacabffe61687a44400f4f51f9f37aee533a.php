<?php $__env->startSection('style'); ?>
<style>
    @media  screen and (max-width: 767px) {
        .select2 {
            width: 100% !important;
        }
    }
    .ui-autocomplete-loading {
        background: white url("<?php echo e(asset('images/ui-anim_basic_16x16.gif')); ?>") right center no-repeat;
    }

    .canvas{
        position:relative; width:150px; height:200px; background-color:#7a7a7a; margin:70px auto 20px auto;
    }

</style>
<link href="<?php echo e(url('/')); ?>/select2/css/select2.min.css" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="list-group list-group-horizontal">
       <?php $__currentLoopData = $casedata['DateWiseRecordLst']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $VisitListDateWise): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($casedata['id'] == $VisitListDateWise['id']): ?>
                    <a href="<?php echo e(url('/PatientMedicalDetails').'/'.$VisitListDateWise['id']); ?>" class="list-group-item active"><?php echo e(Carbon\Carbon::parse($VisitListDateWise['created_at'])->format('d-M-Y')); ?></a> <span> &nbsp;</span>    
                <?php else: ?>
                    <a href="<?php echo e(url('/PatientMedicalDetails').'/'.$VisitListDateWise['id']); ?>" class="list-group-item"><?php echo e(Carbon\Carbon::parse($VisitListDateWise['created_at'])->format('d-M-Y')); ?></a> <span> &nbsp;</span>
                <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<div class="container-fluid">
<div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <?php echo $__env->make('shared.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                          <?php if(Session::has('flash_message')): ?>
                          <div class="alert alert-success">
                          <?php echo e(Session::get('flash_message')); ?>

                          </div>
                          <?php endif; ?>
                       <div class="card">
           
           <?php echo e(Form::model($casedata, array('route' => array('case_masters.store'), 'method' => 'POST', 'class' => 'form-horizontal', 'enctype' => 'multipart/form-data' ))); ?>

            <?php echo e(csrf_field()); ?>

                         <div class="header bg-pink">
                            <h2>
                               Add/Modify Case master
                            </h2>
                          
                        </div>
                        <div class="body">
                          <?php echo e(Form::hidden('id', Request::old('id'), array('class'=> 'form-control'))); ?>

                          <div class="row clearfix">
                          <div class="col-md-12">
                            <?php echo e(Form::hidden('case_number', Request::old('case_number'), array('class'=> 'form-control', 'readonly'=>'readonly'))); ?>

                            <h3> Case Number : <?php echo e($casedata['case_number']); ?> </h3>
            <?php echo e(Form::hidden('patient_emailId', Request::old('patient_emailId'), array('class'=> 'form-control', 'readonly'=>'readonly'))); ?>

                          </div>
                       
                          <div class="col-md-12">
                             <div class="col-md-2">
                              <div class="form-group labelgrp">
                              <?php echo e(Form::label('doctor_id','Doctor')); ?>

                              </div>
                             </div>
                              
                              <div class="col-md-4">
                              <?php echo e(Form::select('doctor_id',array(''=>'Please select') + $casedata['doctorlist']->toArray(), Request::old('doctor_id'), array('class' => 'form-control select2'))); ?>                          
                             </div>
                            
                         
                              <div class="col-md-2">
                              <div class="form-group labelgrp">
                              <?php echo e(Form::label('patient_name', 'Patient Name')); ?>

                              </div>
                              </div>

                              <div class="col-md-4">
                              <div class="form-group">
                              <div class="form-line">
                               <?php echo e(Form::text('patient_name', Request::old('patient_name'), array('class'=> 'form-control'))); ?>                           
                              </div>
                              </div>
                              </div>  
                            </div>
                            
                            <div class="col-md-12">
                              <div class="col-md-2">
                              <div class="form-group labelgrp">
                              <?php echo e(Form::label('patient_address', 'Patient Address')); ?> 
                              </div>
                              </div>


                              <div class="col-md-4">
                              <div class="form-group">
                              <div class="form-line">
                              <?php echo e(Form::text('patient_address', Request::old('patient_address'), array('class'=> 'form-control'))); ?>                            
                              </div>
                              </div>
                              </div>
                          

                              <div class="col-md-2">
                              <div class="form-group labelgrp">
                              <?php echo e(Form::label('patient_emailId', 'Patient Email Id')); ?> 
                              </div>
                              </div>

                              <div class="col-md-4">
                              <div class="form-group">
                              <div class="form-line">
                               <?php echo e(Form::email('patient_emailId', Request::old('patient_emailId'), array('class'=> 'form-control'))); ?>                           
                              </div>
                              </div>
                              </div> 
                            </div> 
                            
                            <div class="col-md-12">
                               <div class="col-md-2">
                              <div class="form-group labelgrp">
                               <?php echo e(Form::label('patient_mobile', 'Patient mobile')); ?> 
                              </div>
                              </div>


                              <div class="col-md-4">
                              <div class="form-group">
                              <div class="form-line">
                              <?php echo e(Form::number('patient_mobile', Request::old('patient_mobile'), array('class'=> 'form-control'))); ?>                           
                              </div>
                              </div>
                              </div>
                          
                              <div class="col-md-2">
                              <div class="form-group labelgrp">
                             <?php echo e(Form::label('male_female', 'Male/Female')); ?> 
                              </div>
                              </div>

                              <div class="col-md-4">
                              
                               <?php echo e(Form::select('male_female', ['Male','Female'], Request::old('male_female'), array('class' => 'form-control select2'))); ?>                         
                              
                              </div> 
                            </div> 
                            
                             <div class="col-md-12">
                               <div class="col-md-2">
                              <div class="form-group labelgrp">
                               <?php echo e(Form::label('patient_age', 'Patient age')); ?>

                              </div>
                              </div>

                              <div class="col-md-4">
                              <div class="form-group">
                              <div class="form-line">
                              <?php echo e(Form::number('patient_age', Request::old('patient_age'), array('class'=> 'form-control'))); ?>                          
                              </div>
                              </div>
                              </div>

                              <div class="col-md-2">
                              <div class="form-group labelgrp">
                               <?php echo e(Form::label('patient_height', 'Height')); ?> 
                              </div>
                              </div>


                              <div class="col-md-4">
                              <div class="form-group">
                              <div class="form-line">
                              <?php echo e(Form::text('patient_height', Request::old('patient_height'), array('class'=> 'form-control'))); ?>                          
                              </div>
                              </div>
                              </div>
                          </div> 

                          <div class="col-md-12">
                               <div class="col-md-2">
                              <div class="form-group labelgrp">
                               <?php echo e(Form::label('patient_weight', 'Weight')); ?> 
                              </div>
                              </div>

                              <div class="col-md-4">
                              <div class="form-group">
                              <div class="form-line">
                              <?php echo e(Form::text('patient_weight', Request::old('patient_weight'), array('class'=> 'form-control'))); ?>                         
                              </div>
                              </div>
                              </div>

                          </div> 

                         

<!---------------tabs---------------------------->
                    <div class="col-md-12" id="TabContainerDiv">
                        <ul class="nav nav-tabs tab-col-pink" role="tablist" id="Tabseyehistory">
                            <li role="presentation" class="active">
                                <a href="#Complaints" data-toggle="tab">Complaint</a>
                            </li>
                            <li role="presentation">
                                <a href="#Diagnosis" data-toggle="tab">Diagnosis</a>
                            </li>
                            <li role="presentation">
                                <a href="#Treatment" data-toggle="tab">Treatment</a>
                            </li>
                        </ul>

                        <div class="tab-content clearfix">
                    
                    <div class="tab-pane active" id="Complaints">
                        <div class="col-sm-4">
                            <b><u>memorized items</u></b>
                            <div style="max-height:200px; overflow:auto;">
                                <ul  class="list-group">
                                    <?php echo e($eyeMemory['id'] = '', $eyeMemory['name'] = ''); ?>

                                    <?php $__empty_1 = true; $__currentLoopData = $casedata['field_type_memory']->where('field_type_id', '1'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Memory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <li class="list-group-item clearfix"><a class="memoryList" data-id="<?php echo e($Memory['id']); ?>" href=""> <?php echo e($Memory['title']); ?> </a>
                                            
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <li  class="list-group-item"> No Data found </li>
                                    <?php endif; ?>
                                </ul>
                            </div>
                        </div>
                        <div class="col-sm-4 col-sm-push-4">
                            <?php echo e(Form::label('complaint', 'Complaint')); ?> 
                            <?php echo e(Form::text('complaint', Request::old('complaint'), array('class'=> 'form-control'))); ?>

                            <br/><br/>
                            <div class="">
                                <button type="submit" name="Add_complaint" class="btn btn-defaul" value="Add_complaint" >
                                    <i class="fa fa-plus"></i> Add
                                </button>
                            </div>
                            <br/><br/>
                            
                                <div style="max-height:200px; overflow:auto;">
                                    <ul  class="list-group">
                                        <?php $__empty_1 = true; $__currentLoopData = $casedata['field_type_data']->where('field_type_id', '1'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fieldData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <li class="list-group-item clearfix"><?php echo e($fieldData['field_data']); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <li  class="list-group-item"> No Data found </li>
                                        <?php endif; ?>
                                    </ul>
                                </div>
                                
                        </div>
                    </div>
                    <div class="tab-pane" id="Diagnosis">
                        <div class="col-sm-4">
                            <b><u>memorized items</u></b>
                            <div style="max-height:200px; overflow:auto;">
                                <ul  class="list-group">
                                    <?php echo e($eyeMemory['id'] = '', $eyeMemory['name'] = ''); ?>

                                    <?php $__empty_1 = true; $__currentLoopData = $casedata['field_type_memory']->where('field_type_id', '2'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Memory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <li class="list-group-item clearfix"><a class="memoryList" data-id="<?php echo e($Memory['id']); ?>" href=""> <?php echo e($Memory['title']); ?> </a>
                                            
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <li  class="list-group-item"> No Data found </li>
                                    <?php endif; ?>
                                </ul>
                            </div>
                        </div>  
                        <div class="col-sm-4 col-sm-push-4">
                            <?php echo e(Form::label('Diagnosis', 'Diagnosis')); ?> 
                            <?php echo e(Form::text('Diagnosis', Request::old('Diagnosis'), array('class'=> 'form-control'))); ?>

                            <br/><br/>
                            <div class="">
                                <button type="submit" name="Add_Diagnosis" class="btn btn-defaul" value="Add_Diagnosis" >
                                    <i class="fa fa-plus"></i> Add
                                </button>
                            </div>
                            <br/><br/>
                            
                                <div style="max-height:200px; overflow:auto;">
                                    <ul  class="list-group">
                                        <?php $__empty_1 = true; $__currentLoopData = $casedata['field_type_data']->where('field_type_id', '2'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fieldData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <li class="list-group-item clearfix"><?php echo e($fieldData['field_data']); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <li  class="list-group-item"> No Data found </li>
                                        <?php endif; ?>
                                    </ul>
                                </div>
                                    
                        </div>                                              
                    </div>
                    <div class="tab-pane" id="Treatment">
                        <div class="col-sm-4">
                            <b><u>memorized items</u></b>
                            <div style="max-height:200px; overflow:auto;">
                                <ul  class="list-group">
                                    <?php echo e($eyeMemory['id'] = '', $eyeMemory['name'] = ''); ?>

                                    <?php $__empty_1 = true; $__currentLoopData = $casedata['field_type_memory']->where('field_type_id', '3'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Memory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <li class="list-group-item clearfix"><a class="memoryList" data-id="<?php echo e($Memory['id']); ?>" href=""> <?php echo e($Memory['title']); ?> </a>
                                            
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <li  class="list-group-item"> No Data found </li>
                                    <?php endif; ?>
                                </ul>
                            </div>
                        </div>  
                        <div class="col-sm-4 col-sm-push-4">
                            <?php echo e(Form::label('Treatment', 'Treatment')); ?> 
                            <?php echo e(Form::text('Treatment', Request::old('Treatment'), array('class'=> 'form-control'))); ?>

                            <br/><br/>
                            <div class="">
                                <button type="submit" name="Add_Treatment" class="btn btn-defaul" value="Add_Treatment" >
                                    <i class="fa fa-plus"></i> Add
                                </button>
                            </div>
                            <br/><br/>
                            
                                <div style="max-height:200px; overflow:auto;">    
                                    <ul  class="list-group">
                                        <?php $__empty_1 = true; $__currentLoopData = $casedata['field_type_data']->where('field_type_id', '3'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fieldData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <li class="list-group-item clearfix"><?php echo e($fieldData['field_data']); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <li  class="list-group-item"> No Data found </li>
                                        <?php endif; ?>
                                    </ul>
                                </div>
                                    
                        </div>                                                
                    </div>
                        <div class="col-sm-4 col-sm-pull-4 tab">
                           
                                <?php echo e(Form::label('title', 'Title')); ?> 
                                <div class="form-line">
                                  <?php echo e(Form::text('title', '', array('class'=> 'form-control'))); ?>

                                </div>
                                
                            
                            <br>
                            <div class="form-group">
                                <?php echo e(Form::label('memory_data', 'Data')); ?> 
                                <?php echo e(Form::text('memory_data', '', array('class'=> 'form-control '))); ?>

                            </div>
                                <?php echo e(Form::hidden('field_type_id', Request::old('field_type_id','#Complaints'), array('class'=> 'form-control', 'id'=>'field_type_id'))); ?>

                                <?php echo e(Form::hidden('memory_id', '', array('class'=> 'form-control', 'id'=>'memory_id'))); ?>

                            <button type="submit" name="drAddToMemory" class="btn-link" value="drAddToMemory" >
                                <i class="fa fa-plus"></i> Add To Memory
                            </button>
                            <button type="submit" name="mem_delete" value="mem_delete" id="mem_delete" class="btn-link hidden"><i class="fa fa-minus"></i> Remove From Memory</button>
                        </div>
                    </div>
                    </div>
<!---------------tabs---------------------------->  
<!---------------follow-up-date---------------------->   

                    <div class="col-md-12">
                        <h3><u>Follow up date.</u><h3>
                    </div>    
                    <div class="col-md-12">
                            <div class="col-md-2">
                            <div class="form-group labelgrp">
                            <?php echo e(Form::label('FollowUpDoctor_id','Doctor')); ?>

                            </div>
                            </div>
                               
                            <div class="col-md-4 ">
                            <div class="form-group">
                           
                            <?php echo e(Form::select('FollowUpDoctor_id',array(''=>'Please select') + $casedata['doctorlist']->toArray(),Request::old('FollowUpDoctor_id'), array('class' => 'form-control select2','data-live-search'=>'true'))); ?>                   
                           
                            </div>
                            </div>
                             
                            <div class="col-md-2">
                             <div class="form-group labelgrp">
                              <?php echo e(Form::label('appointment_dt','Date')); ?>

                             </div>
                             </div>
                             <div class="col-md-4">
                           
                              <input type="text" name="appointment_dt" class="form-control datepicker" id="appointment_dt">
                             </div>     
                         </div>
                        
                         <div class="col-md-12">
                            <div class="col-md-2">
                            <div class="form-group labelgrp">
                            <label>Time Slot</label>
                            </div>
                            </div>
                              
                            <div class="col-md-4">
                            <div class="form-group">
                            
                            <select class="form-control select2" id="FollowUpTimeSlot" name="FollowUpTimeSlot" data-live-search="true"></select>
                            
                            </div>
                            </div> 

                            <div class="col-md-2">
                            <div class="form-group labelgrp">
                            <?php echo e(Form::label('Before_file', 'Before image')); ?>

                            </div>
                            </div>
                            
                            <div class="col-md-4">
                            <div class="form-group">
                            <?php echo e(Form::file('Before_file', Request::old('Before_file'), array('class'=> 'form-control'))); ?>

                            <?php if(isset($casedata['Before_file']) && $casedata['Before_file'] != null): ?>
                            <a href="<?php echo e(Storage::disk('local')->url($casedata['Before_file'])); ?>" class="" target="_blank"> Before Image link</a>              
                            <?php endif; ?>                                                   
                            </div>
                            </div> 
                        </div>

                         <div class="col-md-12">
                           

                            <div class="col-md-2">
                            <div class="form-group labelgrp">
                            <?php echo e(Form::label('After_file', 'After image')); ?> 
                            </div>
                            </div>
                              
                            <div class="col-md-4">
                            <div class="form-group">
                              <?php echo e(Form::file('After_file', Request::old('After_file'), array('class'=> 'form-control'))); ?>

                              <?php if(isset($casedata['After_file']) && $casedata['After_file'] != null): ?>
                                  <a href="<?php echo e(Storage::disk('local')->url($casedata['After_file'])); ?>" class="" target="_blank"> After Image link</a>              
                              <?php endif; ?>                                                   
                            </div>
                            </div> 
                        </div>
              
                         <div class="col-md-12">
                              <div class="col-md-2">
                              <div class="form-group labelgrp">
                              <?php echo e(Form::label('sendemail','Send Email')); ?>

                              </div>
                              </div>


                              <div class="col-md-6">
                              <div class="form-group">
                              <div class="form-line">
                              <?php echo e(Form::text('Email_To', null, array('class'
                                => 'form-control', 'autocomplete'=>'off'))); ?>                              
                              </div> 
                              </div>
                              </div>
                              <div class="col-md-4">
                          
                            <button type="submit" formaction="<?php echo e(url('Send_email')); ?>" name="Send_email" class="btn btn-success " value="Send_email">Email</button>&nbsp;
                              </div>
                              </div>
 <!---------------follow-up-date---------------------->       

                           
                            <div class="row clearfix">
                            <div class="col-md-8 col-md-offset-3">
                            <div class="form-group">
                            <button type="submit" name="submit" class="btn btn-success btn-lg" value="submit" >
                            <i class="fa fa-plus"></i> Submit
                            </button>
                                <a class="btn btn-default btn-lg" href="<?php echo e(url('/case_masters')); ?>"><i class="glyphicon glyphicon-chevron-left"></i> Back</a>
                                <?php if( isset($casedata['id'])): ?>
                                <a class="btn btn-default btn-lg" href="<?php echo e(url('/case_masters/print/').'/'.$casedata['id']); ?>" target="_blank"><i class="glyphicon glyphicon-chevron-left"></i>Print</a>
                                <?php endif; ?>
                
                 <button type="submit" name="Submit_email" formaction="<?php echo e(url('Send_email')); ?>" class="btn btn-primary btn-lg" value="Submit_email"><i class="fa fa-plus"></i> Submit & Email
                                  </button>&nbsp;
                                </div>
                                </div>
                               
                            </div>

                            
                        </div>
                        <?php echo e(Form::close()); ?>

                    </div>
                </div>
            </div>


</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
 <script src="<?php echo e(url('/')); ?>/select2/js/select2.min.js"></script>
   <script type="text/javascript">
     $(document).ready(function() {
     });
     $(".select2").select2();
   </script>


    <script type="text/javascript">
    
    $(document).ready(function(){
   
        
        $("#Tabseyehistory a[href='"+$("#field_type_id").val()+"']").tab('show');
        $('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
            var target = $(e.target).attr("href");
            $("#field_type_id").val(target);
            $("#memory_id").val('');
        });
        $("#TabContainerDiv a.memoryList").on('click',function(e){
            e.preventDefault();
            $("#memory_id").val($(this).data('id'));
            $("button[name='mem_delete']").addClass('hidden');
            $.get('/getMemoryDetials/'+$(this).data('id'),function(data){
                 $("input[name='title']").val(data.title);
                 $("input[name='memory_data']").val(data.data);
                 if(data.field_type_id = "1"){
                    $("input[name='complaint']").val(data.data);
                 }
                 if(data.field_type_id = "2"){
                    $("input[name='Diagnosis']").val(data.data);
                 }
                 if(data.field_type_id = "3"){
                    $("input[name='Treatment']").val(data.data);
                 }
                 $("button[name='mem_delete']").removeClass('hidden');
            });
           
        });


        $("#appointment_dt").on('change.dp', function (e) {
        $("#FollowUpTimeSlot").empty();
        //alert(this.value);         //Date in full format alert(new Date(this.value));
        var inputDate = new Date(this.value);
        var FollowUpDoctor_id = $("#FollowUpDoctor_id").val();
       

        var appointment_dt = $('#appointment_dt').val();
    
       
        
        var url1="<?php echo e(url('avaibaletimeslotscasemaster')); ?>/"+FollowUpDoctor_id+'/'+appointment_dt;
    //alert(url1);

        $.ajax({
            url:url1,
           
            type:'GET',
            success:function(response) {
        //alert(response);
             if(response==0)
                  {
                    $("#FollowUpTimeSlot").append('<option value=" ">No Slots Available</option>');
                    $("#FollowUpTimeSlot").selectpicker("refresh");
                 }

                    else
                 {
                 
                        for(var i=0;i<response['timeslot1'].length;i++){
                  
                     var starttime= response['timeslot1'][i];
                    
                  
                     var toAppend = '<option value="'+starttime+'">'+starttime+'</option>';
                      $('#FollowUpTimeSlot').append(toAppend);
                      $("#FollowUpTimeSlot").selectpicker("refresh");
                  
                  
               

                
               
            }
   

                 }
              }
        }); 



    });
    });
</script>

<!-- jQuery Easing -->


<?php $__env->stopSection(); ?>



<?php echo $__env->make('adminlayouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>