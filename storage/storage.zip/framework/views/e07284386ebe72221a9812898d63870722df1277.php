<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link href="<?php echo e(asset('css/bootstrap.css')); ?>" rel="stylesheet">
    <style>
 /* Print styling */

@media  print {

[class*="col-sm-"] {
  float: left;
}

[class*="col-xs-"] {
  float: left;
}

.col-sm-12, .col-xs-12 {
  width:100% !important;
}

.col-sm-11, .col-xs-11 {
  width:91.66666667% !important;
}

.col-sm-10, .col-xs-10 {
  width:83.33333333% !important;
}

.col-sm-9, .col-xs-9 {
  width:75% !important;
}

.col-sm-8, .col-xs-8 {
  width:66.66666667% !important;
}

.col-sm-7, .col-xs-7 {
  width:58.33333333% !important;
}

.col-sm-6, .col-xs-6 {
  width:50% !important;
}

.col-sm-5, .col-xs-5 {
  width:41.66666667% !important;
}

.col-sm-4, .col-xs-4 {
  width:33.33333333% !important;
}

.col-sm-3, .col-xs-3 {
  width:25% !important;
}

.col-sm-2, .col-xs-2 {
  width:16.66666667% !important;
}

.col-sm-1, .col-xs-1 {
  width:8.33333333% !important;
}
.col-md-offset-3
{
    margin-left: 38% !important;
}

.col-sm-1,
.col-sm-2,
.col-sm-3,
.col-sm-4,
.col-sm-5,
.col-sm-6,
.col-sm-7,
.col-sm-8,
.col-sm-9,
.col-sm-10,
.col-sm-11,
.col-sm-12,
.col-xs-1,
.col-xs-2,
.col-xs-3,
.col-xs-4,
.col-xs-5,
.col-xs-6,
.col-xs-7,
.col-xs-8,
.col-xs-9,
.col-xs-10,
.col-xs-11,
.col-xs-12 {
float: left !important;
}

body {
  margin: 0;
  padding: 0 !important;
  min-width: 768px;
}

.container {
  width: auto;
  min-width: 750px;
}

body {
  font-size: 10px;
}

a[href]:after {
  content: none;
}

.noprint,
div.alert,
header,
.group-media,
.btn,
.footer,
form,
#comments,
.nav,
ul.links.list-inline,
ul.action-links {
  display:none !important;
}
}
    </style>
</head>
<body>
 <div class="container-fluid">    
    
    <div class="row">
        <div class="col-lg-12">
            <img src=<?php echo e(Storage::disk('local')->url($logoUrl)); ?> class="img-rounded" alt="letter head top" width="100%" height="150" />
        </div>
        <div class="col-lg-12">&nbsp;</div>
    </div>
    <br/>
    <br/>
    <br/>
     
    <div class="container" style="border: 2px solid black;border-radius: 15px;">
    <div class="row">
       <div class="col-sm-8 col-md-offset-3">
            <label for="case_number" class="control-label">FINAL BILL CUM RECIEPT</label>   
        </div> 
    </div>
    <br>
      <div class="row">
        <div class="col-sm-6">
            <label for="IPD No." class="control-label">IPD No. :</label> 
            <?php echo e($insurance_bill->ipd_no); ?>

        </div>
        <div class="col-sm-6">
            <label for="IPD No." class="control-label">Bill No. :</label> 
            <?php echo e($insurance_bill->bill_no); ?>

        </div>
     
    </div>  
    <div class="row">
        <div class="col-sm-6">
            <label for="IPD No." class="control-label">UHID No. :</label> 
            <?php echo e($insurance_bill->uhid_no); ?>

        </div>
        <div class="col-sm-6">
            <label for="IPD No." class="control-label">Bill Date. :</label> 
            <?php echo e($insurance_bill->bill_date); ?>

        </div>  
    </div> 
    <div class="row">
        <div class="col-sm-6">
            <label for="IPD No." class="control-label">Patient Name :</label> 
          <?php echo e($case_master['patient_name']); ?> 
        </div>
        <div class="col-sm-6">
            <label for="IPD No." class="control-label">Admission Date & Time :</label> 
            <?php echo e($insurance_bill->admission_date_time); ?>

        </div>  
    </div> 
    <div class="row">
        <div class="col-sm-6">
            <label for="IPD No." class="control-label">Class :</label> 
            <?php echo e($insurance_bill->classes); ?>

        </div>
        <div class="col-sm-6">
            <label for="IPD No." class="control-label">Discharge Date & Time :</label> 
            <?php echo e($insurance_bill->discharge_date_time); ?>

        </div>  
    </div> 
    <div class="row">
        <div class="col-sm-6">
            <label for="IPD No." class="control-label">Doctor-In-Charge :</label> 
           <?php echo e($insurance_bill->surgon_name); ?> 
        </div>
        <div class="col-sm-6">
            <label for="IPD No." class="control-label">Referred By :</label> 
            <?php echo e($insurance_bill->referedby); ?>

        </div>  
    </div> 
    <div class="row">
        <div class="col-sm-6">
            <label for="IPD No." class="control-label">Age/Gender :</label> 
            <?php echo e($case_master['patient_age']); ?>&nbsp;/&nbsp;<?php echo e($case_master['male_female']); ?>

        </div>
        <div class="col-sm-6">
            <label for="IPD No." class="control-label">Discharge Status :</label> 
            <?php echo e($insurance_bill->discharge_sts); ?>

        </div>  
    </div> 
    <div class="row">
        <div class="col-sm-6">
            <label for="IPD No." class="control-label">Final Diagnosis :</label> 
            <?php echo e($insurance_bill->final_diagnosis); ?>

        </div>
         
    </div> 
    </div>
    <br>
    <div class="container">
         <div class="row">
            <div class="col-md-12">
                <div class="table-responsive">
                            <table class="table table-condensed">
                                <thead style="border-bottom: 2px solid black;border-top: 2px solid;">
                                <tr>
                                    <td >
                                        <strong>Sr no.</strong>
                                    </td>
                                    
                                    <td >
                                        <strong>Bill Item</strong>
                                    </td>
                                  
                                    <td  class="text-right"><strong>Totals</strong></td>                           
                                    
                                </tr>
                                </thead>
                                <?php if(!empty($billdata) && count($billdata) > 0 ): ?>
                                    <?php $cntInt = 1 ?>
                                    <?php $__currentLoopData = $billdata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bdata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                        <tr>
                                            <td >
                                                <?php echo e($cntInt++); ?>

                                            </td>
                                       
                                            <td> <?php echo e($bdata->bill_item); ?> </td>
                                        
                                            <td class="text-right"> <?php echo e($bdata->bill_Amount); ?> </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                         <tr>
                                            <td  class="thick-line" >
                                            
                                            </td>
                                           
                                            <td class="thick-line text-right"> <label for="bill_Amount" class="control-label">sub Total</label>  </td>
                                            
                                            <td class="thick-line text-right"> 
                                                <?php 
                                                    $itemsum = 0; 
                                                    $itemsum = $billdata->sum('bill_Amount');
                                                    $itemsum = floatval($itemsum);
                                                ?>
                                                <?php echo e(number_format((float)$itemsum, 2, '.', '')); ?>

                                                  <?php
                                                    
                                                    $billamount = (isset($itemsum) && $itemsum > 0) ? ($itemsum += ($itemsum*(floatval($case_master['tax_percentage'])/100))) : $itemsum;
    
                                                    $billamount = (isset($itemsum) && $itemsum > 0) ? floatval($itemsum - floatval($case_master['paidAmount'])) : 0;
                                                    $billamount = number_format((float)$billamount, 2, '.', '');
													$billamountInWords = "";
													/*
                                                    $f = new \NumberFormatter("en", \NumberFormatter::SPELLOUT);
                                                    $exp = explode('.', $billamount);
                                                    if(sizeof($exp)>1){
    
                                                    }
                                                    $billamountInWords = ucfirst($f->format($exp[0])) . ((sizeof($exp)>1)? (' and ' . ucfirst($f->format($exp[1]))) : '') . ' only.';
													*/

                                                    /* $billamount = $billamount > 0 ? ($billamount += ($billamount*(floatval($case_master['tax_percentage'])/100))) : $billamount; */
                                                ?>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td  class="no-line" >
                                            
                                            </td>
                                      
                                            <td  class="no-line text-right"><label class="control-label">Advance Details</label></td>
                                            <td  class="no-line text-right"> <?php echo e($insurance_bill->advance_amount); ?></td>
                                        </tr>
                                        <tr>
                                            <td  class="no-line" >
                                            
                                            </td>
                                      
                                            <td  class="no-line text-right"><label class="control-label">Discount Details</label></td>
                                            <td  class="no-line text-right"> <?php echo e($insurance_bill->discount_amount); ?></td>
                                        </tr>
                                        <tr>
                                            <td  class="no-line" >
                                            
                                            </td>
                                      
                                            <td  class="no-line text-right"><label class="control-label">Tax %</label></td>
                                            <td  class="no-line text-right"> <?php echo e($case_master['tax_percentage']); ?></td>
                                        </tr>
                                        <tr>
                                            <td  class="no-line" >
                                            
                                            </td>
                                            
                                            <td  class="no-line text-right"><label class="control-label">Paid Amount</label> </td>
                                            <td  class="no-line text-right"> <?php echo e($case_master['paidAmount']); ?> </td>
                                        </tr>
                                        <tr>
                                            <td  class="no-line" >
                                            
                                            </td>
                                          
                                            <td  class="no-line text-right"><label class="control-label">Total Amount</label></td>
                                             <?php 
                                                $itemsum = $itemsum - $insurance_bill->advance_amount - $insurance_bill->discount_amount;
                                             ?>
                                            <td  class="no-line  text-right"> <?php echo e(number_format((float)$itemsum, 2, '.', '')); ?> </td>
                                        </tr>
                                        <tr>
                                            <td class="no-line text-right" colspan="5"><?php echo e($billamountInWords); ?></td>
                                        </tr>
                                <?php endif; ?>
                            </table>
                        </div>
            </div>
        </div>

		<?php if(!empty($payment_details) && count($payment_details) > 0 ): ?>

			<div class="row">
				<div class="col-md-12">
					<div class="panel panel-default">
						<div class="panel-body">
							<div class="table-responsive">
								<table class="table table-condensed">
									<thead>
									<tr>
										<td >
											<strong>Sr no.</strong>
										</td>
									   
										<td >
											<strong>Payment Date</strong>
										</td>
										<td >
											<strong>Payment Mode</strong>
										</td>
										<td class="text-right">
										   Payment Amount
										</td>
									</tr>
									</thead>
									
										<?php $cntInt = 1 ?>
										<?php $__currentLoopData = $payment_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment_details_row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
											<tr>
												<td >
													<?php echo e($cntInt++); ?>

												</td>
												
												<td> <?php echo e(date('d F, Y', strtotime($payment_details_row->payment_date))); ?> </td>
												<td> <?php echo e($payment_modes_array[$payment_details_row->payment_mode]); ?>    </td>
												
												<td class="text-right"> <?php echo e($payment_details_row->paid_amount); ?>   </td>
											</tr>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											 <tr>
												
												<td class="thick-line" >&nbsp;</td>
												<td class="thick-line" >&nbsp;</td>
												<td class="thick-line text-right"> <label for="bill_Amount" class="control-label">Total Paid</label>  </td>
												
												<td class="thick-line text-right"> 
												   Rs. <?php echo e($total_paid); ?>    
												</td>
											</tr>
											
											<tr>
												
												<td  class="no-line">&nbsp;</td>
												<td  class="no-line">&nbsp;</td>
												<td  class="no-line text-right"><label class="control-label">Balance</label></td>
												<td  class="no-line  text-right"> Rs. <?php echo e(round(($itemsum - $total_paid), 2)); ?>    </td>
											   
											</tr>
								</table>
							</div>
						</div>
					</div>
				</div>
			</div>

			<?php endif; ?>
    </div>


	
   

    <br/>
    <br/>
    <br/>
    <br/>
    
    <div class="form-group">
        <div class="col-md-6">
            _______________________
        </div>
        <div class="col-md-6 pull-right">
            _______________________
        </div>
        <div class="col-md-6">
            Signature
        </div>
        <div class="col-md-6 pull-right">
            Signature
        </div>
        <div class="col-md-6">
            <?php echo e($case_master['patient_name']); ?>

        </div>
        <div class="col-md-6 pull-right">
            <?php echo e(config('app.name', 'Dr')); ?>

        </div>
    </div>



    <!-- jQuery -->
    <script src="<?php echo e(asset('js/jquery.min.js')); ?> "></script>
        <!-- Bootstrap -->
    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
    <script type="text/javascript">
        $(document).ready(function(){
           // setTimeout(function () { window.print(); }, 500);
           // window.onfocus = function () { setTimeout(function () { window.close(); }, 50); }
        });
    </script>

</body>
</html>