<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use App\Menu_list;
use App\dynamic_text;
use App\Image_gallery;
use Storage;
use HTML;
use App\helperClass\drAppHelper;
use App\quantity_dropdown;
use App\strength_dropdown;
use App\number_of_times_dropdown;
use App\Models\IPD\patientRegister;
use App\Models\IPD\ipd_prescription;
use App\Models\form_dropdowns;
use App\Setting;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        //
        view()->composer(array('shared.layoutProspera','shared.layoutCaremed'), function($view)
        {
            
            $all_settings = Setting::all()->keyBy('name');
            
            $menulst = Menu_list::where('isActive', 1)->orderBy('orderNo')->get();
            
            $menulst = Menu_list::where('isActive', 1)->orderBy('orderNo')->get();
            $footerText = dynamic_text::where('isActive', 1)->where('textType',5)->first();
            $footerText->html_text = isset($footerText->html_text)?HTML::decode($footerText->html_text) : '';
            //$imageGallery = Image_gallery::where('isActive', 1)->get();
            $bodyOne = dynamic_text::where('textType', 3)->first();
            $siteLogo = Image_gallery::where('isActive', 1)->where('imgTypeId',2)->first();
            $siteLogo = (empty($siteLogo) || !isset($siteLogo->imgUrl)) ? config('app.name', 'Dr App') : Storage::disk('local')->url($siteLogo->imgUrl);
            $view->with('menulst', $menulst)->with('siteLogo',$siteLogo)->with('footerText', $footerText)->with('bodyOne', $bodyOne)->with('all_settings', $all_settings);//->with('title',$title);
        });

        view()->composer('shared.add_prescription' ,function($view)
        {
            $id = $view->getData()['id'];
            $drAppHelper = new drAppHelper;
            $getdata = $drAppHelper->getCaseData($id);
            $presDropdowns = [
            'numberOfTimes_drpdwn' => form_dropdowns::where('formName', 'Prescription')->where('fieldName', 'Times a day')->pluck('ddText','ddText'),
            'quantity'=>form_dropdowns::where('formName', 'Prescription')->where('fieldName', 'Quantity')->pluck('ddText','ddText'),
            'medicine_strength'=>form_dropdowns::where('formName', 'Prescription')->where('fieldName', 'Strength')->pluck('ddText','ddText'),
            'medicinlist' => \App\Medical_store::where('isactive', 1)->where('balance_quantity', '>', 0)->orderBy('created_dt', 'desc')->get()
            ];
            $mergeArray = array_merge($getdata, $presDropdowns);
            $view->with('casedata', $mergeArray);
        });
        
        view()->composer('ipd_discharge.prescription_add' ,function($view)
        {
            $id = $view->getData()['id'];
            $drAppHelper = new drAppHelper;
            $patientRegister = patientRegister::firstOrNew(['id'=>$id]);
            $prescriptionList = $patientRegister->ipd_prescription()->get();
            $presDropdowns = [
            'numberOfTimes_drpdwn' => form_dropdowns::where('formName', 'Prescription')->where('fieldName', 'Times a day')->pluck('ddText','ddText'),
            'quantity'=>form_dropdowns::where('formName', 'Prescription')->where('fieldName', 'Quantity')->pluck('ddText','ddText'),
            'medicine_strength'=>form_dropdowns::where('formName', 'Prescription')->where('fieldName', 'Strength')->pluck('ddText','ddText'),
            'medicinlist' => \App\Medical_store::where('isactive', 1)->where('balance_quantity', '>', 0)->orderBy('created_dt', 'desc')->get()
            ];
            $mergeArray = compact('patientRegister', 'presDropdowns', 'prescriptionList');
            //dump($mergeArray);
            $view->with(compact('patientRegister', 'presDropdowns', 'prescriptionList'));
        });
        
        view()->composer('ipd_dailyTreatment.DailyNotes' ,function($view)
        {
            $id = $view->getData()['id'];
            $patientRegister  = patientRegister::firstOrNew(['id'=>$id]);
            $view->with('patientRegister', $patientRegister);
        });
    }

    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //
    }
}
