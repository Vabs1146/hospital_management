<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class paymentfor extends Model
{
    protected $table = 'paymentfor';
    public $timestamps = true;    //
  
}