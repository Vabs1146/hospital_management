<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class field_type_data extends Model
{
    //
    protected $table = 'field_type_data';
    public $timestamps = true;
}
