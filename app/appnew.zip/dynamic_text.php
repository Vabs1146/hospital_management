<?php


namespace App;

use Illuminate\Database\Eloquent\Model;

class dynamic_text extends Model
{
    //
    protected $table = 'dynamic_text';

}
