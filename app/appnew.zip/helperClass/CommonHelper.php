<?php 
namespace App\helperClass;

use DB;
use Auth;

class CommonHelper{

    public function checkUserAccess($section, $userId, $permission_type = "listing_permission"){
        $access = 0;
        //$accesslevel = DB::select("SELECT useraccess.accesslevel FROM `useraccess` INNER JOIN section ON useraccess.sectionid=section.sectionid JOIN users ON useraccess.userid=users.id WHERE users.id='$userId' AND section.sectionname='$section'");
        /*
        $accesslevel = DB::select("SELECT useraccess.accesslevel FROM `useraccess` INNER JOIN section ON useraccess.sectionid=section.sectionid JOIN users ON useraccess.userid=users.id WHERE users.id='$userId' AND section.sectionname='$section'");
        
        if(!empty($accesslevel)){
            foreach ($accesslevel as $value) {
                $access = $value->accesslevel;
            }
        }
        //return $access;
        */
        
        //echo "SELECT user_permission.* FROM `user_permission` LEFT JOIN menu_section ON menu_section.sectionid=user_permission.section_id  WHERE user_permission.user_id='$userId' AND menu_section.sectionname='$section'"; //exit;
        
        $accesslevel = DB::select("SELECT user_permission.* FROM `user_permission` LEFT JOIN menu_section ON menu_section.sectionid=user_permission.section_id  WHERE user_permission.user_id='$userId' AND menu_section.sectionname='$section'");
        
       // dd($accesslevel);
        if(!empty($accesslevel) && isset($accesslevel[0]->{$permission_type}) && $accesslevel[0]->{$permission_type} == '1'){
            $access = 1;
        } else {
            
        }
        
        if(AUTH::user()->role == 1) {
            $access = 1;
        }
        //echo "=====".$accesslevel[0]->{$permission_type}."======= : ".$access; exit;
        return $access;
    }

	function displaywords($number) {
    $no = round($number);
    $decimal = round($number - ($no = floor($number)), 2) * 100;    
    $digits_length = strlen($no);    
    $i = 0;
    $str = array();
    $words = array(
        0 => '',
        1 => 'One',
        2 => 'Two',
        3 => 'Three',
        4 => 'Four',
        5 => 'Five',
        6 => 'Six',
        7 => 'Seven',
        8 => 'Eight',
        9 => 'Nine',
        10 => 'Ten',
        11 => 'Eleven',
        12 => 'Twelve',
        13 => 'Thirteen',
        14 => 'Fourteen',
        15 => 'Fifteen',
        16 => 'Sixteen',
        17 => 'Seventeen',
        18 => 'Eighteen',
        19 => 'Nineteen',
        20 => 'Twenty',
        30 => 'Thirty',
        40 => 'Forty',
        50 => 'Fifty',
        60 => 'Sixty',
        70 => 'Seventy',
        80 => 'Eighty',
        90 => 'Ninety');
    $digits = array('', 'Hundred', 'Thousand', 'Lakh', 'Crore');
    while ($i < $digits_length) {
        $divider = ($i == 2) ? 10 : 100;
        $number = floor($no % $divider);
        $no = floor($no / $divider);
        $i += $divider == 10 ? 1 : 2;
        if ($number) {
            $plural = (($counter = count($str)) && $number > 9) ? 's' : null;            
            $str [] = ($number < 21) ? $words[$number] . ' ' . $digits[$counter] . $plural : $words[floor($number / 10) * 10] . ' ' . $words[$number % 10] . ' ' . $digits[$counter] . $plural;
        } else {
            $str [] = null;
        }  
    }
    
    $Rupees = implode(' ', array_reverse($str));
    $paise = ($decimal) ? "And Paise " . ($words[$decimal - $decimal%10]) ." " .($words[$decimal%10])  : '';
    return ($Rupees ? 'Rupees ' . $Rupees : '') . $paise . " Only";
}

function get_patient_full_name($case_id) {
    $name = DB::select("SELECT CONCAT(`mr_mrs_ms`, ' ', `patient_name`, ' ', `middle_name`, ' ', `last_name`) name FROM case_master a WHERE a.id='".$case_id."'");
    
    return $name[0]->name;
}
}