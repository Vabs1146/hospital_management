<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class field_type_memory extends Model
{
    //
    protected $table = 'field_type_memory';
    public $timestamps = true;
}
