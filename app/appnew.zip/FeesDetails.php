<?php
namespace App;
use Illuminate\Database\Eloquent\Model;

class FeesDetails extends Model
{
    //
	protected $table = 'doctor_fees';
    protected $guarded = ['id'];
}
