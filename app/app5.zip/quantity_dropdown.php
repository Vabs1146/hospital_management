<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class quantity_dropdown extends Model
{
    protected $table = 'quantity_dropdown';
    public $timestamps = true;
}
