<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Image_gallery extends Model
{
    //
    protected $table = 'image_gallery';

}