<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class number_of_times_dropdown extends Model
{
    //
    protected $table = 'number_of_times_dropdown';
    public $timestamps = true;
}
