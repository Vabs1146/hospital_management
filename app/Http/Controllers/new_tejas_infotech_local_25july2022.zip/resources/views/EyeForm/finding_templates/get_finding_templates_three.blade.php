@include('EyeForm.steps.finding.vitreins')

@include('EyeForm.steps.finding.retina')

@include('EyeForm.steps.finding.onh')

@include('EyeForm.steps.finding.macula')

@include('EyeForm.steps.finding.sac')