 <div class="col-md-3">								
	<div class="input-group">
		<span class="input-group-addon">
		   Mr./Mrs./Ms. :
		</span>
		<select name="mr_mrs_ms" id="mr_mrs_ms" class="form-control select2" placeholder="">
		<option value=""></option> 
	   <option value="Mr.">Mr.</option> 
	   <option value="Mrs.">Mrs.</option> 
	   <option value="Ms.">Ms.</option> 
	</select>
	</div>
</div>

<div class="col-md-3">
	<div class="input-group">
		<span class="input-group-addon">
			First Name :
		</span>
		<div class="form-line">
			<input type="text" class="form-control" placeholder="" id="first_name" name="first_name">
		</div>
	</div>
</div>

<div class="col-md-3">
	<div class="input-group">
		<span class="input-group-addon">
			Middle Name :
		</span>
		<div class="form-line">
			<input type="text" class="form-control" placeholder="" id="middle_name" name="middle_name">
		</div>
	</div>
</div>

<div class="col-md-3">
	<div class="input-group">
		<span class="input-group-addon">
			Last Name :
		</span>
		<div class="form-line">
			<input type="text" class="form-control" placeholder="" id="last_name" name="last_name">
		</div>
	</div>
</div>