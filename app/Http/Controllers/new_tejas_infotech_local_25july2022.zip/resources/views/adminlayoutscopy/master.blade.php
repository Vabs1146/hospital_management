@include('adminlayouts.header')
@yield('content')