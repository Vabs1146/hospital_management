<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Stop_appointment extends Model
{
    //
    protected $table = 'appointment_stop';
    public $timestamps = false;

}