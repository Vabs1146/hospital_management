<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class NewHomePage extends Model
{
    //
    protected $table = 'homepage_data';

}