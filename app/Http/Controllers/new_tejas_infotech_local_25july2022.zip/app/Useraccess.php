<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Useraccess extends Model
{
   protected $table='useraccess';
}
