<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class case_number_generators extends Model
{
    //
    public $timestamps = false;
    protected $guarded = ['id'];
}
