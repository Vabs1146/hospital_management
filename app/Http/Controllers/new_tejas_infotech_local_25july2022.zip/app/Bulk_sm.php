<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Bulk_sm extends Model
{
    //
    protected $table = 'bulk_sms';
    public $timestamps = true;
}