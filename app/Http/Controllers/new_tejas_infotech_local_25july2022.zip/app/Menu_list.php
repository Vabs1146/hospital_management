<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Menu_list extends Model
{
    //
    protected $table = 'menu_list';

}