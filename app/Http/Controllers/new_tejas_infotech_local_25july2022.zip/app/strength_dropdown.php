<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class strength_dropdown extends Model
{
    //
    protected $table = 'strength_dropdown';
    public $timestamps = true;
}
