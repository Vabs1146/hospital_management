<?php
namespace App;
use Illuminate\Database\Eloquent\Model;

class Procedures extends Model
{
    //
    protected $guarded = ['id'];
}
