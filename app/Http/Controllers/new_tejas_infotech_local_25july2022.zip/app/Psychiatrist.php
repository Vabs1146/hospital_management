<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Psychiatrist extends Model {
    protected $table = 'psychiatrist_case_paper';
    public $timestamps = true;
}
