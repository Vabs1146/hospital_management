<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class doctor_form_mapping extends Model
{
    protected $table = 'doctor_form_mapping';
    public $timestamps = false;    //
}
