<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class NewEvents extends Model
{
    //
    protected $table = 'new_events';

}